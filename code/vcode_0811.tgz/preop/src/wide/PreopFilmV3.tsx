// «Подготовка к плановой операции» — вертикаль 9:16, версия 3.
// Сверху — живая 3D/2D-анимация оригинала БЕЗ надписей (кадрируется по artcam_<lang>.json),
// снизу — все надписи сцены крупными карточками (собираются из Chip/Card оригинала через VM.list),
// поэтому тексты и тайминг — те же, что прошли медпроверку, во всех языках.
import React from 'react';
import {AbsoluteFill, Audio, interpolate, Sequence, spring, staticFile, useCurrentFrame} from 'remotion';
import {T, setLang, isRTL, Lang} from './i18n';
import {Scene} from './preop_data';
import {Bg, clamp, ease, FONT, FPS, K, OUT_F, Outro, sceneFrames, scenesFor, Title, TitleL} from './PreopFilm';
import {ArtStage} from './PreopFilmV';
import {VM} from './motion/kit';
import {Icon} from './motion/kit2d';
import ART_RU from './artcam_ru.json';

const VW = 1080;
type R = [number, number, number, number];
type Phase = {t: number; p: R[]};
const PANEL_TOP = 380, PANEL_MAXH = 760, PANEL_W = 1000;
const SKIP_ART = ['S1', 'S6'];

/* ---------- заголовок ---------- */
const HeadV: React.FC<{s: Scene}> = ({s}) => {
  const f = useCurrentFrame();
  const p = spring({frame: f - 2, fps: FPS, config: {damping: 15}});
  const ul = interpolate(f, [16, 32], [0, 1], {...clamp, easing: ease});
  const i = s.title.indexOf(s.accent);
  const pre = i >= 0 ? s.title.slice(0, i) : s.title, acc = i >= 0 ? s.accent : '', post = i >= 0 ? s.title.slice(i + s.accent.length) : '';
  return (
    <div style={{position: 'absolute', left: 60, right: 60, top: 90, opacity: p, translate: `0 ${(1 - p) * 24}px`, direction: isRTL() ? 'rtl' : 'ltr'}}>
      <div style={{display: 'inline-flex', alignItems: 'center', gap: 14, padding: '10px 24px', borderRadius: 40, background: '#14213D0D',
        fontFamily: FONT, fontWeight: 600, fontSize: 30, color: K.sub, letterSpacing: 1}}>
        <span style={{color: K.coral, fontWeight: 800}}>{String(s.n).padStart(2, '0')}</span> {T('ПОДГОТОВКА К ОПЕРАЦИИ')}
      </div>
      <div style={{fontFamily: FONT, fontWeight: 800, fontSize: 74, color: K.ink, marginTop: 26, lineHeight: 1.14}}>
        {pre}
        <span style={{position: 'relative', color: K.coral}}>
          {acc}
          {acc ? (
            <svg viewBox="0 0 300 20" preserveAspectRatio="none" style={{position: 'absolute', left: -4, right: -4, bottom: -14, width: 'calc(100% + 8px)', height: 20}}>
              <path d="M4 12 C 60 4, 120 18, 180 9 S 270 6, 296 11" stroke={K.coral} strokeWidth={6} fill="none" strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - ul} />
            </svg>
          ) : null}
        </span>
        {post}
      </div>
    </div>
  );
};

/* ---------- окно с картинкой ---------- */
const fit = (r: R) => {
  const sc = Math.min(PANEL_W / r[2], PANEL_MAXH / r[3], 2.2);
  return {sc, w: r[2] * sc, h: r[3] * sc};
};
const ArtPanel: React.FC<{s: Scene; lang: Lang; r: R; o: number}> = ({s, lang, r, o}) => {
  const {sc, w, h} = fit(r);
  return (
    <div style={{position: 'absolute', left: (VW - w) / 2, top: PANEL_TOP, width: w, height: h, overflow: 'hidden', opacity: o,
      WebkitMaskImage: 'linear-gradient(to right, transparent 0, #000 26px, #000 calc(100% - 26px), transparent 100%), linear-gradient(to bottom, transparent 0, #000 22px, #000 calc(100% - 22px), transparent 100%)',
      WebkitMaskComposite: 'source-in', maskComposite: 'intersect'}}>
      <div style={{position: 'absolute', left: 0, top: 0, width: 1920, height: 1080, transformOrigin: '0 0', transform: `scale(${sc}) translate(${-r[0]}px, ${-r[1]}px)`}}>
        <ArtStage s={s} lang={lang} />
      </div>
    </div>
  );
};

/* ---------- карточки ---------- */
type Item = {kind: string; text: string; sub?: string; icon?: string; color?: string; at: number};
const lines = (s: string, perLine: number) => Math.max(1, Math.ceil(s.length / perLine));
const itemH = (it: Item) => (it.kind === 'card' ? 44 + lines(it.text, 30) * 54 + (it.sub ? lines(it.sub, 42) * 40 + 6 : 0) : 30 + lines(it.text, 34) * 50);

const ItemView: React.FC<{it: Item}> = ({it}) => {
  const f = useCurrentFrame();
  const p = spring({frame: f - Math.round(it.at * FPS), fps: FPS, config: {damping: 14}});
  const col = it.color && it.color !== K.ink ? it.color : K.ink;
  return (
    <div style={{display: 'flex', alignItems: 'center', gap: 22, background: '#fff', borderRadius: 28, padding: it.kind === 'card' ? '20px 26px' : '16px 26px',
      boxShadow: '0 14px 36px rgba(20,33,61,.10)', borderInlineStart: `10px solid ${it.kind === 'card' ? (it.color || K.ink) : col}`,
      opacity: Math.min(1, p * 1.3), transform: `translateY(${(1 - p) * 30}px)`}}>
      {it.kind === 'card' && it.icon ? <Icon name={it.icon} size={92} /> : it.icon ? (
        <span style={{width: 48, height: 48, borderRadius: 24, background: col, color: '#fff', fontFamily: FONT, fontWeight: 800, fontSize: 30,
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flex: 'none'}}>{it.icon}</span>) : null}
      <div style={{fontFamily: FONT}}>
        <div style={{fontSize: it.kind === 'card' ? 44 : 40, fontWeight: 700, color: it.kind === 'card' ? K.ink : col, lineHeight: 1.2}}>{it.text}</div>
        {it.sub ? <div style={{fontSize: 32, color: K.sub, marginTop: 6, lineHeight: 1.25}}>{it.sub}</div> : null}
      </div>
    </div>
  );
};

const ItemsList: React.FC<{top: number}> = ({top}) => {
  // собранные в этом кадре подписи (порядок появления), без повторов
  const seen = new Set<string>();
  let items = VM.list.filter((x) => (seen.has(x.text) ? false : (seen.add(x.text), true))).sort((a, b) => a.at - b.at);
  const avail = 1870 - top;
  let tot = items.reduce((a, x) => a + itemH(x) + 18, 0);
  while (items.length > 1 && tot > avail) { tot -= itemH(items[0]) + 18; items = items.slice(1); }
  return (
    <div style={{position: 'absolute', left: 50, right: 50, top, display: 'flex', flexDirection: 'column', gap: 18, direction: isRTL() ? 'rtl' : 'ltr'}}>
      {items.map((it) => <ItemView key={it.text} it={it} />)}
    </div>
  );
};

/* ---------- сцена ---------- */
const XF = 0.5;
const camFor = (lang: Lang): Record<string, Phase[]> => ART_RU as unknown as Record<string, Phase[]>; // раскладка картинки одинакова для языков
const SceneV3: React.FC<{s: Scene; audio: boolean; lang: Lang}> = ({s, audio, lang}) => {
  const f = useCurrentFrame();
  const t = f / FPS;
  const ruDur = scenesFor('ru').find((x) => x.id === s.id)!.dur;
  const k = s.dur / ruDur;
  const ph = (SKIP_ART.includes(s.id) ? [] : camFor(lang)[s.id] ?? []).map((x) => ({t: x.t * k, p: (x.p as R[]).filter((r) => r[2] * r[3] > 160 * 160)}));
  let pi = -1;
  ph.forEach((x, i) => { if (t >= x.t) pi = i; });
  const cur = pi >= 0 && ph[pi].p.length ? (ph[pi].p[0] as R) : null;
  const prev = pi > 0 && ph[pi - 1].p.length ? (ph[pi - 1].p[0] as R) : null;
  const inP = pi <= 0 ? 1 : interpolate(t, [ph[pi].t, ph[pi].t + XF], [0, 1], clamp);
  const so = Math.min(interpolate(f, [0, 10], [0, 1], clamp), interpolate(f, [sceneFrames(s) - 10, sceneFrames(s)], [1, 0], clamp));
  const hCur = cur ? fit(cur).h : 0, hPrev = prev ? fit(prev).h : 0;
  const ph_h = inP < 1 ? hPrev + (hCur - hPrev) * inP : hCur;
  VM.list = [];
  return (
    <AbsoluteFill style={{opacity: so}}>
      {audio ? <Audio src={staticFile(`preop_${lang}/${s.id}.wav`)} /> : null}
      <HeadV s={s} />
      {/* картинка рендерится ВСЕГДА (собирает подписи в VM.list), видна — если есть окно */}
      {cur ? <ArtPanel s={s} lang={lang} r={cur} o={inP < 1 ? interpolate(inP, [0.5, 1], [0, 1], clamp) : 1} /> : (
        <div style={{position: 'absolute', width: 1, height: 1, overflow: 'hidden', opacity: 0}}><ArtStage s={s} lang={lang} /></div>)}
      {inP < 1 && prev ? <div style={{opacity: interpolate(inP, [0, 0.5], [1, 0], clamp)}}><ArtPanel s={s} lang={lang} r={prev} o={1} /></div> : null}
      <ItemsList top={ph_h > 0 ? PANEL_TOP + ph_h + 30 : 620} />
    </AbsoluteFill>
  );
};

export const PreopFilmV3: React.FC<{audio: boolean; lang?: Lang}> = ({audio, lang = 'ru'}) => {
  setLang(lang);
  const SC = scenesFor(lang);
  let acc = 3 * FPS;
  return (
    <AbsoluteFill style={{width: VW, height: 1920}}>
      <Bg />
      <Sequence durationInFrames={3 * FPS}>
        <AbsoluteFill style={{padding: '0 50px', scale: '0.86'}}>{lang === 'ru' ? <Title /> : <TitleL s={SC[0]} />}</AbsoluteFill>
      </Sequence>
      {SC.map((s) => {
        const from = acc;
        acc += sceneFrames(s);
        return <Sequence key={s.id} from={from} durationInFrames={sceneFrames(s)} name={s.id}><SceneV3 s={s} audio={audio} lang={lang} /></Sequence>;
      })}
      <Sequence from={acc} durationInFrames={OUT_F + FPS} name="OUT"><AbsoluteFill style={{padding: '0 70px'}}><Outro audio={audio} lang={lang} /></AbsoluteFill></Sequence>
      <div style={{position: 'absolute', left: 0, right: 0, bottom: 22, textAlign: 'center', fontFamily: FONT, fontSize: 24, color: K.sub, opacity: 0.5, direction: isRTL() ? 'rtl' : 'ltr'}}>
        {T('Георгий Кокорин · медбрат')}
      </div>
    </AbsoluteFill>
  );
};
