import {StairClimb} from './motion_he';
import React from 'react';
import {AbsoluteFill, Audio, Freeze, OffthreadVideo, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {C, Cap, Card, Check, Cross, FPS, G, Label, Note, Pop, ease, easeIO, font, K} from './ui';
import {Icon} from './Part1';
import timing from './timing3_he.json';
import CUE from './cues_thr3_he.json';

type T = {id: string; dur: number; audio?: string; k?: number}[];
const TT = timing as T;
const PAD = 0.75;
const A_IDS = ['D01', 'D02', 'D03', 'D04', 'D05', 'D06'];
const END = 75;
export const total3aV_he = () => TT.filter((x) => A_IDS.includes(x.id)).reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0) + END;
export const total3bV_he = () => TT.filter((x) => !A_IDS.includes(x.id)).reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const sec = (s: number) => Math.round(s * FPS);
// время слова в озвучке (сек от начала сцены), см. cues_thr3_*.json
const T = (k: string, d = 0) => ((CUE as Record<string, number>)[k] ?? 0) + d;
const tagFor = (id: string) => (['D01','D02','D03','D04','D05','D06'].includes(id) ? 'החלפת מפרק ירך · חלק 3א' : 'החלפת מפרק ירך · חלק 3ב');

const Row: React.FC<{t: string; at: number; ok?: boolean}> = ({t, at, ok = true}) => {
  const f = useCurrentFrame();
  return (
    <div style={{display: 'flex', alignItems: 'center', gap: 14, padding: '10px 0', opacity: 0.35 + 0.65 * ease(f, sec(at), sec(at) + 10)}}>
      {ok ? <Check p={ease(f, sec(at), sec(at) + 18)} /> : <div style={{width: 34, height: 34, borderRadius: 17, background: C.redL, color: C.red, fontFamily: font, fontWeight: 900, fontSize: 22, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>!</div>}
      <Label size={23}>{t}</Label>
    </div>
  );
};

const Pose: React.FC<{k: 'low' | 'cross' | 'turn' | 'pillow'; p: number}> = ({k, p}) => (
  <div style={{position: 'relative', width: 150, height: 150}}>
    <svg width={150} height={150} viewBox="0 0 100 100">
      {k === 'low' && <><circle cx={40} cy={16} r={8} fill={C.teal} /><path d="M40 24 L46 52 L70 60 L72 86" stroke={C.teal} strokeWidth={8} fill="none" strokeLinecap="round" strokeLinejoin="round" /><rect x={30} y={60} width={44} height={8} rx={3} fill="#9aa5b1" /><path d="M34 68 L34 88 M70 68 L70 88" stroke="#9aa5b1" strokeWidth={4} /></>}
      {k === 'cross' && <><circle cx={50} cy={14} r={8} fill={C.teal} /><path d="M50 22 L50 52" stroke={C.teal} strokeWidth={9} strokeLinecap="round" /><path d="M48 52 L66 72 L40 90 M52 52 L36 74 L62 90" stroke={C.teal} strokeWidth={7} fill="none" strokeLinecap="round" strokeLinejoin="round" /></>}
      {k === 'turn' && <><path d="M44 10 L44 70 L28 86" stroke={C.teal} strokeWidth={9} fill="none" strokeLinecap="round" strokeLinejoin="round" /><path d="M60 10 L60 70 L76 86" stroke={C.teal2} strokeWidth={9} fill="none" strokeLinecap="round" strokeLinejoin="round" opacity={0.5} /><path d="M20 74 C 14 68, 16 60, 24 60" stroke={C.red} strokeWidth={3} fill="none" /></>}
      {k === 'pillow' && <><circle cx={14} cy={40} r={8} fill={C.teal} /><path d="M22 42 L60 46 L90 40 M60 46 L90 54" stroke={C.teal} strokeWidth={8} fill="none" strokeLinecap="round" strokeLinejoin="round" /><ellipse cx={78} cy={47} rx={10} ry={6} fill={C.dawnL} stroke={C.dawn} strokeWidth={2} /></>}
    </svg>
    {k !== 'pillow' && <div style={{position: 'absolute', left: 25, top: 25}}><Cross p={p} size={100} /></div>}
  </div>
);
/* ===== ВЕРТИКАЛЬНАЯ ВЕРСИЯ (9:16): виртуальный холст 720×1280, масштаб ×1.5 → 1080×1920 ===== */
const VW = 720;
const Col: React.FC<{top: number; gap?: number; children: React.ReactNode}> = ({top, gap = 14, children}) => (
  <div style={{position: 'absolute', left: 36, right: 36, top, display: 'flex', flexDirection: 'column', gap, direction: G.rtl ? 'rtl' : 'ltr'}}>{children}</div>
);
const Head: React.FC<{text: string; acc: string[]; size?: number; color?: string}> = ({text, acc, size = 44, color}) => (
  <div style={{position: 'absolute', left: 36, right: 36, top: 92}}><Cap text={text} size={size} accent={acc} width={VW - 72} acc={color} /></div>
);
const Center: React.FC<{top: number; gap?: number; children: React.ReactNode}> = ({top, gap = 16, children}) => (
  <div style={{position: 'absolute', left: 36, right: 36, top, display: 'flex', justifyContent: 'center', alignItems: 'center', flexWrap: 'wrap', gap, direction: G.rtl ? 'rtl' : 'ltr'}}>{children}</div>
);
const PBg: React.FC = () => {
  const f = useCurrentFrame();
  const x = 50 + Math.sin(f / 90) * 6;
  return (
    <AbsoluteFill style={{background: `radial-gradient(900px 900px at ${x}% -5%, #fff3e4 0%, ${C.bg} 45%, ${C.bg2} 100%)`}}>
      <svg width={VW} height={1280} style={{position: 'absolute', opacity: 0.5}}>
        <defs><pattern id="pdots" width={28} height={28} patternUnits="userSpaceOnUse"><circle cx={2} cy={2} r={1.3} fill="#e2d8ca" /></pattern></defs>
        <rect width={VW} height={1280} fill="url(#pdots)" />
      </svg>
    </AbsoluteFill>
  );
};
const VTag: React.FC<{n: string; id: string}> = ({n, id}) => {
  const f = useCurrentFrame();
  return (
    <div style={{position: 'absolute', top: 34, left: 36, right: 36, fontFamily: font, fontWeight: 700, fontSize: 17, letterSpacing: 1.2, opacity: ease(f, 0, 10), direction: G.rtl ? 'rtl' : 'ltr'}}>
      <div style={{color: C.mute, fontWeight: 600}}>{tagFor(id)}</div>
      <div style={{color: C.teal, marginTop: 4}}>{n}</div>
    </div>
  );
};
const Box: React.FC<{at: number; children: React.ReactNode; bg?: string; size?: number; color?: string}> = ({at, children, bg = C.white, size = 24, color}) => (
  <Pop at={sec(at)}><Card style={{background: bg}}><Label size={size} color={color}>{children}</Label></Card></Pop>
);

const EndA: React.FC = () => (
  <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', padding: '0 36px'}}>
    <Pop at={2}>
      <Card style={{padding: 34, textAlign: 'center', borderTop: `8px solid ${C.teal}`}}>
        <Label size={34}>אלה המלצות כלליות.</Label>
        <Label size={28} color={C.mute} style={{fontWeight: 600, marginTop: 8}}>ההוראות האישיות של הרופא ושל הצוות הרפואי קודמות להן.</Label>
      </Card>
    </Pop>
    <div style={{marginTop: 26, textAlign: 'center'}}><Note at={12} color={'#b8661c'} bg={C.dawnL}>בהמשך, חלק 3ב: תנועות, מדרגות, חזרה לשגרה, סימני אזהרה</Note></div>
  </AbsoluteFill>
);

const D1: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <VTag n="שחרור" id="D01" />
      <Head text="אחרי השחרור, בדרך כלל בית חולים שיקומי" acc={['שיקומי']} />
      <Col top={260} gap={12}>
        <Pop at={sec(1)}><Card style={{display: 'flex', alignItems: 'center', gap: 16, padding: '12px 20px'}}><Icon k="bed" s={70} /><Label size={26}>המחלקה שלנו</Label></Card></Pop>
        <div style={{display: 'flex', justifyContent: 'center', opacity: ease(f, sec(T('D01.rehab', -0.4)), sec(T('D01.rehab', 0.2)))}}><svg width={40} height={44}><path d="M20 4 L20 36 M8 24 L20 38 L32 24" stroke={C.teal} strokeWidth={5} fill="none" strokeLinecap="round" /></svg></div>
        <Pop at={sec(T('D01.rehab'))}>
          <Card style={{border: `3px solid ${C.teal}`, display: 'flex', alignItems: 'center', gap: 16}}>
            <svg width={100} height={100} viewBox="0 0 100 100" style={{flex: 'none'}}><rect x={14} y={30} width={72} height={60} rx={6} fill={C.tealL} stroke={C.ink} strokeWidth={4} /><rect x={40} y={14} width={20} height={20} rx={3} fill="#fff" stroke={C.ink} strokeWidth={3} /><path d="M50 18 L50 30 M44 24 L56 24" stroke={C.red} strokeWidth={3} /><g fill="#fff" stroke={C.ink} strokeWidth={2}>{[0, 1, 2].map((i) => <rect key={i} x={22 + i * 22} y={44} width={14} height={14} rx={2} />)}</g><rect x={42} y={68} width={16} height={22} fill="#fff" stroke={C.ink} strokeWidth={3} /></svg>
            <div><Label size={28} color={C.teal}>בית חולים שיקומי</Label><Label size={22} color={C.mute} style={{fontWeight: 600, marginTop: 4}}>בדרך כלל, אחרי החלפת מפרק</Label></div>
          </Card>
        </Pop>
        <div style={{height: 10}} />
        <Box at={T('D01.pt')} bg={C.tealL}>הפיזיותרפיסטים עוזרים לקום, ללכת ולהסתדר בפעולות היומיום בבטחה, כדי להתכונן לחזרה הביתה</Box>
        <Box at={T('D01.home')} bg={C.dawnL}>מעדיפים שיקום בבית? אמרו מראש: זה תלוי במצבכם, בתנאים בבית ובאישור קופת החולים</Box>
        <Note at={sec(T('D01.visit'))}>אם יוסדר, פיזיותרפיסט יגיע אליכם הביתה</Note>
        <Note at={sec(T('D01.video'))} color={'#b8661c'} bg={C.dawnL}>העצות יעזרו גם בבית החולים השיקומי וגם בבית</Note>
      </Col>
    </AbsoluteFill>
  );
};

const D2: React.FC = () => {
  const items = ['איזה ניתוח בוצע', 'תרופות: אילו וכמה זמן', 'כמה מותר להעמיס על הרגל המנותחת', 'טיפול בפצע', 'תפרים או סיכות: 10–14 ימים (אם צריך להוציא)', 'מתי להגיע לביקורת', 'לאן לפנות אם יש בעיה בבית'];
  return (
    <AbsoluteFill>
      <VTag n="מכתב שחרור" id="D02" />
      <Head text="כל מה שחשוב כתוב במכתב השחרור" acc={['השחרור']} size={46} />
      <Col top={240}>
        <Pop at={sec(T('D02.letter'))}>
          <Card style={{borderTop: `8px solid ${C.teal}`}}>
            {items.map((t, i) => <Row key={i} t={t} at={T(['D02.r0', 'D02.r1', 'D02.r2', 'D02.r3', 'D02.r4', 'D02.r5', 'D02.r6'][i])} />)}
          </Card>
        </Pop>
        <Pop at={sec(T('D02.fam'))}>
          <Card style={{display: 'flex', alignItems: 'center', gap: 16, justifyContent: 'center'}}>
            <Icon k="doc" s={80} />
            <svg width={60} height={30} style={{flex: 'none', transform: G.rtl ? 'scaleX(-1)' : undefined}}><path d="M4 15 L46 15 M34 5 L48 15 L34 25" stroke={C.teal} strokeWidth={4} fill="none" strokeLinecap="round" /></svg>
            <Label size={27}>הראו לרופא המשפחה</Label>
          </Card>
        </Pop>
      </Col>
    </AbsoluteFill>
  );
};

const D3: React.FC = () => {
  const f = useCurrentFrame();
  const days = Array.from({length: 28}, (_, i) => i);
  return (
    <AbsoluteFill>
      <VTag n="קרישי דם" id="D03" />
      <Head text="מניעת קרישי דם ממשיכה גם אחרי השחרור" acc={['השחרור']} />
      <Col top={260} gap={12}>
        <Pop at={sec(1)}>
          <Card>
            <Label size={25} color={C.teal}>לפי התוכנית שנקבעה, לרוב כחודש</Label>
            <div style={{display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 8, marginTop: 14}}>
              {days.map((d) => {
                const on = ease(f, sec(T('D03.month')) + d * 6, sec(T('D03.month')) + d * 6 + 8);
                return <div key={d} style={{height: 40, borderRadius: 8, background: on > 0.5 ? C.teal : '#f1f3f5', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{on > 0.5 && <svg width={20} height={20}><path d="M4 10 L8 15 L16 5" stroke="#fff" strokeWidth={3} fill="none" strokeLinecap="round" /></svg>}</div>;
              })}
            </div>
            <div style={{display: 'flex', gap: 14, marginTop: 16, alignItems: 'center'}}>
              <Icon k="syringe" s={60} /><Label size={22} style={{fontWeight: 600}}>זריקות אנוקסאפרין או כדורים, את משך הטיפול יקבע הרופא</Label>
            </div>
          </Card>
        </Pop>
        <Box at={T('D03.skip')} bg={C.tealL}>אל תדלגו על מנות ואל תפסיקו על דעת עצמכם, אחרת ההגנה מפני קרישים תפחת</Box>
        <Pop at={sec(T('D03.bleed'))}><Card style={{background: C.redL}}>
          <Label size={24} color={C.red}>בסימני דימום פנו בדחיפות לעזרה רפואית</Label>
          <Label size={22} style={{fontWeight: 600, marginTop: 6}}>דם בשתן · צואה שחורה · שטפי דם גדולים במיוחד · דימום ממושך</Label>
        </Card></Pop>
        <Box at={T('D03.add')}>אל תוסיפו על דעת עצמכם אספירין, איבופרופן או תרופות אחרות נוגדות דלקת</Box>
      </Col>
    </AbsoluteFill>
  );
};

const D4: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <VTag n="הפצע" id="D04" />
      <Head text="הפצע: נקי, יבש, תחבושת כפי שהסבירו" acc={['נקי', 'יבש']} />
      <Center top={260}>
        <Pop at={sec(1)}>
          <Card style={{width: 300, height: 320, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
            <svg width={240} height={288} viewBox="0 0 200 240">
              <path d="M40 10 C 90 0, 160 6, 172 30 C 176 90, 160 150, 146 230 L 74 230 C 66 150, 50 90, 40 10 Z" fill="#f2d7c2" stroke="#d9b79c" strokeWidth={3} />
              <rect x={118} y={40} width={34} height={90} rx={10} fill="#fff" stroke="#cfd6dd" strokeWidth={3} />
              <rect x={126} y={52} width={18} height={66} rx={5} fill={C.tealL} />
              {[0, 1, 2, 3, 4].map((i) => {
                const t = ((f + i * 14) % 60) / 60;
                const y = 10 + t * 50; const bounce = t > 0.55;
                return <circle key={i} cx={120 + i * 8 + (bounce ? (t - 0.55) * 60 : 0)} cy={bounce ? 38 - (t - 0.55) * 40 : y} r={4} fill={C.teal2} opacity={ease(f, sec(T('D04.shower')), sec(T('D04.shower', 1))) * (1 - t * 0.6)} />;
              })}
            </svg>
          </Card>
        </Pop>
      </Center>
      <Col top={610} gap={12}>
        <Box at={T('D04.cream')}>בלי קרמים ומשחות על הפצע, אם לא הורו לכם</Box>
        <Box at={T('D04.shower')} bg={C.tealL}>מקלחת: בדרך כלל עם תחבושת אטומה למים. מתי ואיך, בררו עם הצוות</Box>
        <Pop at={sec(T('D04.bath'))}>
          <Card style={{display: 'flex', alignItems: 'center', gap: 16}}>
            <div style={{position: 'relative', width: 80, height: 80, flex: 'none'}}>
              <svg width={80} height={80} viewBox="0 0 100 100"><path d="M10 50 L90 50 L84 80 L16 80 Z" fill="#eaf6fb" stroke={C.ink} strokeWidth={4} /><path d="M20 40 C 30 30, 40 50, 50 40 C 60 30, 70 50, 80 40" stroke={C.teal2} strokeWidth={4} fill="none" /></svg>
              <div style={{position: 'absolute', left: -5, top: -5}}><Cross p={ease(f, sec(T('D04.bath', 1)), sec(T('D04.bath', 2)))} size={90} /></div>
            </div>
            <Label size={24}>אמבטיה, בריכה, ים: רק כשהפצע החלים והרופא התיר</Label>
          </Card>
        </Pop>
        <Box at={T('D04.inf')} bg={C.redL} color={C.red}>למה: זיהום סביב המפרק המלאכותי הוא סיבוך חמור</Box>
      </Col>
    </AbsoluteFill>
  );
};

const D5: React.FC = () => (
  <AbsoluteFill>
    <VTag n="כאב ונפיחות" id="D05" />
    <Head text="כשהכאב בשליטה, קל יותר לזוז" acc={['לזוז']} size={46} />
    <Col top={260} gap={12}>
      <Pop at={sec(1)}><Card style={{display: 'flex', alignItems: 'center', gap: 14}}><Icon k="pill" s={64} /><Label size={24}>משככי כאבים לפי התוכנית שנקבעה</Label></Card></Pop>
      <Box at={T('D05.ex')}>לפני התרגילים רק אם הרופא המליץ. בלי מנות נוספות</Box>
      <Box at={T('D05.drowsy')} bg={C.dawnL}>ישנוניות וסחרחורת מעלות את הסיכון לנפילה. דווחו לרופא גם על עצירות</Box>
      <div style={{height: 14}} />
      <Box at={T('D05.swell')}>נפיחות ושטפי דם בשבועות הראשונים הם תופעה שכיחה</Box>
      <Pop at={sec(T('D05.ice'))}>
        <Card style={{display: 'flex', alignItems: 'center', gap: 14, background: C.tealL}}>
          <svg width={80} height={72} viewBox="0 0 100 90" style={{flex: 'none'}}><rect x={10} y={20} width={80} height={50} rx={14} fill="#fff" stroke={C.ink} strokeWidth={4} /><path d="M30 34 L44 48 M44 34 L30 48 M58 40 L72 40 M65 33 L65 47" stroke={C.teal2} strokeWidth={4} strokeLinecap="round" /></svg>
          <Label size={24}>קרח עטוף בבד, 15–20 דקות, כמה פעמים ביום</Label>
        </Card>
      </Pop>
      <Box at={T('D05.sit')}>ישבתם הרבה זמן? הסתובבו קצת</Box>
    </Col>
  </AbsoluteFill>
);

const D6: React.FC = () => {
  const f = useCurrentFrame();
  const rug = 1 - ease(f, sec(T('D06.rugs')), sec(T('D06.rugs', 1)));
  const cable = 1 - ease(f, sec(T('D06.cable')), sec(T('D06.cable', 1)));
  const light = ease(f, sec(T('D06.light')), sec(T('D06.light', 0.8)));
  return (
    <AbsoluteFill>
      <VTag n="בית בטוח" id="D06" />
      <Head text="נפילה מסוכנת במיוחד בשבועות הראשונים" acc={['נפילה']} />
      <Col top={240}>
        <Pop at={sec(1)}>
          <Card style={{padding: 0, overflow: 'hidden', height: 380}}>
            <svg width={648} height={380} viewBox="0 0 640 420" preserveAspectRatio="xMidYMid meet">
              <rect width={640} height={420} fill="#fffdf9" />
              <rect x={20} y={20} width={600} height={380} fill="none" stroke="#b9c4cf" strokeWidth={6} />
              <path d="M320 20 L320 260 M320 320 L320 400" stroke="#b9c4cf" strokeWidth={6} />
              <text x={170} y={60} textAnchor="middle" fontFamily={font} fontWeight={700} fontSize={24} fill={C.mute}>חדר שינה</text>
              <text x={470} y={60} textAnchor="middle" fontFamily={font} fontWeight={700} fontSize={24} fill={C.mute}>שירותים ומקלחת</text>
              <rect x={60} y={100} width={150} height={90} rx={10} fill="#fff" stroke="#9aa5b1" strokeWidth={3} />
              <g opacity={rug}><rect x={120} y={250} width={140} height={80} rx={10} fill="#e9b98d" /><path d="M130 260 L250 320 M250 260 L130 320" stroke="#d99b66" strokeWidth={3} /></g>
              <g opacity={cable}><path d="M40 360 C 90 330, 140 380, 200 350 C 240 330, 260 360, 300 340" stroke="#5d6875" strokeWidth={4} fill="none" /></g>
              <circle cx={300} cy={300} r={10 + 30 * light} fill="#ffd36e" opacity={0.35 * light} /><circle cx={300} cy={300} r={8} fill={light > 0.5 ? '#ffc23d' : '#cfd6dd'} />
              <path d="M210 160 C 260 220, 300 280, 400 300" stroke={C.teal} strokeWidth={5} strokeDasharray="10 8" fill="none" opacity={light} />
              <rect x={420} y={250} width={80} height={90} rx={12} fill="#fff" stroke={C.ink} strokeWidth={3} />
              <rect x={414} y={240} width={92} height={18} rx={6} fill={C.tealL} stroke={C.teal} strokeWidth={3} opacity={ease(f, sec(T('D06.seat')), sec(T('D06.seat', 1)))} />
              <path d="M560 120 L560 220" stroke={C.teal} strokeWidth={10} strokeLinecap="round" opacity={ease(f, sec(T('D06.grab')), sec(T('D06.grab', 0.8)))} />
            </svg>
          </Card>
        </Pop>
      </Col>
      <Col top={640} gap={10}>
        <Box at={T('D06.fall')} bg={C.redL} size={23} color={C.red}>נפילה עלולה לגרום לפריקה של המפרק המלאכותי או לשבר</Box>
        <Box at={T('D06.rugs')} size={23}>להוציא שטיחים וכבלים · אור בלילה · דברים בגובה המותניים</Box>
        <Box at={T('D06.chair')} size={23}>כיסא עם משענות יד · מושב אסלה מוגבה · מאחזי יד במקלחת</Box>
        <Box at={T('D06.walker')} bg={C.tealL} size={23}>עם הליכון: שתי הידיים על ההליכון, חפצים בתיק שמחובר אליו</Box>
        <Box at={T('D06.push')} size={23}>אל תדחפו שולחן רגיל על גלגלים. נעליים יציבות עם סוליה שאינה מחליקה</Box>
      </Col>
    </AbsoluteFill>
  );
};

const D7: React.FC = () => {
  const f = useCurrentFrame();
  const items: {k: 'low' | 'cross' | 'turn' | 'pillow'; t: string; at: number}[] = [
    {k: 'low', t: 'לכופף את הירך חזק', at: T('D07.bend')}, {k: 'cross', t: 'לשכל רגליים', at: T('D07.cross')}, {k: 'turn', t: 'לסובב את הרגל פנימה', at: T('D07.turn')},
    {k: 'pillow', t: 'כרית בין הברכיים', at: T('D07.pillow')},
  ];
  return (
    <AbsoluteFill>
      <VTag n="תנועות" id="D07" />
      <Head text="הגבלות רק אם המנתח קבע אותן" acc={['המנתח']} />
      <Col top={250}>
        <Box at={1} bg={C.dawnL} size={23}>כל עוד הרקמות סביב המפרק מחלימות, תנועות מסוימות עלולות לגרום לפריקה. הצורך בהגבלות וסוגן תלויים באופן שבו בוצע הניתוח</Box>
      </Col>
      <Center top={470} gap={14}>
        {items.map((it, i) => (
          <Pop key={i} at={sec(it.at)}>
            <Card style={{width: 310, height: 230, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6, border: it.k === 'pillow' ? `3px solid ${C.ok}` : '3px solid transparent'}}>
              <Pose k={it.k} p={ease(f, sec(it.at) + 10, sec(it.at) + 30)} />
              <Label size={22} style={{textAlign: 'center'}}>{it.k === 'pillow' ? it.t : `בינתיים לא ${it.t}`}</Label>
            </Card>
          </Pop>
        ))}
      </Center>
      <Col top={990} gap={10}>
        <Note at={sec(T('D07.all'))}>רק אם נקבעו הגבלות</Note>
        <Note at={sec(T('D07.sleep'))} color={'#b8661c'} bg={C.dawnL}>איך לישון? בררו עם המנתח</Note>
      </Col>
    </AbsoluteFill>
  );
};

/* 3D-ролик лестницы (clay3d): подъём на слове «вверх», спуск на «вниз»; между фазами — стоп-кадр */
const Stair3D: React.FC = () => {
  const f = useCurrentFrame();
  const t = f / FPS;
  const R = T('ST.rate') || 1.5;
  const up = T('D08.up'), dn = T('D08.down');
  const u0 = T('ST.u0'), u1 = T('ST.u1'), d0 = T('ST.d0'), d1 = T('ST.d1');
  const st = t < up ? u0 : t < dn ? Math.min(u1, u0 + (t - up) * R) : Math.min(d1, d0 + (t - dn) * R);
  const W = 648, H = 1152;
  return (
    <div style={{width: W, height: 818, overflow: 'hidden', borderRadius: 24, boxShadow: '0 12px 36px rgba(70,50,20,.12)', background: '#e9edf0', direction: 'ltr'}}>
      <div style={{width: W, height: H, marginTop: -0.22 * H}}>
        <Freeze frame={Math.round(st * FPS)}>
          <OffthreadVideo src={staticFile('stairs_he.mp4')} muted style={{width: W, height: H}} />
        </Freeze>
      </div>
    </div>
  );
};

const D8: React.FC = () => {
  const f = useCurrentFrame();
  const sw = ease(f, sec(T('D08.stairs', -0.3)), sec(T('D08.stairs', 0.3)));
  return (
  <AbsoluteFill>
    <VTag n="הליכה ומדרגות" id="D08" />
    <Head text="כל יום הליכות קצרות ותרגילים" acc={['כל']} />
    <div style={{opacity: 1 - sw}}>
    <Col top={250} gap={10}>
        <Box at={T('D08.str')} size={23}>מחזירים כוח לשרירים ומקטינים את הסיכון לסיבוכים משכיבה ממושכת</Box>
        <Box at={T('D08.wb')} bg={C.redL} size={23} color={C.red}>העמסה על הרגל רק לפי הוראת המנתח</Box>
        <Pop at={sec(T('D08.aids'))}>
          <Card style={{display: 'flex', gap: 16, alignItems: 'center', justifyContent: 'space-around', padding: '10px 16px'}}>
            {['הליכון', 'קביים', 'מקל'].map((t) => <div key={t} style={{textAlign: 'center'}}><svg width={60} height={60} viewBox="0 0 100 100">{t === 'הליכון' ? <path d="M30 20 L70 20 M30 20 L24 90 M70 20 L76 90 M26 60 L74 60" stroke="#7f8a96" strokeWidth={7} strokeLinecap="round" fill="none" /> : t === 'קביים' ? <path d="M36 12 L36 90 M64 12 L64 90 M28 12 L44 12 M56 12 L72 12 M30 50 L42 50 M58 50 L70 50" stroke="#7f8a96" strokeWidth={6} strokeLinecap="round" fill="none" /> : <path d="M40 16 C 40 6, 62 6, 62 16 L 62 90" stroke="#7f8a96" strokeWidth={7} strokeLinecap="round" fill="none" />}</svg><Label size={21}>{t}</Label></div>)}
            <Note at={sec(T('D08.assess'))}>את הבחירה עושים עם הפיזיותרפיסט</Note>
          </Card>
        </Pop>
      </Col>
    </div>
    {sw > 0 && (
      <div style={{position: 'absolute', left: 36, right: 36, top: 240, opacity: sw, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12}}>
        <Label size={26} color={C.teal} style={{textAlign: 'center'}}>מדרגות: רק אחרי הדרכה של הפיזיותרפיסט</Label>
        <Stair3D />
        <Pop at={sec(T('D08.end', -0.3))}><Label size={21} style={{fontWeight: 600, textAlign: 'center'}}>למעלה: הרגל הבריאה ← המנותחת והקב. למטה: הקב ← המנותחת ← הבריאה. החזיקו במעקה</Label></Pop>
      </div>
    )}
  </AbsoluteFill>
  );
};

const D9: React.FC = () => (
  <AbsoluteFill>
    <VTag n="חזרה לשגרה" id="D09" />
    <Head text="נהיגה, נסיעות ו״יש לי מפרק מלאכותי״" acc={['מלאכותי״']} />
    <Col top={250} gap={14}>
      <Pop at={sec(1)}><Card style={{display: 'flex', gap: 16, alignItems: 'flex-start'}}>
        <svg width={100} height={67} viewBox="0 0 120 80" style={{flex: 'none'}}><path d="M10 50 L20 26 C 24 18, 96 18, 100 26 L110 50 Z" fill={C.tealL} stroke={C.ink} strokeWidth={4} strokeLinejoin="round" /><rect x={6} y={48} width={108} height={18} rx={6} fill={C.teal} /><circle cx={30} cy={68} r={9} fill={C.ink} /><circle cx={90} cy={68} r={9} fill={C.ink} /></svg>
        <div><Label size={25}>נהיגה: רק באישור הרופא</Label>
        <Label size={21} color={C.mute} style={{fontWeight: 600, marginTop: 8}}>שולטים ברגל בביטחון, מסוגלים לבלום מהר, והתרופות אינן גורמות לישנוניות או לפגיעה בערנות</Label></div>
      </Card></Pop>
      <Pop at={sec(T('D09.long'))}><Card style={{display: 'flex', gap: 16, alignItems: 'flex-start'}}>
        <svg width={100} height={67} viewBox="0 0 120 80" style={{flex: 'none'}}><path d="M10 44 L110 30 C 118 30, 118 40, 110 42 L60 50 L40 74 L30 74 L40 52 L14 56 Z" fill={C.tealL} stroke={C.ink} strokeWidth={3.5} strokeLinejoin="round" /></svg>
        <div><Label size={25}>נסיעות ארוכות וטיסות: דברו עם המנתח</Label>
        <Label size={21} color={C.mute} style={{fontWeight: 600, marginTop: 8}}>ישיבה ממושכת מעלה את הסיכון לקרישי דם; אם התירו, הזיזו את כפות הרגליים ועשו הפסקות</Label></div>
      </Card></Pop>
      <Pop at={sec(T('D09.dent'))}><Card style={{display: 'flex', gap: 16, alignItems: 'center', background: C.dawnL}}>
        <svg width={100} height={67} viewBox="0 0 120 80" style={{flex: 'none'}}><rect x={10} y={10} width={100} height={62} rx={10} fill="#fff" stroke={C.ink} strokeWidth={3.5} /><circle cx={36} cy={36} r={12} fill={C.tealL} /><path d="M58 30 L96 30 M58 44 L86 44" stroke={C.ink} strokeWidth={4} strokeLinecap="round" /></svg>
        <Label size={25}>ספרו לרופאים ולרופא השיניים שיש לכם מפרק מלאכותי</Label>
      </Card></Pop>
    </Col>
  </AbsoluteFill>
);

const Level: React.FC<{c: string; bg: string; h: string; items: string; at: number}> = ({c, bg, h, items, at}) => (
  <Pop at={sec(at)}>
    <Card style={{borderInlineStart: `10px solid ${c}`, background: bg, padding: '18px 22px'}}>
      <Label size={29} color={c}>{h}</Label>
      {items.split(' · ').map((it, i) => <div key={i} style={{display: 'flex', gap: 10, marginTop: 10}}><div style={{width: 12, height: 12, borderRadius: 6, background: c, marginTop: 10, flex: 'none'}} /><Label size={24} style={{fontWeight: 600, lineHeight: 1.3}}>{it}</Label></div>)}
    </Card>
  </Pop>
);

const D10: React.FC = () => (
  <AbsoluteFill>
    <VTag n="מתי לפנות בדחיפות" id="D10" />
    <Head text="שלוש רמות של דחיפות" acc={['דחיפות']} size={46} color={C.red} />
    <Col top={220} gap={16}>
      <Level c={'#b8661c'} bg={C.dawnL} h="באותו יום" items="חום 38° ומעלה, צמרמורת · הפצע מאדים, הפרשה, מוגלה · כאב, נפיחות או אודם חדשים בשוק" at={1} />
      <Level c={C.red} bg={C.redL} h="פנו מיד לעזרה רפואית. אל תלכו" items="כאב חזק פתאומי בירך · הרגל התקצרה או מסובבת באופן חריג · אי אפשר לדרוך עליה" at={T('D10.now')} />
      <Level c={'#8e1b1b'} bg={'#f8d4d1'} h="התקשרו 101" items="קוצר נשימה פתאומי · כאב בחזה" at={T('D10.101')} />
    </Col>
  </AbsoluteFill>
);

const D11: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <VTag n="החלמה" id="D11" />
      <Head text="ההחלמה יכולה להימשך כמה חודשים" acc={['חודשים']} />
      <div style={{position: 'absolute', left: 36, top: 270, width: 648}}>
        <svg width={648} height={70} style={{transform: G.rtl ? 'scaleX(-1)' : undefined}}>
          <rect x={6} y={30} width={636} height={12} rx={6} fill={C.line} />
          <rect x={6} y={30} width={636 * easeIO(f, sec(1), sec(8))} height={12} rx={6} fill={C.teal2} />
        </svg>
        <div style={{display: 'flex', justifyContent: 'space-between', marginTop: -24, direction: G.rtl ? 'rtl' : 'ltr'}}>
          {['שבועות', 'חודש', 'חודשיים', '3 חודשים +'].map((t, i) => <span key={i} style={{fontFamily: font, fontWeight: 700, fontSize: 20, color: C.mute}}>{t}</span>)}
        </div>
      </div>
      <Col top={390} gap={12}>
        <Box at={T('D11.diff')}>אצל כל אחד זה שונה: לפעמים מהר, לפעמים לאט יותר. הגיעו לביקורת שנקבעה</Box>
        <Box at={T('D11.fx')} bg={C.dawnL}>אחרי שבר בירך: דברו עם הרופא על בירור לאוסטאופורוזיס ועל מניעת נפילות</Box>
      </Col>
      <Col top={760}>
        <Pop at={sec(T('D11.gen'))}>
          <Card style={{padding: 28, textAlign: 'center', borderTop: `8px solid ${C.teal}`}}>
            <Label size={32}>אלה המלצות כלליות.</Label>
            <Label size={27} color={C.mute} style={{fontWeight: 600, marginTop: 8}}>ההוראות האישיות של הרופא ושל הצוות הרפואי קודמות להן.</Label>
          </Card>
        </Pop>
      </Col>
    </AbsoluteFill>
  );
};

const MAP: Record<string, React.FC> = {D01: D1, D02: D2, D03: D3, D04: D4, D05: D5, D06: D6, D07: D7, D08: D8, D09: D9, D10: D10, D11: D11};

const Fade: React.FC<{d: number; children: React.ReactNode}> = ({d, children}) => {
  const f = useCurrentFrame();
  const o = Math.min(ease(f, 0, 10), 1 - ease(f, d - 10, d));
  const sc = 1 + 0.02 * (f / Math.max(d, 1));
  return <AbsoluteFill style={{opacity: o, transform: `scale(${sc})`, transformOrigin: '50% 40%'}}>{children}</AbsoluteFill>;
};

export const Part3V_he: React.FC<{withAudio?: boolean; half?: 'a' | 'b'}> = ({withAudio = true, half}) => {
  G.rtl = true;
  let at = 0;
  const list = TT.filter((x) => !half || (half === 'a' ? A_IDS.includes(x.id) : !A_IDS.includes(x.id)));
  const endAt = list.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 0, top: 0, width: VW, height: 1280, transform: 'scale(1.5)', transformOrigin: '0 0', overflow: 'hidden'}}>
        <PBg />
        {half === 'a' && <Sequence from={endAt} durationInFrames={END}><EndA /></Sequence>}
        {list.map((x) => {
          const d = Math.round((x.dur + PAD) * FPS);
          const Comp = MAP[x.id];
          const el = (
            <Sequence key={x.id} from={at} durationInFrames={d} name={x.id}>
              <Fade d={d}><K k={x.k}><Comp /></K></Fade>
              {withAudio && x.audio && <Sequence from={6}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
            </Sequence>
          );
          at += d;
          return el;
        })}
      </div>
    </AbsoluteFill>
  );
};
