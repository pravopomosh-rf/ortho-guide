import {StairClimb} from './motion';
import React from 'react';
import {AbsoluteFill, Audio, Freeze, OffthreadVideo, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {C, Cap, Card, Check, Cross, FPS, G, Label, Note, Pop, ease, easeIO, font} from './ui';
import {Icon} from './Part1';
import timing from './timing3.json';
import CUE from './cues_thr3_ru.json';

type T = {id: string; dur: number; audio?: string}[];
const TT = timing as T;
const PAD = 0.75;
const A_IDS = ['D01', 'D02', 'D03', 'D04', 'D05', 'D06'];
const END = 75;
export const total3aV = () => TT.filter((x) => A_IDS.includes(x.id)).reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0) + END;
export const total3bV = () => TT.filter((x) => !A_IDS.includes(x.id)).reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const sec = (s: number) => Math.round(s * FPS);
// время слова в озвучке (сек от начала сцены), см. cues_thr3_*.json
const T = (k: string, d = 0) => ((CUE as Record<string, number>)[k] ?? 0) + d;
const tagFor = (id: string) => (['D01','D02','D03','D04','D05','D06'].includes(id) ? 'ЗАМЕНА ТАЗОБЕДРЕННОГО СУСТАВА · ЧАСТЬ 3А' : 'ЗАМЕНА ТАЗОБЕДРЕННОГО СУСТАВА · ЧАСТЬ 3Б');

const Row: React.FC<{t: string; at: number; ok?: boolean}> = ({t, at, ok = true}) => {
  const f = useCurrentFrame();
  return (
    <div style={{display: 'flex', alignItems: 'center', gap: 14, padding: '10px 0', opacity: 0.35 + 0.65 * ease(f, sec(at), sec(at) + 10)}}>
      {ok ? <Check p={ease(f, sec(at), sec(at) + 18)} /> : <div style={{width: 34, height: 34, borderRadius: 17, background: C.redL, color: C.red, fontFamily: font, fontWeight: 900, fontSize: 22, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>!</div>}
      <Label size={23}>{t}</Label>
    </div>
  );
};

const Pose: React.FC<{k: 'low' | 'cross' | 'turn' | 'pillow'; p: number}> = ({k, p}) => (
  <div style={{position: 'relative', width: 150, height: 150}}>
    <svg width={150} height={150} viewBox="0 0 100 100">
      {k === 'low' && <><circle cx={40} cy={16} r={8} fill={C.teal} /><path d="M40 24 L46 52 L70 60 L72 86" stroke={C.teal} strokeWidth={8} fill="none" strokeLinecap="round" strokeLinejoin="round" /><rect x={30} y={60} width={44} height={8} rx={3} fill="#9aa5b1" /><path d="M34 68 L34 88 M70 68 L70 88" stroke="#9aa5b1" strokeWidth={4} /></>}
      {k === 'cross' && <><circle cx={50} cy={14} r={8} fill={C.teal} /><path d="M50 22 L50 52" stroke={C.teal} strokeWidth={9} strokeLinecap="round" /><path d="M48 52 L66 72 L40 90 M52 52 L36 74 L62 90" stroke={C.teal} strokeWidth={7} fill="none" strokeLinecap="round" strokeLinejoin="round" /></>}
      {k === 'turn' && <><path d="M44 10 L44 70 L28 86" stroke={C.teal} strokeWidth={9} fill="none" strokeLinecap="round" strokeLinejoin="round" /><path d="M60 10 L60 70 L76 86" stroke={C.teal2} strokeWidth={9} fill="none" strokeLinecap="round" strokeLinejoin="round" opacity={0.5} /><path d="M20 74 C 14 68, 16 60, 24 60" stroke={C.red} strokeWidth={3} fill="none" /></>}
      {k === 'pillow' && <><circle cx={14} cy={40} r={8} fill={C.teal} /><path d="M22 42 L60 46 L90 40 M60 46 L90 54" stroke={C.teal} strokeWidth={8} fill="none" strokeLinecap="round" strokeLinejoin="round" /><ellipse cx={78} cy={47} rx={10} ry={6} fill={C.dawnL} stroke={C.dawn} strokeWidth={2} /></>}
    </svg>
    {k !== 'pillow' && <div style={{position: 'absolute', left: 25, top: 25}}><Cross p={p} size={100} /></div>}
  </div>
);
/* ===== ВЕРТИКАЛЬНАЯ ВЕРСИЯ (9:16): виртуальный холст 720×1280, масштаб ×1.5 → 1080×1920 ===== */
const VW = 720;
const Col: React.FC<{top: number; gap?: number; children: React.ReactNode}> = ({top, gap = 14, children}) => (
  <div style={{position: 'absolute', left: 36, right: 36, top, display: 'flex', flexDirection: 'column', gap, direction: G.rtl ? 'rtl' : 'ltr'}}>{children}</div>
);
const Head: React.FC<{text: string; acc: string[]; size?: number; color?: string}> = ({text, acc, size = 44, color}) => (
  <div style={{position: 'absolute', left: 36, right: 36, top: 92}}><Cap text={text} size={size} accent={acc} width={VW - 72} acc={color} /></div>
);
const Center: React.FC<{top: number; gap?: number; children: React.ReactNode}> = ({top, gap = 16, children}) => (
  <div style={{position: 'absolute', left: 36, right: 36, top, display: 'flex', justifyContent: 'center', alignItems: 'center', flexWrap: 'wrap', gap, direction: G.rtl ? 'rtl' : 'ltr'}}>{children}</div>
);
const PBg: React.FC = () => {
  const f = useCurrentFrame();
  const x = 50 + Math.sin(f / 90) * 6;
  return (
    <AbsoluteFill style={{background: `radial-gradient(900px 900px at ${x}% -5%, #fff3e4 0%, ${C.bg} 45%, ${C.bg2} 100%)`}}>
      <svg width={VW} height={1280} style={{position: 'absolute', opacity: 0.5}}>
        <defs><pattern id="pdots" width={28} height={28} patternUnits="userSpaceOnUse"><circle cx={2} cy={2} r={1.3} fill="#e2d8ca" /></pattern></defs>
        <rect width={VW} height={1280} fill="url(#pdots)" />
      </svg>
    </AbsoluteFill>
  );
};
const VTag: React.FC<{n: string; id: string}> = ({n, id}) => {
  const f = useCurrentFrame();
  return (
    <div style={{position: 'absolute', top: 34, left: 36, right: 36, fontFamily: font, fontWeight: 700, fontSize: 17, letterSpacing: 1.2, opacity: ease(f, 0, 10), direction: G.rtl ? 'rtl' : 'ltr'}}>
      <div style={{color: C.mute, fontWeight: 600}}>{tagFor(id)}</div>
      <div style={{color: C.teal, marginTop: 4}}>{n}</div>
    </div>
  );
};
const Box: React.FC<{at: number; children: React.ReactNode; bg?: string; size?: number; color?: string}> = ({at, children, bg = C.white, size = 24, color}) => (
  <Pop at={sec(at)}><Card style={{background: bg}}><Label size={size} color={color}>{children}</Label></Card></Pop>
);

const EndA: React.FC = () => (
  <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', padding: '0 36px'}}>
    <Pop at={2}>
      <Card style={{padding: 34, textAlign: 'center', borderTop: `8px solid ${C.teal}`}}>
        <Label size={34}>Это общие рекомендации.</Label>
        <Label size={28} color={C.mute} style={{fontWeight: 600, marginTop: 8}}>Индивидуальные указания вашего врача и медицинской команды имеют приоритет.</Label>
      </Card>
    </Pop>
    <div style={{marginTop: 26, textAlign: 'center'}}><Note at={12} color={'#b8661c'} bg={C.dawnL}>Дальше — часть 3б: движения, лестница, обычная жизнь, тревожные признаки</Note></div>
  </AbsoluteFill>
);

const D1: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <VTag n="ВЫПИСКА" id="D01" />
      <Head text="После выписки — обычно реабилитационная больница" acc={['реабилитационная']} />
      <Col top={260} gap={12}>
        <Pop at={sec(1)}><Card style={{display: 'flex', alignItems: 'center', gap: 16, padding: '12px 20px'}}><Icon k="bed" s={70} /><Label size={26}>Наше отделение</Label></Card></Pop>
        <div style={{display: 'flex', justifyContent: 'center', opacity: ease(f, sec(T('D01.rehab', -0.4)), sec(T('D01.rehab', 0.2)))}}><svg width={40} height={44}><path d="M20 4 L20 36 M8 24 L20 38 L32 24" stroke={C.teal} strokeWidth={5} fill="none" strokeLinecap="round" /></svg></div>
        <Pop at={sec(T('D01.rehab'))}>
          <Card style={{border: `3px solid ${C.teal}`, display: 'flex', alignItems: 'center', gap: 16}}>
            <svg width={100} height={100} viewBox="0 0 100 100" style={{flex: 'none'}}><rect x={14} y={30} width={72} height={60} rx={6} fill={C.tealL} stroke={C.ink} strokeWidth={4} /><rect x={40} y={14} width={20} height={20} rx={3} fill="#fff" stroke={C.ink} strokeWidth={3} /><path d="M50 18 L50 30 M44 24 L56 24" stroke={C.red} strokeWidth={3} /><g fill="#fff" stroke={C.ink} strokeWidth={2}>{[0, 1, 2].map((i) => <rect key={i} x={22 + i * 22} y={44} width={14} height={14} rx={2} />)}</g><rect x={42} y={68} width={16} height={22} fill="#fff" stroke={C.ink} strokeWidth={3} /></svg>
            <div><Label size={28} color={C.teal}>Реабилитационная больница</Label><Label size={22} color={C.mute} style={{fontWeight: 600, marginTop: 4}}>обычно — после замены сустава</Label></div>
          </Card>
        </Pop>
        <div style={{height: 10}} />
        <Box at={T('D01.pt')} bg={C.tealL}>Физиотерапевты помогают безопасно вставать, ходить и справляться с повседневными делами — чтобы подготовиться к возвращению домой</Box>
        <Box at={T('D01.home')} bg={C.dawnL}>Хотите реабилитацию на дому — скажите заранее: зависит от состояния, условий дома и больничной кассы</Box>
        <Note at={sec(T('D01.visit'))}>Если организована — физиотерапевт приходит домой</Note>
        <Note at={sec(T('D01.video'))} color={'#b8661c'} bg={C.dawnL}>Советы пригодятся и в больнице, и дома</Note>
      </Col>
    </AbsoluteFill>
  );
};

const D2: React.FC = () => {
  const items = ['Какая операция проведена', 'Лекарства: какие и как долго', 'Допустимая нагрузка на оперированную ногу', 'Уход за раной', 'Швы или скобы: 10–14 дней (если нужно снимать)', 'Когда прийти на контроль', 'Куда звонить, если дома проблема'];
  return (
    <AbsoluteFill>
      <VTag n="ВЫПИСНОЕ ПИСЬМО" id="D02" />
      <Head text="Всё важное — в выписном письме" acc={['выписном']} size={46} />
      <Col top={240}>
        <Pop at={sec(T('D02.letter'))}>
          <Card style={{borderTop: `8px solid ${C.teal}`}}>
            {items.map((t, i) => <Row key={i} t={t} at={T(['D02.r0', 'D02.r1', 'D02.r2', 'D02.r3', 'D02.r4', 'D02.r5', 'D02.r6'][i])} />)}
          </Card>
        </Pop>
        <Pop at={sec(T('D02.fam'))}>
          <Card style={{display: 'flex', alignItems: 'center', gap: 16, justifyContent: 'center'}}>
            <Icon k="doc" s={80} />
            <svg width={60} height={30} style={{flex: 'none', transform: G.rtl ? 'scaleX(-1)' : undefined}}><path d="M4 15 L46 15 M34 5 L48 15 L34 25" stroke={C.teal} strokeWidth={4} fill="none" strokeLinecap="round" /></svg>
            <Label size={27}>Покажите семейному врачу</Label>
          </Card>
        </Pop>
      </Col>
    </AbsoluteFill>
  );
};

const D3: React.FC = () => {
  const f = useCurrentFrame();
  const days = Array.from({length: 28}, (_, i) => i);
  return (
    <AbsoluteFill>
      <VTag n="ТРОМБЫ" id="D03" />
      <Head text="Профилактика тромбов продолжается дома" acc={['дома']} />
      <Col top={260} gap={12}>
        <Pop at={sec(1)}>
          <Card>
            <Label size={25} color={C.teal}>По назначенной схеме — часто около месяца</Label>
            <div style={{display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 8, marginTop: 14}}>
              {days.map((d) => {
                const on = ease(f, sec(T('D03.month')) + d * 6, sec(T('D03.month')) + d * 6 + 8);
                return <div key={d} style={{height: 40, borderRadius: 8, background: on > 0.5 ? C.teal : '#f1f3f5', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{on > 0.5 && <svg width={20} height={20}><path d="M4 10 L8 15 L16 5" stroke="#fff" strokeWidth={3} fill="none" strokeLinecap="round" /></svg>}</div>;
              })}
            </div>
            <div style={{display: 'flex', gap: 14, marginTop: 16, alignItems: 'center'}}>
              <Icon k="syringe" s={60} /><Label size={22} style={{fontWeight: 600}}>уколы эноксапарина или таблетки — точную длительность укажет врач</Label>
            </div>
          </Card>
        </Pop>
        <Box at={T('D03.skip')} bg={C.tealL}>Не пропускайте дозы и не прекращайте сами — иначе защита от тромбов уменьшится</Box>
        <Pop at={sec(T('D03.bleed'))}><Card style={{background: C.redL}}>
          <Label size={24} color={C.red}>Срочно к врачу при признаках кровотечения</Label>
          <Label size={22} style={{fontWeight: 600, marginTop: 6}}>кровь в моче · чёрный стул · необычно большие синяки · долгое кровотечение</Label>
        </Card></Pop>
        <Box at={T('D03.add')}>Не добавляйте сами аспирин, ибупрофен и другие противовоспалительные</Box>
      </Col>
    </AbsoluteFill>
  );
};

const D4: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <VTag n="РАНА" id="D04" />
      <Head text="Рана: чисто, сухо, повязка — как объяснили" acc={['чисто', 'сухо']} />
      <Center top={260}>
        <Pop at={sec(1)}>
          <Card style={{width: 300, height: 320, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
            <svg width={240} height={288} viewBox="0 0 200 240">
              <path d="M40 10 C 90 0, 160 6, 172 30 C 176 90, 160 150, 146 230 L 74 230 C 66 150, 50 90, 40 10 Z" fill="#f2d7c2" stroke="#d9b79c" strokeWidth={3} />
              <rect x={118} y={40} width={34} height={90} rx={10} fill="#fff" stroke="#cfd6dd" strokeWidth={3} />
              <rect x={126} y={52} width={18} height={66} rx={5} fill={C.tealL} />
              {[0, 1, 2, 3, 4].map((i) => {
                const t = ((f + i * 14) % 60) / 60;
                const y = 10 + t * 50; const bounce = t > 0.55;
                return <circle key={i} cx={120 + i * 8 + (bounce ? (t - 0.55) * 60 : 0)} cy={bounce ? 38 - (t - 0.55) * 40 : y} r={4} fill={C.teal2} opacity={ease(f, sec(T('D04.shower')), sec(T('D04.shower', 1))) * (1 - t * 0.6)} />;
              })}
            </svg>
          </Card>
        </Pop>
      </Center>
      <Col top={610} gap={12}>
        <Box at={T('D04.cream')}>Без кремов и мазей на рану, если не назначали</Box>
        <Box at={T('D04.shower')} bg={C.tealL}>Душ — обычно с водонепроницаемой повязкой. Когда и как — уточните у персонала</Box>
        <Pop at={sec(T('D04.bath'))}>
          <Card style={{display: 'flex', alignItems: 'center', gap: 16}}>
            <div style={{position: 'relative', width: 80, height: 80, flex: 'none'}}>
              <svg width={80} height={80} viewBox="0 0 100 100"><path d="M10 50 L90 50 L84 80 L16 80 Z" fill="#eaf6fb" stroke={C.ink} strokeWidth={4} /><path d="M20 40 C 30 30, 40 50, 50 40 C 60 30, 70 50, 80 40" stroke={C.teal2} strokeWidth={4} fill="none" /></svg>
              <div style={{position: 'absolute', left: -5, top: -5}}><Cross p={ease(f, sec(T('D04.bath', 1)), sec(T('D04.bath', 2)))} size={90} /></div>
            </div>
            <Label size={24}>Ванна, бассейн, море — только когда рана зажила и врач разрешил</Label>
          </Card>
        </Pop>
        <Box at={T('D04.inf')} bg={C.redL} color={C.red}>Почему: инфекция вокруг эндопротеза — серьёзное осложнение</Box>
      </Col>
    </AbsoluteFill>
  );
};

const D5: React.FC = () => (
  <AbsoluteFill>
    <VTag n="БОЛЬ И ОТЁК" id="D05" />
    <Head text="Боль под контролем — легче двигаться" acc={['двигаться']} size={46} />
    <Col top={260} gap={12}>
      <Pop at={sec(1)}><Card style={{display: 'flex', alignItems: 'center', gap: 14}}><Icon k="pill" s={64} /><Label size={24}>Обезболивающие — по назначенной схеме</Label></Card></Pop>
      <Box at={T('D05.ex')}>Перед упражнениями — только если так рекомендовал врач. Без дополнительных доз</Box>
      <Box at={T('D05.drowsy')} bg={C.dawnL}>Сонливость и головокружение повышают риск падения. О них и о запоре сообщите врачу</Box>
      <div style={{height: 14}} />
      <Box at={T('D05.swell')}>Отёк и синяки в первые недели — частое явление</Box>
      <Pop at={sec(T('D05.ice'))}>
        <Card style={{display: 'flex', alignItems: 'center', gap: 14, background: C.tealL}}>
          <svg width={80} height={72} viewBox="0 0 100 90" style={{flex: 'none'}}><rect x={10} y={20} width={80} height={50} rx={14} fill="#fff" stroke={C.ink} strokeWidth={4} /><path d="M30 34 L44 48 M44 34 L30 48 M58 40 L72 40 M65 33 L65 47" stroke={C.teal2} strokeWidth={4} strokeLinecap="round" /></svg>
          <Label size={24}>Лёд через ткань, 15–20 минут, несколько раз в день</Label>
        </Card>
      </Pop>
      <Box at={T('D05.sit')}>Долго сидели — пройдитесь</Box>
    </Col>
  </AbsoluteFill>
);

const D6: React.FC = () => {
  const f = useCurrentFrame();
  const rug = 1 - ease(f, sec(T('D06.rugs')), sec(T('D06.rugs', 1)));
  const cable = 1 - ease(f, sec(T('D06.cable')), sec(T('D06.cable', 1)));
  const light = ease(f, sec(T('D06.light')), sec(T('D06.light', 0.8)));
  return (
    <AbsoluteFill>
      <VTag n="БЕЗОПАСНЫЙ ДОМ" id="D06" />
      <Head text="Падение особенно опасно в первые недели" acc={['падение']} />
      <Col top={240}>
        <Pop at={sec(1)}>
          <Card style={{padding: 0, overflow: 'hidden', height: 380}}>
            <svg width={648} height={380} viewBox="0 0 640 420" preserveAspectRatio="xMidYMid meet">
              <rect width={640} height={420} fill="#fffdf9" />
              <rect x={20} y={20} width={600} height={380} fill="none" stroke="#b9c4cf" strokeWidth={6} />
              <path d="M320 20 L320 260 M320 320 L320 400" stroke="#b9c4cf" strokeWidth={6} />
              <text x={170} y={60} textAnchor="middle" fontFamily={font} fontWeight={700} fontSize={24} fill={C.mute}>спальня</text>
              <text x={470} y={60} textAnchor="middle" fontFamily={font} fontWeight={700} fontSize={24} fill={C.mute}>туалет и душ</text>
              <rect x={60} y={100} width={150} height={90} rx={10} fill="#fff" stroke="#9aa5b1" strokeWidth={3} />
              <g opacity={rug}><rect x={120} y={250} width={140} height={80} rx={10} fill="#e9b98d" /><path d="M130 260 L250 320 M250 260 L130 320" stroke="#d99b66" strokeWidth={3} /></g>
              <g opacity={cable}><path d="M40 360 C 90 330, 140 380, 200 350 C 240 330, 260 360, 300 340" stroke="#5d6875" strokeWidth={4} fill="none" /></g>
              <circle cx={300} cy={300} r={10 + 30 * light} fill="#ffd36e" opacity={0.35 * light} /><circle cx={300} cy={300} r={8} fill={light > 0.5 ? '#ffc23d' : '#cfd6dd'} />
              <path d="M210 160 C 260 220, 300 280, 400 300" stroke={C.teal} strokeWidth={5} strokeDasharray="10 8" fill="none" opacity={light} />
              <rect x={420} y={250} width={80} height={90} rx={12} fill="#fff" stroke={C.ink} strokeWidth={3} />
              <rect x={414} y={240} width={92} height={18} rx={6} fill={C.tealL} stroke={C.teal} strokeWidth={3} opacity={ease(f, sec(T('D06.seat')), sec(T('D06.seat', 1)))} />
              <path d="M560 120 L560 220" stroke={C.teal} strokeWidth={10} strokeLinecap="round" opacity={ease(f, sec(T('D06.grab')), sec(T('D06.grab', 0.8)))} />
            </svg>
          </Card>
        </Pop>
      </Col>
      <Col top={640} gap={10}>
        <Box at={T('D06.fall')} bg={C.redL} size={23} color={C.red}>Падение может привести к вывиху эндопротеза или перелому</Box>
        <Box at={T('D06.rugs')} size={23}>Убрать ковры и провода · свет ночью · вещи на уровне пояса</Box>
        <Box at={T('D06.chair')} size={23}>Стул с подлокотниками · приподнятое сиденье для унитаза · поручни в душе</Box>
        <Box at={T('D06.walker')} bg={C.tealL} size={23}>С ходунками — обе руки на ходунках, вещи в закреплённой сумке</Box>
        <Box at={T('D06.push')} size={23}>Не толкайте обычный столик на колёсах. Устойчивая обувь с нескользящей подошвой</Box>
      </Col>
    </AbsoluteFill>
  );
};

const D7: React.FC = () => {
  const f = useCurrentFrame();
  const items: {k: 'low' | 'cross' | 'turn' | 'pillow'; t: string; at: number}[] = [
    {k: 'low', t: 'сильно сгибать бедро', at: T('D07.bend')}, {k: 'cross', t: 'скрещивать ноги', at: T('D07.cross')}, {k: 'turn', t: 'поворачивать ногу внутрь', at: T('D07.turn')},
    {k: 'pillow', t: 'подушка между коленями', at: T('D07.pillow')},
  ];
  return (
    <AbsoluteFill>
      <VTag n="ДВИЖЕНИЯ" id="D07" />
      <Head text="Ограничения — только если их назначил хирург" acc={['назначил']} />
      <Col top={250}>
        <Box at={1} bg={C.dawnL} size={23}>Пока заживают ткани вокруг сустава, некоторые движения могут привести к вывиху. Нужны ли ограничения и какие — зависит от способа операции</Box>
      </Col>
      <Center top={470} gap={14}>
        {items.map((it, i) => (
          <Pop key={i} at={sec(it.at)}>
            <Card style={{width: 310, height: 230, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6, border: it.k === 'pillow' ? `3px solid ${C.ok}` : '3px solid transparent'}}>
              <Pose k={it.k} p={ease(f, sec(it.at) + 10, sec(it.at) + 30)} />
              <Label size={22} style={{textAlign: 'center'}}>{it.k === 'pillow' ? it.t : `временно не ${it.t}`}</Label>
            </Card>
          </Pop>
        ))}
      </Center>
      <Col top={990} gap={10}>
        <Note at={sec(T('D07.all'))}>Только если назначены ограничения</Note>
        <Note at={sec(T('D07.sleep'))} color={'#b8661c'} bg={C.dawnL}>Как спать — уточните у хирурга</Note>
      </Col>
    </AbsoluteFill>
  );
};

/* 3D-ролик лестницы (clay3d): подъём на слове «вверх», спуск на «вниз»; между фазами — стоп-кадр */
const Stair3D: React.FC = () => {
  const f = useCurrentFrame();
  const t = f / FPS;
  const R = T('ST.rate') || 1.5;
  const up = T('D08.up'), dn = T('D08.down');
  const u0 = T('ST.u0'), u1 = T('ST.u1'), d0 = T('ST.d0'), d1 = T('ST.d1');
  const st = t < up ? u0 : t < dn ? Math.min(u1, u0 + (t - up) * R) : Math.min(d1, d0 + (t - dn) * R);
  const W = 648, H = 1152;
  return (
    <div style={{width: W, height: 818, overflow: 'hidden', borderRadius: 24, boxShadow: '0 12px 36px rgba(70,50,20,.12)', background: '#e9edf0', direction: 'ltr'}}>
      <div style={{width: W, height: H, marginTop: -0.22 * H}}>
        <Freeze frame={Math.round(st * FPS)}>
          <OffthreadVideo src={staticFile('stairs_ru.mp4')} muted style={{width: W, height: H}} />
        </Freeze>
      </div>
    </div>
  );
};

const D8: React.FC = () => {
  const f = useCurrentFrame();
  const sw = ease(f, sec(T('D08.stairs', -0.3)), sec(T('D08.stairs', 0.3)));
  return (
  <AbsoluteFill>
    <VTag n="ХОДЬБА И ЛЕСТНИЦА" id="D08" />
    <Head text="Каждый день — короткие прогулки и упражнения" acc={['каждый']} />
    <div style={{opacity: 1 - sw}}>
    <Col top={250} gap={10}>
        <Box at={T('D08.str')} size={23}>Восстанавливают силу мышц и снижают риск осложнений от долгого лежания</Box>
        <Box at={T('D08.wb')} bg={C.redL} size={23} color={C.red}>Нагрузку на ногу — строго по указанию хирурга</Box>
        <Pop at={sec(T('D08.aids'))}>
          <Card style={{display: 'flex', gap: 16, alignItems: 'center', justifyContent: 'space-around', padding: '10px 16px'}}>
            {['ходунки', 'костыли', 'трость'].map((t) => <div key={t} style={{textAlign: 'center'}}><svg width={60} height={60} viewBox="0 0 100 100">{t === 'ходунки' ? <path d="M30 20 L70 20 M30 20 L24 90 M70 20 L76 90 M26 60 L74 60" stroke="#7f8a96" strokeWidth={7} strokeLinecap="round" fill="none" /> : t === 'костыли' ? <path d="M36 12 L36 90 M64 12 L64 90 M28 12 L44 12 M56 12 L72 12 M30 50 L42 50 M58 50 L70 50" stroke="#7f8a96" strokeWidth={6} strokeLinecap="round" fill="none" /> : <path d="M40 16 C 40 6, 62 6, 62 16 L 62 90" stroke="#7f8a96" strokeWidth={7} strokeLinecap="round" fill="none" />}</svg><Label size={21}>{t}</Label></div>)}
            <Note at={sec(T('D08.assess'))}>Выбор — с физиотерапевтом</Note>
          </Card>
        </Pop>
      </Col>
    </div>
    {sw > 0 && (
      <div style={{position: 'absolute', left: 36, right: 36, top: 240, opacity: sw, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12}}>
        <Label size={26} color={C.teal} style={{textAlign: 'center'}}>Лестница — после обучения у физиотерапевта</Label>
        <Stair3D />
        <Pop at={sec(T('D08.end', -0.3))}><Label size={21} style={{fontWeight: 600, textAlign: 'center'}}>Вверх: здоровая → оперированная и костыль. Вниз: костыль → оперированная → здоровая. Держитесь за перила</Label></Pop>
      </div>
    )}
  </AbsoluteFill>
  );
};

const D9: React.FC = () => (
  <AbsoluteFill>
    <VTag n="ОБЫЧНАЯ ЖИЗНЬ" id="D09" />
    <Head text="Руль, поездки и «у меня эндопротез»" acc={['эндопротез»']} />
    <Col top={250} gap={14}>
      <Pop at={sec(1)}><Card style={{display: 'flex', gap: 16, alignItems: 'flex-start'}}>
        <svg width={100} height={67} viewBox="0 0 120 80" style={{flex: 'none'}}><path d="M10 50 L20 26 C 24 18, 96 18, 100 26 L110 50 Z" fill={C.tealL} stroke={C.ink} strokeWidth={4} strokeLinejoin="round" /><rect x={6} y={48} width={108} height={18} rx={6} fill={C.teal} /><circle cx={30} cy={68} r={9} fill={C.ink} /><circle cx={90} cy={68} r={9} fill={C.ink} /></svg>
        <div><Label size={25}>За руль — только с разрешения врача</Label>
        <Label size={21} color={C.mute} style={{fontWeight: 600, marginTop: 8}}>уверенно управляете ногой, можете быстро затормозить, лекарства не вызывают сонливости или заторможенности</Label></div>
      </Card></Pop>
      <Pop at={sec(T('D09.long'))}><Card style={{display: 'flex', gap: 16, alignItems: 'flex-start'}}>
        <svg width={100} height={67} viewBox="0 0 120 80" style={{flex: 'none'}}><path d="M10 44 L110 30 C 118 30, 118 40, 110 42 L60 50 L40 74 L30 74 L40 52 L14 56 Z" fill={C.tealL} stroke={C.ink} strokeWidth={3.5} strokeLinejoin="round" /></svg>
        <div><Label size={25}>Долгие поездки и перелёты — обсудите с хирургом</Label>
        <Label size={21} color={C.mute} style={{fontWeight: 600, marginTop: 8}}>долгое сидение повышает риск тромбов; если разрешили — двигайте стопами и делайте остановки</Label></div>
      </Card></Pop>
      <Pop at={sec(T('D09.dent'))}><Card style={{display: 'flex', gap: 16, alignItems: 'center', background: C.dawnL}}>
        <svg width={100} height={67} viewBox="0 0 120 80" style={{flex: 'none'}}><rect x={10} y={10} width={100} height={62} rx={10} fill="#fff" stroke={C.ink} strokeWidth={3.5} /><circle cx={36} cy={36} r={12} fill={C.tealL} /><path d="M58 30 L96 30 M58 44 L86 44" stroke={C.ink} strokeWidth={4} strokeLinecap="round" /></svg>
        <Label size={25}>Сообщайте врачам и стоматологу: у вас эндопротез</Label>
      </Card></Pop>
    </Col>
  </AbsoluteFill>
);

const Level: React.FC<{c: string; bg: string; h: string; items: string; at: number}> = ({c, bg, h, items, at}) => (
  <Pop at={sec(at)}>
    <Card style={{borderInlineStart: `10px solid ${c}`, background: bg, padding: '18px 22px'}}>
      <Label size={29} color={c}>{h}</Label>
      {items.split(' · ').map((it, i) => <div key={i} style={{display: 'flex', gap: 10, marginTop: 10}}><div style={{width: 12, height: 12, borderRadius: 6, background: c, marginTop: 10, flex: 'none'}} /><Label size={24} style={{fontWeight: 600, lineHeight: 1.3}}>{it}</Label></div>)}
    </Card>
  </Pop>
);

const D10: React.FC = () => (
  <AbsoluteFill>
    <VTag n="КОГДА СРОЧНО ОБРАЩАТЬСЯ" id="D10" />
    <Head text="Три уровня срочности" acc={['срочности']} size={46} color={C.red} />
    <Col top={220} gap={16}>
      <Level c={'#b8661c'} bg={C.dawnL} h="В тот же день" items="Температура 38° и выше, озноб · Рана краснеет, выделения, гной · Новая боль, отёк или покраснение икры" at={1} />
      <Level c={C.red} bg={C.redL} h="Немедленно обратитесь за помощью. Не ходите" items="Внезапная сильная боль в бедре · Нога стала короче или необычно повернулась · Не можете на неё опереться" at={T('D10.now')} />
      <Level c={'#8e1b1b'} bg={'#f8d4d1'} h="Звоните 101" items="Внезапная одышка · Боль в груди" at={T('D10.101')} />
    </Col>
  </AbsoluteFill>
);

const D11: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <VTag n="ВОССТАНОВЛЕНИЕ" id="D11" />
      <Head text="Восстановление может занять несколько месяцев" acc={['месяцев']} />
      <div style={{position: 'absolute', left: 36, top: 270, width: 648}}>
        <svg width={648} height={70} style={{transform: G.rtl ? 'scaleX(-1)' : undefined}}>
          <rect x={6} y={30} width={636} height={12} rx={6} fill={C.line} />
          <rect x={6} y={30} width={636 * easeIO(f, sec(1), sec(8))} height={12} rx={6} fill={C.teal2} />
        </svg>
        <div style={{display: 'flex', justifyContent: 'space-between', marginTop: -24, direction: G.rtl ? 'rtl' : 'ltr'}}>
          {['недели', '1 месяц', '2 месяца', '3 месяца +'].map((t, i) => <span key={i} style={{fontFamily: font, fontWeight: 700, fontSize: 20, color: C.mute}}>{t}</span>)}
        </div>
      </div>
      <Col top={390} gap={12}>
        <Box at={T('D11.diff')}>У каждого по-разному: иногда быстро, иногда медленнее. Приходите на назначенный контроль</Box>
        <Box at={T('D11.fx')} bg={C.dawnL}>После перелома бедра — обсудите проверку на остеопороз и профилактику падений</Box>
      </Col>
      <Col top={760}>
        <Pop at={sec(T('D11.gen'))}>
          <Card style={{padding: 28, textAlign: 'center', borderTop: `8px solid ${C.teal}`}}>
            <Label size={32}>Это общие рекомендации.</Label>
            <Label size={27} color={C.mute} style={{fontWeight: 600, marginTop: 8}}>Индивидуальные указания вашего врача и медицинской команды имеют приоритет.</Label>
          </Card>
        </Pop>
      </Col>
    </AbsoluteFill>
  );
};

const MAP: Record<string, React.FC> = {D01: D1, D02: D2, D03: D3, D04: D4, D05: D5, D06: D6, D07: D7, D08: D8, D09: D9, D10: D10, D11: D11};

const Fade: React.FC<{d: number; children: React.ReactNode}> = ({d, children}) => {
  const f = useCurrentFrame();
  const o = Math.min(ease(f, 0, 10), 1 - ease(f, d - 10, d));
  const sc = 1 + 0.02 * (f / Math.max(d, 1));
  return <AbsoluteFill style={{opacity: o, transform: `scale(${sc})`, transformOrigin: '50% 40%'}}>{children}</AbsoluteFill>;
};

export const Part3V: React.FC<{withAudio?: boolean; half?: 'a' | 'b'}> = ({withAudio = true, half}) => {
  let at = 0;
  const list = TT.filter((x) => !half || (half === 'a' ? A_IDS.includes(x.id) : !A_IDS.includes(x.id)));
  const endAt = list.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 0, top: 0, width: VW, height: 1280, transform: 'scale(1.5)', transformOrigin: '0 0', overflow: 'hidden'}}>
        <PBg />
        {half === 'a' && <Sequence from={endAt} durationInFrames={END}><EndA /></Sequence>}
        {list.map((x) => {
          const d = Math.round((x.dur + PAD) * FPS);
          const Comp = MAP[x.id];
          const el = (
            <Sequence key={x.id} from={at} durationInFrames={d} name={x.id}>
              <Fade d={d}><Comp /></Fade>
              {withAudio && x.audio && <Sequence from={6}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
            </Sequence>
          );
          at += d;
          return el;
        })}
      </div>
    </AbsoluteFill>
  );
};
