import {WalkerWalk} from './motion_he';
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {C, Cap, Card, CallButton, FPS, G, Label, Note, Pop, ease, easeIO, font, K} from './ui';
import {Bed, Icon} from './Part1';
import timing from './timing2_he.json';
import CUE from './cues_thr2_he.json';

type T = {id: string; dur: number; audio?: string; k?: number}[];
const TT = timing as T;
const PAD = 0.75;
export const total2V_he = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const sec = (s: number) => Math.round(s * FPS);
// время слова в озвучке (сек от начала сцены), см. cues_thr2_*.json
const T = (k: string, d = 0) => ((CUE as Record<string, number>)[k] ?? 0) + d;
const P2TAG = 'החלפת מפרק ירך · חלק 2';

const Vital: React.FC<{k: string; t: string; at: number}> = ({k, t, at}) => {
  const f = useCurrentFrame();
  const p = ease(f, sec(at), sec(at) + 14);
  const paths: Record<string, React.ReactNode> = {
    bp: <><rect x={20} y={36} width={40} height={30} rx={8} fill={C.tealL} stroke={C.ink} strokeWidth={4} /><path d="M60 50 C 76 50, 76 28, 64 22" stroke={C.ink} strokeWidth={4} fill="none" /><circle cx={70} cy={74} r={12} fill="#fff" stroke={C.ink} strokeWidth={4} /><path d="M70 74 L76 68" stroke={C.red} strokeWidth={3} strokeLinecap="round" /></>,
    pulse: <path d="M8 50 L30 50 L38 30 L50 72 L60 40 L66 50 L92 50" stroke={C.red} strokeWidth={5} fill="none" strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - p} />,
    breath: <><path d="M50 16 L50 44" stroke={C.ink} strokeWidth={4} strokeLinecap="round" /><path d="M46 44 C 30 40, 16 56, 18 76 C 20 86, 40 88, 46 76 Z M54 44 C 70 40, 84 56, 82 76 C 80 86, 60 88, 54 76 Z" fill={C.tealL} stroke={C.ink} strokeWidth={4} strokeLinejoin="round" /></>,
    dressing: <><rect x={14} y={30} width={72} height={40} rx={10} fill="#fff" stroke={C.ink} strokeWidth={4} /><rect x={30} y={40} width={40} height={20} rx={4} fill={C.dawnL} /></>,
    leg: <><path d="M40 10 C 50 8, 62 10, 64 16 L 60 60 L 62 84 C 70 86, 78 88, 78 92 L 44 92 L 44 62 Z" fill="#f2d7c2" stroke="#c9a283" strokeWidth={3} /><path d="M70 30 L84 22 M72 44 L88 44 M70 58 L84 66" stroke={C.teal} strokeWidth={4} strokeLinecap="round" /></>,
  };
  return (
    <div style={{opacity: p, transform: `translateY(${(1 - p) * 16}px)`}}>
      <Card style={{width: 200, height: 170, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6}}>
        <svg width={86} height={86} viewBox="0 0 100 100">{paths[k]}</svg>
        <Label size={20} style={{textAlign: 'center'}}>{t}</Label>
      </Card>
    </div>
  );
};

const Sip: React.FC<{n: string; p: number}> = ({n, p}) => (
  <svg width={130} height={150} viewBox="0 0 100 115">
    <path d="M22 12 L78 12 L70 104 L30 104 Z" fill="#eaf6fb" stroke={C.ink} strokeWidth={4} strokeLinejoin="round" />
    <path d={`M${25 + (1 - p) * 0} ${30 + (1 - p) * 0} L75 30 L70 102 L30 102 Z`} fill="#bfe3f0" opacity={0.95} />
    <text x={50} y={74} textAnchor="middle" style={{direction: 'ltr', unicodeBidi: 'bidi-override'}} fontFamily={font} fontWeight={800} fontSize={n.length > 1 ? 18 : 24} fill={C.teal}>{n}</text>
  </svg>
);

const Arm: React.FC<{f: number}> = ({f}) => {
  // needle in (2.4–4.4 s), needle out (5.6–7.4 s), soft catheter remains
  const inP = easeIO(f, sec(T('P02.needle', -0.8)), sec(T('P02.needle', 1.2)));
  const outP = easeIO(f, sec(T('P02.soft', -0.6)), sec(T('P02.soft', 1.2)));
  const nx = 120 + 150 * inP - 220 * outP;
  return (
    <svg width={620} height={300} viewBox="0 0 620 300">
      <path d="M0 110 C 160 90, 420 96, 620 120 L 620 230 C 420 220, 160 230, 0 250 Z" fill="#f2d7c2" stroke="#d9b79c" strokeWidth={3} />
      <path d="M0 172 C 180 160, 420 166, 620 180" stroke="#6f8fd8" strokeWidth={16} fill="none" strokeLinecap="round" opacity={0.75} />
      {/* soft catheter in the vein */}
      <path d={`M250 158 L ${250 + 110 * inP} 166`} stroke="#f3f3f3" strokeWidth={7} strokeLinecap="round" />
      <path d={`M250 158 L ${250 + 110 * inP} 166`} stroke={C.teal2} strokeWidth={3} strokeLinecap="round" opacity={0.9} />
      {/* hub */}
      <rect x={196} y={140} width={58} height={22} rx={6} fill={C.dawn} opacity={ease(f, sec(T('P02.needle', -1.2)), sec(T('P02.needle', -0.8)))} />
      <path d="M200 140 L186 120 M250 140 L264 120" stroke={C.dawn} strokeWidth={6} strokeLinecap="round" opacity={ease(f, sec(T('P02.needle', -1.2)), sec(T('P02.needle', -0.8)))} />
      {/* metal needle */}
      <g opacity={1 - ease(f, sec(T('P02.soft', 1.0)), sec(T('P02.soft', 1.6)))}>
        <path d={`M${nx - 140} 150 L ${nx + 110} 166`} stroke="#9aa5b1" strokeWidth={3.5} strokeLinecap="round" />
        <rect x={nx - 200} y={138} width={60} height={20} rx={5} fill="#cfd6dd" />
      </g>
      {/* plaster */}
      <rect x={180} y={128} width={110} height={50} rx={10} fill="#fff" opacity={0.75 * ease(f, sec(T('P02.soft', 1.8)), sec(T('P02.soft', 2.8)))} />
    </svg>
  );
};

const Walker: React.FC<{p: number}> = ({p}) => (
  <svg width={300} height={340} viewBox="0 0 300 340">
    {/* walker */}
    <g stroke="#7f8a96" strokeWidth={7} strokeLinecap="round" fill="none">
      <path d="M170 150 L200 150 M170 150 L160 320 M200 150 L214 320 M150 220 L222 220" />
    </g>
    {/* figure: rises from sitting (p=0) to standing (p=1) */}
    <g transform={`translate(0 ${(1 - p) * 60})`}>
      <circle cx={120} cy={70} r={24} fill={C.teal} />
      <path d={`M120 96 L ${120 + 6 * p} 190`} stroke={C.teal} strokeWidth={22} strokeLinecap="round" />
      <path d={`M124 120 L 176 ${150 - 10 * (1 - p)}`} stroke={C.teal} strokeWidth={14} strokeLinecap="round" />
      <path d={`M${124 + 6 * p} 190 L ${150 - 30 * p} ${250 + 30 * p} L ${130 - 10 * p} 320`} stroke={C.teal} strokeWidth={18} strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <path d={`M${120 + 6 * p} 190 L ${100 + 4 * p} ${250 + 30 * p} L ${110 - 6 * p} 320`} stroke={C.teal2} strokeWidth={18} strokeLinecap="round" strokeLinejoin="round" fill="none" />
    </g>
  </svg>
);
/* ===== ВЕРТИКАЛЬНАЯ ВЕРСИЯ (9:16): виртуальный холст 720×1280, масштаб ×1.5 → 1080×1920 ===== */
const VW = 720;
const Col: React.FC<{top: number; gap?: number; children: React.ReactNode}> = ({top, gap = 14, children}) => (
  <div style={{position: 'absolute', left: 36, right: 36, top, display: 'flex', flexDirection: 'column', gap, direction: G.rtl ? 'rtl' : 'ltr'}}>{children}</div>
);
const Head: React.FC<{text: string; acc: string[]; size?: number; color?: string}> = ({text, acc, size = 44, color}) => (
  <div style={{position: 'absolute', left: 36, right: 36, top: 92}}><Cap text={text} size={size} accent={acc} width={VW - 72} acc={color} /></div>
);
const Center: React.FC<{top: number; gap?: number; children: React.ReactNode}> = ({top, gap = 16, children}) => (
  <div style={{position: 'absolute', left: 36, right: 36, top, display: 'flex', justifyContent: 'center', alignItems: 'center', flexWrap: 'wrap', gap, direction: G.rtl ? 'rtl' : 'ltr'}}>{children}</div>
);
const PBg: React.FC = () => {
  const f = useCurrentFrame();
  const x = 50 + Math.sin(f / 90) * 6;
  return (
    <AbsoluteFill style={{background: `radial-gradient(900px 900px at ${x}% -5%, #fff3e4 0%, ${C.bg} 45%, ${C.bg2} 100%)`}}>
      <svg width={VW} height={1280} style={{position: 'absolute', opacity: 0.5}}>
        <defs><pattern id="pdots" width={28} height={28} patternUnits="userSpaceOnUse"><circle cx={2} cy={2} r={1.3} fill="#e2d8ca" /></pattern></defs>
        <rect width={VW} height={1280} fill="url(#pdots)" />
      </svg>
    </AbsoluteFill>
  );
};
const VTag: React.FC<{n: string}> = ({n}) => {
  const f = useCurrentFrame();
  return (
    <div style={{position: 'absolute', top: 34, left: 36, right: 36, fontFamily: font, fontWeight: 700, fontSize: 17, letterSpacing: 1.2, opacity: ease(f, 0, 10), direction: G.rtl ? 'rtl' : 'ltr'}}>
      <div style={{color: C.mute, fontWeight: 600}}>{P2TAG}</div>
      <div style={{color: C.teal, marginTop: 4}}>{n}</div>
    </div>
  );
};
const VFoot: React.FC<{children: React.ReactNode}> = ({children}) => (
  <div style={{position: 'absolute', left: 36, right: 36, bottom: 40, fontFamily: font, fontSize: 16, color: C.mute, lineHeight: 1.3, direction: G.rtl ? 'rtl' : 'ltr'}}>{children}</div>
);
const Box: React.FC<{at: number; children: React.ReactNode; bg?: string; size?: number; color?: string}> = ({at, children, bg = C.white, size = 26, color}) => (
  <Pop at={sec(at)}><Card style={{background: bg}}><Label size={size} color={color}>{children}</Label></Card></Pop>
);

const P1: React.FC = () => {
  const f = useCurrentFrame();
  const x = interpolate(f, [sec(T('P01.ward', -0.2)), sec(T('P01.ward', 2.6))], [-420, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: (t) => 1 - Math.pow(1 - t, 3)});
  return (
    <AbsoluteFill>
      <VTag n="אחרי הניתוח" />
      <Head text="קודם חדר ההתאוששות, אחר כך המחלקה" acc={['ההתאוששות']} />
      <Center top={270}>
        <Pop at={sec(T('P01.rec'))}><div style={{background: C.tealL, color: C.teal, fontFamily: font, fontWeight: 800, fontSize: 26, padding: '14px 20px', borderRadius: 14}}>חדר התאוששות</div></Pop>
        <svg width={60} height={30} style={{opacity: ease(f, sec(T('P01.ward', -0.3)), sec(T('P01.ward', 0.3))), transform: G.rtl ? 'scaleX(-1)' : undefined}}><path d="M4 15 L46 15 M34 5 L48 15 L34 25" stroke={C.mute} strokeWidth={4} fill="none" strokeLinecap="round" /></svg>
        <Pop at={sec(T('P01.ward'))}><div style={{background: C.teal, color: '#fff', fontFamily: font, fontWeight: 800, fontSize: 26, padding: '14px 20px', borderRadius: 14}}>המחלקה</div></Pop>
      </Center>
      <Center top={360}><div style={{transform: `translateX(${x}px)`, opacity: ease(f, sec(T('P01.ward', -0.2)), sec(T('P01.ward', 0.4)))}}><Bed w={300} /></div></Center>
      <Center top={560} gap={14}>
        <Vital k="bp" t="לחץ דם" at={T('P01.bp')} />
        <Vital k="pulse" t="דופק" at={T('P01.pulse')} />
        <Vital k="breath" t="נשימה" at={T('P01.br')} />
        <Vital k="dressing" t="תחבושת" at={T('P01.dr')} />
        <Vital k="leg" t="תחושה ותנועה ברגל" at={T('P01.leg')} />
      </Center>
      <Center top={1000}><Note at={sec(T('P01.an'))}>ומיד, שיכוך כאבים</Note></Center>
    </AbsoluteFill>
  );
};

const P1b: React.FC = () => {
  const f = useCurrentFrame();
  const steps = [
    {t: 'לגימה קטנה אחת', at: T('P01b.sip'), k: 'glass'},
    {t: 'הפסקה קצרה', at: T('P01b.pause'), k: 'pause'},
    {t: 'עוד כמה לגימות', at: T('P01b.sips'), k: 'glass'},
    {t: 'יותר, ואוכל קל כמו מרק', at: T('P01b.soup'), k: 'soup'},
  ];
  return (
    <AbsoluteFill>
      <VTag n="שתייה ואוכל אחרי הניתוח" />
      <Head text="שותים ואוכלים כשאתם ערניים מספיק והצוות אישר" acc={['אישר']} size={40} />
      <Col top={300}>
        <Pop at={sec(T('P01b.why'))}>
          <Card style={{background: C.dawnL}}>
            <Label size={26} color={'#b8661c'}>למה לא מיד</Label>
            <Label size={23} style={{fontWeight: 600, marginTop: 6}}>חלק מהתרופות להרדמה ולשיכוך כאבים גורמות לישנוניות ולבחילה. לאדם ישנוני קשה יותר לבלוע בבטחה</Label>
          </Card>
        </Pop>
      </Col>
      <Center top={560} gap={14}>
        {steps.map((s, i) => {
          const p = ease(f, sec(s.at), sec(s.at) + 14);
          return (
            <div key={i} style={{opacity: p, transform: `translateY(${(1 - p) * 20}px)`}}>
              <Card style={{width: 310, height: 200, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-end', gap: 6, padding: '10px 10px'}}>
                {s.k === 'glass' && <Sip n={i === 0 ? '1' : '2–3'} p={1} />}
                {s.k === 'pause' && <svg width={110} height={110} viewBox="0 0 100 100"><circle cx={50} cy={52} r={34} fill="#fff" stroke={C.ink} strokeWidth={4} /><path d={`M50 52 L50 26`} stroke={C.teal} strokeWidth={5} strokeLinecap="round" transform={`rotate(${ease(f, sec(s.at), sec(s.at) + 60) * 120} 50 52)`} /><circle cx={50} cy={52} r={4} fill={C.ink} /></svg>}
                {s.k === 'soup' && <svg width={130} height={110} viewBox="0 0 100 85"><path d="M10 40 L90 40 C 90 66, 70 80, 50 80 C 30 80, 10 66, 10 40 Z" fill="#fff" stroke={C.ink} strokeWidth={4} strokeLinejoin="round" /><path d="M16 44 L84 44 C 82 58, 70 70, 50 70 C 30 70, 18 58, 16 44 Z" fill="#f6c38f" /><path d="M36 30 C 32 22, 40 18, 36 10 M52 30 C 48 22, 56 18, 52 10 M68 30 C 64 22, 72 18, 68 10" stroke={C.mute} strokeWidth={3} fill="none" strokeLinecap="round" /></svg>}
                <Label size={22} style={{textAlign: 'center'}}>{s.t}</Label>
              </Card>
            </div>
          );
        })}
      </Center>
      <Col top={1000} gap={10}>
        <Note at={sec(T('P01b.ask'))}>קודם שאלו את האחות</Note>
        <Note at={sec(T('P01b.fast'))} color={'#b8661c'} bg={C.dawnL}>אין צורך לצום זמן רב בלי סיבה</Note>
        <Pop at={sec(T('P01b.naus'))}>
          <Card style={{display: 'flex', alignItems: 'center', gap: 14, padding: '12px 18px'}}>
            <Icon k="drip" s={56} />
            <Label size={22}>יש בחילה? ספרו לאחות: יש תרופות, גם דרך הצנתר</Label>
          </Card>
        </Pop>
      </Col>
    </AbsoluteFill>
  );
};

const P2: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <VTag n="צנתר בווריד" />
      <Head text="המחט רק מנקבת, בווריד נשארת צינורית רכה" acc={['רכה']} />
      <Center top={290}><Pop at={sec(1)}><Card style={{padding: 8}}><Arm f={f} /></Card></Pop></Center>
      <Center top={640} gap={12}>
        <Note at={sec(T('P02.needle'))} color={C.mute} bg="#eef1f3">מחט מתכת</Note>
        <Note at={sec(T('P02.soft'))}>נשארת צינורית רכה</Note>
      </Center>
      <Col top={760}>
        <Pop at={sec(T('P02.move'))}><Card><Label size={26}>אפשר להזיז את היד בזהירות</Label><Label size={22} color={C.mute} style={{fontWeight: 600, marginTop: 4}}>צנתר בקפל המרפק? אל תכופפו את המרפק חזק מדי</Label></Card></Pop>
        <Box at={T('P02.blood')} bg={C.tealL} size={25}>תרופות ונוזלים נכנסים ישר לדם ופועלים מהר</Box>
        <Box at={T('P02.warn')} bg={C.redL} size={25} color={C.red}>כאב, צריבה, נפיחות, דליפה? ספרו מיד לאחות</Box>
      </Col>
    </AbsoluteFill>
  );
};

const P3: React.FC = () => {
  const f = useCurrentFrame();
  const items = ['כדורים', 'דרך הווריד', 'לפי התוכנית'];
  return (
    <AbsoluteFill>
      <VTag n="שיכוך כאבים" />
      <Head text="כמה תרופות יחד, כדי לנוח ולזוז" acc={['יחד']} />
      <Center top={320} gap={14}>
        {items.map((t, i) => (
          <Pop key={i} at={sec([T('P03.tab'), T('P03.iv'), T('P03.team')][i])}><Card style={{width: 200, textAlign: 'center'}}><Icon k={i === 1 ? 'drip' : 'pill'} s={80} /><Label size={24}>{t}</Label></Card></Pop>
        ))}
      </Center>
      <Center top={580}>
        <svg width={220} height={246} viewBox="0 0 100 112" style={{opacity: ease(f, sec(T('P03.team', -0.2)), sec(T('P03.team', 0.6)))}}>
          <path d="M50 4 L92 20 L92 56 C 92 84, 70 102, 50 108 C 30 102, 8 84, 8 56 L 8 20 Z" fill={C.tealL} stroke={C.teal} strokeWidth={5} strokeLinejoin="round" />
          <path d="M32 56 L46 70 L70 42" stroke={C.teal} strokeWidth={7} fill="none" strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - ease(f, sec(T('P03.team', 0.2)), sec(T('P03.team', 1.2)))} />
        </svg>
      </Center>
      <Center top={900} gap={18}>
        <CallButton size={64} glow={(Math.sin(f / 6) + 1) / 2} />
        <Note at={sec(T('P03.dont'))} color={'#b8661c'} bg={C.dawnL}>אל תסבלו מכאב, ספרו לאחות</Note>
      </Center>
    </AbsoluteFill>
  );
};

const P4: React.FC = () => {
  const f = useCurrentFrame();
  const doses = [0, 1, 2];
  return (
    <AbsoluteFill>
      <VTag n="זיהום וקרישי דם" />
      <Head text="מניעה: אנטיביוטיקה וזריקות נגד קרישי דם" acc={['אנטיביוטיקה', 'קרישי']} />
      <Col top={290} gap={18}>
        <Pop at={sec(T('P04.ab'))}>
          <Card>
            <Label size={26} color={C.teal}>אנטיביוטיקה דרך הווריד</Label>
            <div style={{position: 'relative', height: 120, marginTop: 14, direction: 'ltr'}}>
              <div style={{position: 'absolute', left: 10, right: 10, top: 50, height: 6, borderRadius: 3, background: C.line}} />
              <div style={{position: 'absolute', left: 0, top: 22, textAlign: 'center', width: 130, opacity: ease(f, sec(T('P04.pre')), sec(T('P04.pre', 1)))}}>
                <div style={{width: 40, height: 40, borderRadius: 20, background: C.dawn, margin: '8px auto 0'}} />
                <Label size={19} style={{marginTop: 6}}>לפני הניתוח</Label>
              </div>
              {doses.map((d) => (
                <div key={d} style={{position: 'absolute', left: 170 + d * 140, top: 22, textAlign: 'center', width: 110, opacity: ease(f, sec(T('P04.doses', d * 0.6)), sec(T('P04.doses', 0.8 + d * 0.6)))}}>
                  <div style={{width: 40, height: 40, borderRadius: 20, background: d === 2 ? '#fff' : C.teal, border: `3px ${d === 2 ? 'dashed' : 'solid'} ${C.teal}`, margin: '8px auto 0'}} />
                  <Label size={19} style={{marginTop: 6}}>+{(d + 1) * 8} שע׳</Label>
                </div>
              ))}
            </div>
            <Label size={21} color={C.mute} style={{fontWeight: 600}}>אחרי הניתוח בדרך כלל 2–3 מנות, בערך כל 8 שעות, לפי הוראת הרופא</Label>
          </Card>
        </Pop>
        <Pop at={sec(T('P04.clot'))}>
          <Card>
            <Label size={26} color={C.teal}>נגד קרישי דם: אנוקסאפרין</Label>
            <div style={{display: 'flex', alignItems: 'center', gap: 12, marginTop: 10}}>
              <svg width={200} height={100} viewBox="0 0 240 120" style={{flex: 'none'}}>
                <rect x={30} y={44} width={130} height={30} rx={8} fill="#fff" stroke={C.ink} strokeWidth={3.5} />
                <rect x={40} y={50} width={80} height={18} rx={3} fill={C.tealL} />
                <path d="M160 59 L210 59" stroke={C.ink} strokeWidth={2} />
                <path d="M30 59 L8 59 M8 46 L8 72" stroke={C.ink} strokeWidth={4} strokeLinecap="round" />
                <rect x={150} y={48} width={14} height={22} rx={3} fill="#cfd6dd" />
              </svg>
              <div>
                <Label size={23}>קלקסן או קרוסיה</Label>
                <Label size={20} color={C.mute} style={{fontWeight: 600}}>מזרק ממולא מראש, מחט דקה, זריקה מתחת לעור הבטן</Label>
              </div>
            </div>
            <div style={{display: 'flex', gap: 12, marginTop: 12}}>
              <Note at={sec(T('P04.h12'))}>בערך 12 שעות אחרי הניתוח</Note>
            </div>
          </Card>
        </Pop>
      </Col>
      <Col top={840} gap={10}>
        <Note at={sec(T('P04.exact'))} color={'#b8661c'} bg={C.dawnL}>את מועד הזריקה הראשונה קובע הרופא</Note>
        <Note at={sec(T('P04.after'))}>לפעמים גם אחרי השחרור</Note>
      </Col>
    </AbsoluteFill>
  );
};

const P5: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <VTag n="יום הניתוח" />
      <Head text="ביום הניתוח נשארים במיטה, המעקות מורמים" acc={['המעקות']} />
      <Col top={280}>
        <Pop at={sec(1)}>
          <Card style={{height: 300, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative'}}>
            <Bed w={400} rails={ease(f, sec(T('P05.rails')), sec(T('P05.rails', 1.5)))} />
            <div style={{position: 'absolute', right: 26, top: 22}}><CallButton size={60} glow={(Math.sin(f / 6) + 1) / 2 * ease(f, sec(T('P05.call')), sec(T('P05.call', 1)))} /></div>
          </Card>
        </Pop>
      </Col>
      <Col top={610} gap={12}>
        <Box at={T('P05.rails')} bg={C.tealL} size={24}>המעקות תמיד מורמים כל עוד אתם במיטה: פחות סיכון ליפול מהמיטה</Box>
        <Box at={T('P05.climb')} bg={C.redL} size={24} color={C.red}>אל תטפסו מעל המעקות ואל תורידו אותם בעצמכם</Box>
        <Box at={T('P05.call')} size={24}>לעזרה לחצו על לחצן הקריאה</Box>
        <Box at={T('P05.toilet')} size={24}>לשירותים: הצוות יעזור או יביא בקבוק שתן או סיר</Box>
        <Box at={T('P05.first')} bg={C.dawnL} size={23}>הקימה הראשונה בדרך כלל למחרת, עם הפיזיותרפיסט, כשזה בטוח</Box>
      </Col>
    </AbsoluteFill>
  );
};

const P6: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <VTag n="למחרת" />
      <Head text="צילום רנטגן לביקורת וצעדים ראשונים" acc={['ראשונים']} />
      <div style={{position: 'absolute', left: 36, right: 36, top: 250, display: 'flex', gap: 14, alignItems: 'flex-start', direction: 'ltr'}}>
        <Pop at={sec(T('P06.xray'))}>
          <div>
            <Card style={{background: '#111', padding: 8}}>
              <div style={{width: 300, height: 340, overflow: 'hidden', borderRadius: 12}}>
                <Img src={staticFile('Hip_replacement_xray_3684-PH.jpg')} style={{width: '100%', height: '100%', objectFit: 'cover', transform: `scale(${interpolate(f, [0, 300], [1, 1.06], {extrapolateRight: 'clamp'})})`}} />
              </div>
            </Card>
            <div style={{width: 316, marginTop: 8, fontFamily: font, fontSize: 13, color: C.mute, opacity: ease(f, sec(T('P06.xray', 1)), sec(T('P06.xray', 2))), direction: G.rtl ? 'rtl' : 'ltr'}}>דוגמה לצילום רנטגן אחרי החלפת מפרק ירך. התמונה: נחלת הכלל (X-ray Image ID 3684)</div>
          </div>
        </Pop>
        <Pop at={sec(T('P06.pt'))}>
          <Card style={{width: 318, height: 420, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '10px 6px'}}>
            {f < sec(T('P06.steps')) ? <Walker p={easeIO(f, sec(T('P06.stand', -0.4)), sec(T('P06.steps', -0.2)))} /> : <div style={{width: 300, height: 330, display: 'flex', alignItems: 'center', opacity: ease(f, sec(T('P06.steps')), sec(T('P06.steps', 0.5)))}}><div style={{transform: 'scale(0.72)', transformOrigin: '0 50%'}}><WalkerWalk from={sec(T('P06.steps'))} /></div></div>}
            <Label size={21} style={{textAlign: 'center', direction: G.rtl ? 'rtl' : 'ltr'}}>הפיזיותרפיסט יעזור לשבת, לעמוד וללכת</Label>
          </Card>
        </Pop>
      </div>
      <Col top={760}>
        <Box at={T('P06.early')} bg={C.tealL} size={24}>תנועה מוקדמת עוזרת להחלמה ומקטינה את הסיכון לסיבוכים משכיבה ממושכת</Box>
        <Box at={T('P06.safe')} bg={C.redL} size={24} color={C.red}>קמים והולכים רק בבטחה ובעזרת הצוות</Box>
      </Col>
    </AbsoluteFill>
  );
};

const P7: React.FC = () => {
  const f = useCurrentFrame();
  const cyc = (Math.sin((f - sec(T('P07.mouth'))) / 22) + 1) / 2 * ease(f, sec(T('P07.mouth')), sec(T('P07.mouth', 1)));
  return (
    <AbsoluteFill>
      <VTag n="נשימה" />
      <Head text="מכשיר לתרגול נשימה: שאיפה איטית ועמוקה" acc={['שאיפה']} />
      <Center top={270}>
        <Pop at={sec(T('P07.dev'))}>
          <Card style={{width: 340, height: 340, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
            <svg width={260} height={300} viewBox="0 0 200 230">
              <rect x={40} y={40} width={50} height={150} rx={12} fill="#f4f9fb" stroke={C.ink} strokeWidth={4} />
              <circle cx={65} cy={176 - 120 * cyc} r={16} fill={C.dawn} />
              <rect x={36} y={190} width={58} height={20} rx={6} fill="#cfd6dd" stroke={C.ink} strokeWidth={3} />
              <path d="M94 200 C 140 200, 150 170, 150 130 L 150 90" stroke="#9aa5b1" strokeWidth={10} fill="none" strokeLinecap="round" />
              <rect x={138} y={66} width={24} height={30} rx={6} fill={C.teal} />
              <path d="M120 40 L140 60" stroke={C.teal} strokeWidth={4} strokeLinecap="round" opacity={cyc} />
            </svg>
          </Card>
        </Pop>
      </Center>
      <Col top={650} gap={12}>
        <Box at={T('P07.sit')} size={24}>שבו במיטה או על כיסא ובצעו תרגילי נשימה</Box>
        <Box at={T('P07.mouth')} bg={C.tealL} size={24}>נושמים פנימה דרך הפומית לאט ועמוק, כפי שהצוות יראה</Box>
        <Box at={T('P07.lungs')} size={24}>זה עוזר לריאות להתרחב טוב יותר</Box>
        <Box at={T('P07.comb')} bg={C.dawnL} size={23}>הכי טוב: יחד עם שיכוך כאבים ותנועה מוקדמת ובטוחה</Box>
      </Col>
    </AbsoluteFill>
  );
};

const P8: React.FC = () => {
  const f = useCurrentFrame();
  const ik = ['P08.i0', 'P08.i1', 'P08.i2', 'P08.i3', 'P08.i4', 'P08.i5'];
  const items = ['הכאב התגבר פתאום מאוד', 'חולשה או נימול חדשים ברגל', 'כף הרגל התקררה', 'התחבושת נרטבה מאוד', 'כאב או נפיחות חדשים בשוק', 'קשה לנשום או כאב בחזה'];
  return (
    <AbsoluteFill>
      <VTag n="קראו מיד לאחות" />
      <Center top={130}><CallButton size={84} glow={1} /></Center>
      <div style={{position: 'absolute', left: 36, right: 36, top: 250}}><Cap text="לחצו מיד על לחצן הקריאה אם:" size={44} acc={C.red} accent={['מיד']} width={VW - 72} /></div>
      <Col top={420}>
        <Pop at={sec(T('P08.call'))}>
          <Card style={{borderInlineStart: `10px solid ${C.red}`, display: 'flex', flexDirection: 'column', gap: 20, padding: '28px 28px'}}>
            {items.map((t, i) => (
              <div key={i} style={{display: 'flex', alignItems: 'center', gap: 14, opacity: ease(f, sec(T(ik[i])), sec(T(ik[i])) + 8), transform: `translateY(${(1 - ease(f, sec(T(ik[i])), sec(T(ik[i])) + 10)) * 14}px)`}}>
                <div style={{width: 16, height: 16, borderRadius: 8, background: C.red, flex: 'none'}} />
                <Label size={29}>{t}</Label>
              </div>
            ))}
          </Card>
        </Pop>
      </Col>
    </AbsoluteFill>
  );
};

const P9: React.FC = () => (
  <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', padding: '0 36px'}}>
    <Pop at={4}>
      <Card style={{padding: 36, textAlign: 'center', borderTop: `8px solid ${C.teal}`}}>
        <Label size={36} style={{lineHeight: 1.3}}>אלה המלצות כלליות.</Label>
        <Label size={30} color={C.mute} style={{fontWeight: 600, marginTop: 10, lineHeight: 1.3}}>ההוראות האישיות של הרופא ושל הצוות הרפואי קודמות להן.</Label>
      </Card>
    </Pop>
    <div style={{marginTop: 34, textAlign: 'center'}}><Note at={sec(T('P09.next'))} color={'#b8661c'} bg={C.dawnL}>בהמשך, חלק 3: השחרור, השיקום והחזרה הביתה</Note></div>
  </AbsoluteFill>
);

const MAP: Record<string, React.FC> = {P01: P1, P01b: P1b, P02: P2, P03: P3, P04: P4, P05: P5, P06: P6, P07: P7, P08: P8, P09: P9};

const Fade: React.FC<{d: number; children: React.ReactNode}> = ({d, children}) => {
  const f = useCurrentFrame();
  const o = Math.min(ease(f, 0, 10), 1 - ease(f, d - 10, d));
  const sc = 1 + 0.02 * (f / Math.max(d, 1));
  return <AbsoluteFill style={{opacity: o, transform: `scale(${sc})`, transformOrigin: '50% 40%'}}>{children}</AbsoluteFill>;
};

export const Part2V_he: React.FC<{withAudio?: boolean; only?: string}> = ({withAudio = true, only}) => {
  G.rtl = true;
  let at = 0;
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 0, top: 0, width: VW, height: 1280, transform: 'scale(1.5)', transformOrigin: '0 0', overflow: 'hidden'}}>
        <PBg />
        {TT.map((x) => {
          const d = Math.round((x.dur + PAD) * FPS);
          const Comp = MAP[x.id];
          const el = (
            <Sequence key={x.id} from={at} durationInFrames={d} name={x.id}>
              <Fade d={d}><K k={x.k}><Comp /></K></Fade>
              {withAudio && x.audio && <Sequence from={6}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
            </Sequence>
          );
          at += d;
          return el;
        })}
      </div>
    </AbsoluteFill>
  );
};
