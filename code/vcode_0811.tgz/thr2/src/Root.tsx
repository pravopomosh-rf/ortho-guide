import {Part3V, total3aV, total3bV} from './Part3V';
import {Part3V_he, total3aV_he, total3bV_he} from './Part3V_he';
import {Part3V_ar, total3aV_ar, total3bV_ar} from './Part3V_ar';
import {Part3V_en, total3aV_en, total3bV_en} from './Part3V_en';
import {Part2V_en, total2V_en} from './Part2V_en';
import {Part2V_ar, total2V_ar} from './Part2V_ar';
import {Part2V_he, total2V_he} from './Part2V_he';
import {Part2V, total2V} from './Part2V';
import React from 'react';
import {Composition} from 'remotion';
import {MTest} from './MTest';
import {Hip3D} from './Hip3D';
import {Part1, total1} from './Part1';
import {Part2, total2} from './Part2';
import {Part3, total3, total3a, total3b} from './Part3';
import {Part2_he, total2_he} from './Part2_he';
import {Part3_he, total3_he, total3a_he, total3b_he} from './Part3_he';
import {Part2_ar, total2_ar} from './Part2_ar';
import {Part3_ar, total3_ar, total3a_ar, total3b_ar} from './Part3_ar';
import {Part2_en, total2_en} from './Part2_en';
import {Part3_en, total3_en, total3a_en, total3b_en} from './Part3_en';


const Clip: React.FC<any> = (p) => <Hip3D mode={p.mode} len={p.len} start={p.start} spin={p.spin} width={p.w} height={p.h} />;

export const Root: React.FC = () => (
  <>
    <Composition id="Part3bV-en" component={Part3V_en} durationInFrames={total3bV_en()} fps={30} width={1080} height={1920} defaultProps={{half: 'b'}} />
    <Composition id="Part3bV-ar" component={Part3V_ar} durationInFrames={total3bV_ar()} fps={30} width={1080} height={1920} defaultProps={{half: 'b'}} />
    <Composition id="Part3bV-he" component={Part3V_he} durationInFrames={total3bV_he()} fps={30} width={1080} height={1920} defaultProps={{half: 'b'}} />
    <Composition id="Part3bV" component={Part3V} durationInFrames={total3bV()} fps={30} width={1080} height={1920} defaultProps={{half: 'b'}} />
    <Composition id="Part3aV-en" component={Part3V_en} durationInFrames={total3aV_en()} fps={30} width={1080} height={1920} defaultProps={{half: 'a'}} />
    <Composition id="Part3aV-ar" component={Part3V_ar} durationInFrames={total3aV_ar()} fps={30} width={1080} height={1920} defaultProps={{half: 'a'}} />
    <Composition id="Part3aV-he" component={Part3V_he} durationInFrames={total3aV_he()} fps={30} width={1080} height={1920} defaultProps={{half: 'a'}} />
    <Composition id="Part3aV" component={Part3V} durationInFrames={total3aV()} fps={30} width={1080} height={1920} defaultProps={{half: 'a'}} />
    <Composition id="Part2V-en" component={Part2V_en} durationInFrames={total2V_en()} fps={30} width={1080} height={1920} />
    <Composition id="Part2V-ar" component={Part2V_ar} durationInFrames={total2V_ar()} fps={30} width={1080} height={1920} />
    <Composition id="Part2V-he" component={Part2V_he} durationInFrames={total2V_he()} fps={30} width={1080} height={1920} />
    <Composition id="Part2V" component={Part2V} durationInFrames={total2V()} fps={30} width={1080} height={1920} />
    <Composition id="MTest" component={MTest} durationInFrames={260} fps={30} width={1000} height={360} />
    <Composition id="Part1" component={Part1} durationInFrames={total1()} fps={30} width={1280} height={720} />
    <Composition id="Part2" component={Part2} durationInFrames={total2()} fps={30} width={1280} height={720} />
    <Composition id="Part3" component={Part3} durationInFrames={total3()} fps={30} width={1280} height={720} />
    <Composition id="Part3a" component={Part3} durationInFrames={total3a()} fps={30} width={1280} height={720} defaultProps={{half: 'a'}} />
    <Composition id="Part3b" component={Part3} durationInFrames={total3b()} fps={30} width={1280} height={720} defaultProps={{half: 'b'}} />
    <Composition id="Part2-he" component={Part2_he} durationInFrames={total2_he()} fps={30} width={1280} height={720} />
    <Composition id="Part3a-he" component={Part3_he} durationInFrames={total3a_he()} fps={30} width={1280} height={720} defaultProps={{half: 'a'}} />
    <Composition id="Part3b-he" component={Part3_he} durationInFrames={total3b_he()} fps={30} width={1280} height={720} defaultProps={{half: 'b'}} />
    <Composition id="Part2-ar" component={Part2_ar} durationInFrames={total2_ar()} fps={30} width={1280} height={720} />
    <Composition id="Part3a-ar" component={Part3_ar} durationInFrames={total3a_ar()} fps={30} width={1280} height={720} defaultProps={{half: 'a'}} />
    <Composition id="Part3b-ar" component={Part3_ar} durationInFrames={total3b_ar()} fps={30} width={1280} height={720} defaultProps={{half: 'b'}} />
    <Composition id="Part2-en" component={Part2_en} durationInFrames={total2_en()} fps={30} width={1280} height={720} />
    <Composition id="Part3a-en" component={Part3_en} durationInFrames={total3a_en()} fps={30} width={1280} height={720} defaultProps={{half: 'a'}} />
    <Composition id="Part3b-en" component={Part3_en} durationInFrames={total3b_en()} fps={30} width={1280} height={720} defaultProps={{half: 'b'}} />
    <Composition id="Clip" component={Clip} durationInFrames={1000} fps={30} width={600} height={600}
      defaultProps={{mode: 'prosthesis', len: 240, start: 0, spin: 0.5, w: 600, h: 600}}
      calculateMetadata={({props}: any) => ({width: props.w, height: props.h})} />
  </>
);
