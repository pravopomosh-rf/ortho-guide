import React from 'react';
import {camFor, projectPt, LBL} from './Hip3D';
import {camLeg, project, arrowTail, PT, LegMode} from './Leg3D';
import {AbsoluteFill, Img, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig, Easing} from 'remotion';

type T = {id: string; dur: number; audio?: string}[];
const FPS = 30;
export const totalFrames = (t: T) => t.reduce((s, x) => s + Math.round(x.dur * FPS), 0);

const INK = '#1d2433';
const ACC = '#1f6fd1';
const MUTE = '#5b6478';
const AMBER = '#d98a00';
const RED = '#c62828';
const GREEN = '#2e8b57';
const PURPLE = '#6b4fb8';
const font = 'Inter, DejaVu Sans, sans-serif';

const Bg: React.FC = () => (
  <AbsoluteFill style={{background: '#fbfcfe', backgroundImage: 'radial-gradient(#d3d9e4 1.3px, transparent 1.3px)', backgroundSize: '26px 26px'}} />
);
const ease = (f: number, a: number, b: number) =>
  interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});

const Cap: React.FC<{text: string; at?: number; size?: number; color?: string; accent?: string[]; width?: number; step?: number; acc?: string; center?: boolean}> = ({
  text, at = 0, size = 44, color = INK, accent = [], width = 1100, step = 3, acc = ACC, center,
}) => {
  const f = useCurrentFrame();
  const words = text.split(' ');
  return (
    <div style={{display: 'flex', flexWrap: 'wrap', justifyContent: center ? 'center' : 'flex-start', gap: `0 ${size * 0.28}px`, maxWidth: width, fontFamily: font, fontWeight: 800, fontSize: size, lineHeight: 1.18, color}}>
      {words.map((w, i) => {
        const p = ease(f, at + i * step, at + i * step + 8);
        const isAcc = accent.some((a) => w.toLowerCase().replace(/[«»,.:—]/g, '').startsWith(a.toLowerCase()));
        const u = ease(f, at + i * step + 6, at + i * step + 20);
        return (
          <span key={i} style={{position: 'relative', display: 'inline-block', opacity: p, filter: `blur(${(1 - p) * 8}px)`, transform: `translateY(${(1 - p) * 14}px)`, color: isAcc ? acc : color}}>
            {w}
            {isAcc && (
              <svg style={{position: 'absolute', left: 0, bottom: -size * 0.12, width: '100%', height: size * 0.25, overflow: 'visible'}} viewBox="0 0 100 10" preserveAspectRatio="none">
                <path d="M2 6 C 25 2, 55 9, 98 4" stroke={acc} strokeWidth={3.5} fill="none" strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - u} vectorEffect="non-scaling-stroke" />
              </svg>
            )}
          </span>
        );
      })}
    </div>
  );
};

const Pop: React.FC<{at?: number; children: React.ReactNode; style?: React.CSSProperties}> = ({at = 0, children, style}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: f - at, fps, config: {damping: 14, mass: 0.7}});
  return <div style={{opacity: Math.min(1, s * 1.4), transform: `translateY(${(1 - s) * 30}px) scale(${0.92 + 0.08 * s})`, ...style}}>{children}</div>;
};
const Credit: React.FC<{children: React.ReactNode; at?: number}> = ({children, at = 0}) => {
  const f = useCurrentFrame();
  return <div style={{fontFamily: font, fontSize: 14, color: MUTE, opacity: ease(f, at, at + 10), marginTop: 8, lineHeight: 1.35}}>{children}</div>;
};
const Source: React.FC<{children: React.ReactNode; at?: number}> = ({children, at = 0}) => {
  const f = useCurrentFrame();
  return (
    <div style={{position: 'absolute', left: 60, bottom: 24, right: 60, fontFamily: font, fontSize: 16, color: MUTE, opacity: ease(f, at, at + 12)}}>
      <b style={{color: INK}}>Источник: </b>{children}
    </div>
  );
};
const Card: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
  <div style={{background: '#fff', borderRadius: 22, boxShadow: '0 10px 34px rgba(30,40,70,.12)', padding: 16, ...style}}>{children}</div>
);
const Tag: React.FC<{n: string; c?: string}> = ({n, c = ACC}) => (
  <div style={{position: 'absolute', top: 30, left: 60, fontFamily: font, fontWeight: 700, fontSize: 18, color: c, letterSpacing: 1.5}}>{n}</div>
);
const Pic: React.FC<{src: string; w: number; h: number; at?: number; zoom?: boolean; fit?: 'cover' | 'contain'; pos?: string}> = ({src, w, h, at = 0, zoom = true, fit = 'contain', pos = 'center'}) => {
  const f = useCurrentFrame();
  const z = zoom ? interpolate(f - at, [0, 300], [1, 1.08], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) : 1;
  return (
    <div style={{width: w, height: h, overflow: 'hidden', borderRadius: 14, background: fit === 'contain' ? '#fff' : '#000'}}>
      <Img src={staticFile(src)} style={{width: '100%', height: '100%', objectFit: fit, objectPosition: pos, transform: `scale(${z})`}} />
    </div>
  );
};
const Seq3D: React.FC<{name: string; n: number; w: number; h: number; off?: number}> = ({name, n, w, h, off = 0}) => {
  const f = useCurrentFrame();
  const i = Math.max(0, Math.min(n - 1, f - off));
  return <Img src={staticFile(`clips/${name}/${i}.png`)} style={{width: w, height: h, display: 'block'}} />;
};
const Swap: React.FC<{from: number; to?: number; children: React.ReactNode}> = ({from, to = 1e9, children}) => {
  const f = useCurrentFrame();
  if (f < from || f >= to + 8) return null;
  const o = Math.min(from === 0 ? 1 : ease(f, from, from + 8), 1 - ease(f, to, to + 8));
  return <AbsoluteFill style={{opacity: o}}>{children}</AbsoluteFill>;
};
const BP3D = '3D: атлас BodyParts3D, © 2008 Life Science Integrated Database Center, лицензия CC BY-SA 2.1 Япония. Стрелки, капсула и зоны — упрощённые схемы';
const Foot3D: React.FC<{w?: number; left?: number}> = ({w = 560, left = 60}) => (
  <div style={{position: 'absolute', left, bottom: 18, width: w, fontFamily: font, fontSize: 13, color: MUTE, lineHeight: 1.3}}>{BP3D}</div>
);

const Pin: React.FC<{mode: LegMode; pt: number[]; text: string; from: number; to?: number; w: number; h: number; color?: string; dx?: number; dy?: number; size?: number}> = ({mode, pt, text, from, to = 1e9, w, h, color = INK, dx = 60, dy = 0, size = 22}) => {
  const f = useCurrentFrame();
  const o = Math.min(ease(f, from, from + 10), 1 - ease(f, to, to + 8));
  if (o <= 0) return null;
  const q = project(camLeg(mode, f), pt, w, h);
  const left = dx < 0;
  return (
    <div style={{position: 'absolute', left: q.x, top: q.y + dy - 16, opacity: o, display: 'flex', alignItems: 'center', flexDirection: left ? 'row-reverse' : 'row', transform: left ? 'translateX(-100%)' : undefined}}>
      <div style={{width: 8, height: 8, borderRadius: 4, background: color}} />
      <div style={{width: Math.abs(dx) * o, height: 3, background: color}} />
      <div style={{fontFamily: font, fontWeight: 800, fontSize: size, color, background: 'rgba(255,255,255,.94)', padding: '4px 10px', borderRadius: 8, whiteSpace: 'nowrap'}}>{text}</div>
    </div>
  );
};
const Stage: React.FC<{w: number; h: number; x: number; y: number; children: React.ReactNode}> = ({w, h, x, y, children}) => {
  const f = useCurrentFrame();
  const p = ease(f, 0, 14);
  return <div style={{position: 'absolute', left: x, top: y, width: w, height: h, opacity: p, transform: `scale(${0.94 + 0.06 * p})`}}>{children}</div>;
};

/* ============ old scenes (kept, with requested fixes) ============ */

const PLabel: React.FC<{pt: number[]; text: string; from: number; to: number; w: number; h: number; color?: string; dx?: number}> = ({pt, text, from, to, w, h, color = INK, dx = 70}) => {
  const f = useCurrentFrame();
  const o = Math.min(ease(f, from, from + 12), 1 - ease(f, to, to + 10));
  if (o <= 0) return null;
  const q = projectPt(camFor('anatomy', f, 0.5), pt, w, h);
  return (
    <div style={{position: 'absolute', left: q.x, top: q.y - 15, opacity: o, display: 'flex', alignItems: 'center'}}>
      <div style={{width: 7, height: 7, borderRadius: 4, background: color, marginLeft: -3.5}} />
      <div style={{width: dx * o, height: 2.5, background: color}} />
      <div style={{fontFamily: font, fontWeight: 700, fontSize: 20, color, background: 'rgba(255,255,255,.92)', padding: '4px 10px', borderRadius: 8, whiteSpace: 'nowrap'}}>{text}</div>
    </div>
  );
};

const V1: React.FC<{d: number}> = ({d}) => {
  const W = 600, H = 640;
  return (
    <AbsoluteFill style={{padding: '80px 60px'}}>
      <Tag n="ДЛЯ ПАЦИЕНТОВ ПОСЛЕ ОПЕРАЦИИ" />
      <div style={{position: 'absolute', left: 60, top: 170, width: 560}}>
        <Cap text="Замена тазобедренного сустава передним доступом: восстановление" size={54} accent={['передним', 'восстановление']} width={560} step={4} />
      </div>
      <div style={{position: 'absolute', left: 620, top: 50}}>
        <div style={{position: 'relative', width: W, height: H}}>
          <Seq3D name="c1" n={d} w={W} h={H} />
          <PLabel pt={LBL.ilium} text="тазовая кость" from={12} to={76} w={W} h={H} />
          <PLabel pt={LBL.head} text="тазобедренный сустав" from={20} to={76} w={W} h={H} color={ACC} />
          <PLabel pt={LBL.femur} text="бедренная кость" from={28} to={76} w={W} h={H} />
          <PLabel pt={LBL.knee} text="колено" from={36} to={76} w={W} h={H} />
          <PLabel pt={LBL.shin} text="голень" from={44} to={76} w={W} h={H} />
          <PLabel pt={LBL.foot} text="стопа" from={52} to={76} w={W} h={H} />
          <PLabel pt={[0.55, 0.45, 0.75]} text="хрящ" from={156} to={9999} w={W} h={H} color={ACC} dx={110} />
          <PLabel pt={[-0.3, -1.6, 0.2]} text="бедренная кость" from={168} to={9999} w={W} h={H} dx={150} />
        </div>
      </div>
      <Foot3D w={520} />
    </AbsoluteFill>
  );
};

// s2: 0:11–0:20 — HIP X-ray (not knee), then 3D arthrosis of the hip
const V2: React.FC<{d: number}> = ({d}) => {
  const a = Math.min(d - 60, 9 * FPS);
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{padding: '80px 60px'}}>
      <Tag n="ЧТО ТАКОЕ АРТРОЗ" />
      <div style={{marginTop: 26}}>
        <Cap text="Артроз поражает весь сустав. Состояние у людей различается" size={44} accent={['весь', 'различается']} />
      </div>
      <Swap from={0} to={a}>
        <div style={{position: 'absolute', left: 0, right: 0, top: 210, display: 'flex', gap: 40, justifyContent: 'center', alignItems: 'center'}}>
          <Pop at={4}>
            <Card style={{background: '#111', padding: 10}}>
              <div style={{position: 'relative'}}>
                <Pic src="Severe_Tonnis3_hip_OA_xray.jpg" w={400} h={400} />
                <svg width={400} height={400} style={{position: 'absolute', left: 0, top: 0}}>
                  <ellipse cx={250} cy={150} rx={95} ry={60} fill="none" stroke="#ffb020" strokeWidth={4} strokeDasharray="10 7" opacity={ease(f, 40, 55)} />
                </svg>
              </div>
            </Card>
          </Pop>
          <Pop at={14} style={{width: 470}}>
            <div style={{fontFamily: font, fontWeight: 800, fontSize: 38, color: INK, lineHeight: 1.15}}>Тазобедренный сустав при выраженном артрозе</div>
            <div style={{fontFamily: font, fontSize: 22, color: MUTE, marginTop: 12}}>Рентгеновский снимок: суставная щель сужена, края кости изменены</div>
            <Credit>Снимок: Mikael Häggström. Общественное достояние (CC0). Викисклад</Credit>
          </Pop>
        </div>
        <Source at={20}>Национальный институт артрита, костно-мышечных и кожных заболеваний США; Американская академия ортопедических хирургов</Source>
      </Swap>
      <Swap from={a}>
        <div style={{position: 'absolute', left: 340, top: 200}}>
          <Seq3D name="c2" n={d - a} off={a} w={600} h={470} />
        </div>
        <div style={{position: 'absolute', left: 60, top: 320, width: 270, fontFamily: font, fontSize: 22, fontWeight: 700, color: INK}}>Хрящ истончается, появляются костные разрастания</div>
        <Foot3D />
      </Swap>
    </AbsoluteFill>
  );
};

// s3: only the replacement part (phrase about approaches removed)
const V3: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const steps = ['Повреждённые части убирают', 'Чашка — во впадину', 'Ножка — в бедренную кость', 'Головка — на ножку'];
  const cur = Math.min(3, Math.floor(interpolate(f, [d * 0.06, d * 0.94], [0, 4], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})));
  return (
    <AbsoluteFill style={{padding: '80px 60px'}}>
      <Tag n="ЭНДОПРОТЕЗ" />
      <div style={{position: 'absolute', left: 60, top: 140, width: 540}}>
        <Cap text="Повреждённые части сустава заменяют искусственными" size={42} accent={['искусственными']} width={540} />
        <div style={{marginTop: 30}}>
          {steps.map((s, i) => (
            <div key={i} style={{display: 'flex', gap: 14, alignItems: 'center', fontFamily: font, fontSize: 25, fontWeight: 600, marginTop: 14, color: i <= cur ? INK : '#b7bfcc'}}>
              <div style={{width: 36, height: 36, borderRadius: 18, background: i < cur ? ACC : '#fff', border: `3px solid ${i <= cur ? ACC : '#d4dae4'}`, color: i < cur ? '#fff' : ACC, fontWeight: 800, fontSize: 18, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{i < cur ? '✓' : i + 1}</div>
              {s}
            </div>
          ))}
        </div>
      </div>
      <div style={{position: 'absolute', left: 620, top: 70}}>
        <Seq3D name="c3" n={d} w={620} h={600} />
      </div>
      <Foot3D />
    </AbsoluteFill>
  );
};

const Curves: React.FC<{at: number}> = ({at}) => {
  const f = useCurrentFrame();
  const p = ease(f, at, at + 70);
  const W = 560, H = 250;
  const ant = (x: number) => H - 30 - (H - 70) * (1 - Math.exp(-x * 3.2));
  const pos = (x: number) => H - 30 - (H - 70) * (1 - Math.exp(-x * 2.3));
  const path = (fn: (x: number) => number) => {
    let s = '';
    for (let i = 0; i <= 60; i++) {
      const x = i / 60;
      if (x > p) break;
      s += `${i ? 'L' : 'M'}${40 + x * (W - 60)} ${fn(x)} `;
    }
    return s;
  };
  const x6 = 0.22;
  const m = ease(f, at + 30, at + 44);
  return (
    <svg width={W} height={H + 30} viewBox={`0 0 ${W} ${H + 30}`}>
      <line x1={40} y1={H - 30} x2={W - 10} y2={H - 30} stroke="#c3cad6" strokeWidth={2} />
      <line x1={40} y1={20} x2={40} y2={H - 30} stroke="#c3cad6" strokeWidth={2} />
      <text x={W - 10} y={H - 8} textAnchor="end" fontFamily={font} fontSize={15} fill={MUTE}>время после операции →</text>
      <text x={48} y={22} fontFamily={font} fontSize={15} fill={MUTE}>функция ↑</text>
      <path d={path(pos)} stroke={GREEN} strokeWidth={5} fill="none" strokeLinecap="round" />
      <path d={path(ant)} stroke={ACC} strokeWidth={5} fill="none" strokeLinecap="round" />
      <g opacity={m}>
        <line x1={40 + x6 * (W - 60)} y1={30} x2={40 + x6 * (W - 60)} y2={H - 30} stroke={AMBER} strokeWidth={2} strokeDasharray="6 5" />
        <text x={46 + x6 * (W - 60)} y={H - 38} fontFamily={font} fontSize={16} fontWeight={700} fill={AMBER}>≈ 6 недель</text>
      </g>
      <g opacity={ease(f, at + 60, at + 72)}>
        <text x={W - 20} y={ant(1) - 14} textAnchor="end" fontFamily={font} fontSize={17} fontWeight={700} fill={ACC}>передний</text>
        <text x={W - 20} y={pos(1) + 26} textAnchor="end" fontFamily={font} fontSize={17} fontWeight={700} fill={GREEN}>задний</text>
      </g>
    </svg>
  );
};
const Clock: React.FC<{at: number}> = ({at}) => {
  const f = useCurrentFrame();
  const r = interpolate(f, [at, at + 40], [0, -240], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
  return (
    <svg width={86} height={86} viewBox="0 0 86 86">
      <circle cx={43} cy={43} r={38} fill="#eef4fc" stroke={ACC} strokeWidth={4} />
      <line x1={43} y1={43} x2={43} y2={18} stroke={INK} strokeWidth={4} strokeLinecap="round" transform={`rotate(${r} 43 43)`} />
      <line x1={43} y1={43} x2={60} y2={43} stroke={INK} strokeWidth={4} strokeLinecap="round" transform={`rotate(${r / 12} 43 43)`} />
      <circle cx={43} cy={43} r={4} fill={INK} />
    </svg>
  );
};
const V5: React.FC<{d: number}> = ({d}) => {
  const b = Math.round(d * 0.72);
  return (
    <AbsoluteFill style={{padding: '80px 60px'}}>
      <Tag n="ВОССТАНОВЛЕНИЕ: ЧТО ПОКАЗАЛИ ИССЛЕДОВАНИЯ" />
      <Swap from={0} to={b}>
        <div style={{position: 'absolute', left: 60, top: 100, display: 'flex', gap: 40, alignItems: 'center'}}>
          <div style={{width: 470}}>
            <Cap text="Через 6 недель функция в среднем лучше" size={48} accent={['6', 'лучше']} width={470} />
            <Pop at={40} style={{fontFamily: font, fontSize: 22, color: MUTE, marginTop: 16}}>Передний доступ по сравнению с задним. Позже различия часто уменьшаются</Pop>
          </div>
          <Pop at={8}><Card><Curves at={20} /><div style={{fontFamily: font, fontSize: 13, color: MUTE}}>Схема, без масштаба — показывает только направление различий</div></Card></Pop>
        </div>
      </Swap>
      <Swap from={b}>
        <div style={{position: 'absolute', left: 0, right: 0, top: 170, display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
          
          <Pop at={b + 8} style={{marginTop: 20}}><Cap text="Восстановление у каждого своё" size={64} accent={['своё']} at={b + 8} center width={1100} /></Pop>
          <Pop at={b + 30} style={{fontFamily: font, fontSize: 28, color: MUTE, marginTop: 18}}>Средние данные исследований — не гарантия для конкретного человека</Pop>
        </div>
      </Swap>
      <Source at={30}>метаанализ рандомизированных контролируемых исследований, 2023</Source>
    </AbsoluteFill>
  );
};

const V6: React.FC<{d: number}> = ({d}) => {
  const W = 560, H = 640;
  return (
    <AbsoluteFill style={{padding: '80px 60px'}}>
      <Tag n="ОНЕМЕНИЕ КОЖИ" c={AMBER} />
      <div style={{position: 'absolute', left: 60, top: 130, width: 580}}>
        <Cap text="Онемение кожи бедра может уменьшаться, иногда сохраняется" size={44} accent={['уменьшаться', 'сохраняется']} acc={AMBER} width={580} />
        <Pop at={60} style={{marginTop: 22, fontFamily: font, fontSize: 21, color: MUTE, lineHeight: 1.35}}>Оранжевым — примерная зона кожи, за которую отвечает латеральный кожный нерв бедра. Этот нерв отвечает только за чувствительность кожи</Pop>
        <Pop at={Math.round(d * 0.62)} style={{marginTop: 20}}>
          <Card style={{padding: '14px 22px', borderLeft: `8px solid ${AMBER}`}}>
            <div style={{fontFamily: font, fontWeight: 800, fontSize: 28, color: INK}}>Следите за заживлением раны</div>
          </Card>
        </Pop>
      </div>
      <Stage w={W} h={H} x={680} y={40}>
        <Seq3D name="L_numb" n={d} w={W} h={H} />
        <Pin mode="numb" pt={PT.zone} text="зона онемения" from={30} w={W} h={H} color={AMBER} dx={-70} />
        <Pin mode="numb" pt={PT.incA} text="разрез" from={45} w={W} h={H} color="#7a1f1f" dx={-60} dy={20} />
      </Stage>
      <Foot3D />
    </AbsoluteFill>
  );
};

const Q: React.FC = () => (
  <g>
    <circle cx={170} cy={36} r={30} fill={AMBER} />
    <text x={170} y={50} textAnchor="middle" fontFamily={font} fontSize={40} fontWeight={800} fill="#fff">?</text>
  </g>
);
const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
const CrossLegsAnim: React.FC<{at: number}> = ({at}) => {
  const f = useCurrentFrame();
  const c = (Math.sin(Math.max(0, f - at) / 22) + 1) / 2;
  const kx = lerp(128, 140, c), ky = lerp(112, 128, c), fx = lerp(122, 96, c), fy = lerp(182, 184, c);
  return (
    <svg width={210} height={200} viewBox="0 0 210 200">
      <circle cx={60} cy={30} r={16} fill={INK} />
      <path d="M60 48 L60 110 L130 110" stroke={INK} strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <path d="M60 110 L130 104 L124 180" stroke={INK} strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <path d={`M72 112 L${kx} ${ky} L${fx} ${fy}`} stroke="#5b6478" strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <path d="M30 118 L150 118" stroke="#9aa3b5" strokeWidth={6} strokeLinecap="round" />
      <Q />
    </svg>
  );
};
const LowChairAnim: React.FC<{at: number}> = ({at}) => {
  const f = useCurrentFrame();
  const c = (Math.sin(Math.max(0, f - at) / 24 - 1.5) + 1) / 2;
  const hy = lerp(20, 62, c), hipx = lerp(84, 80, c), hipy = lerp(110, 142, c), kx = lerp(110, 140, c), ky = lerp(150, 132, c);
  return (
    <svg width={210} height={200} viewBox="0 0 210 200">
      <circle cx={lerp(80, 70, c)} cy={hy} r={16} fill={INK} />
      <path d={`M${lerp(80, 70, c)} ${hy + 18} L${hipx} ${hipy} L${kx} ${ky} L150 186`} stroke={INK} strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <path d="M40 152 L120 152 M50 152 L50 190 M115 152 L115 190 M40 152 L32 100" stroke="#9aa3b5" strokeWidth={7} strokeLinecap="round" fill="none" />
      <Q />
    </svg>
  );
};
const V7: React.FC<{d: number}> = ({d}) => {
  const b = Math.round(d * 0.55);
  return (
    <AbsoluteFill style={{padding: '80px 60px'}}>
      <Tag n="ОГРАНИЧЕНИЯ ПОСЛЕ ОПЕРАЦИИ" />
      <Swap from={0} to={b}>
        <div style={{position: 'absolute', left: 60, top: 110}}>
          <Cap text="Ограничения индивидуальны" size={56} accent={['индивидуальны']} />
        </div>
        <div style={{position: 'absolute', left: 0, right: 0, top: 260, display: 'flex', gap: 60, justifyContent: 'center'}}>
          <Pop at={20}><Card style={{textAlign: 'center', fontFamily: font, fontSize: 26, fontWeight: 700, color: INK, width: 330}}><CrossLegsAnim at={30} /><div>Скрещивать ноги?</div></Card></Pop>
          <Pop at={36}><Card style={{textAlign: 'center', fontFamily: font, fontSize: 26, fontWeight: 700, color: INK, width: 330}}><LowChairAnim at={46} /><div>Садиться на низкий стул?</div></Card></Pop>
        </div>
      </Swap>
      <Swap from={b}>
        <div style={{position: 'absolute', left: 120, right: 120, top: 200}}>
          <Card style={{padding: '34px 40px', borderLeft: `12px solid ${RED}`}}>
            <Cap text="Не отменяйте указания хирурга самостоятельно" size={48} accent={['хирурга']} acc={RED} at={b} />
            <Pop at={b + 24} style={{fontFamily: font, fontSize: 26, color: MUTE, marginTop: 16}}>Перед выпиской уточните: какие движения разрешены, какая нагрузка, какие упражнения</Pop>
          </Card>
        </div>
      </Swap>
    </AbsoluteFill>
  );
};

const V9: React.FC<{d: number}> = ({d}) => (
  <AbsoluteFill style={{padding: '80px 60px'}}>
    <div style={{display: 'flex', gap: 20}}>
      <div style={{flex: 1}}>
        <div style={{marginTop: 30}}>
          <Cap text="Соблюдайте индивидуальные рекомендации" size={52} accent={['индивидуальные']} width={760} />
        </div>
        <Pop at={30} style={{marginTop: 18, fontFamily: font, fontSize: 23, color: MUTE, width: 740}}>
          Ваши рекомендации из выписки и указания медицинской команды имеют приоритет
        </Pop>
      </div>
      <div style={{width: 300, height: 300, marginTop: -30}}><Seq3D name="c9" n={d} w={300} h={300} /></div>
    </div>
    <Pop at={50} style={{marginTop: 6}}>
      <Card style={{padding: '16px 24px', fontFamily: font, fontSize: 15, color: MUTE, lineHeight: 1.5}}>
        <div style={{fontWeight: 700, color: INK, fontSize: 18}}>Авторы иллюстраций и 3D-моделей</div>
        Mikael Häggström — общественное достояние (CC0) · Рентген эндопротеза — общественное достояние · оба — Викисклад<br />
        3D-кости, мышцы и кожа — атлас BodyParts3D, © 2008 Life Science Integrated Database Center, лицензия CC BY-SA 2.1 Япония<br />
        Хрящ, протез, стрелки доступов, капсула и зоны — упрощённые схемы, сделаны для этого ролика<br />
        <span style={{color: INK}}>Источники — в описании</span>
      </Card>
    </Pop>
  </AbsoluteFill>
);

/* ============ NEW: approaches (A1–A5) ============ */

const LegShot: React.FC<{clip: string; d: number; W?: number; H?: number; x?: number; y?: number; children?: React.ReactNode}> = ({clip, d, W = 560, H = 640, x = 680, y = 40, children}) => (
  <Stage w={W} h={H} x={x} y={y}>
    <Seq3D name={clip} n={d} w={W} h={H} />
    {children}
  </Stage>
);

const A1: React.FC<{d: number}> = ({d}) => (
  <AbsoluteFill>
    <Tag n="ЧТО ТАКОЕ ДОСТУП" />
    <div style={{position: 'absolute', left: 60, top: 110, width: 600}}>
      <Cap text="Чтобы заменить сустав, хирургу нужно до него добраться" size={44} accent={['добраться']} width={600} />
      <div style={{height: 26}} />
      <Pop at={122}><Card style={{padding: '18px 24px', borderLeft: `8px solid ${ACC}`}}>
        <div style={{fontFamily: font, fontWeight: 800, fontSize: 34, color: INK}}>Доступ — это путь к суставу</div>
        <div style={{fontFamily: font, fontSize: 24, color: MUTE, marginTop: 6}}>через кожу и мышцы</div>
      </Card></Pop>
      <Pop at={244} style={{marginTop: 22, fontFamily: font, fontWeight: 800, fontSize: 40, color: INK}}>Основных доступов <span style={{color: ACC}}>три</span></Pop>
    </div>
    <LegShot clip="L_appr" d={d}>
      <Pin mode="approaches" pt={arrowTail('post', 8)} text="задний" from={296} w={560} h={640} color={GREEN} dx={30} />
      <Pin mode="approaches" pt={arrowTail('lat', 8)} text="боковой" from={322} w={560} h={640} color={PURPLE} dx={-30} />
      <Pin mode="approaches" pt={arrowTail('ant', 8)} text="передний" from={348} w={560} h={640} color={ACC} dx={-30} />
    </LegShot>
    <Foot3D />
  </AbsoluteFill>
);

const A2a: React.FC<{d: number}> = () => {
  const f = useCurrentFrame();
  const chip = (t: string, c: string, at: number) => (
    <Pop at={at}><div style={{background: c, color: '#fff', fontFamily: font, fontWeight: 900, fontSize: 56, borderRadius: 24, padding: '18px 44px', transform: `translateY(${Math.sin((f + at) / 18) * 4}px)`}}>{t}</div></Pop>
  );
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'column'}}>
      <Tag n="ДОСТУПЫ" />
      <Cap text="Чаще всего — задний и боковой" size={64} accent={['задний', 'боковой']} center width={1100} />
      <div style={{display: 'flex', gap: 40, marginTop: 50}}>
        {chip('задний', GREEN, 20)}
        {chip('боковой', PURPLE, 30)}
      </div>
      <Pop at={50} style={{marginTop: 34, fontFamily: font, fontSize: 28, color: MUTE}}>Их применяют уже несколько десятилетий</Pop>
    </AbsoluteFill>
  );
};

const Step: React.FC<{n: string; t: string; at: number; c: string}> = ({n, t, at, c}) => (
  <Pop at={at} style={{display: 'flex', gap: 16, alignItems: 'center', marginTop: 22}}>
    <div style={{width: 46, height: 46, borderRadius: 23, background: c, color: '#fff', fontFamily: font, fontWeight: 800, fontSize: 22, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0}}>{n}</div>
    <div style={{fontFamily: font, fontWeight: 700, fontSize: 30, color: INK, lineHeight: 1.2}}>{t}</div>
  </Pop>
);
const A2b: React.FC<{d: number}> = ({d}) => (
  <AbsoluteFill>
    <Tag n="ЗАДНИЙ ДОСТУП" c={GREEN} />
    <div style={{position: 'absolute', left: 60, top: 110, width: 600}}>
      <Cap text="Задний: к суставу — сзади" size={54} accent={['сзади']} acc={GREEN} width={600} />
      <Step n="1" t="Часть небольших мышц отделяют" at={50} c={GREEN} />
      <Step n="2" t="В конце операции подшивают обратно" at={Math.round(d * 0.55)} c={GREEN} />
    </div>
    <LegShot clip="L_post" d={d}>
      <Pin mode="posterior" pt={[1.0, 1.0, -4.3]} text="большая ягодичная мышца" from={30} w={560} h={640} dx={40} dy={-60} color="#a3392f" size={20} />
    </LegShot>
    <Foot3D />
  </AbsoluteFill>
);
const A2c: React.FC<{d: number}> = ({d}) => (
  <AbsoluteFill>
    <Tag n="БОКОВОЙ ДОСТУП" c={PURPLE} />
    <div style={{position: 'absolute', left: 60, top: 110, width: 600}}>
      <Cap text="Боковой: к суставу — сбоку" size={54} accent={['сбоку']} acc={PURPLE} width={600} />
      <Step n="1" t="Через часть ягодичных мышц" at={40} c={PURPLE} />
      <Step n="2" t="Потом их тоже восстанавливают" at={Math.round(d * 0.55)} c={PURPLE} />
    </div>
    <LegShot clip="L_lat" d={d}>
      <Pin mode="lateral" pt={[-2.7, 2.7, 0.04]} text="средняя ягодичная мышца" from={30} w={560} h={640} dx={-40} dy={-60} color="#a3392f" size={20} />
    </LegShot>
    <Foot3D />
  </AbsoluteFill>
);
const A3a: React.FC<{d: number}> = () => {
  const f = useCurrentFrame();
  const p = ease(f, 20, 80);
  return (
    <AbsoluteFill>
      <Tag n="ПЕРЕДНИЙ ДОСТУП" />
      <div style={{position: 'absolute', left: 60, top: 110, width: 1100}}>
        <Cap text="Передний доступ известен давно" size={56} accent={['давно']} />
      </div>
      <div style={{position: 'absolute', left: 100, right: 100, top: 340}}>
        <div style={{height: 10, background: '#dfe4ec', borderRadius: 5}}>
          <div style={{height: 10, width: `${p * 100}%`, background: ACC, borderRadius: 5}} />
        </div>
        <div style={{display: 'flex', justifyContent: 'space-between', marginTop: 18, fontFamily: font}}>
          <Pop at={20}><div style={{fontSize: 32, fontWeight: 800, color: INK}}>известен давно</div></Pop>
          <Pop at={70} style={{textAlign: 'right'}}><div style={{fontSize: 32, fontWeight: 800, color: ACC}}>последние десятилетия</div><div style={{fontSize: 22, color: MUTE}}>широко — при замене сустава</div></Pop>
        </div>
      </div>
      <Source at={30}>Angerame и Dennis, журнал Annals of Joint, 2018</Source>
    </AbsoluteFill>
  );
};
const A3b: React.FC<{d: number}> = ({d}) => {
  const W = 720, H = 640;
  return (
    <AbsoluteFill>
      <Tag n="ПЕРЕДНИЙ ДОСТУП" />
      <div style={{position: 'absolute', left: 60, top: 110, width: 470}}>
        <Cap text="Спереди — в промежутке между мышцами" size={46} accent={['между']} width={470} />
        <Pop at={128} style={{marginTop: 26}}><Card style={{padding: '16px 20px', borderLeft: `8px solid ${AMBER}`}}>
          <div style={{fontFamily: font, fontWeight: 800, fontSize: 30, color: INK}}>Мышцы не отсекают, а раздвигают и отводят</div>
        </Card></Pop>
        <Pop at={Math.round(d * 0.72)} style={{marginTop: 18}}><Card style={{padding: '16px 20px', borderLeft: `8px solid ${RED}`}}>
          <div style={{fontFamily: font, fontWeight: 800, fontSize: 28, color: INK}}>Мягкие ткани всё равно затрагиваются</div>
        </Card></Pop>
      </div>
      <Stage w={W} h={H} x={540} y={40}>
        <Seq3D name="L_ant" n={d} w={W} h={H} />
        <Pin mode="anterior" pt={PT.incA} text="разрез кожи" from={10} to={45} w={W} h={H} color="#7a1f1f" dx={70} />
        <Pin mode="anterior" pt={[1.35, -8, 1.9]} text="портняжная мышца" from={100} w={W} h={H} dx={70} size={20} />
        <Pin mode="anterior" pt={[-3.2, -1.5, 1.8]} text="напрягатель широкой фасции" from={106} w={W} h={H} dx={-30} dy={-50} size={20} />
        <Pin mode="anterior" pt={[-1.0, -6, 2.7]} text="прямая мышца бедра" from={112} w={W} h={H} dx={-90} dy={40} size={20} />
        <Pin mode="anterior" pt={[-0.7, -0.3, 1.0]} text="капсула сустава" from={170} w={W} h={H} dx={110} color={AMBER} size={20} />
        <Pin mode="anterior" pt={PT.knee} text="колено" from={100} w={W} h={H} dx={60} size={20} />
      </Stage>
      <Foot3D w={460} />
    </AbsoluteFill>
  );
};

const ProsCons: React.FC<{d: number; title: string; c: string; plus: string; minus: string; mAt?: number}> = ({d, title, c, plus, minus, mAt = 0.45}) => (
  <AbsoluteFill>
    <Tag n="ПЛЮСЫ И РИСКИ" c={c} />
    <div style={{position: 'absolute', left: 60, top: 100}}>
      <Cap text={title} size={58} accent={[title.split(' ')[0].toLowerCase()]} acc={c} />
    </div>
    <div style={{position: 'absolute', left: 60, right: 60, top: 240, display: 'flex', gap: 40}}>
      <Pop at={12} style={{flex: 1}}><Card style={{padding: '28px 30px', borderTop: `10px solid ${GREEN}`, height: 300}}>
        <div style={{fontFamily: font, fontWeight: 900, fontSize: 60, color: GREEN}}>✓</div>
        <div style={{fontFamily: font, fontWeight: 700, fontSize: 32, color: INK, lineHeight: 1.25}}>{plus}</div>
      </Card></Pop>
      <Pop at={Math.round(d * mAt)} style={{flex: 1}}><Card style={{padding: '28px 30px', borderTop: `10px solid ${AMBER}`, height: 300}}>
        <div style={{fontFamily: font, fontWeight: 900, fontSize: 60, color: AMBER}}>!</div>
        <div style={{fontFamily: font, fontWeight: 700, fontSize: 32, color: INK, lineHeight: 1.25}}>{minus}</div>
      </Card></Pop>
    </div>
  </AbsoluteFill>
);
const A4h: React.FC<{d: number}> = () => (
  <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
    <Cap text="У каждого доступа — свои плюсы и свои риски" size={64} accent={['плюсы', 'риски']} width={1050} center />
  </AbsoluteFill>
);
const A4a: React.FC<{d: number}> = ({d}) => <ProsCons d={d} title="Передний доступ" c={ACC} plus="В первые недели восстановление в среднем немного быстрее" minus="Чаще бывает онемение кожи на бедре" mAt={0.62} />;
const A4b: React.FC<{d: number}> = ({d}) => <ProsCons d={d} title="Задний доступ" c={GREEN} plus="Хирург хорошо видит сустав" minus="Риск вывиха снижают, восстанавливая ткани" mAt={0.5} />;
const A4c: React.FC<{d: number}> = ({d}) => <ProsCons d={d} title="Боковой доступ" c={PURPLE} plus="Вывихи бывают редко" minus="Иногда остаётся слабость ягодичных мышц и прихрамывание" mAt={0.4} />;

const A5a: React.FC<{d: number}> = ({d}) => {
  const items = ['Строение сустава', 'Вес', 'Прошлые операции', 'Опыт хирурга'];
  return (
    <AbsoluteFill>
      <Tag n="КТО ВЫБИРАЕТ ДОСТУП" />
      <div style={{position: 'absolute', left: 60, top: 110}}>
        <Cap text="Какой доступ выбрать, решает хирург" size={56} accent={['хирург']} />
      </div>
      <div style={{position: 'absolute', left: 60, right: 60, top: 280, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 26}}>
        {items.map((t, i) => (
          <Pop key={t} at={[100, 162, 190, 225][i]}>
            <Card style={{padding: '22px 26px', display: 'flex', gap: 18, alignItems: 'center'}}>
              <div style={{width: 46, height: 46, borderRadius: 23, background: ACC, color: '#fff', fontFamily: font, fontWeight: 800, fontSize: 26, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>✓</div>
              <div style={{fontFamily: font, fontWeight: 800, fontSize: 34, color: INK}}>{t}</div>
            </Card>
          </Pop>
        ))}
      </div>
    </AbsoluteFill>
  );
};
const A5b: React.FC<{d: number}> = () => (
  <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'column'}}>
    <Cap text="Доступа, лучшего для всех, нет" size={70} accent={['всех']} center width={1100} />
    <Source at={20}>клинические рекомендации Американской академии ортопедических хирургов, 2023</Source>
  </AbsoluteFill>
);
const A5c: React.FC<{d: number}> = ({d}) => (
  <AbsoluteFill>
    <div style={{position: 'absolute', left: 60, top: 160, width: 580}}>
      <Cap text="Вам сделали операцию передним доступом" size={52} accent={['передним']} width={580} />
      <Pop at={Math.round(d * 0.5)} style={{marginTop: 26, fontFamily: font, fontWeight: 700, fontSize: 30, color: MUTE}}>Дальше — чего ожидать именно после него</Pop>
    </div>
    <LegShot clip="L_chosen" d={d}>
      <Pin mode="chosen" pt={arrowTail('ant', 8)} text="передний" from={20} w={560} h={640} color={ACC} dx={30} />
    </LegShot>
    <Foot3D />
  </AbsoluteFill>
);

/* ============ NEW: warning signs (W0–W7), one per frame ============ */

const Header: React.FC<{text: string; c: string; bg: string; accent: string[]}> = ({text, c, bg, accent}) => (
  <AbsoluteFill style={{background: bg, justifyContent: 'center', alignItems: 'center', flexDirection: 'column'}}>
    <Cap text={text} size={68} accent={accent} acc={c} center width={1100} />
  </AbsoluteFill>
);
const W0: React.FC<{d: number}> = () => <Header text="Свяжитесь с врачом в тот же день, если…" c={AMBER} bg="#fff8ec" accent={['тот', 'же', 'день']} />;
const Sign: React.FC<{c: string; n: string; text: string; children: React.ReactNode}> = ({c, n, text, children}) => (
  <AbsoluteFill>
    <div style={{position: 'absolute', top: 30, left: 60, fontFamily: font, fontWeight: 800, fontSize: 20, color: c, letterSpacing: 1.5}}>{n}</div>
    <div style={{position: 'absolute', left: 60, top: 150, width: 560}}>
      <Cap text={text} size={54} width={560} step={4} />
    </div>
    {children}
  </AbsoluteFill>
);
const Thermo: React.FC = () => {
  const f = useCurrentFrame();
  const h = interpolate(f, [6, 50], [40, 230], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
  return (
    <div style={{position: 'absolute', left: 800, top: 110}}>
      <svg width={300} height={440} viewBox="0 0 300 440">
        <rect x={110} y={20} width={44} height={330} rx={22} fill="#fff" stroke={INK} strokeWidth={5} />
        {[0, 1, 2, 3, 4, 5].map((i) => <line key={i} x1={158} x2={180} y1={300 - i * 45} y2={300 - i * 45} stroke={MUTE} strokeWidth={3} />)}
        <rect x={121} y={340 - h} width={22} height={h} rx={11} fill={RED} />
        <circle cx={132} cy={375} r={44} fill={RED} stroke={INK} strokeWidth={5} />
        <path d="M210 60 l14 -26 l14 26 z M210 110 l14 -26 l14 26 z" fill={RED} opacity={ease(f, 30, 45)} />
      </svg>
    </div>
  );
};
const W1: React.FC<{d: number}> = () => <Sign c={AMBER} n="ПРИЗНАК 1 · ТЕМПЕРАТУРА" text="…поднимается температура"><Thermo /></Sign>;
const W2: React.FC<{d: number}> = ({d}) => (
  <Sign c={AMBER} n="ПРИЗНАК 2 · РАНА" text="…рана покраснела или из неё появились выделения">
    <Stage w={640} h={600} x={620} y={60}><Seq3D name="L_wound" n={d} w={640} h={600} /></Stage>
  </Sign>
);
const W3: React.FC<{d: number}> = ({d}) => {
  const W = 640, H = 600;
  return (
    <Sign c={AMBER} n="ПРИЗНАК 3 · ИКРА" text="…болит и отекла икра, одна стала толще другой">
      <Stage w={W} h={H} x={620} y={60}>
        <Seq3D name="L_calf" n={d} w={W} h={H} />
      </Stage>
      <div style={{position: 'absolute', left: 60, top: 470, fontFamily: font, fontSize: 22, color: MUTE}}>Вид сзади. Справа — оперированная нога</div>
    </Sign>
  );
};
const W4: React.FC<{d: number}> = () => (
  <AbsoluteFill style={{background: '#fff2f2', justifyContent: 'center', alignItems: 'center', flexDirection: 'column'}}>
    <Cap text="Вызывайте скорую помощь, если…" size={60} accent={['скорую']} acc={RED} center width={1100} />
    <Pop at={14} style={{marginTop: 34, display: 'flex', alignItems: 'center', gap: 30}}>
      <div style={{background: RED, color: '#fff', fontFamily: font, fontWeight: 900, fontSize: 150, borderRadius: 26, padding: '0 40px', lineHeight: 1.15}}>101</div>
      <div style={{fontFamily: font, fontWeight: 900, fontSize: 56, color: INK, lineHeight: 1.1}}>«Маген<br />Давид Адом»</div>
    </Pop>
  </AbsoluteFill>
);
const Chest: React.FC = () => {
  const f = useCurrentFrame();
  const b = 1 + 0.06 * Math.sin(f / 4);
  const h = 1 + 0.1 * Math.max(0, Math.sin(f / 3.2)) ** 8;
  return (
    <svg width={460} height={460} viewBox="0 0 460 460" style={{position: 'absolute', left: 740, top: 140}}>
      <path d="M130 70 Q230 30 330 70 L360 420 L100 420 Z" fill="#f7e4dc" stroke="#c99a8a" strokeWidth={4} />
      <circle cx={230} cy={40} r={34} fill="#f7e4dc" stroke="#c99a8a" strokeWidth={4} />
      <g transform={`translate(230 230) scale(${b}) translate(-230 -230)`}>
        <path d="M215 130 Q150 120 140 220 Q135 310 200 300 Q215 250 215 130 Z" fill="#e89a9a" stroke="#b55" strokeWidth={3} />
        <path d="M245 130 Q310 120 320 220 Q325 310 260 300 Q245 250 245 130 Z" fill="#e89a9a" stroke="#b55" strokeWidth={3} />
      </g>
      <g transform={`translate(250 260) scale(${h}) translate(-250 -260)`}>
        <path d="M250 290 C210 260 215 225 238 225 C248 225 250 235 250 240 C250 235 252 225 262 225 C285 225 290 260 250 290 Z" fill={RED} />
      </g>
    </svg>
  );
};
const Bar101: React.FC<{at?: number}> = ({at = 10}) => (
  <Pop at={at} style={{position: 'absolute', left: 60, top: 500, display: 'flex', alignItems: 'center', gap: 22}}>
    <div style={{background: RED, color: '#fff', fontFamily: font, fontWeight: 900, fontSize: 96, borderRadius: 20, padding: '0 28px', lineHeight: 1.15}}>101</div>
    <div style={{fontFamily: font, fontWeight: 900, fontSize: 38, color: INK, lineHeight: 1.15, whiteSpace: 'nowrap'}}>скорая помощь<br /><span style={{color: RED}}>«Маген Давид Адом»</span></div>
  </Pop>
);
const W5: React.FC<{d: number}> = () => <Sign c={RED} n="СКОРАЯ · ДЫХАНИЕ И ГРУДЬ" text="…внезапно появилась одышка или боль в груди"><Chest /><Bar101 /></Sign>;
const W6: React.FC<{d: number}> = ({d}) => (
  <Sign c={RED} n="СКОРАЯ · СУСТАВ" text="…резко заболел сустав и невозможно наступить на ногу">
    <Stage w={560} h={640} x={680} y={40}><Seq3D name="L_pain" n={d} w={560} h={640} /></Stage>
    <Bar101 />
  </Sign>
);
const W7: React.FC<{d: number}> = () => (
  <AbsoluteFill style={{padding: '50px 60px', background: '#fff5f5'}}>
    <div style={{border: `8px solid ${RED}`, borderRadius: 28, background: '#fff', padding: '30px 44px', height: '100%', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', justifyContent: 'center'}}>
      <div style={{fontFamily: font, fontWeight: 900, fontSize: 46, color: RED}}>Экстренно — вызывайте скорую помощь</div>
      <div style={{fontFamily: font, fontSize: 32, color: INK, marginTop: 14, lineHeight: 1.4}}>• Внезапная одышка или боль в груди<br />• Резкая боль в суставе, невозможно наступить на ногу</div>
      <div style={{marginTop: 34, display: 'flex', gap: 34, alignItems: 'center'}}>
        <div style={{background: RED, color: '#fff', fontFamily: font, fontWeight: 900, fontSize: 170, borderRadius: 26, padding: '0 44px', lineHeight: 1.15}}>101</div>
        <div style={{fontFamily: font, fontWeight: 900, fontSize: 56, color: INK, lineHeight: 1.15, whiteSpace: 'nowrap'}}>скорая помощь<br /><span style={{color: RED}}>«Маген Давид Адом»</span></div>
      </div>
    </div>
  </AbsoluteFill>
);

// W4+W5 merged: one continuous voice phrase, no cut — caption changes in place, 101 bar stays
const W45: React.FC<{d: number}> = () => {
  const k = 112;
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', top: 30, left: 60, fontFamily: font, fontWeight: 800, fontSize: 20, color: RED, letterSpacing: 1.5}}>СКОРАЯ · ДЫХАНИЕ И ГРУДЬ</div>
      <Swap from={0} to={k}>
        <div style={{position: 'absolute', left: 60, top: 150, width: 640}}><Cap text="Вызывайте скорую помощь, если…" size={60} accent={['скорую']} acc={RED} width={640} /></div>
      </Swap>
      <Swap from={k}>
        <div style={{position: 'absolute', left: 60, top: 150, width: 560}}><Cap text="…внезапно появилась одышка или боль в груди" size={54} width={560} step={4} at={k} /></div>
        <Chest />
      </Swap>
      <Bar101 at={40} />
    </AbsoluteFill>
  );
};
export const MAP: Record<string, React.FC<{d: number}>> = {
  s1: V1, s2: V2, s3: V3, a1: A1, a2a: A2a, a2b: A2b, a2c: A2c, a3a: A3a, a3b: A3b, a4h: A4h, a4a: A4a, a4b: A4b, a4c: A4c,
  a5a: A5a, a5b: A5b, a5c: A5c, s5: V5, s6: V6, s7: V7, w0: W0, w1: W1, w2: W2, w3: W3, w4: W4, w5: W5, w45: W45, w6: W6, w7: W7, s9: V9,
};

const Fade: React.FC<{d: number; children: React.ReactNode; still?: boolean}> = ({d, children, still}) => {
  const f = useCurrentFrame();
  const o = still ? 1 : interpolate(f, [0, 6, d - 6, d], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  // light continuous motion everywhere (no frozen frames); the emergency card stays static (3 s)
  const z = still ? 1 : 1 + 0.025 * (f / d);
  return <AbsoluteFill style={{opacity: o, transform: `scale(${z})`}}>{children}</AbsoluteFill>;
};

export const Film: React.FC = () => {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const timing: T = require('./timing.json');
  let from = 0;
  return (
    <AbsoluteFill>
      <Bg />
      {timing.map((s) => {
        const d = Math.round(s.dur * FPS);
        const C = MAP[s.id];
        const el = (
          <Sequence key={s.id} from={from} durationInFrames={d}>
            <Fade d={d} still={s.id === 'w7'}><C d={d} /></Fade>
          </Sequence>
        );
        from += d;
        return el;
      })}
    </AbsoluteFill>
  );
};
