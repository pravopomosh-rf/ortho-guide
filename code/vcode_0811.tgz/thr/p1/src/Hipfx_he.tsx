import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {Bg, C, Cap, Card, CallButton, Foot, FPS, Label, Note, Pop, Tag, ease, font, G, K} from './ui';
import {Bed, Icon} from './Part1';
import timing from './timing_hipfx_he.json';

type T = {id: string; dur: number; audio?: string; k?: number}[];
const TT = timing as T;
const PAD = 0.75;
export const totalHipfx_he = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const sec = (s: number) => Math.round(s * FPS * G.k);
const PT = 'שבר בירך · ניתוח דחוף';

/* ---------- схема проксимального отдела правой бедренной кости (вид спереди, не в масштабе) ---------- */
const FEMUR = 'M98 400 L96 236 C 92 200, 70 160, 62 128 C 56 104, 64 84, 80 82 C 94 80, 104 90, 112 100 C 128 90, 148 80, 166 74 L 190 118 C 176 126, 166 140, 162 160 C 168 170, 182 184, 184 200 C 184 214, 172 222, 164 222 L 160 236 L 160 400 Z';
type FemOpt = {neck?: number; troch?: number; glowNeck?: number; screws?: number; dhs?: number; nail?: number; prosth?: number; scale?: number};
const Femur: React.FC<FemOpt> = ({neck = 0, troch = 0, glowNeck = 0, screws = 0, dhs = 0, nail = 0, prosth = 0, scale = 1}) => (
  <svg width={260 * scale} height={420 * scale} viewBox="20 20 240 400">
    <defs>
      <radialGradient id="bone" cx="40%" cy="30%" r="80%"><stop offset="0%" stopColor="#fbf3e3" /><stop offset="100%" stopColor="#e3cfa9" /></radialGradient>
    </defs>
    <path d={FEMUR} fill="url(#bone)" stroke="#a88c5e" strokeWidth={3.5} strokeLinejoin="round" opacity={prosth > 0 ? 0.55 : 1} />
    {prosth === 0 && <circle cx={205} cy={84} r={40} fill="url(#bone)" stroke="#a88c5e" strokeWidth={3.5} />}
    {prosth > 0 && (
      <g opacity={prosth}>
        <path d="M112 330 L104 220 C 102 180, 112 150, 140 128 L172 104 L182 118 L152 146 C 136 162, 132 190, 134 220 L128 330 Z" fill="#9aa8b8" stroke="#5c6b7c" strokeWidth={2.5} strokeLinejoin="round" />
        <circle cx={205} cy={84} r={38} fill="#c8d2dc" stroke="#5c6b7c" strokeWidth={3} />
        <circle cx={194} cy={72} r={10} fill="#eef3f7" opacity={0.8} />
      </g>
    )}
    {/* подсветка шейки */}
    {glowNeck > 0 && <ellipse cx={160} cy={112} rx={34} ry={26} transform="rotate(-30 160 112)" fill={C.teal2} opacity={0.35 * glowNeck} />}
    {/* линия перелома шейки */}
    {neck > 0 && <path d="M150 82 L158 96 L150 108 L160 122 L156 136" stroke={C.red} strokeWidth={5} fill="none" strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - neck} />}
    {/* чрезвертельная линия: от большого вертела к малому, НЕ через шейку */}
    {troch > 0 && <path d="M84 110 L102 132 L114 146 L132 164 L148 180 L170 200" stroke={C.red} strokeWidth={5} fill="none" strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - troch} />}
    {/* винты вдоль шейки */}
    {screws > 0 && [0, 1, 2].map((i) => (
      <g key={i} opacity={screws}>
        <path d={`M${78 + i * 6} ${150 + i * 14} L${196 + i * 2} ${84 + i * 12}`} stroke="#6b7a8c" strokeWidth={7} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - screws} />
      </g>
    ))}
    {/* пластина со скользящим винтом */}
    {dhs > 0 && (
      <g opacity={dhs}>
        <rect x={84} y={150} width={14} height={180} rx={5} fill="#8796a8" stroke="#5c6b7c" strokeWidth={2} />
        {[180, 220, 260, 300].map((y) => <circle key={y} cx={91} cy={y} r={3.5} fill="#e9eef3" />)}
        <path d="M90 160 L198 92" stroke="#6b7a8c" strokeWidth={11} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - dhs} />
      </g>
    )}
    {/* внутрикостный гвоздь */}
    {nail > 0 && (
      <g opacity={nail}>
        <path d="M84 96 C 100 150, 126 210, 128 260 L128 380" stroke="#8796a8" strokeWidth={14} fill="none" strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - nail} />
        <path d="M110 170 L198 94" stroke="#5c6b7c" strokeWidth={9} strokeLinecap="round" opacity={nail > 0.6 ? 1 : 0} />
      </g>
    )}
  </svg>
);

const Src: React.FC<{children: React.ReactNode}> = ({children}) => <Foot>מקור: {children}</Foot>;
const Box: React.FC<{at: number; children: React.ReactNode; bg?: string; size?: number; w?: number}> = ({at, children, bg = C.white, size = 23, w}) => (
  <Pop at={sec(at)}><Card style={{background: bg, width: w}}><Label size={size}>{children}</Label></Card></Pop>
);

const H1: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Tag n="למטופלים ולבני המשפחה" part={PT} />
      <div style={{position: 'absolute', left: 60, top: 110}}>
        <Cap text="שבר בחלק העליון של עצם הירך: ניתוח דחוף" size={50} accent={['דחוף']} width={700} />
        <div style={{marginTop: 26}}><Note at={sec(6)}>מה זה · הכנה · ניתוחים · אחרי</Note></div>
      </div>
      <div style={{position: 'absolute', right: 110, top: 120, opacity: ease(f, 6, 24)}}>
        <Femur glowNeck={ease(f, sec(3), sec(5))} scale={1.25} />
      </div>
    </AbsoluteFill>
  );
};

const H2: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Tag n="מהו השבר" part={PT} />
      <div style={{position: 'absolute', left: 60, top: 80}}>
        <Cap text="צוואר הירך: מתחת לראש עצם הירך" size={42} accent={['צוואר']} width={720} />
      </div>
      <div style={{position: 'absolute', right: 90, top: 70}}>
        <Femur glowNeck={ease(f, sec(0.5), sec(2))} neck={ease(f, sec(5), sec(7))} scale={1.4} />
        <div style={{fontFamily: font, fontSize: 15, color: C.mute, textAlign: 'center', marginTop: -10}}>שרטוט, לא בקנה מידה</div>
      </div>
      <div style={{position: 'absolute', left: 60, top: 230, width: 640, display: 'flex', flexDirection: 'column', gap: 14}}>
        <Box at={5}>עצמות שבירות, אוסטאופורוזיס ← שבר גם בנפילה רגילה</Box>
        <Box at={13.2}>כאב במפשעה · לא מצליח לדרוך · הרגל קצרה יותר ומסובבת החוצה</Box>
        <Box at={22} bg={C.dawnL}>לפעמים האדם עדיין יכול ללכת</Box>
      </div>
    </AbsoluteFill>
  );
};

const H3: React.FC = () => {
  const f = useCurrentFrame();
  const card = (t: string, sub: string, at: number, bg = C.white) => (
    <Pop at={sec(at)}><Card style={{width: 330, height: 200, background: bg, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 8}}><Label size={30}>{t}</Label><Label size={19} color={C.mute} style={{fontWeight: 600}}>{sub}</Label></Card></Pop>
  );
  const arr = (at: number) => <svg width={60} height={30} style={{opacity: ease(f, sec(at), sec(at) + 8)}}><path d="M4 15 L46 15 M34 5 L48 15 L34 25" stroke={C.mute} strokeWidth={4} fill="none" strokeLinecap="round" /></svg>;
  return (
    <AbsoluteFill>
      <Tag n="אבחנה" part={PT} />
      <div style={{position: 'absolute', left: 60, top: 80}}><Cap text="בדיקה ורנטגן בחדר המיון" size={44} accent={['ורנטגן']} /></div>
      <div style={{position: 'absolute', left: 60, top: 220, display: 'flex', alignItems: 'center', gap: 14}}>
        {card('בדיקה + רנטגן', 'בדרך כלל זה מספיק', 1)}
        {arr(4.6)}
        {card('תהודה מגנטית', 'אם ברנטגן לא רואים, אבל החשד נשאר', 5, C.tealL)}
        {arr(11.2)}
        {card('טומוגרפיה ממוחשבת', 'אם אי אפשר לבצע תהודה מגנטית בתוך 24 שעות, או שיש סיבה רפואית שלא לבצע אותה', 11.4)}
      </div>
      <Src>המכון הלאומי למצוינות בבריאות ובטיפול, בריטניה: הנחיות לשבר בירך</Src>
    </AbsoluteFill>
  );
};

const Scale: React.FC<{at: number}> = ({at}) => {
  const f = useCurrentFrame();
  const v = Math.round(interpolate(f, [sec(at), sec(at + 3)], [7, 3], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}));
  return (
    <div style={{display: 'flex', gap: 4}}>
      {Array.from({length: 11}, (_, i) => (
        <div key={i} style={{width: 34, height: 44, borderRadius: 8, background: i === v ? C.teal : i < 4 ? '#dff1e9' : i < 7 ? C.dawnL : C.redL, color: i === v ? '#fff' : C.ink, fontFamily: font, fontWeight: 800, fontSize: 18, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{i}</div>
      ))}
    </div>
  );
};

const H4: React.FC = () => (
  <AbsoluteFill>
    <Tag n="במחלקה לפני הניתוח" part={PT} />
    <div style={{position: 'absolute', left: 60, top: 80, display: 'flex', alignItems: 'center', gap: 20}}>
      <CallButton size={56} glow={1} />
      <Cap text="אל תקומו לבד: קראו לצוות" size={44} accent={['קראו']} />
    </div>
    <div style={{position: 'absolute', left: 60, top: 230}}><Pop at={sec(1)}><Bed w={300} rails={1} /></Pop></div>
    <div style={{position: 'absolute', left: 430, right: 60, top: 210, display: 'flex', flexDirection: 'column', gap: 14}}>
      <Box at={8.4}>הצוות יעזור להסתובב ולשמור על היגיינה</Box>
      <Pop at={sec(11.9)}><Card><Label size={23}>טיפול בכאב מתחיל מיד. הכאב התגבר? ספרו לאחות</Label><div style={{marginTop: 12}}><Scale at={13} /></div></Card></Pop>
      <Box at={18.9} bg={C.tealL}>חסם עצבי: זריקה נגד כאב ליד העצב</Box>
      <Box at={23.3}>בדיקות והכנה לניתוח</Box>
    </div>
  </AbsoluteFill>
);

const H5: React.FC = () => {
  const f = useCurrentFrame();
  const tl = ease(f, sec(34.4), sec(38));
  return (
    <AbsoluteFill>
      <Tag n="הכנה" part={PT} />
      <div style={{position: 'absolute', left: 60, top: 80}}><Cap text="העור ומניעת קרישי דם" size={44} accent={['קרישי']} /></div>
      <div style={{position: 'absolute', left: 60, top: 180, width: 560, display: 'flex', flexDirection: 'column', gap: 12}}>
        <Box at={0.5} size={21}>הצוות מנקה את העור לפי נהלי בית החולים</Box>
        <Box at={11.4} size={21}>אל תגלחו את העור בעצמכם</Box>
        <Box at={14.1} size={21} bg={C.dawnL}>אלרגיה לכלורהקסידין, פצע או גירוי בעור? ספרו לצוות</Box>
      </div>
      <div style={{position: 'absolute', left: 660, right: 60, top: 180, display: 'flex', flexDirection: 'column', gap: 12}}>
        <Pop at={sec(21)}><Card style={{display: 'flex', alignItems: 'center', gap: 14}}><Icon k="syringe" s={70} /><Label size={22}>קלקסן (אנוקסאפרין): מניעת קרישי דם</Label></Card></Pop>
        <Pop at={sec(34.2)}>
          <Card style={{background: C.tealL}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 10, fontFamily: font, fontWeight: 800, fontSize: 20, color: C.ink}}>
              <span>זריקה</span><span style={{fontSize: 18, color: C.teal, whiteSpace: 'nowrap'}}>≥ 12 שעות</span>
              <svg width={130} height={20}><path d="M4 10 L126 10" stroke={C.teal} strokeWidth={5} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - tl} /></svg>
              <span style={{whiteSpace: 'nowrap'}}>הרדמה ספינלית</span>
            </div>
            <Label size={20} style={{marginTop: 8}}>אחרי מנה מונעת: לפחות 12 שעות</Label>
            <Label size={18} color={C.mute} style={{marginTop: 6, fontWeight: 600}}>את המרווח הסופי קובע הרופא המרדים</Label>
          </Card>
        </Pop>
      </div>
      <Src>האגודה האמריקאית להרדמה אזורית, 2025</Src>
    </AbsoluteFill>
  );
};

const H6: React.FC = () => (
  <AbsoluteFill>
    <Tag n="אוכל, שתייה, תרופות" part={PT} />
    <div style={{position: 'absolute', left: 60, top: 80}}><Cap text="אוכל ושתייה: רק באישור" size={44} accent={['באישור']} /></div>
    <div style={{position: 'absolute', left: 60, right: 60, top: 190, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16}}>
      <Box at={3.6}>ספרו מתי אכלתם או שתיתם בפעם האחרונה</Box>
      <Box at={10.4}>הניתוח נדחה? שאלו מתי מותר לשתות</Box>
      <Box at={15.6} bg={C.dawnL} size={21}>מדללי דם: קומדין, אליקוויס, קסרלטו, פרדקסה, פלביקס: ספרו לרופא</Box>
      <Box at={18.5} bg={C.dawnL} size={21}>תרופות לסוכרת: ספרו לרופא אילו אתם לוקחים ומתי לקחתם אותן לאחרונה</Box>
      <Box at={22}>אל תתחילו ואל תפסיקו תרופות בעצמכם</Box>
      <Pop at={sec(27.2)}><Card style={{display: 'flex', alignItems: 'center', gap: 14, background: C.tealL}}><Icon k="pill" s={64} /><Label size={22}>בני משפחה: רשימת תרופות או האריזות</Label></Card></Pop>
    </div>
  </AbsoluteFill>
);

const H7: React.FC = () => {
  const f = useCurrentFrame();
  const col = (title: string, sub: string, at: number, el: React.ReactNode) => (
    <Pop at={sec(at)}><Card style={{width: 270, height: 380, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, padding: '16px 12px'}}>
      <Label size={20} style={{textAlign: 'center'}}>{title}</Label>
      <div style={{height: 228, display: 'flex', alignItems: 'center'}}>{el}</div>
      <Label size={17} color={C.mute} style={{fontWeight: 600, textAlign: 'center'}}>{sub}</Label>
    </Card></Pop>
  );
  return (
    <AbsoluteFill>
      <Tag n="ניתוחים" part={PT} />
      <div style={{position: 'absolute', left: 60, top: 76}}><Cap text="איזה ניתוח לבצע, מחליט המנתח" size={40} accent={['המנתח']} /></div>
      <div style={{position: 'absolute', left: 60, right: 60, top: 150, display: 'flex', gap: 14, justifyContent: 'space-between'}}>
        {col('שבר בצוואר הירך ללא תזוזה', 'ברגים או אמצעי קיבוע אחר', 0.3, <Femur neck={1} screws={ease(f, sec(1.5), sec(3.5))} scale={0.58} />)}
        {col('שבר בצוואר הירך עם תזוזה', 'לרוב החלפה חלקית או מלאה של המפרק (בשרטוט: דוגמה להחלפה חלקית)', 5.7, <Femur prosth={ease(f, sec(7), sec(9))} scale={0.58} />)}
        {col('בין טרוכנטרי', 'פלטה עם בורג מחליק', 11.3, <Femur troch={1} dhs={ease(f, sec(13.5), sec(15.5))} scale={0.58} />)}
        {col('בין טרוכנטרי', 'או מסמר בתוך העצם', 13, <Femur troch={1} nail={ease(f, sec(16), sec(18))} scale={0.58} />)}
      </div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 560, display: 'flex', justifyContent: 'center'}}>
        <Note at={sec(20.7)}>בדרך כלל בתוך 24 עד 48 שעות</Note>
      </div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 618, display: 'flex', justifyContent: 'center'}}>
        <Note at={sec(26.1)} color={C.mute} bg={C.white}>משרד הבריאות מפרסם את שיעור המטופלים שנותחו בתוך 48 שעות</Note>
      </div>
      <Src>האקדמיה האמריקאית למנתחים אורתופדיים, 2021; משרד הבריאות, התוכנית הלאומית למדדי איכות. השרטוטים מפושטים ואינם בקנה מידה.</Src>
    </AbsoluteFill>
  );
};

const H8: React.FC = () => (
  <AbsoluteFill>
    <Tag n="אחרי הניתוח" part={PT} />
    <div style={{position: 'absolute', left: 60, top: 80}}><Cap text="קימה: בדרך כלל למחרת, עם הפיזיותרפיסט" size={40} accent={['קימה']} width={1150} /></div>
    <div style={{position: 'absolute', left: 60, top: 200, width: 560, display: 'flex', flexDirection: 'column', gap: 12}}>
      <Box at={5.4} size={21}>תנועה מוקדמת: פחות סיכון לקרישי דם, לדלקת ריאות ולפצעי לחץ</Box>
      <Box at={9.6} size={21} bg={C.tealL}>דריכה על הרגל: לפי הוראת הרופא</Box>
      <Box at={15.9} size={21}>מניעת קרישי דם יכולה להימשך גם אחרי השחרור</Box>
    </div>
    <div style={{position: 'absolute', left: 660, right: 60, top: 200, display: 'flex', flexDirection: 'column', gap: 12}}>
      <Box at={19.8} size={21} bg={C.dawnL}>בלבול פתאומי (דליריום): ספרו מיד לצוות</Box>
      <Box at={23.9} size={19}>יכול להיות "שקט": ישנוניות, איטיות, הסתגרות</Box>
      <Pop at={sec(33.2)}><Card style={{display: 'flex', justifyContent: 'space-around', alignItems: 'center'}}>
        <svg width={66} height={66} viewBox="0 0 100 100"><circle cx={30} cy={56} r={16} fill="#eaf6fb" stroke={C.ink} strokeWidth={4} /><circle cx={70} cy={56} r={16} fill="#eaf6fb" stroke={C.ink} strokeWidth={4} /><path d="M46 54 C 48 50, 52 50, 54 54 M14 52 L6 40 M86 52 L94 40" stroke={C.ink} strokeWidth={4} fill="none" strokeLinecap="round" /></svg><Icon k="hearing" s={66} /><Icon k="denture" s={66} /><Icon k="alarm" s={66} />
      </Card></Pop>
      <Box at={34} size={19}>משקפיים · מכשיר שמיעה · תותבות שיניים · ביקורים תכופים · איזה יום היום</Box>
    </div>
  </AbsoluteFill>
);

const H9: React.FC = () => {
  const f = useCurrentFrame();
  const day: [string, number][] = [['חום', 5.5], ['שינויים בפצע: אודם, נפיחות, הפרשה', 8.5], ['כאב או נפיחות בשוק של רגל אחת', 17]];
  const now: [string, number][] = [['כאב חדש וחזק בירך', 10.5], ['לא מצליחים לדרוך על הרגל, או שהמנח שלה השתנה', 13.4]];
  return (
    <AbsoluteFill>
      <Tag n="מתי לפנות בדחיפות" part={PT} />
      <div style={{position: 'absolute', left: 60, top: 76}}><Cap text="בבית החולים: ספרו מיד לאחות" size={40} accent={['מיד']} /></div>
      <div style={{position: 'absolute', left: 60, top: 150, width: 640}}>
        <Label size={21} color={C.teal}>אחרי השחרור, פנו לעזרה רפואית באותו יום:</Label>
        <div style={{display: 'flex', flexDirection: 'column', gap: 8, marginTop: 8}}>
          {day.map(([t, at], i) => <Box key={i} at={at} size={20}>{t}</Box>)}
        </div>
        <Label size={21} color={C.red} style={{marginTop: 16}}>מיד לחדר המיון. אל תנסו ללכת:</Label>
        <div style={{display: 'flex', flexDirection: 'column', gap: 8, marginTop: 8}}>
          {now.map(([t, at], i) => <Box key={i} at={at} size={20} bg={C.dawnL}>{t}</Box>)}
        </div>
      </div>
      <Pop at={sec(22.5)} style={{position: 'absolute', left: 740, right: 60, top: 200}}>
        <Card style={{background: C.redL, borderLeft: `10px solid ${C.red}`, transform: `scale(${1 + 0.02 * Math.sin(f / 8)})`}}>
          <div style={{fontFamily: font, fontWeight: 900, fontSize: 84, color: C.red, lineHeight: 1}}>101</div>
          <Label size={22} style={{marginTop: 6}}>מגן דוד אדום, מיד:</Label>
          <Label size={22} color={C.red} style={{marginTop: 8}}>קוצר נשימה פתאומי · כאב בחזה · התעלפות</Label>
        </Card>
      </Pop>
    </AbsoluteFill>
  );
};

const H10: React.FC = () => (
  <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
    <Pop at={4}>
      <Card style={{width: 900, padding: 40, textAlign: 'center', borderTop: `8px solid ${C.teal}`}}>
        <Label size={34} style={{lineHeight: 1.3}}>אלה המלצות כלליות.</Label>
        <Label size={30} color={C.mute} style={{fontWeight: 600, marginTop: 10, lineHeight: 1.3}}>ההוראות האישיות של הרופא ושל הצוות הרפואי קודמות להן.</Label>
      </Card>
    </Pop>
    <Foot>השרטוטים מפושטים ואינם בקנה מידה. המקורות בתיאור ובאתר.</Foot>
  </AbsoluteFill>
);

const MAP: Record<string, React.FC> = {H01: H1, H02: H2, H03: H3, H04: H4, H05: H5, H06: H6, H07: H7, H08: H8, H09: H9, H10: H10};

const Fade: React.FC<{d: number; children: React.ReactNode}> = ({d, children}) => {
  const f = useCurrentFrame();
  const o = Math.min(ease(f, 0, 10), 1 - ease(f, d - 10, d));
  const sc = 1 + 0.03 * (f / Math.max(d, 1));
  return <AbsoluteFill style={{opacity: o, transform: `scale(${sc})`, transformOrigin: '50% 45%'}}>{children}</AbsoluteFill>;
};

export const Hipfx_he: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  G.rtl = true;
  let at = 0;
  return (
    <AbsoluteFill>
      <Bg />
      {TT.map((x) => {
        const d = Math.round((x.dur + PAD) * FPS);
        const Comp = MAP[x.id];
        const el = (
          <Sequence key={x.id} from={at} durationInFrames={d} name={x.id}>
            <Fade d={d}><K k={x.k}><Comp /></K></Fade>
            {withAudio && x.audio && <Sequence from={6}><Audio src={staticFile(`aud/hipfx/${x.audio}`)} /></Sequence>}
          </Sequence>
        );
        at += d;
        return el;
      })}
    </AbsoluteFill>
  );
};
