import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {Bg, C, Cap, Card, Check, CallButton, Cross, Foot, FPS, Label, Note, Pop, Seq3D, Tag, ease, easeIO, font} from './ui';
import timing from './timing1.json';

type T = {id: string; dur: number; audio: string}[];
const TT = timing as T;
const PAD = 0.75;
export const fr = (id: string) => Math.round(((TT.find((x) => x.id === id)?.dur ?? 5) + PAD) * FPS);
export const total1 = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const sec = (s: number) => Math.round(s * FPS);

/* ---------- small illustrations ---------- */
const Bracelet: React.FC<{color: string; text?: string; w?: number}> = ({color, text, w = 300}) => (
  <svg width={w} height={w * 0.5} viewBox="0 0 300 150">
    <path d="M40 60 C 40 30, 260 30, 260 60 L 260 95 C 260 125, 40 125, 40 95 Z" fill="#f2d7c2" />
    <rect x={28} y={56} width={244} height={40} rx={12} fill={color} stroke={color === '#ffffff' ? '#cfd6dd' : color} strokeWidth={2} />
    <rect x={100} y={62} width={100} height={28} rx={6} fill="#ffffffcc" />
    <rect x={108} y={69} width={60} height={5} rx={2} fill="#9aa5b1" />
    <rect x={108} y={78} width={42} height={5} rx={2} fill="#c3cad2" />
    <g>{[0, 1, 2, 3, 4, 5, 6].map((i) => <rect key={i} x={174 + i * 3.5} y={68} width={i % 2 ? 1.5 : 2.5} height={16} fill="#5d6875" />)}</g>
    {text && <text x={150} y={130} textAnchor="middle" fontFamily={font} fontWeight={800} fontSize={22} fill={color === '#ffffff' ? C.mute : color}>{text}</text>}
  </svg>
);

const Monitor: React.FC<{p: number}> = ({p}) => (
  <svg width={300} height={230} viewBox="0 0 300 230">
    <rect x={20} y={10} width={260} height={160} rx={14} fill="#25313f" />
    <rect x={32} y={22} width={236} height={136} rx={8} fill="#f6fafb" />
    <rect x={46} y={36} width={60} height={60} rx={30} fill={C.tealL} />
    <circle cx={76} cy={58} r={11} fill={C.teal} />
    <path d="M58 90 C 60 74, 92 74, 94 90" fill={C.teal} />
    {[0, 1, 2, 3].map((i) => (
      <rect key={i} x={120} y={40 + i * 22} width={(130 - i * 18) * ease(p * 100, i * 15, i * 15 + 25)} height={10} rx={5} fill={i === 0 ? C.teal : '#c9d3dc'} />
    ))}
    <rect x={46} y={110} width={206} height={10} rx={5} fill="#e3e9ee" />
    <rect x={46} y={128} width={150 * p} height={10} rx={5} fill={C.teal2} />
    <rect x={130} y={170} width={40} height={30} fill="#25313f" />
    <rect x={90} y={198} width={120} height={12} rx={6} fill="#25313f" />
  </svg>
);

export const Bed: React.FC<{w?: number; rails?: number}> = ({w = 260, rails = 0}) => (
  <svg width={w} height={w * 0.62} viewBox="0 0 260 160">
    <rect x={20} y={70} width={220} height={30} rx={8} fill="#dfe6ec" />
    <rect x={24} y={58} width={212} height={22} rx={10} fill="#fff" stroke="#cfd6dd" strokeWidth={2} />
    <rect x={30} y={46} width={54} height={20} rx={10} fill="#eef3f6" stroke="#cfd6dd" strokeWidth={2} />
    <rect x={14} y={30} width={10} height={100} rx={4} fill="#9aa5b1" />
    <rect x={236} y={50} width={10} height={80} rx={4} fill="#9aa5b1" />
    <circle cx={40} cy={138} r={10} fill="#5d6875" />
    <circle cx={220} cy={138} r={10} fill="#5d6875" />
    <rect x={90} y={40 - 10 * rails} width={110} height={8} rx={4} fill={C.teal} opacity={rails} />
  </svg>
);

export const Icon: React.FC<{k: string; s?: number}> = ({k, s = 92}) => {
  const st = {fill: 'none', stroke: C.ink, strokeWidth: 4, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const};
  const g: Record<string, React.ReactNode> = {
    ring: <><circle cx={50} cy={60} r={22} {...st} /><path d="M40 34 L50 22 L60 34 Z" fill={C.dawn} stroke={C.ink} strokeWidth={3} /></>,
    earring: <><circle cx={38} cy={30} r={6} {...st} /><path d="M38 36 L38 50" {...st} /><circle cx={38} cy={62} r={12} {...st} /><circle cx={68} cy={30} r={6} {...st} /><path d="M68 36 L68 50" {...st} /><circle cx={68} cy={62} r={12} {...st} /></>,
    watch: <><rect x={36} y={12} width={28} height={20} rx={6} {...st} /><rect x={36} y={68} width={28} height={20} rx={6} {...st} /><circle cx={50} cy={50} r={20} {...st} /><path d="M50 40 L50 50 L58 55" {...st} /></>,
    lens: <><ellipse cx={50} cy={56} rx={30} ry={16} {...st} /><path d="M22 52 C 30 30, 70 30, 78 52" {...st} stroke={C.teal} /></>,
    hearing: <><path d="M58 18 C 80 18, 86 46, 70 60 C 62 67, 62 76, 56 84 C 50 92, 36 88, 38 76" {...st} /><circle cx={42} cy={70} r={6} fill={C.ink} /></>,
    denture: <><path d="M18 40 C 18 76, 82 76, 82 40 Z" fill="#fff" stroke={C.ink} strokeWidth={4} strokeLinejoin="round" /><path d="M30 40 L30 52 M42 40 L42 56 M58 40 L58 56 M70 40 L70 52" {...st} strokeWidth={3} /><path d="M14 40 L86 40" stroke="#e58f8f" strokeWidth={7} strokeLinecap="round" /></>,
    gown: <><path d="M30 20 L44 14 C 46 22, 54 22, 56 14 L70 20 L84 40 L72 46 L70 88 L30 88 L28 46 L16 40 Z" fill={C.tealL} stroke={C.teal} strokeWidth={4} strokeLinejoin="round" /><circle cx={50} cy={50} r={2.5} fill={C.teal} /><circle cx={50} cy={64} r={2.5} fill={C.teal} /></>,
    doc: <><rect x={22} y={10} width={56} height={78} rx={8} fill="#fff" stroke={C.ink} strokeWidth={4} /><path d="M34 30 L66 30 M34 42 L66 42 M34 54 L56 54" {...st} strokeWidth={3} /><path d="M34 72 C 40 64, 44 78, 50 70 C 54 66, 58 74, 66 70" stroke={C.teal} strokeWidth={3} fill="none" strokeLinecap="round" /></>,
    shower: <><path d="M30 20 C 30 10, 56 10, 56 24 L56 30" {...st} /><path d="M42 30 L70 30 L64 40 L48 40 Z" fill="#fff" stroke={C.ink} strokeWidth={4} strokeLinejoin="round" /><path d="M50 48 L46 60 M56 48 L56 62 M62 48 L66 60 M52 68 L50 78 M60 68 L62 78" stroke={C.teal2} strokeWidth={4} strokeLinecap="round" /></>,
    bed: <><rect x={12} y={50} width={76} height={18} rx={5} fill="#fff" stroke={C.ink} strokeWidth={4} /><rect x={16} y={40} width={22} height={12} rx={5} fill={C.tealL} stroke={C.ink} strokeWidth={3} /><path d="M12 30 L12 84 M88 50 L88 84" {...st} /><path d="M44 46 L84 46" stroke={C.teal} strokeWidth={5} strokeLinecap="round" /></>,
    drip: <><path d="M40 10 L60 10 L62 46 C 62 54, 38 54, 38 46 Z" fill={C.tealL} stroke={C.ink} strokeWidth={4} strokeLinejoin="round" /><path d="M50 52 L50 64" {...st} /><path d="M46 64 L54 64 L52 74 L48 74 Z" fill="#fff" stroke={C.ink} strokeWidth={3} /><path d="M50 74 C 50 86, 70 84, 74 92" {...st} strokeWidth={3} /></>,
    heart: <><path d="M50 82 C 18 60, 14 34, 32 26 C 42 22, 48 28, 50 34 C 52 28, 58 22, 68 26 C 86 34, 82 60, 50 82 Z" fill={C.dawnL} stroke={C.ink} strokeWidth={4} strokeLinejoin="round" /><path d="M24 50 L40 50 L46 40 L54 62 L60 50 L76 50" stroke={C.red} strokeWidth={3.5} fill="none" strokeLinecap="round" strokeLinejoin="round" /></>,
    pill: <><rect x={18} y={36} width={64} height={28} rx={14} fill="#fff" stroke={C.ink} strokeWidth={4} transform="rotate(-30 50 50)" /><path d="M50 36 L50 64" stroke={C.ink} strokeWidth={4} transform="rotate(-30 50 50)" /><rect x={50} y={38} width={30} height={24} rx={12} fill={C.dawn} transform="rotate(-30 50 50)" /></>,
    plate: <><circle cx={50} cy={52} r={32} fill="#fff" stroke={C.ink} strokeWidth={4} /><circle cx={50} cy={52} r={20} fill="none" stroke="#c9d3dc" strokeWidth={3} /><path d="M10 18 L12 40 M16 18 L16 40 M22 18 L20 40 M16 40 L16 88" {...st} strokeWidth={3} /><path d="M88 18 C 78 30, 78 44, 86 48 L86 88" {...st} strokeWidth={3} /></>,
    glass: <><path d="M30 18 L70 18 L64 86 L36 86 Z" fill="#eaf6fb" stroke={C.ink} strokeWidth={4} strokeLinejoin="round" /><path d="M33 44 L67 44 L64 84 L36 84 Z" fill="#bfe3f0" /></>,
    toilet: <><path d="M26 20 L74 20 L74 44 L26 44 Z" fill="#fff" stroke={C.ink} strokeWidth={4} /><path d="M20 48 L80 48 C 80 70, 66 78, 60 78 L62 90 L38 90 L40 78 C 34 78, 20 70, 20 48 Z" fill="#fff" stroke={C.ink} strokeWidth={4} strokeLinejoin="round" /></>,
    water: <><rect x={28} y={12} width={44} height={60} rx={6} fill="#eaf6fb" stroke={C.ink} strokeWidth={4} /><path d="M40 30 C 40 22, 50 16, 50 16 C 50 16, 60 22, 60 30 C 60 36, 55 40, 50 40 C 45 40, 40 36, 40 30 Z" fill={C.teal2} /><rect x={36} y={72} width={28} height={16} rx={3} fill="#c9d3dc" stroke={C.ink} strokeWidth={3} /></>,
    alarm: <><circle cx={50} cy={54} r={30} fill="#fff" stroke={C.ink} strokeWidth={4} /><path d="M50 36 L50 54 L62 60" {...st} /><path d="M22 26 L32 18 M78 26 L68 18" {...st} strokeWidth={5} /></>,
    syringe: <><rect x={22} y={40} width={50} height={18} rx={4} fill="#fff" stroke={C.ink} strokeWidth={4} /><path d="M72 49 L92 49" stroke={C.ink} strokeWidth={2.5} /><path d="M22 49 L8 49 M8 40 L8 58" {...st} /><rect x={30} y={44} width={30} height={10} fill={C.tealL} /></>,
  };
  return <svg width={s} height={s} viewBox="0 0 100 100">{g[k]}</svg>;
};

export const Step: React.FC<{k: string; title: string; at: number; sub?: string; w?: number}> = ({k, title, at, sub, w = 300}) => (
  <Pop at={at} style={{width: w}}>
    <Card style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, padding: '22px 16px'}}>
      <Icon k={k} s={96} />
      <Label size={26} style={{textAlign: 'center'}}>{title}</Label>
      {sub && <Label size={19} color={C.mute} style={{fontWeight: 600, textAlign: 'center'}}>{sub}</Label>}
    </Card>
  </Pop>
);

/* simple front body silhouette with highlightable zones */
const Body: React.FC<{zones: {x: number; y: number; r: number; on: number; n?: number}[]; w?: number}> = ({zones, w = 300}) => (
  <svg width={w} height={w * 1.9} viewBox="0 0 200 380">
    <g fill="#f2d7c2" stroke="#d9b79c" strokeWidth={2}>
      <circle cx={100} cy={38} r={26} />
      <path d="M70 70 C 80 64, 120 64, 130 70 L150 84 C 160 92, 164 140, 168 190 L156 192 C 150 150, 146 120, 140 110 L138 180 L142 250 L136 370 L110 370 L104 260 L96 260 L90 370 L64 370 L58 250 L62 180 L60 110 C 54 120, 50 150, 44 192 L32 190 C 36 140, 40 92, 50 84 Z" />
    </g>
    {zones.map((z, i) => (
      <g key={i} opacity={Math.min(1, z.on * 1.5)}>
        <circle cx={z.x} cy={z.y} r={z.r * (0.85 + 0.15 * z.on)} fill={C.teal2} opacity={0.32} />
        <circle cx={z.x} cy={z.y} r={z.r * 0.92} fill="none" stroke={C.teal} strokeWidth={2.5} strokeDasharray="5 4" />
        {z.n !== undefined && <text x={z.x} y={z.y + 6} textAnchor="middle" fontFamily={font} fontWeight={800} fontSize={17} fill={C.teal}>{z.n}</text>}
      </g>
    ))}
  </svg>
);

const Bottle: React.FC = () => (
  <svg width={190} height={300} viewBox="0 0 190 300">
    <rect x={70} y={10} width={50} height={24} rx={5} fill="#f1f1f1" stroke="#c8c8c8" strokeWidth={2} />
    <rect x={62} y={30} width={66} height={22} rx={6} fill="#e6e6e6" stroke="#c8c8c8" strokeWidth={2} />
    <path d="M40 70 C 40 52, 150 52, 150 70 L 156 270 C 156 286, 34 286, 34 270 Z" fill="#d62f2f" />
    <path d="M52 76 C 52 66, 70 64, 72 76 L 70 250" stroke="#ffffff55" strokeWidth={8} fill="none" strokeLinecap="round" />
    <rect x={50} y={118} width={92} height={104} rx={10} fill="#fff" />
    <text x={96} y={150} textAnchor="middle" fontFamily={font} fontWeight={800} fontSize={17} fill="#b71c1c">Септал</text>
    <text x={96} y={172} textAnchor="middle" fontFamily={font} fontWeight={800} fontSize={17} fill="#b71c1c">скраб</text>
    <text x={96} y={196} textAnchor="middle" fontFamily={font} fontWeight={600} fontSize={12} fill={C.mute}>хлоргексидин</text>
    <text x={96} y={212} textAnchor="middle" fontFamily={font} fontWeight={800} fontSize={14} fill={C.mute}>4%</text>
  </svg>
);
const Sponge: React.FC<{s?: number}> = ({s = 70}) => (
  <svg width={s} height={s * 0.7} viewBox="0 0 100 70">
    <rect x={6} y={10} width={88} height={50} rx={16} fill="#fff" stroke="#cfd6dd" strokeWidth={3} />
    {[[24, 26], [44, 40], [64, 24], [76, 44], [34, 46], [56, 32]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r={3} fill="#dbe2e8" />)}
  </svg>
);
const Bin: React.FC = () => (
  <svg width={90} height={100} viewBox="0 0 90 100">
    <rect x={12} y={18} width={66} height={10} rx={4} fill="#9aa5b1" />
    <path d="M18 30 L72 30 L66 94 L24 94 Z" fill="#e3e9ee" stroke="#9aa5b1" strokeWidth={3} />
    <path d="M34 42 L36 84 M45 42 L45 84 M56 42 L54 84" stroke="#9aa5b1" strokeWidth={3} strokeLinecap="round" />
  </svg>
);
const Wipes: React.FC = () => (
  <svg width={300} height={200} viewBox="0 0 300 200">
    <rect x={20} y={40} width={260} height={140} rx={26} fill="#f4f7fa" stroke="#b9c4cf" strokeWidth={3} />
    <rect x={100} y={30} width={100} height={30} rx={12} fill={C.teal} />
    <path d="M118 46 C 140 36, 160 56, 182 46" stroke="#fff" strokeWidth={3} fill="none" />
    <text x={150} y={110} textAnchor="middle" fontFamily={font} fontWeight={800} fontSize={24} fill={C.ink}>Салфетки</text>
    <text x={150} y={140} textAnchor="middle" fontFamily={font} fontWeight={700} fontSize={18} fill={C.mute}>хлоргексидин 2%</text>
  </svg>
);

/* ---------- scenes ---------- */
const S1: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const nodes = ['День до операции', 'Вечер и ночь', 'Утро', 'Операционная'];
  return (
    <AbsoluteFill>
      <Tag n="ДЛЯ ПАЦИЕНТОВ" />
      <div style={{position: 'absolute', left: 60, top: 120, width: 600}}>
        <Cap text="Замена тазобедренного сустава" size={60} accent={['тазобедренного']} width={600} step={4} />
        <div style={{height: 18}} />
        <Cap text="Часть 1. От поступления до операционной" size={30} color={C.mute} at={22} step={2} width={600} />
      </div>
      <div style={{position: 'absolute', right: 40, top: 60}}>
        <Seq3D name="c1" n={d} w={560} h={520} />
      </div>
      <div style={{position: 'absolute', left: 60, top: 560, width: 680}}>
        <svg width={680} height={20} style={{position: 'absolute', top: 14}}>
          <rect x={10} y={4} width={660} height={6} rx={3} fill={C.line} />
          <rect x={10} y={4} width={660 * easeIO(f, 60, 220)} height={6} rx={3} fill={C.teal2} />
        </svg>
        <div style={{display: 'flex', justifyContent: 'space-between'}}>
          {nodes.map((n, i) => {
            const p = ease(f, 60 + i * 50, 75 + i * 50);
            return (
              <div key={i} style={{display: 'flex', flexDirection: 'column', alignItems: i === 0 ? 'flex-start' : i === 3 ? 'flex-end' : 'center', width: 160}}>
                <div style={{width: 34, height: 34, borderRadius: 17, background: p > 0.5 ? C.teal : '#fff', border: `3px solid ${C.teal}`, transform: `scale(${0.7 + 0.3 * p})`}} />
                <Label size={19} style={{marginTop: 10, opacity: 0.3 + 0.7 * p}}>{n}</Label>
              </div>
            );
          })}
        </div>
      </div>
      <Foot>3D: атлас BodyParts3D, © Life Science Integrated Database Center, CC BY-SA 2.1 JP. Эндопротез — упрощённая модель</Foot>
    </AbsoluteFill>
  );
};

const S2: React.FC = () => (
  <AbsoluteFill>
    <Tag n="ПОСТУПЛЕНИЕ" />
    <div style={{position: 'absolute', left: 60, top: 80}}>
      <Cap text="Обычно — днём накануне операции" size={46} accent={['накануне']} />
    </div>
    <div style={{position: 'absolute', left: 60, right: 60, top: 200, display: 'flex', gap: 30, alignItems: 'stretch', justifyContent: 'center'}}>
      <Pop at={sec(2.6)}>
        <Card style={{width: 340, height: 360, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center'}}>
          <MonitorP at={sec(2.6)} />
          <Label size={24} style={{textAlign: 'center', marginTop: 8}}>Оформление в компьютере</Label>
        </Card>
      </Pop>
      <Pop at={sec(6.2)}>
        <Card style={{width: 340, height: 360, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6}}>
          <Bracelet color="#ffffff" text="обычный браслет" />
          <Label size={24} style={{textAlign: 'center'}}>Браслет с вашими данными</Label>
        </Card>
      </Pop>
      <Pop at={sec(10.4)}>
        <Card style={{width: 340, height: 360, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6, border: `3px solid ${C.red}`}}>
          <Bracelet color={C.red} text="АЛЛЕРГИЯ" />
          <Label size={24} style={{textAlign: 'center'}}>Есть аллергия — браслет красный</Label>
        </Card>
      </Pop>
    </div>
    <div style={{position: 'absolute', left: 0, right: 0, top: 600, display: 'flex', justifyContent: 'center'}}>
      <Note at={sec(13.2)} color={C.red} bg={C.redL}>Сообщите о любой аллергии</Note>
    </div>
  </AbsoluteFill>
);
const MonitorP: React.FC<{at: number}> = ({at}) => {
  const f = useCurrentFrame();
  return <Monitor p={ease(f, at, at + 70)} />;
};

const S3: React.FC = () => {
  const f = useCurrentFrame();
  const glow = (Math.sin(f / 6) + 1) / 2 * ease(f, sec(4), sec(5));
  return (
    <AbsoluteFill>
      <Tag n="ПАЛАТА" />
      <div style={{position: 'absolute', left: 60, top: 80}}>
        <Cap text="Кнопка вызова — всегда рядом" size={46} accent={['вызова']} />
      </div>
      <Pop at={sec(3.8)} style={{position: 'absolute', left: 80, top: 190}}>
        <Card style={{width: 340, height: 420, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center'}}>
          <CallButton size={170} glow={glow} />
          <Label size={24} style={{textAlign: 'center', marginTop: 6}}>Провод с кнопкой у кровати</Label>
        </Card>
      </Pop>
      <div style={{position: 'absolute', left: 470, top: 190, width: 740}}>
        <Pop at={sec(1.2)}>
          <Card style={{height: 300, position: 'relative', padding: 0, overflow: 'hidden'}}>
            {/* floor plan */}
            <svg width={740} height={300} viewBox="0 0 740 300">
              <rect x={0} y={0} width={740} height={300} fill="#fffdf9" />
              <rect x={250} y={20} width={240} height={190} rx={10} fill="#f3f7f9" stroke="#b9c4cf" strokeWidth={3} />
              <text x={370} y={48} textAnchor="middle" fontFamily={font} fontWeight={700} fontSize={18} fill={C.mute}>ваша палата</text>
              <rect x={300} y={70} width={70} height={110} rx={10} fill="#fff" stroke="#9aa5b1" strokeWidth={2.5} />
              <rect x={308} y={76} width={54} height={22} rx={8} fill={C.tealL} />
              <rect x={400} y={70} width={70} height={110} rx={10} fill="#fff" stroke="#e1e6ea" strokeWidth={2} />
              <rect x={340} y={206} width={60} height={8} fill="#fffdf9" />
              <rect x={20} y={224} width={700} height={56} rx={8} fill="#efe8de" />
              <text x={690} y={258} textAnchor="end" fontFamily={font} fontWeight={700} fontSize={17} fill={C.mute}>коридор</text>
              <g opacity={ease(f, sec(2.4), sec(3))}>
                <rect x={120} y={60} width={110} height={110} rx={10} fill="#fff" stroke={C.teal} strokeWidth={3} />
                <text x={175} y={150} textAnchor="middle" fontFamily={font} fontWeight={800} fontSize={18} fill={C.teal}>туалет</text>
                <path d="M340 230 C 300 232, 210 232, 180 175" stroke={C.teal} strokeWidth={4} fill="none" strokeDasharray="8 7" strokeLinecap="round" />
              </g>
              <g opacity={ease(f, sec(3), sec(3.6))}>
                <rect x={510} y={60} width={110} height={110} rx={10} fill="#fff" stroke={C.teal} strokeWidth={3} />
                <text x={565} y={150} textAnchor="middle" fontFamily={font} fontWeight={800} fontSize={18} fill={C.teal}>душ</text>
                <path d="M400 230 C 440 232, 530 232, 560 175" stroke={C.teal} strokeWidth={4} fill="none" strokeDasharray="8 7" strokeLinecap="round" />
              </g>
            </svg>
            <div style={{position: 'absolute', left: 140, top: 66}}><Icon k="toilet" s={56} /></div>
            <div style={{position: 'absolute', left: 530, top: 66}}><Icon k="shower" s={56} /></div>
          </Card>
        </Pop>
        <div style={{display: 'flex', gap: 16, marginTop: 20, flexWrap: 'wrap'}}>
          <Note at={sec(7.6)}>Нужна помощь — нажмите</Note>
          <Note at={sec(9.4)} color={C.dawn} bg={C.dawnL}>Ночью и при головокружении</Note>
          <Note at={sec(11.6)} color={C.red} bg={C.redL}>Не вставайте одни, если запретили</Note>
        </div>
      </div>
    </AbsoluteFill>
  );
};

const S4: React.FC = () => {
  const f = useCurrentFrame();
  const items: {k: string; t: string; at: number}[] = [
    {k: 'ring', t: 'украшения', at: 2.2}, {k: 'earring', t: 'пирсинг, серьги', at: 3.2}, {k: 'watch', t: 'металл', at: 4.4},
    {k: 'lens', t: 'контактные линзы', at: 8.8}, {k: 'hearing', t: 'слуховой аппарат', at: 11.2}, {k: 'denture', t: 'зубные протезы', at: 12.6},
  ];
  return (
    <AbsoluteFill>
      <Tag n="ЧТО СНЯТЬ" />
      <div style={{position: 'absolute', left: 60, top: 80}}>
        <Cap text="Перед операцией — снять" size={46} accent={['снять']} />
      </div>
      <div style={{position: 'absolute', left: 60, top: 180, width: 760, display: 'grid', gridTemplateColumns: 'repeat(3, 240px)', gap: 20}}>
        {items.map((it, i) => {
          const later = i >= 4;
          return (
            <Pop key={i} at={sec(it.at)}>
              <Card style={{height: 170, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4, border: later ? `3px dashed ${C.dawn}` : '3px solid transparent'}}>
                <Icon k={it.k} s={82} />
                <Label size={21} style={{textAlign: 'center'}}>{it.t}</Label>
              </Card>
            </Pop>
          );
        })}
      </div>
      <div style={{position: 'absolute', left: 860, top: 180, width: 360, display: 'flex', flexDirection: 'column', gap: 18}}>
        <Pop at={sec(5.6)}>
          <Card style={{background: C.redL}}>
            <Label size={22} color={C.red}>Почему</Label>
            <Label size={21} style={{fontWeight: 600, marginTop: 6}}>Металл может мешать операции и иногда повреждать кожу</Label>
          </Card>
        </Pop>
        <Pop at={sec(14.5)}>
          <Card style={{background: C.dawnL}}>
            <Label size={22} color={'#b8661c'}>Аппарат и протезы</Label>
            <Label size={21} style={{fontWeight: 600, marginTop: 6}}>снимают перед отъездом в операционную — персонал скажет, когда. До этого вы хорошо слышите объяснения</Label>
          </Card>
        </Pop>
        <Pop at={sec(20.6)}>
          <Card style={{display: 'flex', alignItems: 'center', gap: 12}}>
            <Icon k="gown" s={70} />
            <Label size={21}>Чистая больничная одежда</Label>
          </Card>
        </Pop>
      </div>
    </AbsoluteFill>
  );
};

const S4b: React.FC = () => {
  const f = useCurrentFrame();
  const docs = [
    {t: 'Операция', s: 'что будут делать, риски, другие варианты', at: 3.4},
    {t: 'Переливание крови', s: 'при замене сустава теряется кровь', at: 13.6},
    {t: 'Анестезия', s: 'отдельно придёт анестезиолог', at: 21.8},
  ];
  const showA = ease(f, sec(25), sec(26));
  return (
    <AbsoluteFill>
      <Tag n="ДОКУМЕНТЫ" />
      <div style={{position: 'absolute', left: 60, top: 80}}>
        <Cap text="Три согласия до операции" size={46} accent={['три']} />
      </div>
      <div style={{position: 'absolute', left: 60, top: 180, width: 560, display: 'flex', flexDirection: 'column', gap: 18}}>
        {docs.map((d, i) => (
          <Pop key={i} at={sec(d.at)}>
            <Card style={{display: 'flex', alignItems: 'center', gap: 16, padding: '14px 20px'}}>
              <Icon k="doc" s={70} />
              <div style={{flex: 1}}>
                <Label size={26}>{i + 1}. {d.t}</Label>
                <Label size={19} color={C.mute} style={{fontWeight: 600, marginTop: 4}}>{d.s}</Label>
              </div>
              <Check p={ease(f, sec(d.at) + 25, sec(d.at) + 45)} size={40} />
            </Card>
          </Pop>
        ))}
        <div style={{opacity: ease(f, sec(9), sec(10))}}>
          <Label size={18} color={C.mute} style={{fontWeight: 600}}>Подписано давно — могут попросить подписать заново</Label>
        </div>
      </div>
      <div style={{position: 'absolute', left: 660, top: 180, width: 560, opacity: showA, transform: `translateY(${(1 - showA) * 30}px)`}}>
        <Card>
          <Label size={24} color={C.teal}>Анестезиолог объяснит</Label>
          <div style={{display: 'flex', gap: 18, marginTop: 14}}>
            <div style={{flex: 1, background: '#f5f8fa', borderRadius: 16, padding: 14, textAlign: 'center', opacity: 0.3 + 0.7 * ease(f, sec(28.4), sec(29.4))}}>
              <svg width={150} height={110} viewBox="0 0 150 110">
                <circle cx={75} cy={50} r={36} fill="#f2d7c2" />
                <path d="M56 50 C 62 56, 68 56, 72 50 M80 50 C 84 56, 90 56, 96 50" stroke={C.ink} strokeWidth={3.5} fill="none" strokeLinecap="round" />
                <text x={110} y={26} fontFamily={font} fontWeight={800} fontSize={20} fill={C.teal}>z z</text>
              </svg>
              <Label size={22}>Общая</Label>
              <Label size={18} color={C.mute} style={{fontWeight: 600}}>вы спите</Label>
            </div>
            <div style={{flex: 1, background: '#f5f8fa', borderRadius: 16, padding: 14, textAlign: 'center', opacity: 0.3 + 0.7 * ease(f, sec(30.4), sec(31.4))}}>
              <svg width={150} height={110} viewBox="0 0 200 146">
                <g transform="translate(60,4) scale(0.36)">
                  <circle cx={100} cy={38} r={26} fill="#f2d7c2" />
                  <path d="M70 70 C 80 64, 120 64, 130 70 L150 84 L156 192 L140 192 L138 180 L62 180 L44 192 L44 84 Z" fill="#f2d7c2" />
                  <path d="M62 180 L142 180 L142 250 L136 370 L64 370 L58 250 Z" fill={C.teal2} opacity={0.75} />
                </g>
              </svg>
              <Label size={22}>Спинальная</Label>
              <Label size={18} color={C.mute} style={{fontWeight: 600}}>обезболивается нижняя часть тела</Label>
            </div>
          </div>
          <Label size={18} color={C.mute} style={{fontWeight: 600, marginTop: 12, opacity: ease(f, sec(33.2), sec(34))}}>Иногда методы сочетают</Label>
        </Card>
        <div style={{marginTop: 18}}><Note at={sec(34.8)}>Задавайте вопросы до того, как подписываете</Note></div>
      </div>
    </AbsoluteFill>
  );
};

const S5: React.FC = () => {
  const f = useCurrentFrame();
  const z = [
    {x: 100, y: 96, r: 18, at: 8}, {x: 66, y: 118, r: 15, at: 9}, {x: 134, y: 118, r: 15, at: 9.6},
    {x: 100, y: 150, r: 26, at: 10.4}, {x: 100, y: 214, r: 22, at: 11.2},
    {x: 126, y: 262, r: 26, at: 12.8}, {x: 74, y: 262, r: 22, at: 13.6},
  ];
  const n = z.filter((q) => f > sec(q.at)).length;
  const zones = z.map((q, i) => ({x: q.x, y: q.y, r: q.r, on: ease(f, sec(q.at), sec(q.at) + 12), n: i + 1}));
  // focus zones (operation, armpits, groin, folds)
  const focus = ease(f, sec(14.4), sec(15.4));
  return (
    <AbsoluteFill>
      <Tag n="ВЕЧЕРОМ · ДУШ" />
      <div style={{position: 'absolute', left: 60, top: 80}}>
        <Cap text="Душ с антисептическим мылом" size={46} accent={['антисептическим']} />
      </div>
      <Pop at={sec(1)} style={{position: 'absolute', left: 70, top: 180}}>
        <Card style={{width: 270, height: 440, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center'}}>
          <Bottle />
          <Label size={20} color={C.mute} style={{fontWeight: 600, textAlign: 'center', marginTop: 4}}>красное мыло с хлоргексидином</Label>
        </Card>
      </Pop>
      <div style={{position: 'absolute', left: 380, top: 160}}>
        <Body zones={zones} w={250} />
      </div>
      <div style={{position: 'absolute', left: 660, top: 180, width: 560, display: 'flex', flexDirection: 'column', gap: 14}}>
        <Pop at={sec(5.2)}>
          <Card style={{display: 'flex', alignItems: 'center', gap: 14}}>
            <Sponge s={80} />
            <div style={{fontFamily: font, fontWeight: 800, fontSize: 30, color: C.teal, minWidth: 40}}>{Math.max(1, n)}</div>
            <svg width={60} height={30}><path d="M4 15 L50 15 M40 6 L52 15 L40 24" stroke={C.mute} strokeWidth={4} fill="none" strokeLinecap="round" /></svg>
            <Bin />
            <Label size={20} style={{fontWeight: 600, flex: 1}}>Одна губка — одна часть тела</Label>
          </Card>
        </Pop>
        <div style={{opacity: focus}}>
          <Card style={{background: C.tealL}}>
            <Label size={21}>Особенно тщательно: место операции, подмышки, пах, кожные складки</Label>
          </Card>
        </div>
        <Pop at={sec(18.4)}>
          <Card style={{background: C.redL, padding: '14px 20px'}}>
            <Label size={21} color={C.red}>Не в глаза, уши и на слизистые</Label>
          </Card>
        </Pop>
        <Pop at={sec(22.4)}>
          <Card style={{display: 'flex', alignItems: 'center', gap: 12, padding: '10px 20px'}}>
            <Icon k="gown" s={56} />
            <Label size={20}>Чистое полотенце и чистый халат</Label>
          </Card>
        </Pop>
        <Pop at={sec(27.2)}>
          <Card style={{padding: '12px 20px'}}>
            <Label size={20}>После душа — без кремов и дезодоранта</Label>
          </Card>
        </Pop>
        <Pop at={sec(30.2)}>
          <Card style={{padding: '12px 20px', border: `3px solid ${C.red}`}}>
            <Label size={20} color={C.red}>Аллергия на хлоргексидин — скажите заранее</Label>
          </Card>
        </Pop>
      </div>
    </AbsoluteFill>
  );
};

const S6: React.FC = () => (
  <AbsoluteFill>
    <Tag n="ЕСЛИ НЕ МОЖЕТЕ ВСТАТЬ" />
    <div style={{position: 'absolute', left: 60, top: 80}}>
      <Cap text="Персонал протрёт кожу в постели" size={46} accent={['в', 'постели']} />
    </div>
    <div style={{position: 'absolute', left: 60, right: 60, top: 210, display: 'flex', gap: 40, justifyContent: 'center', alignItems: 'center'}}>
      <Pop at={sec(1.4)}><Card style={{padding: 30}}><Bed w={340} /></Card></Pop>
      <Pop at={sec(4)}><Card style={{padding: 26}}><Wipes /></Card></Pop>
    </div>
    <div style={{position: 'absolute', left: 0, right: 0, top: 560, display: 'flex', justifyContent: 'center'}}>
      <Note at={sec(7.4)}>Не смывают — кожа высыхает сама</Note>
    </div>
  </AbsoluteFill>
);

const Bar: React.FC<{label: string; hours: number; color: string; at: number; note?: string}> = ({label, hours, color, at, note}) => {
  const f = useCurrentFrame();
  const p = ease(f, sec(at), sec(at) + 30);
  const W = 640;
  const x = W - (hours / 9) * W;
  return (
    <div style={{position: 'relative', height: 74, marginBottom: 20, opacity: ease(f, sec(at), sec(at) + 8)}}>
      <Label size={21} style={{marginBottom: 8}}>{label}{note && <span style={{color: C.mute, fontWeight: 600}}> · {note}</span>}</Label>
      <div style={{position: 'relative', width: W, height: 34, background: '#eef1f3', borderRadius: 10}}>
        <div style={{position: 'absolute', left: 0, width: x * p + 0.001, height: 34, background: color, borderRadius: 10, opacity: 0.85}} />
        <div style={{position: 'absolute', left: x, top: -6, width: 4, height: 46, background: C.ink, opacity: p}} />
        <div style={{position: 'absolute', left: x + 10, top: 4, fontFamily: font, fontWeight: 800, fontSize: 20, color: C.ink, opacity: p}}>стоп за {hours} ч</div>
      </div>
    </div>
  );
};

const S7: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Tag n="НОЧЬ ПЕРЕД ОПЕРАЦИЕЙ" />
      <div style={{position: 'absolute', left: 60, top: 80}}>
        <Cap text="Перед анестезией желудок пустой" size={46} accent={['пустой']} />
      </div>
      <Pop at={sec(1.6)} style={{position: 'absolute', left: 60, top: 180}}>
        <Card style={{width: 330, background: C.dawnL}}>
          <Label size={22} color={'#b8661c'}>Почему</Label>
          <Label size={21} style={{fontWeight: 600, marginTop: 6}}>Чтобы содержимое желудка не попало в дыхательные пути во время анестезии</Label>
        </Card>
      </Pop>
      <div style={{position: 'absolute', left: 440, top: 190}}>
        <Bar label="Жирная и тяжёлая пища" hours={8} color={C.dawn} at={8.6} />
        <Bar label="Лёгкая пища" hours={6} color={'#f6c38f'} at={6.4} />
        <Bar label="Прозрачные жидкости" hours={2} color={C.teal2} at={11.6} note="иногда, если разрешили" />
        <div style={{display: 'flex', justifyContent: 'space-between', width: 640, fontFamily: font, fontSize: 16, color: C.mute, fontWeight: 600}}>
          <span>← раньше</span><span>анестезия</span>
        </div>
      </div>
      <div style={{position: 'absolute', left: 60, top: 470, display: 'flex', gap: 18, alignItems: 'center'}}>
        <Note at={sec(13.6)} color={C.red} bg={C.redL}>Соблюдайте время, которое назвал персонал</Note>
      </div>
      <div style={{position: 'absolute', left: 60, top: 540, display: 'flex', gap: 20}}>
        <Pop at={sec(17)}><Card style={{display: 'flex', alignItems: 'center', gap: 10, padding: '10px 18px'}}><Icon k="drip" s={64} /><Label size={20}>Капельница — при необходимости</Label></Card></Pop>
        <Pop at={sec(21.6)}><Card style={{display: 'flex', alignItems: 'center', gap: 10, padding: '10px 18px'}}><CallButton size={42} /><Label size={20}>В туалет — нажмите кнопку вызова</Label></Card></Pop>
        <Pop at={sec(28)}><Card style={{display: 'flex', alignItems: 'center', gap: 10, padding: '10px 18px'}}><Icon k="bed" s={64} /><Label size={20}>Не ходите — всё дадут в кровать</Label></Card></Pop>
      </div>
      <div style={{position: 'absolute', right: 60, top: 80, opacity: ease(f, 0, 12)}}><Icon k="alarm" s={70} /></div>
    </AbsoluteFill>
  );
};

const S8: React.FC = () => (
  <AbsoluteFill>
    <Tag n="ПРЕМЕДИКАЦИЯ" />
    <div style={{position: 'absolute', left: 60, top: 80}}>
      <Cap text="Лекарства для подготовки — если назначил врач" size={44} accent={['если', 'назначил']} width={1150} />
    </div>
    <div style={{position: 'absolute', left: 60, right: 60, top: 210, display: 'flex', gap: 36, justifyContent: 'center'}}>
      <Pop at={sec(6)}><Card style={{width: 460, height: 170, display: 'flex', alignItems: 'center', gap: 20}}><Icon k="pill" s={120} /><div><Label size={36}>Вабен</Label><Label size={24} color={C.mute} style={{fontWeight: 600}}>успокаивает</Label></div></Card></Pop>
      <Pop at={sec(8.6)}><Card style={{width: 520, height: 170, display: 'flex', alignItems: 'center', gap: 20}}><Icon k="pill" s={120} /><div><Label size={36}>Омепрадекс</Label><Label size={24} color={C.mute} style={{fontWeight: 600}}>снижает кислотность желудка</Label></div></Card></Pop>
    </div>
    <div style={{position: 'absolute', left: 0, right: 0, top: 450, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 22}}>
      <Note at={sec(12.6)}>Назначают не всем — решает врач</Note>
      <Note at={sec(15.4)} color={C.red} bg={C.redL}>После успокаивающего не вставайте сами — позовите медсестру</Note>
    </div>
  </AbsoluteFill>
);

const Leg2D: React.FC<{arrow: number}> = ({arrow}) => (
  <svg width={300} height={420} viewBox="0 0 300 420">
    {/* pelvis hint + right leg, front view */}
    <path d="M60 20 C 110 4, 200 6, 240 26 L 236 60 C 200 50, 120 50, 70 64 Z" fill="#ead2bf" />
    <path d="M86 56 C 130 46, 200 48, 232 58 C 236 110, 222 170, 206 214 C 200 232, 202 246, 200 262 C 196 300, 186 340, 184 372 C 184 384, 190 392, 214 398 C 230 402, 232 412, 220 414 L 160 414 C 150 414, 148 404, 150 392 C 152 360, 146 320, 142 284 C 140 266, 136 250, 130 232 C 112 180, 92 120, 86 56 Z" fill="#f2d7c2" stroke="#d9b79c" strokeWidth={3} strokeLinejoin="round" />
    <ellipse cx={170} cy={238} rx={20} ry={16} fill="none" stroke="#d9b79c" strokeWidth={2.5} />
    <g opacity={arrow} transform={`translate(0 ${(1 - arrow) * 20})`}>
      <path d="M184 170 L184 96" stroke="#2350c8" strokeWidth={9} strokeLinecap="round" />
      <path d="M162 116 L184 90 L206 116" stroke="#2350c8" strokeWidth={9} fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </g>
  </svg>
);

const S9: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Tag n="УТРО ОПЕРАЦИИ" />
      <div style={{position: 'absolute', left: 60, top: 80, display: 'flex', alignItems: 'center', gap: 24}}>
        <Pop at={2}><div style={{display: 'flex', alignItems: 'center', gap: 10, background: '#fff', borderRadius: 20, padding: '6px 18px', boxShadow: '0 8px 24px rgba(70,50,20,.1)'}}><Icon k="alarm" s={60} /><span style={{fontFamily: font, fontWeight: 800, fontSize: 44, color: C.ink}}>05:30</span></div></Pop>
        <Cap text="Рано утром — снова подготовка" size={44} accent={['снова']} at={10} />
      </div>
      <div style={{position: 'absolute', left: 60, top: 210, display: 'flex', gap: 18}}>
        <Step k="shower" title="Душ с тем же мылом" at={sec(3.6)} w={230} />
        <Step k="gown" title="Новый чистый халат" at={sec(5.6)} w={230} />
        <Step k="bed" title="Свежее бельё" at={sec(7)} w={230} />
      </div>
      <div style={{position: 'absolute', left: 60, top: 470, display: 'flex', flexDirection: 'column', gap: 14}}>
        <Note at={sec(10.4)} color={C.red} bg={C.redL}>До операционной не вставайте сами — позовите медсестру</Note>
        <Note at={sec(15.6)}>Капельница — при необходимости</Note>
      </div>
      <Pop at={sec(18.6)} style={{position: 'absolute', left: 840, top: 150}}>
        <Card style={{width: 380, height: 520, display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
          <Leg2D arrow={ease(f, sec(19.4), sec(20.4))} />
          <Label size={22} style={{textAlign: 'center'}}>Метка хирурга на оперируемой ноге</Label>
          <Label size={19} color={C.mute} style={{fontWeight: 600, textAlign: 'center', marginTop: 6, opacity: ease(f, sec(23.4), sec(24.2))}}>Не смывайте. Стёрлась — скажите медсестре</Label>
        </Card>
      </Pop>
    </AbsoluteFill>
  );
};

const S10: React.FC = () => {
  const f = useCurrentFrame();
  const items = [
    {t: 'Кардиостимулятор?', at: 3}, {t: 'Аллергия на лекарства', at: 4.6}, {t: 'Когда последний раз ели и пили', at: 6.4},
    {t: 'Лекарства, разжижающие кровь', at: 8.4}, {t: 'Украшения и предметы сняты', at: 10.4},
  ];
  const bedX = interpolate(f, [sec(19.2), sec(23.4)], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill>
      <Tag n="ПЕРЕД ОПЕРАЦИОННОЙ" />
      <div style={{position: 'absolute', left: 60, top: 80}}>
        <Cap text="Последние проверки безопасности" size={46} accent={['безопасности']} />
      </div>
      <Pop at={sec(1)} style={{position: 'absolute', left: 60, top: 180}}>
        <Card style={{width: 520}}>
          {items.map((it, i) => (
            <div key={i} style={{display: 'flex', alignItems: 'center', gap: 14, padding: '9px 0', borderBottom: i < items.length - 1 ? `1px solid ${C.line}` : 'none', opacity: 0.35 + 0.65 * ease(f, sec(it.at), sec(it.at) + 10)}}>
              <Check p={ease(f, sec(it.at), sec(it.at) + 18)} />
              <Label size={22}>{it.t}</Label>
            </div>
          ))}
        </Card>
      </Pop>
      <Pop at={sec(12.6)} style={{position: 'absolute', left: 640, top: 180}}>
        <Card style={{width: 580}}>
          <Label size={22} color={C.teal}>Санитар сверяет имя и фамилию</Label>
          <div style={{display: 'flex', alignItems: 'center', gap: 10, marginTop: 10}}>
            <Bracelet color="#ffffff" w={230} />
            <svg width={70} height={40}><path d="M6 20 L64 20 M14 10 L4 20 L14 30 M56 10 L66 20 L56 30" stroke={C.teal} strokeWidth={4} fill="none" strokeLinecap="round" /></svg>
            <div style={{transform: 'scale(0.8)'}}><Icon k="doc" s={90} /></div>
            <Check p={ease(f, sec(15), sec(16))} size={44} />
          </div>
          <Label size={19} color={C.mute} style={{fontWeight: 600}}>Это обязательная проверка, а не ошибка</Label>
        </Card>
      </Pop>
      <div style={{position: 'absolute', left: 640, top: 450, width: 580, height: 170, opacity: ease(f, sec(18.6), sec(19.4))}}>
        <div style={{position: 'absolute', left: 0, right: 0, top: 128, height: 10, borderRadius: 5, background: '#e9e1d5'}} />
        <div style={{position: 'absolute', right: 0, top: 6, background: C.teal, color: '#fff', fontFamily: font, fontWeight: 800, fontSize: 20, padding: '8px 14px', borderRadius: 12}}>Операционная</div>
        <div style={{position: 'absolute', left: bedX * 300, top: -20}}><Bed w={230} /></div>
      </div>
    </AbsoluteFill>
  );
};

const S11: React.FC = () => (
  <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
    <Pop at={4}>
      <Card style={{width: 900, padding: 40, textAlign: 'center', borderTop: `8px solid ${C.teal}`}}>
        <Label size={34} style={{lineHeight: 1.3}}>Это общие рекомендации.</Label>
        <Label size={30} color={C.mute} style={{fontWeight: 600, marginTop: 10, lineHeight: 1.3}}>Индивидуальные указания вашего врача и медицинской команды имеют приоритет.</Label>
      </Card>
    </Pop>
    <div style={{marginTop: 34}}><Note at={sec(6.4)} color={'#b8661c'} bg={C.dawnL}>Дальше — часть 2: после операции</Note></div>
  </AbsoluteFill>
);

const MAP: Record<string, React.FC<{d: number}>> = {
  S01: S1, S02: S2 as any, S03: S3 as any, S04: S4 as any, S04b: S4b as any, S05: S5 as any, S06: S6 as any,
  S07: S7 as any, S08: S8 as any, S09: S9 as any, S10: S10 as any, S11: S11 as any,
};

const Fade: React.FC<{d: number; children: React.ReactNode}> = ({d, children}) => {
  const f = useCurrentFrame();
  const o = Math.min(ease(f, 0, 10), 1 - ease(f, d - 10, d));
  return <AbsoluteFill style={{opacity: o}}>{children}</AbsoluteFill>;
};

export const Part1: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill>
      <Bg />
      {TT.map((x) => {
        const d = Math.round((x.dur + PAD) * FPS);
        const Comp = MAP[x.id];
        const el = (
          <Sequence key={x.id} from={at} durationInFrames={d} name={x.id}>
            <Fade d={d}><Comp d={d} /></Fade>
            {withAudio && <Sequence from={6}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
          </Sequence>
        );
        at += d;
        return el;
      })}
    </AbsoluteFill>
  );
};
