import {WalkerWalk, StairClimb} from './motion_en';
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {Bg, C, Cap, Card, Check, CallButton, Foot, FPS, Label, Note, Pop, Tag, ease, easeIO, font, G, K} from './ui';
import {Bed, Icon} from './Part1';
import timing from './timing2_en.json';

type T = {id: string; dur: number; audio?: string; k?: number}[];
const TT = timing as T;
const PAD = 0.75;
export const total2_en = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const sec = (s: number) => Math.round(s * FPS * G.k);
const P2TAG = 'HIP REPLACEMENT · PART 2';

const Vital: React.FC<{k: string; t: string; at: number}> = ({k, t, at}) => {
  const f = useCurrentFrame();
  const p = ease(f, sec(at), sec(at) + 14);
  const paths: Record<string, React.ReactNode> = {
    bp: <><rect x={20} y={36} width={40} height={30} rx={8} fill={C.tealL} stroke={C.ink} strokeWidth={4} /><path d="M60 50 C 76 50, 76 28, 64 22" stroke={C.ink} strokeWidth={4} fill="none" /><circle cx={70} cy={74} r={12} fill="#fff" stroke={C.ink} strokeWidth={4} /><path d="M70 74 L76 68" stroke={C.red} strokeWidth={3} strokeLinecap="round" /></>,
    pulse: <path d="M8 50 L30 50 L38 30 L50 72 L60 40 L66 50 L92 50" stroke={C.red} strokeWidth={5} fill="none" strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - p} />,
    breath: <><path d="M50 16 L50 44" stroke={C.ink} strokeWidth={4} strokeLinecap="round" /><path d="M46 44 C 30 40, 16 56, 18 76 C 20 86, 40 88, 46 76 Z M54 44 C 70 40, 84 56, 82 76 C 80 86, 60 88, 54 76 Z" fill={C.tealL} stroke={C.ink} strokeWidth={4} strokeLinejoin="round" /></>,
    dressing: <><rect x={14} y={30} width={72} height={40} rx={10} fill="#fff" stroke={C.ink} strokeWidth={4} /><rect x={30} y={40} width={40} height={20} rx={4} fill={C.dawnL} /></>,
    leg: <><path d="M40 10 C 50 8, 62 10, 64 16 L 60 60 L 62 84 C 70 86, 78 88, 78 92 L 44 92 L 44 62 Z" fill="#f2d7c2" stroke="#c9a283" strokeWidth={3} /><path d="M70 30 L84 22 M72 44 L88 44 M70 58 L84 66" stroke={C.teal} strokeWidth={4} strokeLinecap="round" /></>,
  };
  return (
    <div style={{opacity: p, transform: `translateY(${(1 - p) * 16}px)`}}>
      <Card style={{width: 200, height: 170, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6}}>
        <svg width={86} height={86} viewBox="0 0 100 100">{paths[k]}</svg>
        <Label size={20} style={{textAlign: 'center'}}>{t}</Label>
      </Card>
    </div>
  );
};

const P1: React.FC = () => {
  const f = useCurrentFrame();
  const x = interpolate(f, [sec(2.6), sec(5.4)], [-420, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: (t) => 1 - Math.pow(1 - t, 3)});
  return (
    <AbsoluteFill>
      <Tag n="AFTER SURGERY" part={P2TAG} />
      <div style={{position: 'absolute', left: 60, top: 80}}>
        <Cap text="First the recovery room, then the ward" size={44} accent={['recovery']} width={1150} />
      </div>
      <div style={{position: 'absolute', left: 60, top: 210, display: 'flex', alignItems: 'center', gap: 20}}>
        <Pop at={sec(0.8)}><div style={{background: C.tealL, color: C.teal, fontFamily: font, fontWeight: 800, fontSize: 22, padding: '12px 18px', borderRadius: 14}}>Recovery room</div></Pop>
        <svg width={80} height={30} style={{opacity: ease(f, sec(2.2), sec(2.8))}}><path d="M4 15 L66 15 M54 5 L68 15 L54 25" stroke={C.mute} strokeWidth={4} fill="none" strokeLinecap="round" /></svg>
        <Pop at={sec(2.4)}><div style={{background: C.teal, color: '#fff', fontFamily: font, fontWeight: 800, fontSize: 22, padding: '12px 18px', borderRadius: 14}}>Ward</div></Pop>
        <div style={{transform: `translateX(${x}px)`, opacity: ease(f, sec(2.6), sec(3.2)), marginLeft: 30}}><Bed w={210} /></div>
      </div>
      <div style={{position: 'absolute', left: 60, right: 60, top: 400, display: 'flex', gap: 22, justifyContent: 'center'}}>
        <Vital k="bp" t="Blood pressure" at={6.6} />
        <Vital k="pulse" t="Pulse" at={7.3} />
        <Vital k="breath" t="Breathing" at={8} />
        <Vital k="dressing" t="Dressing" at={8.7} />
        <Vital k="leg" t="Feeling and movement in the leg" at={9.6} />
      </div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 610, display: 'flex', justifyContent: 'center'}}>
        <Note at={sec(13.4)}>And straight away, pain relief</Note>
      </div>
    </AbsoluteFill>
  );
};

const Sip: React.FC<{n: string; p: number}> = ({n, p}) => (
  <svg width={130} height={150} viewBox="0 0 100 115">
    <path d="M22 12 L78 12 L70 104 L30 104 Z" fill="#eaf6fb" stroke={C.ink} strokeWidth={4} strokeLinejoin="round" />
    <path d={`M${25 + (1 - p) * 0} ${30 + (1 - p) * 0} L75 30 L70 102 L30 102 Z`} fill="#bfe3f0" opacity={0.95} />
    <text x={50} y={74} textAnchor="middle" fontFamily={font} fontWeight={800} fontSize={n.length > 1 ? 18 : 24} fill={C.teal}>{n}</text>
  </svg>
);

const P1b: React.FC = () => {
  const f = useCurrentFrame();
  const steps = [
    {t: '1 small sip', at: 15.6, k: 'glass'},
    {t: 'a short pause', at: 18.2, k: 'pause'},
    {t: 'a few more sips', at: 19.4, k: 'glass'},
    {t: 'more, and light food such as soup', at: 21.8, k: 'soup'},
  ];
  return (
    <AbsoluteFill>
      <Tag n="DRINKING AND EATING AFTER SURGERY" part={P2TAG} />
      <div style={{position: 'absolute', left: 60, top: 80}}>
        <Cap text="Drink and eat when you are awake enough and staff say it is okay" size={42} accent={['okay']} width={1160} />
      </div>
      <Pop at={sec(4.6)} style={{position: 'absolute', left: 60, top: 200}}>
        <Card style={{width: 420, background: C.dawnL}}>
          <Label size={22} color={'#b8661c'}>Why not straight away</Label>
          <Label size={21} style={{fontWeight: 600, marginTop: 6}}>Some anaesthesia and pain medicines cause drowsiness and nausea. A drowsy person finds it harder to swallow safely</Label>
        </Card>
      </Pop>
      <div style={{position: 'absolute', left: 520, top: 200, display: 'flex', gap: 14, alignItems: 'flex-end'}}>
        {steps.map((s, i) => {
          const p = ease(f, sec(s.at), sec(s.at) + 14);
          return (
            <div key={i} style={{opacity: p, transform: `translateY(${(1 - p) * 20}px)`}}>
              <Card style={{width: 165, height: 250, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-end', gap: 8, padding: '14px 10px'}}>
                {s.k === 'glass' && <Sip n={i === 0 ? '1' : '2–3'} p={1} />}
                {s.k === 'pause' && <svg width={110} height={110} viewBox="0 0 100 100"><circle cx={50} cy={52} r={34} fill="#fff" stroke={C.ink} strokeWidth={4} /><path d={`M50 52 L50 26`} stroke={C.teal} strokeWidth={5} strokeLinecap="round" transform={`rotate(${ease(f, sec(s.at), sec(s.at) + 60) * 120} 50 52)`} /><circle cx={50} cy={52} r={4} fill={C.ink} /></svg>}
                {s.k === 'soup' && <svg width={130} height={110} viewBox="0 0 100 85"><path d="M10 40 L90 40 C 90 66, 70 80, 50 80 C 30 80, 10 66, 10 40 Z" fill="#fff" stroke={C.ink} strokeWidth={4} strokeLinejoin="round" /><path d="M16 44 L84 44 C 82 58, 70 70, 50 70 C 30 70, 18 58, 16 44 Z" fill="#f6c38f" /><path d="M36 30 C 32 22, 40 18, 36 10 M52 30 C 48 22, 56 18, 52 10 M68 30 C 64 22, 72 18, 68 10" stroke={C.mute} strokeWidth={3} fill="none" strokeLinecap="round" /></svg>}
                <Label size={18} style={{textAlign: 'center'}}>{s.t}</Label>
              </Card>
            </div>
          );
        })}
      </div>
      <div style={{position: 'absolute', left: 60, top: 500, display: 'flex', flexDirection: 'column', gap: 14}}>
        <Note at={sec(11.6)}>Ask the nurse first</Note>
        <Note at={sec(25.4)} color={'#b8661c'} bg={C.dawnL}>No need to go without food longer than necessary</Note>
      </div>
      <Pop at={sec(27.6)} style={{position: 'absolute', left: 640, top: 500}}>
        <Card style={{width: 580, display: 'flex', alignItems: 'center', gap: 14}}>
          <Icon k="drip" s={70} />
          <Label size={21}>Feeling sick? Tell the nurse: there are medicines, including through the cannula</Label>
        </Card>
      </Pop>
    </AbsoluteFill>
  );
};

const Arm: React.FC<{f: number}> = ({f}) => {
  // needle in (2.4–4.4 s), needle out (5.6–7.4 s), soft catheter remains
  const inP = easeIO(f, sec(2.4), sec(4.4));
  const outP = easeIO(f, sec(5.6), sec(7.4));
  const nx = 120 + 150 * inP - 220 * outP;
  return (
    <svg width={620} height={300} viewBox="0 0 620 300">
      <path d="M0 110 C 160 90, 420 96, 620 120 L 620 230 C 420 220, 160 230, 0 250 Z" fill="#f2d7c2" stroke="#d9b79c" strokeWidth={3} />
      <path d="M0 172 C 180 160, 420 166, 620 180" stroke="#6f8fd8" strokeWidth={16} fill="none" strokeLinecap="round" opacity={0.75} />
      {/* soft catheter in the vein */}
      <path d={`M250 158 L ${250 + 110 * inP} 166`} stroke="#f3f3f3" strokeWidth={7} strokeLinecap="round" />
      <path d={`M250 158 L ${250 + 110 * inP} 166`} stroke={C.teal2} strokeWidth={3} strokeLinecap="round" opacity={0.9} />
      {/* hub */}
      <rect x={196} y={140} width={58} height={22} rx={6} fill={C.dawn} opacity={ease(f, sec(2), sec(2.4))} />
      <path d="M200 140 L186 120 M250 140 L264 120" stroke={C.dawn} strokeWidth={6} strokeLinecap="round" opacity={ease(f, sec(2), sec(2.4))} />
      {/* metal needle */}
      <g opacity={1 - ease(f, sec(7.2), sec(7.8))}>
        <path d={`M${nx - 140} 150 L ${nx + 110} 166`} stroke="#9aa5b1" strokeWidth={3.5} strokeLinecap="round" />
        <rect x={nx - 200} y={138} width={60} height={20} rx={5} fill="#cfd6dd" />
      </g>
      {/* plaster */}
      <rect x={180} y={128} width={110} height={50} rx={10} fill="#fff" opacity={0.75 * ease(f, sec(8), sec(9))} />
    </svg>
  );
};

const P2: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Tag n="CANNULA IN THE VEIN" part={P2TAG} />
      <div style={{position: 'absolute', left: 60, top: 80}}>
        <Cap text="The needle only pierces; a soft tube stays in the vein" size={42} accent={['soft']} width={1160} />
      </div>
      <Pop at={sec(1)} style={{position: 'absolute', left: 60, top: 190}}>
        <Card style={{padding: 10}}><Arm f={f} /></Card>
      </Pop>
      <div style={{position: 'absolute', left: 60, top: 520, display: 'flex', gap: 14, flexWrap: 'wrap', width: 640}}>
        <Note at={sec(3.4)} color={C.mute} bg="#eef1f3">metal needle</Note>
        <Note at={sec(6.4)}>a soft catheter stays</Note>
      </div>
      <div style={{position: 'absolute', left: 740, top: 190, width: 480, display: 'flex', flexDirection: 'column', gap: 16}}>
        <Pop at={sec(9.4)}><Card><Label size={22}>You can move your arm carefully</Label><Label size={19} color={C.mute} style={{fontWeight: 600, marginTop: 4}}>Cannula in the bend of the elbow? Do not bend the elbow too much</Label></Card></Pop>
        <Pop at={sec(16.4)}><Card style={{background: C.tealL}}><Label size={21}>Medicines and fluids go straight into the blood and work quickly</Label></Card></Pop>
        <Pop at={sec(20.4)}><Card style={{background: C.redL}}><Label size={21} color={C.red}>Pain, burning, swelling, leaking? Tell the nurse at once</Label></Card></Pop>
      </div>
    </AbsoluteFill>
  );
};

const P3: React.FC = () => {
  const f = useCurrentFrame();
  const items = ['tablets', 'through the vein', 'as planned'];
  return (
    <AbsoluteFill>
      <Tag n="PAIN RELIEF" part={P2TAG} />
      <div style={{position: 'absolute', left: 60, top: 80}}>
        <Cap text="Several medicines together, so you can rest and move" size={42} accent={['together']} width={1160} />
      </div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 220, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 30}}>
        {items.map((t, i) => (
          <Pop key={i} at={sec(1.4 + i * 0.9)}><Card style={{width: 220, textAlign: 'center'}}><Icon k={i === 1 ? 'drip' : 'pill'} s={80} /><Label size={22}>{t}</Label></Card></Pop>
        ))}
        <svg width={170} height={190} viewBox="0 0 100 112" style={{opacity: ease(f, sec(4.6), sec(5.4))}}>
          <path d="M50 4 L92 20 L92 56 C 92 84, 70 102, 50 108 C 30 102, 8 84, 8 56 L 8 20 Z" fill={C.tealL} stroke={C.teal} strokeWidth={5} strokeLinejoin="round" />
          <path d="M32 56 L46 70 L70 42" stroke={C.teal} strokeWidth={7} fill="none" strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - ease(f, sec(5), sec(6))} />
        </svg>
      </div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 520, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 18}}>
        <CallButton size={48} glow={(Math.sin(f / 6) + 1) / 2} />
        <Note at={sec(8.6)} color={'#b8661c'} bg={C.dawnL}>Don’t put up with pain: tell the nurse</Note>
      </div>
    </AbsoluteFill>
  );
};

const P4: React.FC = () => {
  const f = useCurrentFrame();
  const doses = [0, 1, 2];
  return (
    <AbsoluteFill>
      <Tag n="INFECTION AND BLOOD CLOTS" part={P2TAG} />
      <div style={{position: 'absolute', left: 60, top: 80}}>
        <Cap text="Prevention: antibiotic and injections against clots" size={42} accent={['antibiotic', 'clots']} width={1160} />
      </div>
      <Pop at={sec(1)} style={{position: 'absolute', left: 60, top: 190}}>
        <Card style={{width: 560}}>
          <Label size={23} color={C.teal}>Antibiotic through the vein</Label>
          <div style={{position: 'relative', height: 120, marginTop: 14}}>
            <div style={{position: 'absolute', left: 10, right: 10, top: 50, height: 6, borderRadius: 3, background: C.line}} />
            <div style={{position: 'absolute', left: 0, top: 22, textAlign: 'center', width: 110, opacity: ease(f, sec(2), sec(3))}}>
              <div style={{width: 40, height: 40, borderRadius: 20, background: C.dawn, margin: '8px auto 0'}} />
              <Label size={16} style={{marginTop: 6}}>before surgery</Label>
            </div>
            {doses.map((d) => (
              <div key={d} style={{position: 'absolute', left: 150 + d * 130, top: 22, textAlign: 'center', width: 110, opacity: ease(f, sec(7 + d * 1.2), sec(8 + d * 1.2))}}>
                <div style={{width: 40, height: 40, borderRadius: 20, background: d === 2 ? '#fff' : C.teal, border: `3px ${d === 2 ? 'dashed' : 'solid'} ${C.teal}`, margin: '8px auto 0'}} />
                <Label size={16} style={{marginTop: 6}}>+{(d + 1) * 8} h</Label>
              </div>
            ))}
          </div>
          <Label size={18} color={C.mute} style={{fontWeight: 600}}>After surgery usually 2–3 doses, about every 8 hours, as the doctor prescribes</Label>
        </Card>
      </Pop>
      <Pop at={sec(14.6)} style={{position: 'absolute', left: 660, top: 190}}>
        <Card style={{width: 560}}>
          <Label size={23} color={C.teal}>Against clots: enoxaparin</Label>
          <div style={{display: 'flex', alignItems: 'center', gap: 16, marginTop: 10}}>
            <svg width={240} height={120} viewBox="0 0 240 120">
              <rect x={30} y={44} width={130} height={30} rx={8} fill="#fff" stroke={C.ink} strokeWidth={3.5} />
              <rect x={40} y={50} width={80} height={18} rx={3} fill={C.tealL} />
              <path d="M160 59 L210 59" stroke={C.ink} strokeWidth={2} />
              <path d="M30 59 L8 59 M8 46 L8 72" stroke={C.ink} strokeWidth={4} strokeLinecap="round" />
              <rect x={150} y={48} width={14} height={22} rx={3} fill="#cfd6dd" />
            </svg>
            <div>
              <Label size={20}>Clexane or Crusia</Label>
              <Label size={18} color={C.mute} style={{fontWeight: 600}}>pre-filled syringe, thin needle, injection under the skin of the abdomen</Label>
            </div>
          </div>
          <div style={{display: 'flex', gap: 12, marginTop: 12}}>
            <Note at={sec(19)}>≈ 12 h after surgery</Note>
          </div>
        </Card>
      </Pop>
      <div style={{position: 'absolute', left: 60, right: 60, top: 560, display: 'flex', gap: 14, justifyContent: 'center', flexWrap: 'wrap'}}>
        <Note at={sec(23)} color={'#b8661c'} bg={C.dawnL}>The doctor decides when to give the first injection</Note>
        <Note at={sec(29)}>Sometimes also after discharge</Note>
      </div>
    </AbsoluteFill>
  );
};

const P5: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Tag n="DAY OF SURGERY" part={P2TAG} />
      <div style={{position: 'absolute', left: 60, top: 80}}>
        <Cap text="On the day of surgery you stay in bed, rails raised" size={44} accent={['rails']} width={1160} />
      </div>
      <Pop at={sec(1)} style={{position: 'absolute', left: 60, top: 200}}>
        <Card style={{width: 520, height: 330, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative'}}>
          <Bed w={380} rails={ease(f, sec(5), sec(6.5))} />
          <div style={{position: 'absolute', right: 30, top: 30}}><CallButton size={60} glow={(Math.sin(f / 6) + 1) / 2 * ease(f, sec(16), sec(17))} /></div>
        </Card>
      </Pop>
      <div style={{position: 'absolute', left: 620, top: 200, width: 600, display: 'flex', flexDirection: 'column', gap: 14}}>
        <Pop at={sec(5.5)}><Card style={{background: C.tealL}}><Label size={22}>Rails always raised while you are in bed: less risk of falling out of bed</Label></Card></Pop>
        <Pop at={sec(11)}><Card style={{background: C.redL}}><Label size={21} color={C.red}>Do not climb over the rails or lower them yourself</Label></Card></Pop>
        <Pop at={sec(15.5)}><Card><Label size={21}>For help, press the call button</Label></Card></Pop>
        <Pop at={sec(19.5)}><Card><Label size={21}>Toilet: staff will help or bring a urinal or bedpan</Label></Card></Pop>
        <Pop at={sec(22.5)}><Card style={{background: C.dawnL}}><Label size={20}>First time up: usually the next day, with the physiotherapist, when it is safe</Label></Card></Pop>
      </div>
    </AbsoluteFill>
  );
};

const Walker: React.FC<{p: number}> = ({p}) => (
  <svg width={300} height={340} viewBox="0 0 300 340">
    {/* walker */}
    <g stroke="#7f8a96" strokeWidth={7} strokeLinecap="round" fill="none">
      <path d="M170 150 L200 150 M170 150 L160 320 M200 150 L214 320 M150 220 L222 220" />
    </g>
    {/* figure: rises from sitting (p=0) to standing (p=1) */}
    <g transform={`translate(0 ${(1 - p) * 60})`}>
      <circle cx={120} cy={70} r={24} fill={C.teal} />
      <path d={`M120 96 L ${120 + 6 * p} 190`} stroke={C.teal} strokeWidth={22} strokeLinecap="round" />
      <path d={`M124 120 L 176 ${150 - 10 * (1 - p)}`} stroke={C.teal} strokeWidth={14} strokeLinecap="round" />
      <path d={`M${124 + 6 * p} 190 L ${150 - 30 * p} ${250 + 30 * p} L ${130 - 10 * p} 320`} stroke={C.teal} strokeWidth={18} strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <path d={`M${120 + 6 * p} 190 L ${100 + 4 * p} ${250 + 30 * p} L ${110 - 6 * p} 320`} stroke={C.teal2} strokeWidth={18} strokeLinecap="round" strokeLinejoin="round" fill="none" />
    </g>
  </svg>
);

const P6: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Tag n="THE NEXT DAY" part={P2TAG} />
      <div style={{position: 'absolute', left: 60, top: 80}}>
        <Cap text="Check X-ray and first steps" size={44} accent={['first']} width={1160} />
      </div>
      <Pop at={sec(1)} style={{position: 'absolute', left: 60, top: 180}}>
        <Card style={{background: '#111', padding: 10}}>
          <div style={{width: 400, height: 380, overflow: 'hidden', borderRadius: 12}}>
            <Img src={staticFile('Hip_replacement_xray_3684-PH.jpg')} style={{width: '100%', height: '100%', objectFit: 'cover', transform: `scale(${interpolate(f, [0, 300], [1, 1.06], {extrapolateRight: 'clamp'})})`}} />
          </div>
        </Card>
      </Pop>
      <div style={{position: 'absolute', left: 60, top: 590, width: 420, fontFamily: font, fontSize: 13, color: C.mute, opacity: ease(f, sec(2), sec(3))}}>Example X-ray after hip replacement. Image: public domain (X-ray Image ID 3684)</div>
      <Pop at={sec(4.4)} style={{position: 'absolute', left: 520, top: 170}}>
        <Card style={{width: 330, height: 420, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center'}}>
          {f < sec(10.5) ? <Walker p={easeIO(f, sec(6), sec(9.6))} /> : <div style={{width: 315, height: 340, display: 'flex', alignItems: 'center', opacity: ease(f, sec(10.5), sec(11))}}><div style={{transform: 'scale(0.75)', transformOrigin: '0 50%'}}><WalkerWalk from={sec(10.5)} /></div></div>}
          <Label size={20} style={{textAlign: 'center'}}>The physiotherapist helps you sit, stand and walk</Label>
        </Card>
      </Pop>
      <div style={{position: 'absolute', left: 880, top: 180, width: 340, display: 'flex', flexDirection: 'column', gap: 14}}>
        <Pop at={sec(11)}><Card style={{background: C.tealL}}><Label size={20}>Moving early helps recovery and lowers the risk of complications from lying in bed for long</Label></Card></Pop>
        <Pop at={sec(16.4)}><Card style={{background: C.redL}}><Label size={20} color={C.red}>Get up and walk only when it is safe and with the team’s help</Label></Card></Pop>
      </div>
    </AbsoluteFill>
  );
};

const P7: React.FC = () => {
  const f = useCurrentFrame();
  const cyc = (Math.sin((f - sec(5)) / 22) + 1) / 2 * ease(f, sec(5), sec(6));
  return (
    <AbsoluteFill>
      <Tag n="BREATHING" part={P2TAG} />
      <div style={{position: 'absolute', left: 60, top: 80}}>
        <Cap text="Breathing exerciser: a slow, deep breath in" size={44} accent={['deep']} width={1160} />
      </div>
      <Pop at={sec(3)} style={{position: 'absolute', left: 140, top: 190}}>
        <Card style={{width: 380, height: 400, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
          <svg width={300} height={340} viewBox="0 0 200 230">
            <rect x={40} y={40} width={50} height={150} rx={12} fill="#f4f9fb" stroke={C.ink} strokeWidth={4} />
            <circle cx={65} cy={176 - 120 * cyc} r={16} fill={C.dawn} />
            <rect x={36} y={190} width={58} height={20} rx={6} fill="#cfd6dd" stroke={C.ink} strokeWidth={3} />
            <path d="M94 200 C 140 200, 150 170, 150 130 L 150 90" stroke="#9aa5b1" strokeWidth={10} fill="none" strokeLinecap="round" />
            <rect x={138} y={66} width={24} height={30} rx={6} fill={C.teal} />
            <path d="M120 40 L140 60" stroke={C.teal} strokeWidth={4} strokeLinecap="round" opacity={cyc} />
          </svg>
        </Card>
      </Pop>
      <div style={{position: 'absolute', left: 600, top: 200, width: 600, display: 'flex', flexDirection: 'column', gap: 16}}>
        <Pop at={sec(1)}><Card><Label size={21}>Sit up in bed or in a chair and do breathing exercises</Label></Card></Pop>
        <Pop at={sec(5.4)}><Card style={{background: C.tealL}}><Label size={21}>Breathe in slowly and deeply through the mouthpiece, as staff show you</Label></Card></Pop>
        <Pop at={sec(10)}><Card><Label size={21}>This helps your lungs expand better</Label></Card></Pop>
        <Pop at={sec(13)}><Card style={{background: C.dawnL}}><Label size={20}>Best together with pain relief and early, safe movement</Label></Card></Pop>
      </div>
    </AbsoluteFill>
  );
};

const P8: React.FC = () => {
  const items = ['Pain has suddenly got much worse', 'New weakness or numbness in the leg', 'The foot has become cold', 'The dressing is very wet', 'New pain or swelling in the calf', 'Hard to breathe or chest pain'];
  return (
    <AbsoluteFill>
      <Tag n="CALL THE NURSE AT ONCE" part={P2TAG} />
      <div style={{position: 'absolute', left: 60, top: 80, display: 'flex', alignItems: 'center', gap: 20}}>
        <CallButton size={56} glow={1} />
        <Cap text="Press the call button at once if:" size={44} acc={C.red} accent={['once']} />
      </div>
      <Pop at={sec(1)} style={{position: 'absolute', left: 60, right: 60, top: 200}}>
        <Card style={{borderLeft: `10px solid ${C.red}`, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '18px 40px', padding: '30px 34px'}}>
          {items.map((t, i) => (
            <div key={i} style={{display: 'flex', alignItems: 'center', gap: 14}}>
              <div style={{width: 16, height: 16, borderRadius: 8, background: C.red, flex: 'none'}} />
              <Label size={26}>{t}</Label>
            </div>
          ))}
        </Card>
      </Pop>
    </AbsoluteFill>
  );
};

const P9: React.FC = () => (
  <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
    <Pop at={4}>
      <Card style={{width: 900, padding: 40, textAlign: 'center', borderTop: `8px solid ${C.teal}`}}>
        <Label size={34} style={{lineHeight: 1.3}}>These are general recommendations.</Label>
        <Label size={30} color={C.mute} style={{fontWeight: 600, marginTop: 10, lineHeight: 1.3}}>Individual instructions from your doctor and medical team come first.</Label>
      </Card>
    </Pop>
    <div style={{marginTop: 34}}><Note at={sec(6.4)} color={'#b8661c'} bg={C.dawnL}>Next, part 3: discharge, rehabilitation and returning home</Note></div>
  </AbsoluteFill>
);

const MAP: Record<string, React.FC> = {P01: P1, P01b: P1b, P02: P2, P03: P3, P04: P4, P05: P5, P06: P6, P07: P7, P08: P8, P09: P9};

const Fade: React.FC<{d: number; children: React.ReactNode}> = ({d, children}) => {
  const f = useCurrentFrame();
  const o = Math.min(ease(f, 0, 10), 1 - ease(f, d - 10, d));
  const sc = 1 + 0.035 * (f / Math.max(d, 1));
  return <AbsoluteFill style={{opacity: o, transform: `scale(${sc})`, transformOrigin: '50% 45%'}}>{children}</AbsoluteFill>;
};

export const Part2_en: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  G.rtl = false;
  let at = 0;
  return (
    <AbsoluteFill>
      <Bg />
      {TT.map((x) => {
        const d = Math.round((x.dur + PAD) * FPS);
        const Comp = MAP[x.id];
        const el = (
          <Sequence key={x.id} from={at} durationInFrames={d} name={x.id}>
            <Fade d={d}><K k={x.k}><Comp /></K></Fade>
            {withAudio && x.audio && <Sequence from={6}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
          </Sequence>
        );
        at += d;
        return el;
      })}
    </AbsoluteFill>
  );
};
