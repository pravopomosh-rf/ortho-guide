import {useMesh} from './Leg3D';
import React, {useEffect, useMemo, useState} from 'react';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import {useCurrentFrame, interpolate, Easing, staticFile, delayRender, continueRender} from 'remotion';
import * as THREE from 'three';
import {STLLoader} from 'three/examples/jsm/loaders/STLLoader.js';
import BP from './bp3d.json';

// Real bone geometry: BodyParts3D (c) 2008 Life Science Integrated Database Center, CC BY-SA 2.1 JP

const cl = (f: number, a: number, b: number) =>
  interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic)});

const K = 0.98 / BP.r;
const V = (a: number[]) => new THREE.Vector3(a[0], a[1], a[2]);
const DOME = V(BP.dome).normalize();
const NECK = V(BP.neck).normalize();
const S620 = V(BP.s620).multiplyScalar(K);

function mergeVerts(geo: THREE.BufferGeometry) {
  const p = geo.attributes.position as THREE.BufferAttribute;
  const map = new Map<string, number>();
  const verts: number[] = [];
  const idx: number[] = [];
  for (let i = 0; i < p.count; i++) {
    const key = `${p.getX(i).toFixed(4)},${p.getY(i).toFixed(4)},${p.getZ(i).toFixed(4)}`;
    let j = map.get(key);
    if (j === undefined) {
      j = verts.length / 3;
      map.set(key, j);
      verts.push(p.getX(i), p.getY(i), p.getZ(i));
    }
    idx.push(j);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
  g.setIndex(idx);
  return g;
}

const cache: Record<string, THREE.BufferGeometry> = {};
const useBone = (name: string) => {
  const [g, setG] = useState<THREE.BufferGeometry | null>(cache[name] ?? null);
  const [h] = useState(() => (cache[name] ? null : delayRender('stl ' + name, {timeoutInMilliseconds: 120000})));
  useEffect(() => {
    if (cache[name]) {
      if (!g) setG(cache[name]);
      if (h !== null) continueRender(h);
      return;
    }
    fetch(staticFile(`bp3d/${name}.stl`))
      .then((r) => r.arrayBuffer())
      .then((buf) => {
        const geo = new STLLoader().parse(buf);
        const p = geo.attributes.position as THREE.BufferAttribute;
        const [cx, cy, cz] = BP.c;
        for (let i = 0; i < p.count; i++) {
          const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
          p.setXYZ(i, (x - cx) * K, (z - cz) * K, -(y - cy) * K);
        }
        const merged = mergeVerts(geo);
        merged.computeVertexNormals();
        cache[name] = merged;
        setG(merged);
        if (h !== null) continueRender(h);
      });
  }, [name, h]);
  return g;
};

const hash = (x: number, y: number, z: number) => {
  const s = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453;
  return s - Math.floor(s);
};
const noise = (x: number, y: number, z: number) => {
  const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
  const xf = x - xi, yf = y - yi, zf = z - zi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf), w = zf * zf * (3 - 2 * zf);
  let r = 0;
  for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) for (let k = 0; k < 2; k++) {
    r += hash(xi + i, yi + j, zi + k) * (i ? u : 1 - u) * (j ? v : 1 - v) * (k ? w : 1 - w);
  }
  return r;
};

const BONE = '#e8d6b0';
const CART = '#7fbdf0';
const qFromY = (d: THREE.Vector3) => new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.clone().normalize());

const Cartilage: React.FC<{r: number; thick: number; wear: number; theta: number; opacity?: number; seed?: number; side?: THREE.Side}> = ({r, thick, wear, theta, opacity = 1, seed = 0, side = THREE.FrontSide}) => {
  const base = useMemo(() => new THREE.SphereGeometry(1, 120, 80, 0, Math.PI * 2, 0, theta), [theta]);
  const geo = useMemo(() => {
    const g = base.clone();
    const pos = g.attributes.position as THREE.BufferAttribute;
    const cols = new Float32Array(pos.count * 3);
    const c0 = new THREE.Color(CART), c1 = new THREE.Color('#d0785a'), tmp = new THREE.Color();
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
      const n = noise(x * 3 + seed, y * 3, z * 3) * 0.6 + noise(x * 8 + seed, y * 8, z * 8) * 0.4;
      const load = 0.55 + 0.45 * y;
      const loss = wear * load * (0.6 + 1.1 * Math.max(0, n - 0.32));
      const rr = r + thick * (1 - Math.min(1.25, loss));
      pos.setXYZ(i, x * rr, y * rr, z * rr);
      tmp.copy(c0).lerp(c1, Math.min(1, Math.max(0, loss - 0.4) * 1.7));
      cols.set([tmp.r, tmp.g, tmp.b], i * 3);
    }
    g.setAttribute('color', new THREE.BufferAttribute(cols, 3));
    g.computeVertexNormals();
    return g;
  }, [base, r, thick, wear, seed]);
  return (
    <mesh geometry={geo} quaternion={qFromY(DOME)}>
      <meshStandardMaterial vertexColors roughness={0.3} transparent={opacity < 1} opacity={opacity} side={side} />
    </mesh>
  );
};

const Osteophytes: React.FC<{s: number}> = ({s}) => {
  if (s <= 0.001) return null;
  const q = qFromY(DOME);
  const items = [0, 1, 2, 3, 4, 5, 6].map((i) => {
    const a = (i / 7) * Math.PI * 2 + 0.4;
    const th = Math.PI * 0.6;
    const local = new THREE.Vector3(Math.sin(th) * Math.cos(a), Math.cos(th), Math.sin(th) * Math.sin(a)).applyQuaternion(q);
    return {p: local.clone().multiplyScalar(0.99), q: qFromY(local), k: 0.7 + (0.5 * ((i * 37) % 10)) / 10};
  });
  return (
    <group>
      {items.map((o, i) => (
        <mesh key={i} position={o.p} quaternion={o.q} scale={[s * 0.18 * o.k, s * 0.42 * o.k, s * 0.18 * o.k]}>
          <coneGeometry args={[1, 1, 14]} />
          <meshStandardMaterial color="#d9c391" roughness={0.85} />
        </mesh>
      ))}
    </group>
  );
};

const Cyl: React.FC<{a: THREE.Vector3; b: THREE.Vector3; r1: number; r2: number; flat?: number; children: React.ReactNode}> = ({a, b, r1, r2, flat = 1, children}) => {
  const d = b.clone().sub(a);
  const mid = a.clone().add(b).multiplyScalar(0.5);
  return (
    <mesh position={mid} quaternion={qFromY(d)} scale={[1, 1, flat]}>
      <cylinderGeometry args={[r2, r1, d.length(), 40]} />
      {children}
    </mesh>
  );
};

const CUT = 1.55;
const lerpN = (a: number, b: number, p: number) => a + (b - a) * p;
export type Cam = {yaw: number; dist: number; target: [number, number, number]; pitch: number};
export const camFor = (mode: Hip3DMode, t: number, spin = 0.5, dist?: number): Cam => {
  const nearD = dist ?? (mode === 'oa' ? 9.5 : 15.5);
  const nearT: [number, number, number] = mode === 'oa' ? [0.2, 0.1, 0] : [0.8, 0.9, 0];
  const nearYaw = -0.1 + Math.sin(t / 80) * spin * 0.7;
  if (mode !== 'anatomy') return {yaw: nearYaw, dist: nearD, target: nearT, pitch: 0.08};
  const p = cl(t, 80, 150);
  const farYaw = -0.3 + Math.sin(t / 60) * 0.12;
  return {
    yaw: lerpN(farYaw, nearYaw, p),
    dist: lerpN(64, nearD, p),
    target: [lerpN(0.3, nearT[0], p), lerpN(-14.4, nearT[1], p), 0],
    pitch: lerpN(0.05, 0.08, p),
  };
};
const camPos = (c: Cam) => new THREE.Vector3(
  c.target[0] + c.dist * Math.sin(c.yaw) * Math.cos(c.pitch),
  c.target[1] + c.dist * Math.sin(c.pitch),
  c.target[2] + c.dist * Math.cos(c.yaw) * Math.cos(c.pitch),
);
export const projectPt = (c: Cam, pt: number[], w: number, h: number) => {
  const cam = new THREE.PerspectiveCamera(40, w / h, 0.1, 500);
  cam.position.copy(camPos(c));
  cam.lookAt(c.target[0], c.target[1], c.target[2]);
  cam.updateMatrixWorld();
  const v = new THREE.Vector3(pt[0], pt[1], pt[2]).project(cam);
  return {x: ((v.x + 1) / 2) * w, y: ((1 - v.y) / 2) * h};
};
export const LBL: Record<string, number[]> = (BP as any).labels;

const CamRig: React.FC<{yaw: number; dist: number; target: [number, number, number]; pitch?: number}> = ({yaw, dist, target, pitch = 0.08}) => {
  const {camera} = useThree();
  camera.position.copy(camPos({yaw, dist, target, pitch}));
  camera.lookAt(target[0], target[1], target[2]);
  camera.updateProjectionMatrix();
  return null;
};

export type Hip3DMode = 'anatomy' | 'oa' | 'prosthesis';

export const Hip3D: React.FC<{mode: Hip3DMode; start?: number; len?: number; width: number; height: number; spin?: number; dist?: number}> = ({
  mode, start = 0, len = 240, width, height, spin = 0.5, dist,
}) => {
  const D = dist ?? (mode === 'oa' ? 9.5 : 15.5);
  const hip = useMesh('hip_r');
  const fem = useMesh('femur_r');
  const leg = useMesh('leg_r');
  const f = useCurrentFrame();
  const t = f - start;
  const cam = camFor(mode, t, spin, dist);
  const wear = mode === 'oa' ? cl(t, 20, len * 0.75) : 0;
  const osteo = mode === 'oa' ? cl(t, len * 0.35, len * 0.85) : 0;
  const P = mode === 'prosthesis';
  const out = P ? cl(t, len * 0.06, len * 0.26) : 0;
  const cup = P ? cl(t, len * 0.28, len * 0.5) : 0;
  const stem = P ? cl(t, len * 0.52, len * 0.74) : 0;
  const ball = P ? cl(t, len * 0.76, len * 0.94) : 0;

  const keepPlane = useMemo(() => new THREE.Plane(NECK.clone(), -CUT), []);
  const top = NECK.clone().multiplyScalar(CUT + 0.55);
  const bottom = top.clone().add(S620.clone().sub(top).normalize().multiplyScalar(5.0));
  const trunnion = NECK.clone().multiplyScalar(0.35);

  const cutPlane = new THREE.Plane(NECK.clone().negate(), CUT);
  const pelvisOpacity = P ? 0.5 - 0.2 * cup : mode === 'oa' ? 0.32 : 0.5;
  const femOpacity = P ? 1 - 0.6 * stem : 1;
  const away = NECK.clone().negate().add(new THREE.Vector3(-1.2, -0.2, 0.6)).normalize().multiplyScalar(out * 3);
  cutPlane.constant = CUT + NECK.dot(away);
  const cupFrom = DOME.clone().multiplyScalar(-(1 - cup) * 5);
  const ballFrom = new THREE.Vector3(-1, -0.4, 1).normalize().multiplyScalar((1 - ball) * 3.5);
  const stemFrom = top.clone().sub(bottom).normalize().multiplyScalar((1 - stem) * 7);

  return (
    <ThreeCanvas
      width={width}
      height={height}
      camera={{position: [0, 0, D], fov: 40, near: 0.1, far: 500}}
      gl={{antialias: true, alpha: true}}
      onCreated={({gl}: any) => {
        gl.localClippingEnabled = true;
      }}
    >
      <hemisphereLight args={['#ffffff', '#b3a184', 0.95]} />
      <directionalLight position={[5, 6, 9]} intensity={1.7} />
      <directionalLight position={[-7, -1, 4]} intensity={0.55} color="#d4e6ff" />
      <CamRig yaw={cam.yaw} dist={cam.dist} target={cam.target} pitch={cam.pitch} />
      <group>
        {leg && mode === 'anatomy' && (
          <mesh geometry={leg}>
            <meshStandardMaterial color={BONE} roughness={0.7} />
          </mesh>
        )}
        {fem && (
          <mesh geometry={fem}>
            <meshStandardMaterial color={BONE} roughness={0.7} transparent={femOpacity < 1} opacity={femOpacity} depthWrite={femOpacity >= 1} clippingPlanes={P && out > 0 ? [keepPlane] : []} side={THREE.DoubleSide} />
          </mesh>
        )}
        {fem && P && out > 0 && out < 1 && (
          <group position={away}>
            <mesh geometry={fem}>
              <meshStandardMaterial color={BONE} roughness={0.7} transparent opacity={1 - out} clippingPlanes={[cutPlane]} side={THREE.DoubleSide} />
            </mesh>
          </group>
        )}
        {(!P || out === 0) && (
          <>
            <Cartilage r={0.99} thick={0.07} wear={wear} theta={Math.PI * 0.62} seed={1} />
            <Osteophytes s={osteo} />
          </>
        )}
        {(!P || cup < 0.3) && <Cartilage r={1.035} thick={0.045} wear={wear * 0.9} theta={Math.PI * 0.46} seed={5} side={THREE.BackSide} opacity={P ? Math.max(0.01, 1 - cup * 3) : 1} />}
        {hip && (
          <mesh geometry={hip} renderOrder={5}>
            <meshStandardMaterial color={BONE} roughness={0.75} transparent opacity={pelvisOpacity} depthWrite={false} side={THREE.DoubleSide} />
          </mesh>
        )}
        {P && (
          <group>
            {cup > 0.001 && (
              <group position={cupFrom} quaternion={qFromY(DOME)}>
                <mesh>
                  <sphereGeometry args={[1.12, 72, 40, 0, Math.PI * 2, 0, Math.PI / 2]} />
                  <meshStandardMaterial color="#c4cbd6" metalness={0.6} roughness={0.3} side={THREE.DoubleSide} />
                </mesh>
                <mesh>
                  <sphereGeometry args={[1.0, 72, 40, 0, Math.PI * 2, 0, Math.PI / 2]} />
                  <meshStandardMaterial color="#f5f6f8" roughness={0.5} side={THREE.DoubleSide} />
                </mesh>
              </group>
            )}
            {stem > 0.001 && (
              <group position={stemFrom}>
                <Cyl a={bottom} b={top} r1={0.12} r2={0.42} flat={0.55}>
                  <meshStandardMaterial color="#cfd5de" metalness={0.65} roughness={0.28} />
                </Cyl>
                <Cyl a={top} b={trunnion} r1={0.3} r2={0.17} flat={0.75}>
                  <meshStandardMaterial color="#cfd5de" metalness={0.65} roughness={0.28} />
                </Cyl>
              </group>
            )}
            {ball > 0.001 && (
              <mesh position={ballFrom}>
                <sphereGeometry args={[0.93, 64, 48]} />
                <meshStandardMaterial color="#eef1f5" metalness={0.3} roughness={0.12} />
              </mesh>
            )}
          </group>
        )}
      </group>
    </ThreeCanvas>
  );
};
