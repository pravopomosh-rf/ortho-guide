import React from 'react';
import {Composition} from 'remotion';
import {HipfxV, totalHipfxV} from './HipfxV';
import {HipfxV_he, totalHipfxV_he} from './HipfxV_he';
import {HipfxV_ar, totalHipfxV_ar} from './HipfxV_ar';
import {HipfxV_en, totalHipfxV_en} from './HipfxV_en';

export const Root: React.FC = () => (
  <>
    <Composition id="HipfxV" component={HipfxV} durationInFrames={totalHipfxV()} fps={30} width={1080} height={1920} />
    <Composition id="HipfxV-he" component={HipfxV_he} durationInFrames={totalHipfxV_he()} fps={30} width={1080} height={1920} />
    <Composition id="HipfxV-ar" component={HipfxV_ar} durationInFrames={totalHipfxV_ar()} fps={30} width={1080} height={1920} />
    <Composition id="HipfxV-en" component={HipfxV_en} durationInFrames={totalHipfxV_en()} fps={30} width={1080} height={1920} />
  </>
);
