import React from 'react';
import './hebar.css';

// i18n: k = time scale of the active scene (lang audio / RU audio); rtl for HE/AR
export const G = {k: 1, rtl: false};
export const K: React.FC<{k?: number; children: React.ReactNode}> = ({k = 1, children}) => { G.k = k; return <>{children}</>; };
import {AbsoluteFill, Easing, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';

// «цвета надежды»: бирюза + тёплый фон + рассвет; красный только для срочного
export const C = {
  bg: '#fbf7f1', bg2: '#f3ece2', ink: '#1f2a37', mute: '#5d6875', teal: '#0f7f80', teal2: '#14a3a0', tealL: '#d7efee',
  dawn: '#f2994a', dawnL: '#fde7d3', red: '#c62828', redL: '#fde3e1', white: '#ffffff', line: '#e4ddd2', ok: '#1f8a5b',
};
export const font = 'Inter, HebAr, DejaVu Sans, sans-serif';
export const FPS = 30;

export const ease = (f: number, a: number, b: number) =>
  interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
export const easeIO = (f: number, a: number, b: number) =>
  interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic)});

export const Bg: React.FC = () => {
  const f = useCurrentFrame();
  const x = 50 + Math.sin(f / 90) * 6;
  return (
    <AbsoluteFill style={{background: `radial-gradient(1200px 700px at ${x}% -10%, #fff3e4 0%, ${C.bg} 45%, ${C.bg2} 100%)`}}>
      <svg width={1280} height={720} style={{position: 'absolute', opacity: 0.5}}>
        <defs>
          <pattern id="dots" width={28} height={28} patternUnits="userSpaceOnUse">
            <circle cx={2} cy={2} r={1.3} fill="#e2d8ca" />
          </pattern>
        </defs>
        <rect width={1280} height={720} fill="url(#dots)" />
      </svg>
    </AbsoluteFill>
  );
};

export const Cap: React.FC<{text: string; at?: number; size?: number; color?: string; accent?: string[]; width?: number; step?: number; acc?: string; center?: boolean}> = ({
  text, at = 0, size = 46, color = C.ink, accent = [], width = 1100, step = 3, acc = C.teal, center,
}) => {
  const f = useCurrentFrame();
  const words = text.split(' ');
  return (
    <div style={{direction: G.rtl ? 'rtl' : 'ltr', display: 'flex', flexWrap: 'wrap', justifyContent: center ? 'center' : 'flex-start', gap: `0 ${size * 0.28}px`, maxWidth: width, fontFamily: font, fontWeight: 800, fontSize: size, lineHeight: 1.16, color, letterSpacing: G.rtl ? 0 : -0.5}}>
      {words.map((w, i) => {
        const p = ease(f, at + i * step, at + i * step + 9);
        const isAcc = accent.some((a) => w.toLowerCase().replace(/[«»,.:—!?]/g, '').startsWith(a.toLowerCase()));
        const u = ease(f, at + i * step + 6, at + i * step + 22);
        return (
          <span key={i} style={{position: 'relative', display: 'inline-block', opacity: p, filter: `blur(${(1 - p) * 8}px)`, transform: `translateY(${(1 - p) * 16}px)`, color: isAcc ? acc : color}}>
            {w}
            {isAcc && (
              <svg style={{position: 'absolute', left: 0, bottom: -size * 0.12, width: '100%', height: size * 0.25, overflow: 'visible'}} viewBox="0 0 100 10" preserveAspectRatio="none">
                <path d="M2 6 C 25 2, 55 9, 98 4" stroke={C.dawn} strokeWidth={4} fill="none" strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - u} vectorEffect="non-scaling-stroke" />
              </svg>
            )}
          </span>
        );
      })}
    </div>
  );
};

export const Pop: React.FC<{at?: number; children: React.ReactNode; style?: React.CSSProperties}> = ({at = 0, children, style}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: f - at, fps, config: {damping: 14, mass: 0.7}});
  return <div style={{opacity: Math.min(1, s * 1.4), transform: `translateY(${(1 - s) * 30}px) scale(${0.9 + 0.1 * s})`, ...style}}>{children}</div>;
};

export const Card: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
  <div style={{background: '#fff', borderRadius: 24, boxShadow: '0 12px 36px rgba(70,50,20,.10), 0 2px 6px rgba(70,50,20,.06)', padding: 20, ...style}}>{children}</div>
);

export const Tag: React.FC<{n: string; part?: string}> = ({n, part = 'ЗАМЕНА ТАЗОБЕДРЕННОГО СУСТАВА · ЧАСТЬ 1'}) => {
  const f = useCurrentFrame();
  return (
    <div style={{position: 'absolute', top: 28, left: 60, right: 60, display: 'flex', justifyContent: 'space-between', fontFamily: font, fontWeight: 700, fontSize: 17, letterSpacing: 1.4, opacity: ease(f, 0, 10)}}>
      <span style={{color: C.teal, direction: G.rtl ? 'rtl' : 'ltr'}}>{n}</span>
      <span style={{color: C.mute, fontWeight: 600, direction: G.rtl ? 'rtl' : 'ltr'}}>{part}</span>
    </div>
  );
};

export const Label: React.FC<{children: React.ReactNode; color?: string; bg?: string; size?: number; style?: React.CSSProperties}> = ({children, color = C.ink, bg = 'transparent', size = 24, style}) => (
  <div style={{fontFamily: font, fontWeight: 700, fontSize: size, color, background: bg, borderRadius: 12, padding: bg === 'transparent' ? 0 : '6px 14px', lineHeight: 1.2, direction: G.rtl ? 'rtl' : 'ltr', ...style}}>{children}</div>
);

export const Note: React.FC<{children: React.ReactNode; at?: number; color?: string; bg?: string}> = ({children, at = 0, color = C.teal, bg = C.tealL}) => {
  const f = useCurrentFrame();
  const p = ease(f, at, at + 12);
  return (
    <div style={{display: 'inline-flex', alignItems: 'center', gap: 10, fontFamily: font, fontWeight: 700, fontSize: 22, color, background: bg, padding: '10px 18px', borderRadius: 999, direction: G.rtl ? 'rtl' : 'ltr', opacity: p, transform: `translateY(${(1 - p) * 10}px)`}}>
      {children}
    </div>
  );
};

export const Check: React.FC<{p: number; size?: number; color?: string}> = ({p, size = 34, color = C.ok}) => (
  <svg width={size} height={size} viewBox="0 0 34 34">
    <circle cx={17} cy={17} r={16} fill={p > 0 ? color : '#fff'} stroke={p > 0 ? color : C.line} strokeWidth={2} opacity={0.15 + 0.85 * Math.min(1, p * 2)} />
    <path d="M9 17.5 L15 23 L25 11.5" fill="none" stroke="#fff" strokeWidth={3.6} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - p} />
  </svg>
);
export const Cross: React.FC<{p: number; size?: number}> = ({p, size = 120}) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{position: 'absolute', left: 0, top: 0}}>
    <path d="M18 18 L82 82" stroke={C.red} strokeWidth={9} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - Math.min(1, p * 2)} />
    <path d="M82 18 L18 82" stroke={C.red} strokeWidth={9} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - Math.max(0, Math.min(1, p * 2 - 1))} />
  </svg>
);

export const Pic: React.FC<{src: string; w: number; h: number; at?: number; zoom?: boolean; fit?: 'cover' | 'contain'}> = ({src, w, h, at = 0, zoom = true, fit = 'contain'}) => {
  const f = useCurrentFrame();
  const z = zoom ? interpolate(f - at, [0, 300], [1, 1.07], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) : 1;
  return (
    <div style={{width: w, height: h, overflow: 'hidden', borderRadius: 16, background: '#fff'}}>
      <Img src={staticFile(src)} style={{width: '100%', height: '100%', objectFit: fit, transform: `scale(${z})`}} />
    </div>
  );
};

export const Seq3D: React.FC<{name: string; n: number; w: number; h: number; off?: number}> = ({name, n, w, h, off = 0}) => {
  const f = useCurrentFrame();
  const i = Math.max(0, Math.min(n - 1, f - off));
  return <Img src={staticFile(`clips/${name}/${i}.png`)} style={{width: w, height: h, display: 'block'}} />;
};

export const Foot: React.FC<{children: React.ReactNode}> = ({children}) => (
  <div style={{position: 'absolute', left: 60, right: 60, bottom: 16, fontFamily: font, fontSize: 13, color: C.mute, lineHeight: 1.3}}>{children}</div>
);

// small generic call button (cord + button), used in many scenes
export const CallButton: React.FC<{size?: number; glow?: number}> = ({size = 160, glow = 0}) => (
  <svg width={size} height={size * 1.4} viewBox="0 0 100 140">
    <path d="M50 0 C 50 30, 20 40, 40 70" stroke="#8b96a3" strokeWidth={4} fill="none" />
    <rect x={22} y={66} width={56} height={70} rx={18} fill="#eef1f4" stroke="#9aa5b1" strokeWidth={2.5} />
    <circle cx={50} cy={96} r={18 + glow * 8} fill={C.dawn} opacity={0.25 * glow} />
    <circle cx={50} cy={96} r={16} fill={C.dawn} />
    <path d="M41 101 L59 101 M44 101 L44 94 A6 6 0 0 1 56 94 L56 101 M48 105 A2 2 0 0 0 52 105" stroke="#fff" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round" fill="none" />
  </svg>
);
