import React, {useEffect, useMemo, useState} from 'react';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import {useCurrentFrame, interpolate, Easing, staticFile, delayRender, continueRender} from 'remotion';
import * as THREE from 'three';
import {STLLoader} from 'three/examples/jsm/loaders/STLLoader.js';
import BP from './bp3d.json';

// BodyParts3D (c) 2008 Life Science Integrated Database Center, CC BY-SA 2.1 JP
// bones, muscles and skin (FMA7163) of the right lower limb; coordinates re-centred on the femoral head.

const K = 0.98 / BP.r;
export const cl = (f: number, a: number, b: number) =>
  interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic)});
const lerp = (a: number, b: number, p: number) => a + (b - a) * p;

function mergeVerts(geo: THREE.BufferGeometry) {
  const p = geo.attributes.position as THREE.BufferAttribute;
  const map = new Map<string, number>();
  const verts: number[] = [];
  const idx: number[] = [];
  for (let i = 0; i < p.count; i++) {
    const key = `${p.getX(i).toFixed(3)},${p.getY(i).toFixed(3)},${p.getZ(i).toFixed(3)}`;
    let j = map.get(key);
    if (j === undefined) {
      j = verts.length / 3;
      map.set(key, j);
      verts.push(p.getX(i), p.getY(i), p.getZ(i));
    }
    idx.push(j);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
  g.setIndex(idx);
  return g;
}

const cache: Record<string, THREE.BufferGeometry> = {};
export const useMesh = (name: string, on = true) => {
  const [g, setG] = useState<THREE.BufferGeometry | null>(cache[name] ?? null);
  const [h] = useState(() => (cache[name] || !on ? null : delayRender('stl ' + name, {timeoutInMilliseconds: 120000})));
  useEffect(() => {
    if (!on) return;
    if (cache[name]) {
      if (!g) setG(cache[name]);
      if (h !== null) continueRender(h);
      return;
    }
    fetch(staticFile(`bp3d/${name}.bin`))
      .then((r) => r.arrayBuffer())
      .then((buf) => {
        const hd = new Uint32Array(buf, 0, 2);
        const pos = new Float32Array(buf, 8, hd[0] * 3);
        const idx = new Uint32Array(buf, 8 + hd[0] * 12, hd[1]);
        const merged = new THREE.BufferGeometry();
        merged.setAttribute('position', new THREE.BufferAttribute(pos.slice(), 3));
        merged.setIndex(new THREE.BufferAttribute(idx.slice(), 1));
        merged.computeVertexNormals();
        cache[name] = merged;
        setG(merged);
        if (h !== null) continueRender(h);
      });
  }, [name, h, on]);
  return on ? g : null;
};

export type Cam = {yaw: number; dist: number; target: [number, number, number]; pitch: number};
const camPos = (c: Cam) => new THREE.Vector3(
  c.target[0] + c.dist * Math.sin(c.yaw) * Math.cos(c.pitch),
  c.target[1] + c.dist * Math.sin(c.pitch),
  c.target[2] + c.dist * Math.cos(c.yaw) * Math.cos(c.pitch),
);
export const project = (c: Cam, pt: number[], w: number, h: number) => {
  const cam = new THREE.PerspectiveCamera(34, w / h, 0.1, 500);
  cam.position.copy(camPos(c));
  cam.lookAt(c.target[0], c.target[1], c.target[2]);
  cam.updateMatrixWorld();
  const v = new THREE.Vector3(pt[0], pt[1], pt[2]).project(cam);
  return {x: ((v.x + 1) / 2) * w, y: ((1 - v.y) / 2) * h};
};
const CamRig: React.FC<{c: Cam}> = ({c}) => {
  const {camera} = useThree();
  camera.position.copy(camPos(c));
  camera.lookAt(c.target[0], c.target[1], c.target[2]);
  camera.updateProjectionMatrix();
  return null;
};

export type LegMode = 'approaches' | 'posterior' | 'lateral' | 'anterior' | 'calves' | 'wound' | 'numb' | 'pain' | 'chosen';

// key points (units), computed from the meshes
export const PT = {
  joint: [0, 0, 0],
  asis: [-1.25, 3.16, 3.35],
  incA: [-2.32, 2.5, 2.73],
  incB: [-3.41, -1.75, 1.82],
  knee: [0.18, -16.7, -0.8],
  thigh: [-0.6, -8, 1.5],
  zone: [-2.35, -5.6, 3.0],
  calfR: [-0.2, -21, -2.4],
  calfL: [7.1, -21, -2.3],
};

const ARROWS: Record<string, {dir: number[]; color: string}> = {
  ant: {dir: [-0.25, 0.1, 1], color: '#1f6fd1'},
  lat: {dir: [-1, 0.05, 0.05], color: '#6b4fb8'},
  post: {dir: [-0.2, 0.1, -1], color: '#2e8b57'},
};
export const arrowTail = (k: string, len = 8) => {
  const d = new THREE.Vector3(...(ARROWS[k].dir as [number, number, number])).normalize();
  return d.multiplyScalar(len).toArray();
};

export const camLeg = (mode: LegMode, t: number): Cam => {
  const s = Math.sin(t / 70) * 0.06;
  switch (mode) {
    case 'approaches': {
      const z = cl(t, 150, 230);
      return {yaw: lerp(-0.35, -0.7, z) + s, dist: lerp(62, 40, z), target: [lerp(0.4, -0.8, z), lerp(-15, -6, z), 0], pitch: lerp(0.05, 0.55, z)};
    }
    case 'chosen': {
      const z = cl(t, 10, 60);
      return {yaw: lerp(-0.7, -0.4, z) + s, dist: lerp(40, 42, z), target: [-0.4, lerp(-6, -7, z), 0], pitch: lerp(0.55, 0.12, z)};
    }
    case 'posterior':
      return {yaw: -2.55 + s, dist: 40, target: [-0.4, -6.5, 0], pitch: 0.12};
    case 'lateral':
      return {yaw: -0.6 + s, dist: 40, target: [-0.6, -6.5, 0], pitch: 0.25};
    case 'anterior': {
      const z = cl(t, 100, 175);
      return {yaw: -0.62 + s * 0.6, dist: lerp(47, 44, z), target: [-0.6, -6.8, 0.8], pitch: 0.1};
    }
    case 'calves':
      return {yaw: Math.PI + s * 0.5, dist: 25, target: [3.45, -20.5, 0], pitch: 0.05};
    case 'wound': {
      const z = cl(t, 40, 90);
      return {yaw: lerp(-0.45, -0.75, z), dist: lerp(46, 12, z), target: [lerp(-0.6, -2.8, z), lerp(-6.8, 0.4, z), lerp(0.5, 2.2, z)], pitch: 0.08};
    }
    case 'numb':
      return {yaw: -0.7 + s, dist: lerp(46, 36, cl(t, 60, 200)), target: [-0.8, lerp(-6.8, -5.5, cl(t, 60, 200)), 0.5], pitch: 0.08};
    case 'pain':
      return {yaw: -0.3 + s, dist: 56, target: [0.4, -13, 0], pitch: 0.06};
  }
};

const SKIN = new THREE.Color('#e9b9a0');
const BONE = '#e8d6b0';
const MUSC = '#c25a4f';

// per-vertex weight helpers
const weights = (g: THREE.BufferGeometry, fn: (x: number, y: number, z: number) => number) => {
  const p = g.attributes.position as THREE.BufferAttribute;
  const w = new Float32Array(p.count);
  for (let i = 0; i < p.count; i++) w[i] = fn(p.getX(i), p.getY(i), p.getZ(i));
  return w;
};
const segDist = (x: number, y: number, z: number, a: number[], b: number[]) => {
  const ab = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
  const ap = [x - a[0], y - a[1], z - a[2]];
  const L = ab[0] ** 2 + ab[1] ** 2 + ab[2] ** 2;
  const t = Math.max(0, Math.min(1, (ap[0] * ab[0] + ap[1] * ab[1] + ap[2] * ab[2]) / L));
  return Math.hypot(ap[0] - ab[0] * t, ap[1] - ab[1] * t, ap[2] - ab[2] * t);
};

const Skin: React.FC<{g: THREE.BufferGeometry; opacity: number; tint?: Float32Array; tintColor?: string; amount?: number; disp?: (x: number, y: number, z: number) => number[] | null}> = ({g, opacity, tint, tintColor = '#c62828', amount = 0, disp}) => {
  const geo = useMemo(() => {
    const out = g.clone();
    if (disp) {
      const p = out.attributes.position as THREE.BufferAttribute;
      for (let i = 0; i < p.count; i++) {
        const d = disp(p.getX(i), p.getY(i), p.getZ(i));
        if (d) p.setXYZ(i, d[0], d[1], d[2]);
      }
      out.computeVertexNormals();
    }
    const n = out.attributes.position.count;
    const cols = new Float32Array(n * 3);
    const tc = new THREE.Color(tintColor), tmp = new THREE.Color();
    for (let i = 0; i < n; i++) {
      tmp.copy(SKIN);
      if (tint) tmp.lerp(tc, Math.min(1, tint[i] * amount));
      cols[i * 3] = tmp.r; cols[i * 3 + 1] = tmp.g; cols[i * 3 + 2] = tmp.b;
    }
    out.setAttribute('color', new THREE.BufferAttribute(cols, 3));
    return out;
  }, [g, tint, amount, disp, tintColor]);
  return (
    <mesh geometry={geo} renderOrder={10}>
      <meshStandardMaterial vertexColors roughness={0.62} transparent={opacity < 1} opacity={opacity} depthWrite={opacity >= 1} />
    </mesh>
  );
};

const Arrow3D: React.FC<{k: string; p: number; len?: number; tip?: number}> = ({k, p, len = 8, tip = 1.9}) => {
  if (p <= 0.001) return null;
  const d = new THREE.Vector3(...(ARROWS[k].dir as [number, number, number])).normalize();
  const end = d.clone().multiplyScalar(tip);
  const start = d.clone().multiplyScalar(len);
  const head = start.clone().lerp(end, p);
  const shaftEnd = head.clone().add(d.clone().multiplyScalar(0.9));
  const mid = start.clone().add(shaftEnd).multiplyScalar(0.5);
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.clone().negate());
  return (
    <group>
      <mesh position={mid} quaternion={q}>
        <cylinderGeometry args={[0.22, 0.22, Math.max(0.01, start.distanceTo(shaftEnd)), 24]} />
        <meshStandardMaterial color={ARROWS[k].color} roughness={0.35} emissive={ARROWS[k].color} emissiveIntensity={0.25} />
      </mesh>
      <mesh position={head.clone().add(d.clone().multiplyScalar(0.45))} quaternion={q}>
        <coneGeometry args={[0.55, 1.1, 28]} />
        <meshStandardMaterial color={ARROWS[k].color} roughness={0.35} emissive={ARROWS[k].color} emissiveIntensity={0.25} />
      </mesh>
    </group>
  );
};

const Bone: React.FC<{g: THREE.BufferGeometry | null; opacity?: number; rot?: number}> = ({g, opacity = 1}) =>
  g ? (
    <mesh geometry={g}>
      <meshStandardMaterial color={BONE} roughness={0.72} transparent={opacity < 1} opacity={opacity} depthWrite={opacity >= 1} />
    </mesh>
  ) : null;

const Muscle: React.FC<{g: THREE.BufferGeometry | null; dx?: number; y0?: number; hy?: number; color?: string; opacity?: number; emissive?: number}> = ({g, dx = 0, y0 = -1.5, hy = 4.5, color = MUSC, opacity = 1, emissive = 0}) => {
  const geo = useMemo(() => {
    if (!g) return null;
    if (Math.abs(dx) < 1e-4) return g;
    const out = g.clone();
    const p = out.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < p.count; i++) {
      const y = p.getY(i);
      const w = Math.exp(-(((y - y0) / hy) ** 2));
      p.setX(i, p.getX(i) + dx * w);
      p.setZ(i, p.getZ(i) + Math.abs(dx) * 0.35 * w);
    }
    out.computeVertexNormals();
    return out;
  }, [g, dx, y0, hy]);
  if (!geo) return null;
  return (
    <mesh geometry={geo}>
      <meshStandardMaterial color={color} roughness={0.55} transparent={opacity < 1} opacity={opacity} depthWrite={opacity >= 0.99} emissive={color} emissiveIntensity={emissive} />
    </mesh>
  );
};

// smooth incision path on the skin (drawn as a tube)
const Incision: React.FC<{p: number; color?: string; r?: number}> = ({p, color = '#7a1f1f', r = 0.075}) => {
  const curve = useMemo(() => {
    const A = new THREE.Vector3(...(PT.incA as [number, number, number]));
    const B = new THREE.Vector3(...(PT.incB as [number, number, number]));
    const M = A.clone().lerp(B, 0.5).add(new THREE.Vector3(-0.05, 0, 0.12));
    return new THREE.QuadraticBezierCurve3(A.add(new THREE.Vector3(0, 0, 0.1)), M, B.add(new THREE.Vector3(0, 0, 0.12)));
  }, []);
  const geo = useMemo(() => {
    if (p <= 0.01) return null;
    const pts = curve.getPoints(40).slice(0, Math.max(2, Math.round(41 * p)));
    return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 40, r, 10, false);
  }, [curve, p, r]);
  if (!geo) return null;
  return (
    <mesh geometry={geo} renderOrder={20}>
      <meshStandardMaterial color={color} roughness={0.5} />
    </mesh>
  );
};

const Stitches: React.FC<{o: number}> = ({o}) => {
  if (o <= 0) return null;
  const A = new THREE.Vector3(...(PT.incA as [number, number, number]));
  const B = new THREE.Vector3(...(PT.incB as [number, number, number]));
  const d = B.clone().sub(A).normalize();
  const side = d.clone().cross(new THREE.Vector3(0, 0, 1)).normalize();
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), side);
  return (
    <group>
      {[0.12, 0.26, 0.4, 0.54, 0.68, 0.82].map((t) => {
        const c = A.clone().lerp(B, t).add(new THREE.Vector3(0.02, 0, 0.18));
        return (
          <mesh key={t} position={c} quaternion={q} renderOrder={21}>
            <cylinderGeometry args={[0.035, 0.035, 0.5, 8]} />
            <meshStandardMaterial color="#1d2433" transparent opacity={o} />
          </mesh>
        );
      })}
    </group>
  );
};

const Capsule: React.FC<{o: number}> = ({o}) => {
  if (o <= 0) return null;
  const neck = new THREE.Vector3(...(BP.neck as [number, number, number])).normalize();
  const mid = neck.clone().multiplyScalar(0.8);
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), neck);
  return (
    <mesh position={mid} quaternion={q} renderOrder={15}>
      <capsuleGeometry args={[1.15, 1.4, 12, 32]} />
      <meshStandardMaterial color="#f2a33a" transparent opacity={0.55 * o} emissive="#f2a33a" emissiveIntensity={0.35} depthWrite={false} />
    </mesh>
  );
};

export const Leg3D: React.FC<{mode: LegMode; len?: number; width: number; height: number}> = ({mode, len = 240, width, height}) => {
  const t = useCurrentFrame();
  const needBones = ['approaches', 'posterior', 'lateral', 'anterior', 'pain', 'chosen'].includes(mode);
  const hip = useMesh('hip_r', needBones);
  const fem = useMesh('femur_r', needBones);
  const leg = useMesh('leg_r', needBones);
  const skinR = useMesh('skinR', ['approaches', 'posterior', 'lateral', 'anterior', 'wound', 'numb', 'chosen'].includes(mode));
  const skinLegs = useMesh('skinLegs', mode === 'calves');
  const skinIso = useMesh('skin_r', mode === 'pain');
  const sart = useMesh('sart', mode === 'anterior');
  const tfl = useMesh('tfl', mode === 'anterior');
  const rf = useMesh('rf', mode === 'anterior');
  const gmed = useMesh('gmed', ['anterior', 'lateral', 'posterior'].includes(mode));
  const gmax = useMesh('gmax', mode === 'posterior');
  const vl = useMesh('vl', mode === 'anterior');
  const cam = camLeg(mode, t);

  // tints
  const woundW = useMemo(() => (skinR && (mode === 'wound') ? weights(skinR, (x, y, z) => Math.max(0, 1 - segDist(x, y, z, PT.incA, PT.incB) / 1.15)) : undefined), [skinR, mode]);
  const zoneW = useMemo(() => (skinR && mode === 'numb' ? weights(skinR, (x, y, z) => {
    if (z < 0.4 || x > -0.6) return 0;
    const d = ((y - PT.zone[1]) / 4.6) ** 2 + ((x - PT.zone[0]) / 1.5) ** 2;
    return Math.max(0, Math.min(1, (1 - d) * 2.2));
  }) : undefined), [skinR, mode]);
  const swell = mode === 'calves' ? cl(t, 25, 85) : 0;
  const calfDisp = useMemo(() => {
    if (mode !== 'calves') return undefined;
    const s = 0.2 * swell;
    return (x: number, y: number, z: number) => {
      if (x > 3.45) return null;
      const b = Math.exp(-(((y + 21) / 4.2) ** 2));
      const cx = -0.2, cz = -1.6;
      return [cx + (x - cx) * (1 + s * b), y, cz + (z - cz) * (1 + s * b * (z < cz ? 1.25 : 0.6))];
    };
  }, [mode, swell]);
  const calfW = useMemo(() => (skinLegs && mode === 'calves' ? weights(skinLegs, (x, y, z) => (x < 3.45 ? Math.exp(-(((y + 21) / 4.2) ** 2)) * (z < -1 ? 1 : 0.5) : 0)) : undefined), [skinLegs, mode]);

  let body: React.ReactNode = null;
  const pulse = (Math.sin(t / 6) + 1) / 2;

  if (mode === 'approaches' || mode === 'chosen') {
    const only = mode === 'chosen';
    body = (
      <>
        <Bone g={hip} /><Bone g={fem} /><Bone g={leg} />
        {skinR && <Skin g={skinR} opacity={only ? 0.18 : lerp(0.2, 0.06, cl(t, 160, 230))} />}
        {!only && <Arrow3D k="post" p={cl(t, 290, 312)} />}
        {!only && <Arrow3D k="lat" p={cl(t, 316, 338)} />}
        <Arrow3D k="ant" p={only ? 1 : cl(t, 342, 364)} />
      </>
    );
  } else if (mode === 'posterior') {
    body = (
      <>
        <Bone g={hip} /><Bone g={fem} /><Bone g={leg} />
        <Muscle g={gmed} opacity={0.55} color="#b8655c" />
        <Muscle g={gmax} opacity={0.5 + 0.15 * pulse} color="#c0473c" />
        {skinR && <Skin g={skinR} opacity={0.12} />}
        <Arrow3D k="post" p={cl(t, 10, 40)} tip={3.2} len={10} />
      </>
    );
  } else if (mode === 'lateral') {
    body = (
      <>
        <Bone g={hip} /><Bone g={fem} /><Bone g={leg} />
        <Muscle g={gmed} opacity={0.7} color="#c0473c" emissive={0.15 * pulse} />
        {skinR && <Skin g={skinR} opacity={0.12} />}
        <Arrow3D k="lat" p={cl(t, 10, 40)} tip={3.4} len={10} />
      </>
    );
  } else if (mode === 'anterior') {
    const inc = cl(t, 8, 36);
    const skinO = lerp(0.95, 0.1, cl(t, 45, 85));
    const spread = cl(t, 115, 180) * 0.95;
    body = (
      <>
        <Bone g={hip} /><Bone g={fem} /><Bone g={leg} />
        <Capsule o={cl(t, 160, 190)} />
        <Muscle g={gmed} dx={-spread * 0.8} opacity={0.95} color="#a9564c" />
        <Muscle g={vl} opacity={0.9} color="#b9655a" />
        <Muscle g={rf} dx={spread * 0.9} opacity={0.97} color="#c25a4f" />
        <Muscle g={tfl} dx={-spread * 1.1} opacity={0.97} color="#c9675a" />
        <Muscle g={sart} dx={spread * 1.1} opacity={0.97} color="#d0705f" />
        {skinR && <Skin g={skinR} opacity={skinO} />}
        {skinO > 0.3 && <Incision p={inc} />}
      </>
    );
  } else if (mode === 'wound') {
    const red = cl(t, 60, 110) * (0.75 + 0.25 * pulse);
    body = (
      <>
        {skinR && <Skin g={skinR} opacity={1} tint={woundW} amount={red} />}
        <Incision p={1} r={0.05} />
        <Stitches o={1} />
        {[0.3, 0.55, 0.78].map((k, i) => {
          const A = new THREE.Vector3(...(PT.incA as [number, number, number]));
          const B = new THREE.Vector3(...(PT.incB as [number, number, number]));
          const c = A.lerp(B, k).add(new THREE.Vector3(0.05, -0.15 - 0.4 * cl(t, 85 + i * 8, 120 + i * 8), 0.22));
          const o = cl(t, 85 + i * 8, 100 + i * 8);
          return o > 0 ? (
            <mesh key={i} position={c} scale={[0.13, 0.18, 0.1]} renderOrder={22}>
              <sphereGeometry args={[1, 16, 12]} />
              <meshStandardMaterial color="#e6c34a" roughness={0.2} transparent opacity={o} />
            </mesh>
          ) : null;
        })}
      </>
    );
  } else if (mode === 'numb') {
    body = (
      <>
        {skinR && <Skin g={skinR} opacity={1} tint={zoneW} tintColor="#f0a020" amount={cl(t, 15, 45) * (0.7 + 0.3 * pulse)} />}
        <Incision p={1} r={0.05} />
      </>
    );
  } else if (mode === 'calves') {
    body = skinLegs ? <Skin g={skinLegs} opacity={1} tint={calfW} amount={swell * (0.45 + 0.15 * pulse)} disp={calfDisp} /> : null;
  } else if (mode === 'pain') {
    const lift = cl(t, 20, 60) * 0.16;
    body = (
      <>
        <Bone g={hip} />
        <group rotation={[-lift, 0, 0]}>
          <Bone g={fem} /><Bone g={leg} />
          {skinIso && <Skin g={skinIso} opacity={0.22} />}
        </group>
        <mesh renderOrder={30}>
          <sphereGeometry args={[2.3 + 0.6 * pulse, 32, 24]} />
          <meshStandardMaterial color="#e53935" transparent opacity={0.28 + 0.2 * pulse} emissive="#e53935" emissiveIntensity={0.8} depthWrite={false} />
        </mesh>
      </>
    );
  }

  return (
    <ThreeCanvas width={width} height={height} camera={{position: [0, 0, 30], fov: 34, near: 0.1, far: 500}} gl={{antialias: true, alpha: true}}>
      <hemisphereLight args={['#ffffff', '#b3a184', 0.95]} />
      <directionalLight position={[5, 8, 10]} intensity={1.6} />
      <directionalLight position={[-8, 2, -6]} intensity={0.7} color="#d4e6ff" />
      <directionalLight position={[0, -4, 10]} intensity={0.35} />
      <CamRig c={cam} />
      {body}
    </ThreeCanvas>
  );
};
