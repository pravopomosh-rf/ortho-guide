import {StairClimb} from './motion_en';
import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {Bg, C, Cap, Card, Check, Cross, FPS, Label, Note, Pop, Tag, ease, easeIO, font, G, K} from './ui';
import {Icon} from './Part1';
import timing from './timing3_en.json';

type T = {id: string; dur: number; audio?: string; k?: number}[];
const TT = timing as T;
const PAD = 0.75;
export const total3_en = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const A_IDS = ['D01', 'D02', 'D03', 'D04', 'D05', 'D06'];
const END = 75;
export const total3a_en = () => TT.filter((x) => A_IDS.includes(x.id)).reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0) + END;
export const total3b_en = () => TT.filter((x) => !A_IDS.includes(x.id)).reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const EndA: React.FC = () => (
  <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
    <Pop at={2}>
      <Card style={{width: 900, padding: 34, textAlign: 'center', borderTop: `8px solid ${C.teal}`}}>
        <Label size={30}>These are general recommendations.</Label>
        <Label size={26} color={C.mute} style={{fontWeight: 600, marginTop: 8}}>Individual instructions from your doctor and medical team come first.</Label>
      </Card>
    </Pop>
    <div style={{marginTop: 26}}><Note at={12} color={'#b8661c'} bg={C.dawnL}>Next, part 3B: movements, stairs, everyday life, warning signs</Note></div>
  </AbsoluteFill>
);
const sec = (s: number) => Math.round(s * FPS * G.k);
const P3TAG = 'HIP REPLACEMENT · PART 3';
const tagFor = (id: string) => (['D01','D02','D03','D04','D05','D06'].includes(id) ? 'HIP REPLACEMENT · PART 3A' : 'HIP REPLACEMENT · PART 3B');

const Row: React.FC<{t: string; at: number; ok?: boolean}> = ({t, at, ok = true}) => {
  const f = useCurrentFrame();
  return (
    <div style={{display: 'flex', alignItems: 'center', gap: 14, padding: '10px 0', opacity: 0.35 + 0.65 * ease(f, sec(at), sec(at) + 10)}}>
      {ok ? <Check p={ease(f, sec(at), sec(at) + 18)} /> : <div style={{width: 34, height: 34, borderRadius: 17, background: C.redL, color: C.red, fontFamily: font, fontWeight: 900, fontSize: 22, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>!</div>}
      <Label size={23}>{t}</Label>
    </div>
  );
};

const D1: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Tag n="DISCHARGE" part={tagFor('D01')} />
      <div style={{position: 'absolute', left: 60, top: 80}}><Cap text="After discharge, usually a rehabilitation hospital" size={44} accent={['rehabilitation']} width={1160} /></div>
      <div style={{position: 'absolute', left: 60, top: 200, display: 'flex', alignItems: 'center', gap: 20}}>
        <Pop at={sec(1)}><Card style={{width: 230, height: 200, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8}}><Icon k="bed" s={90} /><Label size={22}>Our ward</Label></Card></Pop>
        <svg width={90} height={40} style={{opacity: ease(f, sec(2.2), sec(3))}}><path d="M6 20 L76 20 M62 8 L78 20 L62 32" stroke={C.teal} strokeWidth={5} fill="none" strokeLinecap="round" /></svg>
        <Pop at={sec(2.6)}>
          <Card style={{width: 420, height: 200, border: `3px solid ${C.teal}`, display: 'flex', alignItems: 'center', gap: 16}}>
            <svg width={110} height={110} viewBox="0 0 100 100"><rect x={14} y={30} width={72} height={60} rx={6} fill={C.tealL} stroke={C.ink} strokeWidth={4} /><rect x={40} y={14} width={20} height={20} rx={3} fill="#fff" stroke={C.ink} strokeWidth={3} /><path d="M50 18 L50 30 M44 24 L56 24" stroke={C.red} strokeWidth={3} /><g fill="#fff" stroke={C.ink} strokeWidth={2}>{[0, 1, 2].map((i) => <rect key={i} x={22 + i * 22} y={44} width={14} height={14} rx={2} />)}</g><rect x={42} y={68} width={16} height={22} fill="#fff" stroke={C.ink} strokeWidth={3} /></svg>
            <div><Label size={26} color={C.teal}>Rehabilitation hospital</Label><Label size={19} color={C.mute} style={{fontWeight: 600, marginTop: 4}}>usually, after joint replacement</Label></div>
          </Card>
        </Pop>
      </div>
      <div style={{position: 'absolute', left: 60, top: 430, display: 'flex', gap: 20}}>
        <Pop at={sec(5)}><Card style={{width: 560, background: C.tealL}}><Label size={21}>Physiotherapists help you get up, walk and manage everyday activities safely, to get ready to go home</Label></Card></Pop>
        <Pop at={sec(15)}><Card style={{width: 580, background: C.dawnL}}><Label size={21}>Prefer rehabilitation at home? Say so in advance: it depends on your health, home conditions and approval from your health fund</Label></Card></Pop>
      </div>
      <div style={{position: 'absolute', left: 60, top: 590, display: 'flex', gap: 16}}>
        <Note at={sec(23)}>If arranged, a physiotherapist visits you at home</Note>
        <Note at={sec(27)} color={'#b8661c'} bg={C.dawnL}>The advice helps both in the rehabilitation hospital and at home</Note>
      </div>
    </AbsoluteFill>
  );
};

const D2: React.FC = () => {
  const items = ['Which operation was done', 'Medicines: which and for how long', 'How much weight you may put on the operated leg', 'Wound care', 'Stitches or staples: 10–14 days (if they need removing)', 'When to come for follow-up', 'Who to call if there is a problem at home'];
  return (
    <AbsoluteFill>
      <Tag n="DISCHARGE LETTER" part={tagFor('D02')} />
      <div style={{position: 'absolute', left: 60, top: 80}}><Cap text="Everything important is in the discharge letter" size={46} accent={['discharge']} /></div>
      <Pop at={sec(1)} style={{position: 'absolute', left: 60, top: 180}}>
        <Card style={{width: 720, borderTop: `8px solid ${C.teal}`}}>
          {items.map((t, i) => <Row key={i} t={t} at={3 + i * 2.6} />)}
        </Card>
      </Pop>
      <Pop at={sec(24)} style={{position: 'absolute', left: 840, top: 260}}>
        <Card style={{width: 380, textAlign: 'center'}}>
          <Icon k="doc" s={90} />
          <svg width={80} height={30}><path d="M4 15 L66 15 M54 5 L68 15 L54 25" stroke={C.teal} strokeWidth={4} fill="none" strokeLinecap="round" /></svg>
          <Label size={24}>Show it to your family doctor</Label>
        </Card>
      </Pop>
    </AbsoluteFill>
  );
};

const D3: React.FC = () => {
  const f = useCurrentFrame();
  const days = Array.from({length: 28}, (_, i) => i);
  return (
    <AbsoluteFill>
      <Tag n="BLOOD CLOTS" part={tagFor('D03')} />
      <div style={{position: 'absolute', left: 60, top: 80}}><Cap text="Clot prevention continues after discharge" size={44} accent={['discharge']} /></div>
      <Pop at={sec(1)} style={{position: 'absolute', left: 60, top: 180}}>
        <Card style={{width: 560}}>
          <Label size={22} color={C.teal}>As prescribed, often about a month</Label>
          <div style={{display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 8, marginTop: 14}}>
            {days.map((d) => {
              const on = ease(f, sec(8) + d * 6, sec(8) + d * 6 + 8);
              return <div key={d} style={{height: 40, borderRadius: 8, background: on > 0.5 ? C.teal : '#f1f3f5', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{on > 0.5 && <svg width={20} height={20}><path d="M4 10 L8 15 L16 5" stroke="#fff" strokeWidth={3} fill="none" strokeLinecap="round" /></svg>}</div>;
            })}
          </div>
          <div style={{display: 'flex', gap: 14, marginTop: 16, alignItems: 'center'}}>
            <Icon k="syringe" s={64} /><Label size={19} style={{fontWeight: 600}}>enoxaparin injections or tablets; the doctor will say exactly how long</Label>
          </div>
        </Card>
      </Pop>
      <div style={{position: 'absolute', left: 660, top: 180, width: 560, display: 'flex', flexDirection: 'column', gap: 14}}>
        <Pop at={sec(18)}><Card style={{background: C.tealL}}><Label size={21}>Do not miss doses or stop on your own, or protection against clots will drop</Label></Card></Pop>
        <Pop at={sec(25)}><Card style={{background: C.redL}}>
          <Label size={21} color={C.red}>Signs of bleeding: get medical help urgently</Label>
          <Label size={19} style={{fontWeight: 600, marginTop: 6}}>blood in urine · black stools · unusually large bruises · prolonged bleeding</Label>
        </Card></Pop>
        <Pop at={sec(35)}><Card><Label size={20}>Do not add aspirin, ibuprofen or other anti-inflammatories on your own</Label></Card></Pop>
      </div>
    </AbsoluteFill>
  );
};

const D4: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Tag n="THE WOUND" part={tagFor('D04')} />
      <div style={{position: 'absolute', left: 60, top: 80}}><Cap text="Wound: clean, dry, dressing as you were shown" size={44} accent={['clean', 'dry']} width={1160} /></div>
      <Pop at={sec(1)} style={{position: 'absolute', left: 60, top: 190}}>
        <Card style={{width: 420, height: 400, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative'}}>
          <svg width={300} height={360} viewBox="0 0 200 240">
            <path d="M40 10 C 90 0, 160 6, 172 30 C 176 90, 160 150, 146 230 L 74 230 C 66 150, 50 90, 40 10 Z" fill="#f2d7c2" stroke="#d9b79c" strokeWidth={3} />
            <rect x={118} y={40} width={34} height={90} rx={10} fill="#fff" stroke="#cfd6dd" strokeWidth={3} />
            <rect x={126} y={52} width={18} height={66} rx={5} fill={C.tealL} />
            {[0, 1, 2, 3, 4].map((i) => {
              const t = ((f + i * 14) % 60) / 60;
              const y = 10 + t * 50; const bounce = t > 0.55;
              return <circle key={i} cx={120 + i * 8 + (bounce ? (t - 0.55) * 60 : 0)} cy={bounce ? 38 - (t - 0.55) * 40 : y} r={4} fill={C.teal2} opacity={ease(f, sec(10), sec(11)) * (1 - t * 0.6)} />;
            })}
          </svg>
        </Card>
      </Pop>
      <div style={{position: 'absolute', left: 530, top: 190, width: 690, display: 'flex', flexDirection: 'column', gap: 14}}>
        <Pop at={sec(5)}><Card><Label size={21}>No creams or ointments on the wound unless prescribed</Label></Card></Pop>
        <Pop at={sec(9.4)}><Card style={{background: C.tealL}}><Label size={21}>Shower: usually with a waterproof dressing. When and how: ask the staff</Label></Card></Pop>
        <Pop at={sec(15)}>
          <Card style={{display: 'flex', alignItems: 'center', gap: 18}}>
            <div style={{position: 'relative', width: 90, height: 90}}>
              <svg width={90} height={90} viewBox="0 0 100 100"><path d="M10 50 L90 50 L84 80 L16 80 Z" fill="#eaf6fb" stroke={C.ink} strokeWidth={4} /><path d="M20 40 C 30 30, 40 50, 50 40 C 60 30, 70 50, 80 40" stroke={C.teal2} strokeWidth={4} fill="none" /></svg>
              <Cross p={ease(f, sec(16), sec(17))} size={90} />
            </div>
            <Label size={21}>Bath, pool, sea: only when the wound has healed and the doctor allows it</Label>
          </Card>
        </Pop>
        <Pop at={sec(22)}><Card style={{background: C.redL}}><Label size={20} color={C.red}>Why: infection around the joint replacement is a serious complication</Label></Card></Pop>
      </div>
    </AbsoluteFill>
  );
};

const D5: React.FC = () => (
  <AbsoluteFill>
    <Tag n="PAIN AND SWELLING" part={tagFor('D05')} />
    <div style={{position: 'absolute', left: 60, top: 80}}><Cap text="Pain under control makes it easier to move" size={46} accent={['move']} /></div>
    <div style={{position: 'absolute', left: 60, top: 190, width: 560, display: 'flex', flexDirection: 'column', gap: 14}}>
      <Pop at={sec(1)}><Card style={{display: 'flex', alignItems: 'center', gap: 14}}><Icon k="pill" s={70} /><Label size={21}>Painkillers as prescribed</Label></Card></Pop>
      <Pop at={sec(8)}><Card><Label size={20}>Before exercises only if your doctor advised it. No extra doses</Label></Card></Pop>
      <Pop at={sec(15)}><Card style={{background: C.dawnL}}><Label size={20}>Drowsiness and dizziness raise the risk of falling. Tell your doctor about these and constipation</Label></Card></Pop>
    </div>
    <div style={{position: 'absolute', left: 660, top: 190, width: 560, display: 'flex', flexDirection: 'column', gap: 14}}>
      <Pop at={sec(24)}><Card><Label size={21}>Swelling and bruising in the first weeks are common</Label></Card></Pop>
      <Pop at={sec(28)}>
        <Card style={{display: 'flex', alignItems: 'center', gap: 14, background: C.tealL}}>
          <svg width={90} height={80} viewBox="0 0 100 90"><rect x={10} y={20} width={80} height={50} rx={14} fill="#fff" stroke={C.ink} strokeWidth={4} /><path d="M30 34 L44 48 M44 34 L30 48 M58 40 L72 40 M65 33 L65 47" stroke={C.teal2} strokeWidth={4} strokeLinecap="round" /></svg>
          <Label size={21}>Ice wrapped in cloth, 15–20 minutes, several times a day</Label>
        </Card>
      </Pop>
      <Pop at={sec(33)}><Card><Label size={21}>Sat for a long time? Take a short walk</Label></Card></Pop>
    </div>
  </AbsoluteFill>
);

const D6: React.FC = () => {
  const f = useCurrentFrame();
  const rug = 1 - ease(f, sec(8), sec(9));
  const cable = 1 - ease(f, sec(9), sec(10));
  const light = ease(f, sec(10.6), sec(11.4));
  return (
    <AbsoluteFill>
      <Tag n="A SAFE HOME" part={tagFor('D06')} />
      <div style={{position: 'absolute', left: 60, top: 80}}><Cap text="A fall is especially dangerous in the first few weeks" size={44} accent={['fall']} width={1160} /></div>
      <Pop at={sec(1)} style={{position: 'absolute', left: 60, top: 180}}>
        <Card style={{padding: 0, overflow: 'hidden', width: 640, height: 420}}>
          <svg width={640} height={420} viewBox="0 0 640 420">
            <rect width={640} height={420} fill="#fffdf9" />
            <rect x={20} y={20} width={600} height={380} fill="none" stroke="#b9c4cf" strokeWidth={6} />
            <path d="M320 20 L320 260 M320 320 L320 400" stroke="#b9c4cf" strokeWidth={6} />
            <text x={170} y={60} textAnchor="middle" fontFamily={font} fontWeight={700} fontSize={20} fill={C.mute}>bedroom</text>
            <text x={470} y={60} textAnchor="middle" fontFamily={font} fontWeight={700} fontSize={20} fill={C.mute}>toilet and shower</text>
            <rect x={60} y={100} width={150} height={90} rx={10} fill="#fff" stroke="#9aa5b1" strokeWidth={3} />
            <g opacity={rug}><rect x={120} y={250} width={140} height={80} rx={10} fill="#e9b98d" /><path d="M130 260 L250 320 M250 260 L130 320" stroke="#d99b66" strokeWidth={3} /></g>
            <g opacity={cable}><path d="M40 360 C 90 330, 140 380, 200 350 C 240 330, 260 360, 300 340" stroke="#5d6875" strokeWidth={4} fill="none" /></g>
            <circle cx={300} cy={300} r={10 + 30 * light} fill="#ffd36e" opacity={0.35 * light} /><circle cx={300} cy={300} r={8} fill={light > 0.5 ? '#ffc23d' : '#cfd6dd'} />
            <path d="M210 160 C 260 220, 300 280, 400 300" stroke={C.teal} strokeWidth={5} strokeDasharray="10 8" fill="none" opacity={light} />
            <rect x={420} y={250} width={80} height={90} rx={12} fill="#fff" stroke={C.ink} strokeWidth={3} />
            <rect x={414} y={240} width={92} height={18} rx={6} fill={C.tealL} stroke={C.teal} strokeWidth={3} opacity={ease(f, sec(17), sec(18))} />
            <path d="M560 120 L560 220" stroke={C.teal} strokeWidth={10} strokeLinecap="round" opacity={ease(f, sec(18.4), sec(19.2))} />
          </svg>
        </Card>
      </Pop>
      <div style={{position: 'absolute', left: 740, top: 180, width: 480, display: 'flex', flexDirection: 'column', gap: 12}}>
        <Pop at={sec(3)}><Card style={{background: C.redL}}><Label size={20} color={C.red}>A fall can dislocate the joint replacement or cause a fracture</Label></Card></Pop>
        <Pop at={sec(8)}><Card><Label size={20}>Remove rugs and cables · light at night · things at waist height</Label></Card></Pop>
        <Pop at={sec(15)}><Card><Label size={20}>Chair with armrests · raised toilet seat · grab rails in the shower</Label></Card></Pop>
        <Pop at={sec(21)}><Card style={{background: C.tealL}}><Label size={20}>With a walker: both hands on it, things in a bag attached to it</Label></Card></Pop>
        <Pop at={sec(29)}><Card><Label size={20}>Do not push an ordinary table on wheels. Stable shoes with non-slip soles</Label></Card></Pop>
      </div>
    </AbsoluteFill>
  );
};

const Pose: React.FC<{k: 'low' | 'cross' | 'turn' | 'pillow'; p: number}> = ({k, p}) => (
  <div style={{position: 'relative', width: 150, height: 150}}>
    <svg width={150} height={150} viewBox="0 0 100 100">
      {k === 'low' && <><circle cx={40} cy={16} r={8} fill={C.teal} /><path d="M40 24 L46 52 L70 60 L72 86" stroke={C.teal} strokeWidth={8} fill="none" strokeLinecap="round" strokeLinejoin="round" /><rect x={30} y={60} width={44} height={8} rx={3} fill="#9aa5b1" /><path d="M34 68 L34 88 M70 68 L70 88" stroke="#9aa5b1" strokeWidth={4} /></>}
      {k === 'cross' && <><circle cx={50} cy={14} r={8} fill={C.teal} /><path d="M50 22 L50 52" stroke={C.teal} strokeWidth={9} strokeLinecap="round" /><path d="M48 52 L66 72 L40 90 M52 52 L36 74 L62 90" stroke={C.teal} strokeWidth={7} fill="none" strokeLinecap="round" strokeLinejoin="round" /></>}
      {k === 'turn' && <><path d="M44 10 L44 70 L28 86" stroke={C.teal} strokeWidth={9} fill="none" strokeLinecap="round" strokeLinejoin="round" /><path d="M60 10 L60 70 L76 86" stroke={C.teal2} strokeWidth={9} fill="none" strokeLinecap="round" strokeLinejoin="round" opacity={0.5} /><path d="M20 74 C 14 68, 16 60, 24 60" stroke={C.red} strokeWidth={3} fill="none" /></>}
      {k === 'pillow' && <><circle cx={14} cy={40} r={8} fill={C.teal} /><path d="M22 42 L60 46 L90 40 M60 46 L90 54" stroke={C.teal} strokeWidth={8} fill="none" strokeLinecap="round" strokeLinejoin="round" /><ellipse cx={78} cy={47} rx={10} ry={6} fill={C.dawnL} stroke={C.dawn} strokeWidth={2} /></>}
    </svg>
    {k !== 'pillow' && <div style={{position: 'absolute', left: 25, top: 25}}><Cross p={p} size={100} /></div>}
  </div>
);

const D7: React.FC = () => {
  const f = useCurrentFrame();
  const items: {k: 'low' | 'cross' | 'turn' | 'pillow'; t: string; at: number}[] = [
    {k: 'low', t: 'bend the hip a lot', at: 11}, {k: 'cross', t: 'cross your legs', at: 13.4}, {k: 'turn', t: 'turn the leg inwards', at: 15},
    {k: 'pillow', t: 'a pillow between the knees', at: 27},
  ];
  return (
    <AbsoluteFill>
      <Tag n="MOVEMENTS" part={tagFor('D07')} />
      <div style={{position: 'absolute', left: 60, top: 80}}><Cap text="Restrictions only if your surgeon set them" size={44} accent={['surgeon']} width={1160} /></div>
      <Pop at={sec(1)} style={{position: 'absolute', left: 60, top: 180}}>
        <Card style={{width: 1160, background: C.dawnL}}><Label size={21}>While the tissues around the joint heal, some movements can cause dislocation. Whether you need restrictions, and which, depends on how you were operated on</Label></Card>
      </Pop>
      <div style={{position: 'absolute', left: 60, right: 60, top: 300, display: 'flex', gap: 20, justifyContent: 'center'}}>
        {items.map((it, i) => (
          <Pop key={i} at={sec(it.at)}>
            <Card style={{width: 250, height: 250, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8, border: it.k === 'pillow' ? `3px solid ${C.ok}` : '3px solid transparent'}}>
              <Pose k={it.k} p={ease(f, sec(it.at) + 10, sec(it.at) + 30)} />
              <Label size={20} style={{textAlign: 'center'}}>{it.k === 'pillow' ? it.t : `for now, do not ${it.t}`}</Label>
            </Card>
          </Pop>
        ))}
      </div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 590, display: 'flex', justifyContent: 'center', gap: 16}}>
        <Note at={sec(19)}>Only if restrictions were set</Note>
        <Note at={sec(23)} color={'#b8661c'} bg={C.dawnL}>How to sleep: ask your surgeon</Note>
      </div>
    </AbsoluteFill>
  );
};

const Stairs: React.FC = () => {
  const f = useCurrentFrame();
  const up = easeIO(f, sec(36), sec(40));
  return (
    <svg width={520} height={300} viewBox="0 0 520 300">
      <path d="M20 280 L120 280 L120 220 L220 220 L220 160 L320 160 L320 100 L420 100 L420 40 L500 40" stroke={C.ink} strokeWidth={5} fill="none" />
      <path d="M40 200 L460 20" stroke={C.mute} strokeWidth={4} strokeDasharray="6 6" />
      <g transform={`translate(${60 + up * 220} ${200 - up * 120})`}>
        <rect x={0} y={0} width={40} height={20} rx={8} fill={C.teal} />
        <text x={20} y={45} textAnchor="middle" fontFamily={font} fontWeight={800} fontSize={16} fill={C.teal}>good leg</text>
      </g>
      <g transform={`translate(${40 + Math.max(0, up - 0.15) * 200} ${220 - Math.max(0, up - 0.15) * 110})`}>
        <rect x={0} y={0} width={40} height={20} rx={8} fill={C.dawn} />
        <text x={20} y={45} textAnchor="middle" fontFamily={font} fontWeight={800} fontSize={16} fill={'#b8661c'}>operated leg</text>
      </g>
    </svg>
  );
};

const D8: React.FC = () => (
  <AbsoluteFill>
    <Tag n="WALKING AND STAIRS" part={tagFor('D08')} />
    <div style={{position: 'absolute', left: 60, top: 80}}><Cap text="Every day: short walks and exercises" size={44} accent={['every']} width={1160} /></div>
    <div style={{position: 'absolute', left: 60, top: 180, width: 540, display: 'flex', flexDirection: 'column', gap: 12}}>
      <Pop at={sec(1)}><Card><Label size={20}>They rebuild muscle strength and lower the risk of complications from lying down for long</Label></Card></Pop>
      <Pop at={sec(9)}><Card style={{background: C.redL}}><Label size={20} color={C.red}>Weight on the leg strictly as your surgeon says</Label></Card></Pop>
      <Pop at={sec(17)}>
        <Card style={{display: 'flex', gap: 16, alignItems: 'center', justifyContent: 'space-around'}}>
          {['walker', 'crutches', 'stick'].map((t) => <div key={t} style={{textAlign: 'center'}}><svg width={70} height={70} viewBox="0 0 100 100">{t === 'walker' ? <path d="M30 20 L70 20 M30 20 L24 90 M70 20 L76 90 M26 60 L74 60" stroke="#7f8a96" strokeWidth={7} strokeLinecap="round" fill="none" /> : t === 'crutches' ? <path d="M36 12 L36 90 M64 12 L64 90 M28 12 L44 12 M56 12 L72 12 M30 50 L42 50 M58 50 L70 50" stroke="#7f8a96" strokeWidth={6} strokeLinecap="round" fill="none" /> : <path d="M40 16 C 40 6, 62 6, 62 16 L 62 90" stroke="#7f8a96" strokeWidth={7} strokeLinecap="round" fill="none" />}</svg><Label size={18}>{t}</Label></div>)}
        </Card>
      </Pop>
      <div><Note at={sec(19)}>Choose together with the physiotherapist</Note></div>
    </div>
    <Pop at={sec(25)} style={{position: 'absolute', left: 640, top: 180}}>
      <Card style={{width: 580}}>
        <Label size={22} color={C.teal}>Stairs: after training with the physiotherapist</Label>
        <StairClimb upFrom={sec(28)} upTo={sec(37)} downFrom={sec(38)} downTo={sec(46.5)} />
        <Label size={19} style={{fontWeight: 600}}>Up: good leg → operated leg and crutch. Down: crutch → operated leg → good leg. Hold the handrail</Label>
      </Card>
    </Pop>
  </AbsoluteFill>
);

const D9: React.FC = () => (
  <AbsoluteFill>
    <Tag n="EVERYDAY LIFE" part={tagFor('D09')} />
    <div style={{position: 'absolute', left: 60, top: 80}}><Cap text="Driving, travel and “I have a joint replacement”" size={44} accent={['replacement”']} width={1160} /></div>
    <div style={{position: 'absolute', left: 60, right: 60, top: 190, display: 'flex', gap: 22}}>
      <Pop at={sec(1)}><Card style={{width: 360, height: 380}}>
        <svg width={120} height={80} viewBox="0 0 120 80"><path d="M10 50 L20 26 C 24 18, 96 18, 100 26 L110 50 Z" fill={C.tealL} stroke={C.ink} strokeWidth={4} strokeLinejoin="round" /><rect x={6} y={48} width={108} height={18} rx={6} fill={C.teal} /><circle cx={30} cy={68} r={9} fill={C.ink} /><circle cx={90} cy={68} r={9} fill={C.ink} /></svg>
        <Label size={22} style={{marginTop: 6}}>Driving: only when your doctor says it is safe</Label>
        <Label size={18} color={C.mute} style={{fontWeight: 600, marginTop: 8}}>you can control your leg confidently, brake quickly, and your medicines do not make you drowsy or less alert</Label>
      </Card></Pop>
      <Pop at={sec(12)}><Card style={{width: 400, height: 380}}>
        <svg width={120} height={80} viewBox="0 0 120 80"><path d="M10 44 L110 30 C 118 30, 118 40, 110 42 L60 50 L40 74 L30 74 L40 52 L14 56 Z" fill={C.tealL} stroke={C.ink} strokeWidth={3.5} strokeLinejoin="round" /></svg>
        <Label size={22} style={{marginTop: 6}}>Long journeys and flights: discuss with your surgeon</Label>
        <Label size={18} color={C.mute} style={{fontWeight: 600, marginTop: 8}}>long sitting raises the risk of clots; if allowed, move your feet and take breaks</Label>
      </Card></Pop>
      <Pop at={sec(25)}><Card style={{width: 360, height: 380, background: C.dawnL}}>
        <svg width={120} height={80} viewBox="0 0 120 80"><rect x={10} y={10} width={100} height={62} rx={10} fill="#fff" stroke={C.ink} strokeWidth={3.5} /><circle cx={36} cy={36} r={12} fill={C.tealL} /><path d="M58 30 L96 30 M58 44 L86 44" stroke={C.ink} strokeWidth={4} strokeLinecap="round" /></svg>
        <Label size={22} style={{marginTop: 6}}>Tell doctors and your dentist that you have a joint replacement</Label>
      </Card></Pop>
    </div>
  </AbsoluteFill>
);

const Level: React.FC<{c: string; bg: string; h: string; items: string; at: number}> = ({c, bg, h, items, at}) => (
  <Pop at={sec(at)}>
    <Card style={{width: 370, height: 380, borderTop: `10px solid ${c}`, background: bg}}>
      <Label size={30} color={c}>{h}</Label>
      {items.split(' · ').map((it, i) => <div key={i} style={{display: 'flex', gap: 10, marginTop: 14}}><div style={{width: 12, height: 12, borderRadius: 6, background: c, marginTop: 9, flex: 'none'}} /><Label size={23} style={{fontWeight: 600, lineHeight: 1.3}}>{it}</Label></div>)}
    </Card>
  </Pop>
);

const D10: React.FC = () => (
  <AbsoluteFill>
    <Tag n="WHEN TO GET URGENT HELP" part={tagFor('D10')} />
    <div style={{position: 'absolute', left: 60, top: 80}}><Cap text="Three levels of urgency" size={46} acc={C.red} accent={['urgency']} /></div>
    <div style={{position: 'absolute', left: 60, right: 60, top: 190, display: 'flex', gap: 24, justifyContent: 'center'}}>
      <Level c={'#b8661c'} bg={C.dawnL} h="The same day" items="Temperature 38° or higher, chills · Wound getting red, discharge, pus · New pain, swelling or redness of the calf" at={1} />
      <Level c={C.red} bg={C.redL} h="Get medical help immediately. Do not walk" items="Sudden severe hip pain · Leg looks shorter or oddly turned · You cannot put weight on it" at={sec(19) / FPS} />
      <Level c={'#8e1b1b'} bg={'#f8d4d1'} h="Call 101" items="Sudden shortness of breath · Chest pain" at={sec(30) / FPS} />
    </div>
  </AbsoluteFill>
);

const D11: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Tag n="RECOVERY" part={tagFor('D11')} />
      <div style={{position: 'absolute', left: 60, top: 80}}><Cap text="Recovery can take several months" size={44} accent={['months']} width={1160} /></div>
      <div style={{position: 'absolute', left: 60, top: 200, width: 1160}}>
        <svg width={1160} height={70}>
          <rect x={10} y={30} width={1140} height={10} rx={5} fill={C.line} />
          <rect x={10} y={30} width={1140 * easeIO(f, sec(1), sec(8))} height={10} rx={5} fill={C.teal2} />
          {['weeks', '1 month', '2 months', '3 months +'].map((t, i) => <text key={i} x={i === 3 ? 1150 : 10 + i * 370} y={66} textAnchor={i === 3 ? 'end' : 'start'} fontFamily={font} fontWeight={700} fontSize={18} fill={C.mute}>{t}</text>)}
        </svg>
        <div style={{display: 'flex', gap: 18, marginTop: 20}}>
          <Pop at={sec(5)}><Card style={{width: 560}}><Label size={20}>Everyone is different: sometimes fast, sometimes slower. Come to your follow-up</Label></Card></Pop>
          <Pop at={sec(15)}><Card style={{width: 580, background: C.dawnL}}><Label size={20}>After a hip fracture: ask your doctor about checking for osteoporosis and preventing falls</Label></Card></Pop>
        </div>
      </div>
      <Pop at={sec(24)} style={{position: 'absolute', left: 190, top: 500}}>
        <Card style={{width: 900, padding: 28, textAlign: 'center', borderTop: `8px solid ${C.teal}`}}>
          <Label size={28}>These are general recommendations.</Label>
          <Label size={24} color={C.mute} style={{fontWeight: 600, marginTop: 8}}>Individual instructions from your doctor and medical team come first.</Label>
        </Card>
      </Pop>
    </AbsoluteFill>
  );
};

const MAP: Record<string, React.FC> = {D01: D1, D02: D2, D03: D3, D04: D4, D05: D5, D06: D6, D07: D7, D08: D8, D09: D9, D10: D10, D11: D11};

const Fade: React.FC<{d: number; children: React.ReactNode}> = ({d, children}) => {
  const f = useCurrentFrame();
  const o = Math.min(ease(f, 0, 10), 1 - ease(f, d - 10, d));
  const sc = 1 + 0.035 * (f / Math.max(d, 1));
  return <AbsoluteFill style={{opacity: o, transform: `scale(${sc})`, transformOrigin: '50% 45%'}}>{children}</AbsoluteFill>;
};

export const Part3_en: React.FC<{withAudio?: boolean; half?: 'a' | 'b'}> = ({withAudio = true, half}) => {
  G.rtl = false;
  let at = 0;
  const list = TT.filter((x) => !half || (half === 'a' ? A_IDS.includes(x.id) : !A_IDS.includes(x.id)));
  const endAt = list.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
  return (
    <AbsoluteFill>
      <Bg />
      {half === 'a' && <Sequence from={endAt} durationInFrames={END}><EndA /></Sequence>}
      {list.map((x) => {
        const d = Math.round((x.dur + PAD) * FPS);
        const Comp = MAP[x.id];
        const el = (
          <Sequence key={x.id} from={at} durationInFrames={d} name={x.id}>
            <Fade d={d}><K k={x.k}><Comp /></K></Fade>
            {withAudio && x.audio && <Sequence from={6}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
          </Sequence>
        );
        at += d;
        return el;
      })}
    </AbsoluteFill>
  );
};
