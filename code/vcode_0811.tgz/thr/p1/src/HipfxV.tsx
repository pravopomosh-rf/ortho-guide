import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {C, Cap, Card, CallButton, FPS, G, Label, Note, Pop, ease, font} from './ui';
import {Bed, Icon} from './Part1';
import timing from './timing_hipfx.json';
import CUE from './cues_hipfx_ru.json';

type T = {id: string; dur: number; audio?: string}[];
const TT = timing as T;
const PAD = 0.75;
export const totalHipfxV = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const sec = (s: number) => Math.round(s * FPS);
// время слова в озвучке (сек от начала сцены), см. cues_hipfx_*.json
const T = (k: string, d = 0) => ((CUE as Record<string, number>)[k] ?? 0) + d;
const PT = 'ПЕРЕЛОМ БЕДРА · СРОЧНАЯ ОПЕРАЦИЯ';

/* ---------- схема проксимального отдела правой бедренной кости (вид спереди, не в масштабе) ---------- */
const FEMUR = 'M98 400 L96 236 C 92 200, 70 160, 62 128 C 56 104, 64 84, 80 82 C 94 80, 104 90, 112 100 C 128 90, 148 80, 166 74 L 190 118 C 176 126, 166 140, 162 160 C 168 170, 182 184, 184 200 C 184 214, 172 222, 164 222 L 160 236 L 160 400 Z';
type FemOpt = {neck?: number; troch?: number; glowNeck?: number; screws?: number; dhs?: number; nail?: number; prosth?: number; scale?: number};
const Femur: React.FC<FemOpt> = ({neck = 0, troch = 0, glowNeck = 0, screws = 0, dhs = 0, nail = 0, prosth = 0, scale = 1}) => (
  <svg width={260 * scale} height={420 * scale} viewBox="20 20 240 400">
    <defs>
      <radialGradient id="bone" cx="40%" cy="30%" r="80%"><stop offset="0%" stopColor="#fbf3e3" /><stop offset="100%" stopColor="#e3cfa9" /></radialGradient>
    </defs>
    <path d={FEMUR} fill="url(#bone)" stroke="#a88c5e" strokeWidth={3.5} strokeLinejoin="round" opacity={prosth > 0 ? 0.55 : 1} />
    {prosth === 0 && <circle cx={205} cy={84} r={40} fill="url(#bone)" stroke="#a88c5e" strokeWidth={3.5} />}
    {prosth > 0 && (
      <g opacity={prosth}>
        <path d="M112 330 L104 220 C 102 180, 112 150, 140 128 L172 104 L182 118 L152 146 C 136 162, 132 190, 134 220 L128 330 Z" fill="#9aa8b8" stroke="#5c6b7c" strokeWidth={2.5} strokeLinejoin="round" />
        <circle cx={205} cy={84} r={38} fill="#c8d2dc" stroke="#5c6b7c" strokeWidth={3} />
        <circle cx={194} cy={72} r={10} fill="#eef3f7" opacity={0.8} />
      </g>
    )}
    {/* подсветка шейки */}
    {glowNeck > 0 && <ellipse cx={160} cy={112} rx={34} ry={26} transform="rotate(-30 160 112)" fill={C.teal2} opacity={0.35 * glowNeck} />}
    {/* линия перелома шейки */}
    {neck > 0 && <path d="M150 82 L158 96 L150 108 L160 122 L156 136" stroke={C.red} strokeWidth={5} fill="none" strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - neck} />}
    {/* чрезвертельная линия: от большого вертела к малому, НЕ через шейку */}
    {troch > 0 && <path d="M84 110 L102 132 L114 146 L132 164 L148 180 L170 200" stroke={C.red} strokeWidth={5} fill="none" strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - troch} />}
    {/* винты вдоль шейки */}
    {screws > 0 && [0, 1, 2].map((i) => (
      <g key={i} opacity={screws}>
        <path d={`M${78 + i * 6} ${150 + i * 14} L${196 + i * 2} ${84 + i * 12}`} stroke="#6b7a8c" strokeWidth={7} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - screws} />
      </g>
    ))}
    {/* пластина со скользящим винтом */}
    {dhs > 0 && (
      <g opacity={dhs}>
        <rect x={84} y={150} width={14} height={180} rx={5} fill="#8796a8" stroke="#5c6b7c" strokeWidth={2} />
        {[180, 220, 260, 300].map((y) => <circle key={y} cx={91} cy={y} r={3.5} fill="#e9eef3" />)}
        <path d="M90 160 L198 92" stroke="#6b7a8c" strokeWidth={11} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - dhs} />
      </g>
    )}
    {/* внутрикостный гвоздь */}
    {nail > 0 && (
      <g opacity={nail}>
        <path d="M84 96 C 100 150, 126 210, 128 260 L128 380" stroke="#8796a8" strokeWidth={14} fill="none" strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - nail} />
        <path d="M110 170 L198 94" stroke="#5c6b7c" strokeWidth={9} strokeLinecap="round" opacity={nail > 0.6 ? 1 : 0} />
      </g>
    )}
  </svg>
);



/* ===== ВЕРТИКАЛЬНАЯ ВЕРСИЯ (9:16): виртуальный холст 720×1280, масштаб ×1.5 → 1080×1920 ===== */
const VW = 720;
const dir = () => (G.rtl ? 'rtl' : 'ltr') as 'rtl' | 'ltr';
const Col: React.FC<{top: number; gap?: number; children: React.ReactNode}> = ({top, gap = 14, children}) => (
  <div style={{position: 'absolute', left: 36, right: 36, top, display: 'flex', flexDirection: 'column', gap, direction: dir()}}>{children}</div>
);
const Head: React.FC<{text: string; acc: string[]; size?: number}> = ({text, acc, size = 44}) => (
  <div style={{position: 'absolute', left: 36, right: 36, top: 92}}><Cap text={text} size={size} accent={acc} width={VW - 72} /></div>
);
const Center: React.FC<{top: number; gap?: number; children: React.ReactNode}> = ({top, gap = 16, children}) => (
  <div style={{position: 'absolute', left: 36, right: 36, top, display: 'flex', justifyContent: 'center', alignItems: 'center', flexWrap: 'wrap', gap, direction: dir()}}>{children}</div>
);
const PBg: React.FC = () => {
  const f = useCurrentFrame();
  const x = 50 + Math.sin(f / 90) * 6;
  return (
    <AbsoluteFill style={{background: `radial-gradient(900px 900px at ${x}% -5%, #fff3e4 0%, ${C.bg} 45%, ${C.bg2} 100%)`}}>
      <svg width={VW} height={1280} style={{position: 'absolute', opacity: 0.5}}>
        <defs><pattern id="pdots" width={28} height={28} patternUnits="userSpaceOnUse"><circle cx={2} cy={2} r={1.3} fill="#e2d8ca" /></pattern></defs>
        <rect width={VW} height={1280} fill="url(#pdots)" />
      </svg>
    </AbsoluteFill>
  );
};
const VTag: React.FC<{n: string}> = ({n}) => {
  const f = useCurrentFrame();
  return (
    <div style={{position: 'absolute', top: 34, left: 36, right: 36, fontFamily: font, fontWeight: 700, fontSize: 17, letterSpacing: 1.2, opacity: ease(f, 0, 10), direction: dir()}}>
      <div style={{color: C.mute, fontWeight: 600}}>{PT}</div>
      <div style={{color: C.teal, marginTop: 4}}>{n}</div>
    </div>
  );
};
const VFoot: React.FC<{children: React.ReactNode}> = ({children}) => (
  <div style={{position: 'absolute', left: 36, right: 36, bottom: 36, fontFamily: font, fontSize: 16, color: C.mute, lineHeight: 1.3, direction: dir()}}>{children}</div>
);
const Src: React.FC<{children: React.ReactNode}> = ({children}) => <VFoot>Источник: {children}</VFoot>;
const Box: React.FC<{at: number; children: React.ReactNode; bg?: string; size?: number}> = ({at, children, bg = C.white, size = 25}) => (
  <Pop at={sec(at)}><Card style={{background: bg, padding: '16px 20px'}}><Label size={size}>{children}</Label></Card></Pop>
);
const Arrow: React.FC<{at: number}> = ({at}) => {
  const f = useCurrentFrame();
  return <svg width={30} height={34} style={{alignSelf: 'center', opacity: ease(f, sec(at), sec(at) + 8)}}><path d="M15 3 L15 27 M5 18 L15 29 L25 18" stroke={C.mute} strokeWidth={4} fill="none" strokeLinecap="round" /></svg>;
};

const H1: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <VTag n="ДЛЯ ПАЦИЕНТОВ И БЛИЗКИХ" />
      <Head text="Перелом верхнего отдела бедренной кости: срочная операция" size={46} acc={['срочная']} />
      <Center top={330}><Note at={sec(T('H01.note'))}>Что это · подготовка · операции · после</Note></Center>
      <Center top={430}><div style={{opacity: ease(f, 6, 24)}}><Femur glowNeck={ease(f, sec(T('H01.fx')), sec(T('H01.fx', 2)))} scale={1.55} /></div></Center>
    </AbsoluteFill>
  );
};

const H2: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <VTag n="ЧТО ЭТО ЗА ПЕРЕЛОМ" />
      <Head text="Шейка бедра — под головкой бедренной кости" acc={['шейка']} />
      <Center top={250}>
        <div>
          <Femur glowNeck={ease(f, sec(0.5), sec(2))} neck={ease(f, sec(T('H02.fx')), sec(T('H02.fx', 1.5)))} scale={1.1} />
          <div style={{fontFamily: font, fontSize: 17, color: C.mute, textAlign: 'center', marginTop: -10}}>схема, не в масштабе</div>
        </div>
      </Center>
      <Col top={760}>
        <Box at={T('H02.osteo')}>Хрупкие кости, остеопороз → перелом даже при обычном падении</Box>
        <Box at={T('H02.pain')}>Боль в паху · не может опереться · нога короче и развёрнута наружу</Box>
        <Box at={T('H02.walk')} bg={C.dawnL}>Иногда человек ещё может ходить</Box>
      </Col>
    </AbsoluteFill>
  );
};

const H3: React.FC = () => {
  const card = (t: string, sub: string, at: number, bg = C.white) => (
    <Pop at={sec(at)}><Card style={{background: bg, display: 'flex', flexDirection: 'column', gap: 8, padding: '22px 24px'}}><Label size={32}>{t}</Label><Label size={23} color={C.mute} style={{fontWeight: 600}}>{sub}</Label></Card></Pop>
  );
  return (
    <AbsoluteFill>
      <VTag n="ДИАГНОЗ" />
      <Head text="Осмотр и рентген в приёмном отделении" acc={['рентген']} />
      <Col top={300} gap={10}>
        {card('Осмотр + рентген', 'обычно этого достаточно', T('H03.xr'))}
        <Arrow at={T('H03.mri', -0.4)} />
        {card('Магнитно-резонансная томография', 'если на рентгене не видно, а подозрение остаётся', T('H03.mri'), C.tealL)}
        <Arrow at={T('H03.ct', -0.4)} />
        {card('Компьютерная томография', 'если МРТ нельзя сделать в течение 24 часов или она противопоказана', T('H03.ct'))}
      </Col>
      <Src>Национальный институт здоровья и качества медицинской помощи Великобритании — рекомендации по перелому бедра</Src>
    </AbsoluteFill>
  );
};

const Scale: React.FC<{at: number}> = ({at}) => {
  const f = useCurrentFrame();
  const v = Math.round(interpolate(f, [sec(at), sec(at + 3)], [7, 3], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}));
  return (
    <div style={{display: 'flex', gap: 4, direction: 'ltr'}}>
      {Array.from({length: 11}, (_, i) => (
        <div key={i} style={{width: 48, height: 52, borderRadius: 9, background: i === v ? C.teal : i < 4 ? '#dff1e9' : i < 7 ? C.dawnL : C.redL, color: i === v ? '#fff' : C.ink, fontFamily: font, fontWeight: 800, fontSize: 21, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{i}</div>
      ))}
    </div>
  );
};

const H4: React.FC = () => (
  <AbsoluteFill>
    <VTag n="В ОТДЕЛЕНИИ ДО ОПЕРАЦИИ" />
    <Head text="Не вставайте сами — позовите персонал" acc={['позовите']} />
    <Center top={250} gap={30}><Pop at={sec(1)}><Bed w={300} rails={1} /></Pop><CallButton size={76} glow={1} /></Center>
    <Col top={500}>
      <Box at={T('H04.help')}>Персонал поможет повернуться и провести гигиену</Box>
      <Pop at={sec(T('H04.pain'))}><Card style={{padding: '16px 20px'}}><Label size={25}>Обезболивание — сразу. Боль усилилась? Скажите медсестре</Label><div style={{marginTop: 12}}><Scale at={T('H04.scale')} /></div></Card></Pop>
      <Box at={T('H04.block')} bg={C.tealL}>Блокада нерва — обезболивающий укол около нерва</Box>
      <Box at={T('H04.labs')}>Анализы и подготовка к операции</Box>
    </Col>
  </AbsoluteFill>
);

const H5: React.FC = () => {
  const f = useCurrentFrame();
  const tl = ease(f, sec(T('H05.tl', 0.2)), sec(T('H05.tl', 3.6)));
  return (
    <AbsoluteFill>
      <VTag n="ПОДГОТОВКА" />
      <Head text="Кожа и профилактика тромбов" acc={['тромбов']} />
      <Col top={250} gap={12}>
        <Box at={0.5} size={24}>Кожу очищает персонал — по правилам больницы</Box>
        <Box at={T('H05.shave')} size={24}>Не брейте кожу сами</Box>
        <Box at={T('H05.allergy')} size={24} bg={C.dawnL}>Аллергия на хлоргексидин, рана или раздражение на коже? Скажите персоналу</Box>
        <Pop at={sec(T('H05.clex'))}><Card style={{display: 'flex', alignItems: 'center', gap: 14, padding: '14px 20px'}}><Icon k="syringe" s={76} /><Label size={25}>Клексан (эноксапарин) — профилактика тромбов</Label></Card></Pop>
        <Pop at={sec(T('H05.tl'))}>
          <Card style={{background: C.tealL, padding: '16px 20px'}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 10, fontFamily: font, fontWeight: 800, fontSize: 22, color: C.ink}}>
              <span>укол</span><span style={{fontSize: 20, color: C.teal, whiteSpace: 'nowrap'}}>≥ 12 ч</span>
              <svg width={110} height={20}><path d="M4 10 L106 10" stroke={C.teal} strokeWidth={5} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - tl} /></svg>
              <span style={{whiteSpace: 'nowrap'}}>спинальная анестезия</span>
            </div>
            <Label size={23} style={{marginTop: 8}}>После профилактической дозы — минимум 12 часов</Label>
            <Label size={20} color={C.mute} style={{marginTop: 6, fontWeight: 600}}>Окончательный интервал определяет анестезиолог</Label>
          </Card>
        </Pop>
      </Col>
      <Src>Американское общество регионарной анестезии, 2025</Src>
    </AbsoluteFill>
  );
};

const H6: React.FC = () => (
  <AbsoluteFill>
    <VTag n="ЕДА, ПИТЬЁ, ЛЕКАРСТВА" />
    <Head text="Еда и питьё — только с разрешения" acc={['разрешения']} />
    <Col top={250} gap={12}>
      <Box at={T('H06.last')} size={24}>Скажите, когда вы в последний раз ели или пили</Box>
      <Box at={T('H06.delay')} size={24}>Операцию отложили? Уточните, когда можно пить</Box>
      <Box at={T('H06.thin')} bg={C.dawnL} size={24}>Разжижающие кровь: Кумадин, Эликвис, Ксарелто, Прадакса, Плавикс — скажите врачу</Box>
      <Box at={T('H06.diab')} bg={C.dawnL} size={24}>Лекарства от диабета — скажите врачу и время последнего приёма</Box>
      <Box at={T('H06.self')} size={24}>Не принимайте и не отменяйте лекарства сами</Box>
      <Pop at={sec(T('H06.fam'))}><Card style={{display: 'flex', alignItems: 'center', gap: 14, background: C.tealL, padding: '14px 20px'}}><Icon k="pill" s={68} /><Label size={24}>Близкие: список лекарств или упаковки</Label></Card></Pop>
    </Col>
  </AbsoluteFill>
);

const H7: React.FC = () => {
  const f = useCurrentFrame();
  const col = (title: string, sub: string, at: number, el: React.ReactNode) => (
    <Pop at={sec(at)}><Card style={{width: 312, height: 360, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, padding: '14px 12px', boxSizing: 'border-box'}}>
      <Label size={22} style={{textAlign: 'center'}}>{title}</Label>
      <div style={{height: 200, display: 'flex', alignItems: 'center'}}>{el}</div>
      <Label size={18} color={C.mute} style={{fontWeight: 600, textAlign: 'center'}}>{sub}</Label>
    </Card></Pop>
  );
  return (
    <AbsoluteFill>
      <VTag n="ОПЕРАЦИИ" />
      <Head text="Какую операцию выбрать — решает хирург" size={40} acc={['хирург']} />
      <Center top={240} gap={14}>
        {col('Перелом шейки без смещения', 'винты или другая фиксация', 0.3, <Femur neck={1} screws={ease(f, sec(T('H07.screw')), sec(T('H07.screw', 2)))} scale={0.5} />)}
        {col('Перелом шейки со смещением', 'чаще частичная или полная замена сустава (на схеме — пример частичной)', T('H07.disp'), <Femur prosth={ease(f, sec(T('H07.repl')), sec(T('H07.repl', 2)))} scale={0.5} />)}
        {col('Чрезвертельный', 'пластина со скользящим винтом', T('H07.troch'), <Femur troch={1} dhs={ease(f, sec(T('H07.plate')), sec(T('H07.plate', 2)))} scale={0.5} />)}
        {col('Чрезвертельный', 'или внутрикостный гвоздь', T('H07.nail', -0.2), <Femur troch={1} nail={ease(f, sec(T('H07.nail', 0.3)), sec(T('H07.nail', 2.3)))} scale={0.5} />)}
      </Center>
      <Col top={1000} gap={10}>
        <Note at={sec(T('H07.time'))}>Обычно в течение 24–48 часов</Note>
        <Note at={sec(T('H07.moh'))} color={C.mute} bg={C.white}>Минздрав Израиля публикует долю пациентов, прооперированных в течение 48 часов</Note>
      </Col>
      <Src>Американская академия ортопедических хирургов, 2021; Министерство здравоохранения Израиля, Национальная программа показателей качества. Схемы упрощены, не в масштабе.</Src>
    </AbsoluteFill>
  );
};

const H8: React.FC = () => (
  <AbsoluteFill>
    <VTag n="ПОСЛЕ ОПЕРАЦИИ" />
    <Head text="Подъём — обычно на следующий день, с физиотерапевтом" size={40} acc={['подъём']} />
    <Col top={300} gap={11}>
      <Box at={T('H08.early')} size={23}>Ранние движения: меньше риск тромбов, пневмонии, пролежней</Box>
      <Box at={T('H08.wb')} size={23} bg={C.tealL}>Нагрузка на ногу — как скажет врач</Box>
      <Box at={T('H08.vte')} size={23}>Профилактика тромбов может продолжаться и после выписки</Box>
      <Box at={T('H08.delir')} size={23} bg={C.dawnL}>Внезапная спутанность сознания (делирий) — сразу скажите персоналу</Box>
      <Box at={T('H08.quiet')} size={22}>Бывает «тихой»: сонливость, заторможенность, замкнутость</Box>
      <Pop at={sec(T('H08.fam'))}><Card style={{display: 'flex', justifyContent: 'space-around', alignItems: 'center', padding: '12px 20px'}}>
        <svg width={70} height={70} viewBox="0 0 100 100"><circle cx={30} cy={56} r={16} fill="#eaf6fb" stroke={C.ink} strokeWidth={4} /><circle cx={70} cy={56} r={16} fill="#eaf6fb" stroke={C.ink} strokeWidth={4} /><path d="M46 54 C 48 50, 52 50, 54 54 M14 52 L6 40 M86 52 L94 40" stroke={C.ink} strokeWidth={4} fill="none" strokeLinecap="round" /></svg><Icon k="hearing" s={70} /><Icon k="denture" s={70} /><Icon k="alarm" s={70} />
      </Card></Pop>
      <Box at={T('H08.fam', 0.8)} size={22}>Очки · слуховой аппарат · зубные протезы · частые визиты · какой сегодня день</Box>
    </Col>
  </AbsoluteFill>
);

const H9: React.FC = () => {
  const f = useCurrentFrame();
  const day: [string, number][] = [['Повышенная температура', T('H09.temp')], ['Изменения раны: покраснение, отёк, выделения', T('H09.wound')], ['Боль или отёк одной икры', T('H09.calf')]];
  const now: [string, number][] = [['Новая сильная боль в бедре', T('H09.hip')], ['Не может опереться на ногу, нога изменила положение', T('H09.wt')]];
  return (
    <AbsoluteFill>
      <VTag n="КОГДА СРОЧНО ОБРАЩАТЬСЯ" />
      <Head text="В больнице — сразу скажите медсестре" size={40} acc={['сразу']} />
      <Col top={240} gap={8}>
        <Label size={23} color={C.teal}>После выписки — в тот же день за медицинской помощью:</Label>
        {day.map(([t, at], i) => <Box key={i} at={at} size={22}>{t}</Box>)}
        <Label size={23} color={C.red} style={{marginTop: 10}}>Немедленно в приёмное отделение. Не пытайтесь ходить:</Label>
        {now.map(([t, at], i) => <Box key={i} at={at} size={22} bg={C.dawnL}>{t}</Box>)}
        <Pop at={sec(T('H09.mda'))} style={{marginTop: 10}}>
          <Card style={{background: C.redL, borderInlineStart: `10px solid ${C.red}`, transform: `scale(${1 + 0.02 * Math.sin(f / 8)})`, display: 'flex', alignItems: 'center', gap: 20, padding: '14px 20px'}}>
            <div style={{fontFamily: font, fontWeight: 900, fontSize: 80, color: C.red, lineHeight: 1}}>101</div>
            <div>
              <Label size={22}>Скорая «Маген Давид Адом» — немедленно:</Label>
              <Label size={22} color={C.red} style={{marginTop: 6}}>внезапная одышка · боль в груди · обморок</Label>
            </div>
          </Card>
        </Pop>
      </Col>
    </AbsoluteFill>
  );
};

const H10: React.FC = () => (
  <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
    <Pop at={4}>
      <Card style={{width: 620, padding: 36, textAlign: 'center', borderTop: `8px solid ${C.teal}`}}>
        <Label size={36} style={{lineHeight: 1.3}}>Это общие рекомендации.</Label>
        <Label size={30} color={C.mute} style={{fontWeight: 600, marginTop: 12, lineHeight: 1.3}}>Индивидуальные указания вашего врача и медицинской команды имеют приоритет.</Label>
      </Card>
    </Pop>
    <VFoot>Схемы упрощены, не в масштабе. Источники — в описании и на сайте.</VFoot>
  </AbsoluteFill>
);

const MAP: Record<string, React.FC> = {H01: H1, H02: H2, H03: H3, H04: H4, H05: H5, H06: H6, H07: H7, H08: H8, H09: H9, H10: H10};

const Fade: React.FC<{d: number; children: React.ReactNode}> = ({d, children}) => {
  const f = useCurrentFrame();
  const o = Math.min(ease(f, 0, 10), 1 - ease(f, d - 10, d));
  const sc = 1 + 0.02 * (f / Math.max(d, 1));
  return <AbsoluteFill style={{opacity: o, transform: `scale(${sc})`, transformOrigin: '50% 40%'}}>{children}</AbsoluteFill>;
};

export const HipfxV: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 0, top: 0, width: VW, height: 1280, transform: 'scale(1.5)', transformOrigin: '0 0', overflow: 'hidden'}}>
        <PBg />
        {TT.map((x) => {
          const d = Math.round((x.dur + PAD) * FPS);
          const Comp = MAP[x.id];
          const el = (
            <Sequence key={x.id} from={at} durationInFrames={d} name={x.id}>
              <Fade d={d}><Comp /></Fade>
              {withAudio && x.audio && <Sequence from={6}><Audio src={staticFile(`aud/hipfx/${x.audio}`)} /></Sequence>}
            </Sequence>
          );
          at += d;
          return el;
        })}
      </div>
    </AbsoluteFill>
  );
};
