import React from 'react';
import {AbsoluteFill} from 'remotion';
import {StairClimb, WalkerWalk} from './motion';
export const MTest: React.FC = () => (
  <AbsoluteFill style={{background: '#fff8ef', flexDirection: 'row', gap: 20, padding: 20}}>
    <StairClimb upFrom={0} upTo={120} downFrom={130} downTo={250} />
    <WalkerWalk />
  </AbsoluteFill>
);
