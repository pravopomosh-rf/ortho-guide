// «Кифопластика» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import timing from './timing_kyph_ar.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalKyph_ar = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'جراحة العظام · للمرضى';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

// ---- Кифопластика: сцены K01–K05, K09–K11 ----
const BONE = '#EFE6D8', BONES = '#C9B79C';
// боковая проекция позвоночника: тела слева (спереди), задние элементы справа (сзади)
const Body: React.FC<{y: number; hf?: number; porous?: number; hl?: number}> = ({y, hf = 1, porous = 0, hl = 0}) => {
  // hf: высота передней части (1 = норма), задняя стенка тела сохраняется
  const H = 120, front = H * hf, top = y + (H - front) * 0.5;
  return <g>
    <path d={`M 250 ${top} L 470 ${y} L 470 ${y + H} L 250 ${top + front} Z`} fill={BONE} stroke={hl > 0 ? C.acc : BONES} strokeWidth={hl > 0 ? 6 : 4} strokeLinejoin="round" />
    {porous > 0 && <g opacity={porous}>{Array.from({length: 18}, (_, i) => <circle key={i} cx={275 + (i % 6) * 32} cy={y + 22 + Math.floor(i / 6) * 34} r={7 + (i % 3) * 2} fill="#D8CBB3" />)}</g>}
    <path d={`M 468 ${y + 30} L 560 ${y + 24} L 560 ${y + 76} L 468 ${y + 80} Z`} fill={BONE} stroke={BONES} strokeWidth={4} />
    <path d={`M 560 ${y + 14} L 610 ${y + 6} L 740 ${y + 50} L 748 ${y + 86} L 610 ${y + 96} L 560 ${y + 90} Z`} fill={BONE} stroke={BONES} strokeWidth={4} />
  </g>;
};
const Disc: React.FC<{y: number}> = ({y}) => <rect x={262} y={y} width={196} height={34} rx={14} fill="#D7E9EE" stroke="#9CC9D3" strokeWidth={3} />;
const Column: React.FC<{hf: number; porous?: number; hl?: number; children?: React.ReactNode; top?: number}> = ({hf, porous = 0, hl = 0, children, top = 470}) => (
  <svg width={1080} height={760} viewBox="170 0 800 563" style={{position: 'absolute', left: 0, top}}>
    <Body y={40} porous={porous} /><Disc y={166} />
    <Body y={206} hf={hf} porous={porous} hl={hl} /><Disc y={332} />
    <Body y={372} porous={porous} />
    {children}
    <text textAnchor="end" x={250} y={560} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.teal}>الأمام</text><text textAnchor="end" x={450} y={560} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.mute}>منظر جانبي</text><text textAnchor="end" x={720} y={560} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.teal}>الخلف</text>
  </svg>
);

const S01: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const pulse = ease(f, fr(d, 0.2), fr(d, 0.3)) * (0.6 + 0.4 * Math.sin(f / 5));
  return <>
    <Card x={64} y={470} w={420} label="المريضة" at={4}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>امرأة</div>
      <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 28, color: C.mute}}>74 عامًا</div>
    </Card>
    <Card x={540} y={470} w={476} label="ألم الظهر" at={14}>
      <div><Counter from={0} to={4} a={fr(d, 0.45)} b={fr(d, 0.8)} size={78} suffix=" أسابيع" /></div>
      <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 24, color: C.mute, marginTop: 8}}>رغم المسكّنات</div>
    </Card>
    <Column hf={1} top={690}>
      <circle cx={360} cy={266} r={95} fill={C.acc} opacity={0.22 * pulse} />
      <circle cx={360} cy={266} r={55} fill={C.acc} opacity={0.35 * pulse} />
    </Column>
    <div style={{position: 'absolute', left: 64, top: 1460, opacity: ease(f, fr(d, 0.3), fr(d, 0.4))}}><Note size={30}>ألم شديد بعد الانحناء</Note></div>
  </>;
};

const S02: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const c = ease(f, fr(d, 0.1), fr(d, 0.45)), por = ease(f, fr(d, 0.55), fr(d, 0.75));
  return <>
    <Column hf={1 - 0.45 * c} porous={por} hl={c > 0.5 ? 1 : 0} />
    <div style={{position: 'absolute', left: 64, top: 1235, display: 'flex', gap: 16, flexWrap: 'wrap'}}>
      <div style={{opacity: c}}><Note size={30}>جسم الفقرة متسطّح</Note></div>
      <div style={{opacity: por}}><Note color={C.navy} bg="#E3E7EF" size={30}>هشاشة العظام: عظام هشّة</Note></div>
    </div>
    <div style={{position: 'absolute', left: 64, top: 1430, fontFamily: BODY, fontWeight: 600, fontSize: 22, color: C.mute}}>رسم توضيحي، ليس بمقياس حقيقي</div>
  </>;
};

const S03: React.FC<{d: number}> = ({d}) => {
  const items: [string, string][] = [['clock', 'كسر فقري حديث'], ['drop', 'الألم الشديد مستمر'], ['pills', 'تسكين الألم لم يساعد'], ['check', 'الفحص والصور يؤكّدان مصدر الألم']];
  return <>{items.map(([k, t], i) => <Slot key={i} x={64} y={480 + i * 200} w={952} h={170} at={fr(d, 0.06 + i * 0.2)}>
    <Icon k={k} s={70} /><div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink, lineHeight: 1.2}}>{t}</div></Slot>)}
    <div style={{position: 'absolute', left: 64, top: 1300, opacity: ease(useCurrentFrame(), fr(d, 0.85), fr(d, 0.95))}}><Note color={C.navy} bg="#E3E7EF" size={30}>القرار بعد نقاش بين المختصين</Note></div></>;
};

// игла через ножку дуги сзади в тело среднего позвонка
const Needle: React.FC<{p: number}> = ({p}) => {
  const x0 = 860, y0 = 236, x1 = 360, y1 = 266;
  const x = x0 + (x1 - x0) * p, y = y0 + (y1 - y0) * p;
  return <g>
    <line x1={x0 + 30} y1={y0} x2={x} y2={y} stroke="#6B7686" strokeWidth={14} strokeLinecap="round" />
    <rect x={x0 + 20} y={y0 - 22} width={50} height={44} rx={10} fill={C.navy} />
  </g>;
};
const S04: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const n = ease(f, fr(d, 0.08), fr(d, 0.35)), b = ease(f, fr(d, 0.4), fr(d, 0.75));
  return <>
    <Column hf={0.55 + 0.2 * b}>
      <Needle p={n} />
      {b > 0 && <ellipse cx={360} cy={266} rx={30 + 50 * b} ry={12 + 22 * b} fill="#8FC7E8" stroke="#3A8CC0" strokeWidth={4} opacity={0.9} />}
    </Column>
    <div style={{position: 'absolute', left: 64, top: 1300, display: 'flex', gap: 16, flexWrap: 'wrap'}}>
      <div style={{opacity: n}}><Note color={C.navy} bg="#E3E7EF" size={28}>وخز تحت توجيه الأشعة</Note></div>
      <div style={{opacity: b}}><Note color="#1F6E99" bg="#DDEFFA" size={28}>البالون يُحدث تجويفًا</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.7), fr(d, 0.85))}}><Note size={28}>أحيانًا يُستعاد جزء من الارتفاع</Note></div>
    </div>
    <div style={{position: 'absolute', left: 64, top: 1430, fontFamily: BODY, fontWeight: 600, fontSize: 22, color: C.mute}}>رسم توضيحي، ليس بمقياس حقيقي</div>
  </>;
};

const S05: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const out = ease(f, fr(d, 0.05), fr(d, 0.2)), cem = ease(f, fr(d, 0.22), fr(d, 0.55)), hard = ease(f, fr(d, 0.55), fr(d, 0.65));
  return <>
    <Column hf={0.75}>
      {out < 1 && <ellipse cx={360} cy={266} rx={80 * (1 - out) + 4} ry={34 * (1 - out) + 4} fill="#8FC7E8" stroke="#3A8CC0" strokeWidth={4} opacity={1 - out} />}
      <ellipse cx={360} cy={266} rx={78 * cem} ry={32 * cem} fill={hard > 0.5 ? '#9AA3AD' : '#BCC4CC'} stroke="#7D8794" strokeWidth={3} />
      <Needle p={1 - ease(f, fr(d, 0.68), fr(d, 0.8))} />
    </Column>
    <div style={{position: 'absolute', left: 64, top: 1235, display: 'flex', gap: 16, flexWrap: 'wrap'}}>
      <div style={{opacity: cem}}><Note color="#4B5563" bg="#E5E7EB" size={28}>إسمنت عبر القنية</Note></div>
      <div style={{opacity: cem}}><Note color={C.navy} bg="#E3E7EF" size={28}>مراقبة بالأشعة: يجب ألا يتسرّب الإسمنت</Note></div>
      <div style={{opacity: hard}}><Note color={C.teal} bg={C.tealL} size={28}>الهدف: ألم أقل وفقرة أقوى</Note></div>
    </div>
    <Card x={64} y={1320} w={952} at={fr(d, 0.72)} label="التخدير">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>تخدير عام أو موضعي مع تهدئة، يختاره طبيب التخدير</div>
    </Card>
  </>;
};

const S09: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Card x={64} y={480} w={952} at={2} label="وخزات صغيرة في الجلد">
      <svg width={880} height={220}>
        <rect x={60} y={30} width={760} height={160} rx={40} fill="#F3E2D6" stroke="#D9B79F" strokeWidth={3} />
        {[330, 550].map((x, i) => <g key={x} opacity={ease(f, 10 + i * 8, 22 + i * 8)}><rect x={x - 45} y={85} width={90} height={50} rx={12} fill="#fff" stroke="#C9CED6" strokeWidth={3} /><circle cx={x} cy={110} r={6} fill="#D4A59A" /></g>)}
      </svg>
    </Card>
    <Card x={64} y={830} w={952} at={fr(d, 0.35)} label="أنبوب التصريف · نادرًا">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink}}>اطلب من الطاقم أن يشرح كيف تتعامل معه</div>
      <div style={{display: 'flex', gap: 12, flexWrap: 'wrap', marginTop: 16}}>
        {['لا تلمسه', 'لا تفصله'].map((t, i) => <div key={t} style={{opacity: ease(f, fr(d, 0.6) + i * 10, fr(d, 0.6) + 10 + i * 10)}}><Note size={28}>{t}</Note></div>)}
      </div>
    </Card>
  </>;
};

const S10: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const a = ease(f, 4, 20), b = ease(f, fr(d, 0.35), fr(d, 0.5)), c = ease(f, fr(d, 0.6), fr(d, 0.75));
  return <>
    <Card x={64} y={480} w={952} at={2} label="رأب الحدبة">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink}}>لا يعالج هشاشة العظام نفسها</div>
    </Card>
    <svg width={1080} height={300} style={{position: 'absolute', left: 0, top: 700, opacity: a}}>
      <circle cx={540} cy={150} r={130} fill={BONE} stroke={BONES} strokeWidth={5} />
      {Array.from({length: 22}, (_, i) => <circle key={i} cx={540 + 90 * Math.cos(i * 2.4) * ((i % 4) / 4 + 0.2)} cy={150 + 90 * Math.sin(i * 2.4) * ((i % 4) / 4 + 0.2)} r={8 + (i % 3) * 4} fill="#D8CBB3" />)}
    </svg>
    <Card x={64} y={1030} w={952} at={fr(d, 0.35)} style={{background: C.navy, opacity: b}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: '#fff'}}>ناقش مع الطبيب فحوصات وعلاج هشاشة العظام</div>
    </Card>
    <div style={{position: 'absolute', left: 64, top: 1250, opacity: c}}><Note color={C.teal} bg={C.tealL} size={32}>خطر كسور جديدة ↓</Note></div>
  </>;
};

const S11: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={380} at={fr(d, 0.02)} title="فورًا إلى الطوارئ" color="#B45309" bg="#FFF7ED"
    items={[['leg', 'ضعف أو خدر في ساق واحدة أو كلتيهما'], ['bladder', 'خدر بين الأعضاء التناسلية وفتحة الشرج، صعوبة في التبوّل'], ['bladder', 'فقدان السيطرة على المثانة أو الأمعاء']]} />
  <Tier y={880} h={250} at={fr(d, 0.45)} title="101 فورًا" color={C.blood} bg="#FDECEC"
    items={[['lungs', 'ضيق نفس مفاجئ'], ['heart', 'ألم في الصدر'], ['faint', 'إغماء']]} />
  <Tier y={1160} h={280} at={fr(d, 0.72)} title="اطلب المساعدة بشكل عاجل" color={C.navy} bg="#fff"
    items={[['wound', 'ألم جديد وشديد في الظهر'], ['therm', 'حمّى'], ['wound', 'احمرار أو تورّم أو إفرازات من مكان الوخز']]} />
</>;

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const S06: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={500} at={fr(d, 0.02)} icon="shower" text="استحمام مساءً وصباحًا حسب تعليمات القسم" />
  <CheckRow y={700} at={fr(d, 0.25)} icon="razor" text="لا تحلقوا ظهوركم بأنفسكم" />
  <CheckRow y={900} at={fr(d, 0.38)} icon="therm" text="أخبروا عن الجروح والحرارة والسعال والحرقة والأسنان والحساسية من المطهّرات" />
</>;

const S07: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const calA = fr(d, 0.3);
  return <>
    <CheckRow y={480} at={2} icon="pills" text="قائمة بكل الأدوية" />
    <Card x={64} y={660} w={952} at={fr(d, 0.1)} label="مميّعات الدم">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink}}>فقط بتعليمات الطبيب. لا توقفوا الأسبرين بأنفسكم</div>
    </Card>
    <Card x={64} y={880} w={952} at={calA} label="الغليفلوزينات">
      <div style={{display: 'flex', gap: 30, alignItems: 'center'}}>
        <div style={{textAlign: 'center'}}><div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 72, color: C.acc, direction: 'ltr'}}>≥{Math.round(interpolate(f, [calA, calA + 30], [0, 3], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}))}</div><div style={{fontFamily: MONO, fontWeight: 700, fontSize: 20, color: C.mute}}>أيام</div></div>
        <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.ink, lineHeight: 1.3}}>إمباغليفلوزين، داباغليفلوزين<div style={{color: C.mute, fontWeight: 600}}>إرتوغليفلوزين: 4 أيام على الأقل</div></div>
      </div>
      <div style={{marginTop: 14}}><Note>فقط حسب خطة الطبيب · خطر الحماض الكيتوني</Note></div>
    </Card>
    <Card x={64} y={1200} w={952} at={fr(d, 0.85)} label="الإنسولين وأدوية السكري الأخرى">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink}}>خطة فردية من الطبيب</div>
    </Card>
  </>;
};

const S08: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const marks = [{h: 'قبل 8 ساعات', t: 'طعام ثقيل أو دسم', c: C.acc}, {h: 'قبل 6 ساعات', t: 'طعام خفيف', c: '#E58A2B'}, {h: 'قبل ساعتين', t: 'الماء والسوائل الصافية', c: C.teal}, {h: '0', t: 'التخدير', c: C.navy}];
  const p = ease(f, 6, fr(d, 0.85));
  return <>
    <div style={{position: 'absolute', left: 150, top: 520, width: 8, height: 900, background: C.line, borderRadius: 8}} />
    <div style={{position: 'absolute', left: 150, top: 520, width: 8, height: 900 * p, background: C.ink, borderRadius: 8}} />
    {marks.map((m, i) => {
      const a = 6 + i * fr(d, 0.22), o = ease(f, a, a + 12);
      return <div key={i} style={{position: 'absolute', left: 120, top: 500 + i * 290, display: 'flex', alignItems: 'center', gap: 34, opacity: o, transform: `translateX(${(1 - o) * 30}px)`}}>
        <div style={{width: 68, height: 68, borderRadius: 68, background: m.c, boxShadow: `0 0 0 10px ${C.bg1}`}} />
        <div style={{background: '#fff', borderRadius: 26, padding: '22px 30px', boxShadow: '0 12px 30px rgba(20,24,32,.07)', width: 680}}>
          <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 56, color: m.c}}>{m.h}</div>
          <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>{m.t}</div>
        </div>
      </div>;
    })}
  </>;
};

const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
const S12: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>هذه توصيات عامة</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>تعليمات طبيبكم والفريق الطبي الخاصة بكم لها الأولوية</div>
  </Card>
);

const SC: Record<string, React.FC<{d: number}>> = {K01: S01, K02: S02, K03: S03, K04: S04, K05: S05, K06: S06, K07: S07, K08: S08, K09: S09, K10: S10, K11: S11, K12: S12};

export const Kyph_ar: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill style={{direction: 'rtl'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
