import json,subprocess
T=json.load(open('src/timing_ru_v6orig.json'));out=[];args=[];flt=[]
for k,x in enumerate(T):
    i=x['id']
    if i in('a2a','w3'):
        a=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',f'/home/claude/ttsrepo/aud/ant/ru/{i}.opus']))
        d=round((a+0.6)*30)/30; args+=['-i',f'/home/claude/ttsrepo/aud/ant/ru/{i}.opus']
        flt.append(f"[{k}:a]aresample=48000,aformat=channel_layouts=mono,adelay=200,apad,atrim=0:{d:.4f}[a{k}]")
    else:
        d=round(x['dur']*30)/30; args+=['-i',f'ruseg/{i}.wav']
        flt.append(f"[{k}:a]aresample=48000,aformat=channel_layouts=mono,apad,atrim=0:{d:.4f}[a{k}]")
    out.append({'id':i,'dur':d})
flt.append(''.join(f'[a{j}]' for j in range(len(out)))+f'concat=n={len(out)}:v=0:a=1[o]')
subprocess.run(['ffmpeg','-v','error','-y',*args,'-filter_complex',';'.join(flt),'-map','[o]','-c:a','pcm_s16le','aud/voice_ru.wav'],check=True)
json.dump(out,open('src/timing.json','w'));print(sum(o['dur'] for o in out))
