set -e; L=$1; cd /home/claude/ant
python3 mkL.py $L
python3 mkjobs.py full timing_$L.json; cp jobs/full.json jobs/full_$L.json
CD=/home/claude/ant/clips_$L node render3d_cd.mjs jobs/full_$L.json $L > /tmp/r3_$L.log 2>&1
TF=timing_$L.json PD=/home/claude/ant/probe_$L LG=$L node probe.mjs > /tmp/probe_$L.log 2>&1
python3 lay2.py $L > /tmp/lay_$L.log
rm -rf public/clips; cp -r clips_$L public/clips
npx remotion render src/index.ts FilmV out/fv_$L.mp4 --muted --props="{\"lang\":\"$L\"}" --concurrency=2 --crf=16 --log=error
ffmpeg -v error -y -i out/fv_$L.mp4 -i aud/voice_$L.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 128k -shortest out/thr_anterior_${L}_v.mp4
bash /home/claude/tools/finish.sh out/thr_anterior_${L}_v.mp4 thr_anterior $L
python3 /home/claude/tools/vcheck.py /home/claude/out/thr_anterior_$L.mp4 > /tmp/vc_$L.log 2>&1
echo "DONE $L"
