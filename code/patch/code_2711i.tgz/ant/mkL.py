import json,subprocess,sys
L=sys.argv[1]
T=json.load(open('src/timing.json'));out=[]
for x in T:
    i=x['id']; a=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',f'/home/claude/ttsrepo/aud/ant/{L}/{i}.opus']))
    pad=0.35 if i in('w0','w1','w2') else 0.6
    out.append({'id':i,'dur':round((a+pad)*30)/30})
json.dump(out,open(f'src/timing_{L}.json','w'))
args=[];flt=[]
for k,x in enumerate(out):
    i=x['id'];lead=0.1 if i in('w0','w1','w2') else 0.2
    args+=['-i',f'/home/claude/ttsrepo/aud/ant/{L}/{i}.opus']
    flt.append(f"[{k}:a]aresample=48000,aformat=channel_layouts=mono,adelay={int(lead*1000)},apad,atrim=0:{x['dur']:.4f}[a{k}]")
flt.append(''.join(f'[a{j}]' for j in range(len(out)))+f'concat=n={len(out)}:v=0:a=1[o]')
subprocess.run(['ffmpeg','-v','error','-y',*args,'-filter_complex',';'.join(flt),'-map','[o]','-c:a','pcm_s16le',f'aud/voice_{L}.wav'],check=True)
print(L,sum(o['dur'] for o in out))
