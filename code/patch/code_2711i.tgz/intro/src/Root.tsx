import React from 'react';
import {Composition} from 'remotion';
import {Intro, total} from './Intro';
import {Comp, compTotal} from './Comp';
export const Root: React.FC = () => (<>
  <Composition id="Intro" component={Intro} durationInFrames={total()} fps={30} width={1080} height={1920} />
  <Composition id="Comp" component={Comp} durationInFrames={compTotal()} fps={30} width={1080} height={1920} />
</>);
