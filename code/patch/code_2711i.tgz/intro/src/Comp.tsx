import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, spring, staticFile, useCurrentFrame, getInputProps, Easing} from 'remotion';
// eslint-disable-next-line @typescript-eslint/no-var-requires
const DATA: any = require('./comp_data.json');
const P: any = getInputProps() || {};
const LANG: string = P.lang || 'ru';
const RTL = LANG === 'he' || LANG === 'ar';
const FPS = 30;
const TEAL = '#1f7a70', INK = '#14233a', MUTE = '#5b6b80', RED = '#c8372d', AMB = '#d98a1c', LINE = '#e2e8ee', BLUE = '#2f6fd6';
const FONT = LANG === 'he' ? "'NSH', sans-serif" : LANG === 'ar' ? "'NSA', sans-serif" : "'IN', sans-serif";
const FF = [600, 700, 800].map((w) => `@font-face{font-family:'IN';font-weight:${w};src:url(${staticFile(`fonts/inter-cyrillic-${w}-normal.woff2`)})}@font-face{font-family:'IN';font-weight:${w};src:url(${staticFile(`fonts/inter-latin-${w}-normal.woff2`)});unicode-range:U+0000-00FF,U+2000-206F}@font-face{font-family:'NSH';font-weight:${w};src:url(${staticFile(`fonts/noto-sans-hebrew-hebrew-${w}-normal.woff2`)})}@font-face{font-family:'NSA';font-weight:${w};src:url(${staticFile(`fonts/noto-sans-arabic-arabic-${w}-normal.woff2`)})}`).join('');
// eslint-disable-next-line @typescript-eslint/no-var-requires
const SCR: Record<string, Record<string, string>> = require('./comp_screen.json');
const t = (k: string) => SCR[LANG]?.[k] ?? SCR.ru[k];
const ease = (f: number, a: number, b: number) => interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});

const Title: React.FC<{k: string; c?: string; at?: number}> = ({k, c = INK, at = 0}) => {
  const f = useCurrentFrame();
  const o = ease(f, at, at + 14);
  return <div style={{position: 'absolute', top: 150, left: 70, right: 70, fontFamily: FONT, fontWeight: 800, fontSize: 64, lineHeight: 1.12, color: c, opacity: o, transform: `translateY(${(1 - o) * 30}px)`, textAlign: RTL ? 'right' : 'left'}}>{t(k)}</div>;
};
const Pill: React.FC<{k: string; at: number; c?: string; bg?: string; size?: number}> = ({k, at, c = INK, bg = '#fff', size = 40}) => {
  const f = useCurrentFrame();
  const o = ease(f, at, at + 12);
  return <div style={{opacity: o, transform: `scale(${0.92 + 0.08 * o})`, background: bg, color: c, borderRadius: 26, padding: '22px 30px', fontFamily: FONT, fontWeight: 700, fontSize: size, lineHeight: 1.25, boxShadow: '0 8px 24px rgba(20,35,58,.08)'}}>{t(k)}</div>;
};

/* lower leg in a cast (side view), swelling pulse */
const LegCast: React.FC<{sw?: number; split?: number}> = ({sw = 0, split = 0}) => (
  <svg width={560} height={900} viewBox="0 0 560 900" style={{direction: 'ltr'}}>
    <defs><linearGradient id="sk" x1="0" x2="1"><stop offset="0" stopColor="#e9b99a" /><stop offset="1" stopColor="#d9a283" /></linearGradient>
      <linearGradient id="cs" x1="0" x2="1"><stop offset="0" stopColor="#ffffff" /><stop offset="1" stopColor="#dfe6ee" /></linearGradient></defs>
    <path d="M200 20 C190 160 205 300 215 420 L345 420 C355 300 370 160 360 20 Z" fill="url(#sk)" />
    <path d={`M${205 - sw * 18} 360 C${190 - sw * 22} 500 ${195 - sw * 20} 640 ${210 - sw * 10} 740 L${345 + sw * 10} 740 C${365 + sw * 20} 640 ${370 + sw * 22} 500 ${355 + sw * 18} 360 Z`} fill="url(#cs)" stroke="#c5cfdb" strokeWidth={4} />
    {[420, 480, 540, 600, 660].map((y) => <path key={y} d={`M${202 - sw * 20} ${y} Q280 ${y + 14} ${358 + sw * 20} ${y}`} stroke="#d3dbe5" strokeWidth={3} fill="none" />)}
    <path d={`M${210 - sw * 10} 740 C200 790 205 820 230 840 L440 850 C470 850 480 820 455 800 L345 760 Z`} fill="url(#sk)" />
    {[0, 1, 2, 3, 4].map((i) => <ellipse key={i} cx={455 - i * 4} cy={812 + i * 9} rx={14} ry={9} fill="#e3ad8e" />)}
    {split > 0 && <path d={`M280 360 L280 ${360 + 380 * split}`} stroke={RED} strokeWidth={6} strokeDasharray="14 10" />}
    <circle cx={280} cy={560} r={130 + sw * 30} fill="rgba(217,138,28,.10)" />
  </svg>
);

/* cross-section of the lower leg: 2 bones, 4 compartments, fascia, vessels */
const Section: React.FC<{press?: number; vs?: number}> = ({press = 0, vs = 1}) => {
  const ant = 1 + press * 0.22;
  return (
    <svg width={900} height={760} viewBox="0 0 900 760" style={{direction: 'ltr'}}>
      <ellipse cx={450} cy={380} rx={400} ry={330} fill="#f3cdb5" />
      <ellipse cx={450} cy={380} rx={372} ry={302} fill="none" stroke="#e8b99c" strokeWidth={10} />
      {/* superficial posterior (calf) */}
      <path d="M170 450 C190 610 330 690 450 692 C590 690 720 610 735 470 C650 500 560 505 470 500 C360 495 260 480 170 450Z" fill="#c9555a" stroke="#f7f2e8" strokeWidth={9} />
      {/* deep posterior */}
      <path d="M380 360 C420 380 520 400 610 410 C600 460 540 485 470 485 C410 480 360 450 350 410 Z" fill="#b8474d" stroke="#f7f2e8" strokeWidth={8} />
      {/* lateral */}
      <path d="M630 250 C710 270 760 330 745 440 C700 430 660 410 640 380 C630 340 620 290 630 250Z" fill="#cf6066" stroke="#f7f2e8" strokeWidth={9} />
      {/* anterior (swells) */}
      <g transform={`translate(${520} ${260}) scale(${ant}) translate(${-520} ${-260})`}>
        <path d="M430 175 C480 140 580 150 625 215 C640 270 630 330 610 380 C540 372 470 352 420 330 C440 280 430 220 430 175Z" fill={press > 0.3 ? `rgb(${201 + 40 * press},${85 + 90 * press},${90 + 80 * press})` : '#c9555a'} stroke="#f7f2e8" strokeWidth={9} />
      </g>
      {/* interosseous membrane */}
      <path d="M420 330 L630 395" stroke="#f7f2e8" strokeWidth={6} />
      {/* tibia (anteromedial) & fibula (lateral) */}
      <path d="M300 230 C300 170 360 140 410 160 C440 180 445 260 430 320 C400 350 340 340 315 300 C303 280 300 255 300 230Z" fill="#f4ecd8" stroke="#d6c8a6" strokeWidth={6} />
      <ellipse cx={660} cy={400} rx={34} ry={30} fill="#f4ecd8" stroke="#d6c8a6" strokeWidth={6} />
      {/* vessels + nerve in anterior compartment */}
      <circle cx={500} cy={330} r={13 * vs} fill="#c62828" />
      <circle cx={528} cy={334} r={11 * vs} fill="#3557b7" />
      <circle cx={514} cy={308} r={8} fill="#f2c94c" />
      {press > 0 && [0, 1, 2, 3, 4, 5].map((i) => {
        const a = (i / 6) * Math.PI * 2;
        const r = 150;
        return <path key={i} d={`M${525 + Math.cos(a) * r} ${265 + Math.sin(a) * r * 0.75} L${525 + Math.cos(a) * (r - 46)} ${265 + Math.sin(a) * (r - 46) * 0.75}`} stroke={AMB} strokeWidth={8} strokeLinecap="round" opacity={press} markerEnd="url(#ar)" />;
      })}
      <defs><marker id="ar" markerWidth="6" markerHeight="6" refX="3" refY="3" orient="auto"><path d="M0 0L6 3L0 6Z" fill={AMB} /></marker></defs>
    </svg>
  );
};
const Lbl: React.FC<{x: number; y: number; k: string; at: number; c?: string}> = ({x, y, k, at, c = INK}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: x, top: y, opacity: ease(f, at, at + 10), background: '#fff', borderRadius: 14, padding: '8px 16px', fontFamily: FONT, fontWeight: 700, fontSize: 30, color: c, boxShadow: '0 4px 14px rgba(0,0,0,.1)', direction: RTL ? 'rtl' : 'ltr'}}>{t(k)}</div>;
};

const S01: React.FC<{d: number}> = () => {
  const f = useCurrentFrame();
  return (<AbsoluteFill><Title k="s01" /><div style={{position: 'absolute', top: 420, left: 260}}><LegCast sw={0.5 + 0.5 * Math.sin(f / 9)} /></div></AbsoluteFill>);
};
const S02: React.FC<{d: number}> = () => (
  <AbsoluteFill><Title k="s02t" />
    <div style={{position: 'absolute', top: 470, left: 90}}><Section /></div>
    <Lbl x={400} y={1100} k="l_mus" at={10} /><Lbl x={790} y={540} k="l_fas" at={20} c={TEAL} /><Lbl x={140} y={560} k="l_bone" at={30} /><Lbl x={560} y={590} k="l_vn" at={40} c={RED} />
  </AbsoluteFill>
);
const S03: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const p = ease(f, 10, d * 0.6);
  return (<AbsoluteFill><Title k="s03" c={RED} />
    <div style={{position: 'absolute', top: 470, left: 90}}><Section press={p} vs={1 - 0.55 * p} /></div>
    <Lbl x={140} y={1240} k="l_less" at={Math.round(d * 0.5)} c={RED} /></AbsoluteFill>);
};
const S04: React.FC<{d: number}> = () => {
  const f = useCurrentFrame();
  const a = (f * 6) % 360;
  return (<AbsoluteFill style={{alignItems: 'center'}}><Title k="s04" />
    <svg width={420} height={420} viewBox="0 0 100 100" style={{position: 'absolute', top: 520, direction: 'ltr'}}><circle cx={50} cy={50} r={44} fill="#fff" stroke={RED} strokeWidth={4} /><path d={`M50 50 L${50 + 32 * Math.sin((a * Math.PI) / 180)} ${50 - 32 * Math.cos((a * Math.PI) / 180)}`} stroke={INK} strokeWidth={4} strokeLinecap="round" /><path d={`M50 50 L${50 + 22 * Math.sin((a * Math.PI) / 2160)} ${50 - 22 * Math.cos((a * Math.PI) / 2160)}`} stroke={INK} strokeWidth={5} strokeLinecap="round" /><circle cx={50} cy={50} r={3} fill={INK} /></svg>
    <div style={{position: 'absolute', top: 1000, left: 90, right: 90}}><Pill k="s04b" at={20} c={RED} bg="#fff1ef" size={44} /></div></AbsoluteFill>);
};
const S05: React.FC<{d: number}> = ({d}) => {
  const ks = ['c1', 'c2', 'c3', 'c4', 'c5'];
  const st = (d * 0.75) / 5;
  return (<AbsoluteFill><Title k="s05" c={RED} />
    <div style={{position: 'absolute', top: 300, left: 70, right: 70, display: 'flex', flexDirection: 'column', gap: 22}}>
      {ks.map((k, i) => <Pill key={k} k={k} at={Math.round(8 + i * st)} c={INK} bg="#fff" size={40} />)}
      <Pill k="c6" at={Math.round(d * 0.8)} c="#8a4a44" bg="#fff1ef" size={34} />
    </div></AbsoluteFill>);
};
const S06: React.FC<{d: number}> = () => {
  const f = useCurrentFrame();
  return (<AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', paddingBottom: 380}}>
    <div style={{width: 900, background: RED, color: '#fff', borderRadius: 40, padding: '56px 50px', fontFamily: FONT, fontWeight: 800, fontSize: 64, textAlign: 'center', opacity: ease(f, 0, 12), lineHeight: 1.15}}>{t('s06a')}</div>
    <div style={{marginTop: 60, opacity: ease(f, 14, 26), transform: `scale(${1 + 0.05 * Math.sin(f / 5)})`, display: 'flex', gap: 30, alignItems: 'center'}}>
      <div style={{fontFamily: FONT, fontWeight: 700, fontSize: 44, color: INK}}>{t('s06b')}</div>
      <div style={{background: '#fff', border: `6px solid ${RED}`, color: RED, borderRadius: 30, padding: '10px 40px', fontFamily: "'IN'", fontWeight: 800, fontSize: 110}}>101</div>
    </div></AbsoluteFill>);
};
const S07: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return (<AbsoluteFill><Title k="s07" c={RED} />
    <div style={{position: 'absolute', top: 470, left: 260}}><LegCast split={ease(f, d * 0.35, d * 0.7)} /></div>
    <svg width={260} height={260} viewBox="0 0 100 100" style={{position: 'absolute', top: 470, left: RTL ? 90 : 730, opacity: ease(f, 6, 16), direction: 'ltr'}}><circle cx={30} cy={70} r={12} fill="none" stroke={INK} strokeWidth={5} /><circle cx={70} cy={70} r={12} fill="none" stroke={INK} strokeWidth={5} /><path d="M38 62 L70 15 M62 62 L30 15" stroke={INK} strokeWidth={5} /><circle cx={50} cy={50} r={46} fill="none" stroke={RED} strokeWidth={7} /><path d="M18 18 L82 82" stroke={RED} strokeWidth={7} /></svg>
  </AbsoluteFill>);
};
/* lying person, leg on pillows; up = above heart, else at heart level */
const Lying: React.FC<{up: boolean}> = ({up}) => (
  <svg width={760} height={400} viewBox="0 60 460 250" style={{direction: 'ltr'}}>
    <rect x={10} y={210} width={440} height={40} rx={14} fill="#dfe8f0" />
    <ellipse cx={60} cy={176} rx={36} ry={34} fill="#e3ad8e" />
    <path d="M90 168 C140 150 210 150 250 165 L250 205 C210 212 140 212 92 200 Z" fill="#7fa7d9" />
    <circle cx={150} cy={178} r={9} fill={RED} />
    {up ? (<><rect x={290} y={150} width={150} height={60} rx={20} fill="#fff" stroke="#cfd9e3" strokeWidth={3} /><path d="M245 172 C300 160 360 120 420 112 L428 140 C370 150 310 190 250 205Z" fill="#f2f5f8" stroke="#c5cfdb" strokeWidth={3} /></>)
      : (<path d="M245 172 C300 172 370 174 430 176 L430 204 C370 206 300 206 250 205Z" fill="#f2f5f8" stroke="#c5cfdb" strokeWidth={3} />)}
    <path d="M40 140 L440 140" stroke={RED} strokeWidth={2} strokeDasharray="8 8" opacity={0.6} />
  </svg>
);
const S08: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const b = Math.round(d * 0.5);
  return (<AbsoluteFill>
    <div style={{position: 'absolute', top: 200, left: 70, right: 70, display: 'flex', flexDirection: 'column', gap: 50}}>
      <div style={{opacity: ease(f, 4, 16), background: '#fff', borderRadius: 32, padding: 30, boxShadow: '0 8px 24px rgba(20,35,58,.08)'}}><div style={{fontFamily: FONT, fontWeight: 800, fontSize: 44, color: TEAL, marginBottom: 10}}>{t('s08a')}</div><Lying up /></div>
      <div style={{opacity: ease(f, b, b + 14), background: '#fff1ef', borderRadius: 32, padding: 30}}><div style={{fontFamily: FONT, fontWeight: 800, fontSize: 44, color: RED, marginBottom: 10}}>{t('s08b')}</div><Lying up={false} /></div>
    </div></AbsoluteFill>);
};
const S09: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const c = ease(f, d * 0.2, d * 0.55);
  const r = 70 - 30 * c;
  return (<AbsoluteFill><Title k="s09" />
    <svg width={940} height={520} viewBox="0 0 940 520" style={{position: 'absolute', top: 520, left: 70, direction: 'ltr'}}>
      <rect x={0} y={0} width={940} height={520} rx={40} fill={`rgb(${255 - 30 * c},${244 - 4 * c},${238 + 12 * c})`} />
      <path d={`M40 ${260 - r} C300 ${260 - r} 640 ${260 - r} 900 ${260 - r} L900 ${260 + r} C640 ${260 + r} 300 ${260 + r} 40 ${260 + r}Z`} fill="#d9433b" />
      {[0, 1, 2, 3, 4, 5, 6].map((i) => <circle key={i} cx={((f * 6 + i * 130) % 860) + 40} cy={260 + ((i % 3) - 1) * r * 0.5} r={12} fill="#f7b3ae" />)}
      {[0, 1, 2].map((i) => <text key={i} x={700 + i * 70} y={90 + (i % 2) * 40} fontSize={60} fill={BLUE} opacity={c}>❄</text>)}
    </svg>
    <div style={{position: 'absolute', top: 1110, left: 70, right: 70}}><Pill k="s09b" at={Math.round(d * 0.6)} c={INK} bg="#eef4ff" size={38} /></div>
  </AbsoluteFill>);
};
const S10: React.FC<{d: number}> = ({d}) => {
  const ks = ['s10a', 's10b', 's10c'];
  return (<AbsoluteFill><div style={{position: 'absolute', top: 300, left: 70, right: 70, display: 'flex', flexDirection: 'column', gap: 30}}>
    {ks.map((k, i) => <Pill key={k} k={k} at={Math.round(8 + (i * d) / 4)} c={TEAL} bg="#fff" size={46} />)}</div></AbsoluteFill>);
};
const S11: React.FC<{d: number}> = () => {
  const f = useCurrentFrame();
  return (<AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', paddingBottom: 380}}><div style={{opacity: ease(f, 0, 14), width: 900, background: '#e6f3f0', borderRadius: 40, padding: '56px 50px', fontFamily: FONT, fontWeight: 700, fontSize: 46, color: INK, lineHeight: 1.35}}>{t('s11')}</div></AbsoluteFill>);
};

const Cap: React.FC<{text: string; d: number}> = ({text, d}) => {
  const f = useCurrentFrame();
  const o = interpolate(f, [4, 12, d - 8, d], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (<div style={{position: 'absolute', left: 60, right: 60, bottom: 300, opacity: o, display: 'flex', justifyContent: 'center'}}><div style={{background: 'rgba(20,35,58,.88)', color: '#fff', borderRadius: 26, padding: '20px 30px', fontFamily: FONT, fontWeight: 600, fontSize: 34, lineHeight: 1.35, textAlign: 'center', direction: RTL ? 'rtl' : 'ltr'}}>{text}</div></div>);
};
const MAP: Record<string, React.FC<{d: number}>> = {CS01: S01, CS02: S02, CS03: S03, CS04: S04, CS05: S05, CS06: S06, CS07: S07, CS08: S08, CS09: S09, CS10: S10, CS11: S11};
export const compTotal = () => (DATA[LANG] as any[]).reduce((a, s) => a + Math.round(s.dur * FPS), 0);
export const Comp: React.FC = () => {
  const f = useCurrentFrame();
  let from = 0;
  return (
    <AbsoluteFill style={{background: 'linear-gradient(180deg,#f3f7f9,#f7f5f0)', direction: RTL ? 'rtl' : 'ltr'}}>
      <style>{FF}</style>
      {(DATA[LANG] as any[]).map((s) => {
        const d = Math.round(s.dur * FPS);
        const C = MAP[s.id];
        const el = (<Sequence key={s.id} from={from} durationInFrames={d}>
          <AbsoluteFill style={{opacity: interpolate(f - from, [0, 8, d - 8, d], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})}}><C d={d} /></AbsoluteFill>
          {s.id !== 'CS11' && <Cap text={s.text} d={d} />}
          {s.audio && <Sequence from={6}><Audio src={staticFile(s.audio)} /></Sequence>}
        </Sequence>);
        from += d;
        return el;
      })}
    </AbsoluteFill>
  );
};
