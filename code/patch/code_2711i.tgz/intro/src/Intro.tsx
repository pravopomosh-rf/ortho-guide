import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig, getInputProps, Easing} from 'remotion';
// eslint-disable-next-line @typescript-eslint/no-var-requires
const DATA: any = require('./data.json');
const P: any = getInputProps() || {};
export const LANG: string = P.lang || 'ru';
const RTL = LANG === 'he' || LANG === 'ar';
const FPS = 30;
const TEAL = '#1f7a70', INK = '#14233a', MUTE = '#5b6b80', RED = '#c8372d', BG = '#f5f8fa', LINE = '#e2e8ee';
const FONT = LANG === 'he' ? "'NSH', sans-serif" : LANG === 'ar' ? "'NSA', sans-serif" : "'IN', sans-serif";
const FF = [600, 700, 800].map((w) => `@font-face{font-family:'IN';font-weight:${w};src:url(${staticFile(`fonts/inter-cyrillic-${w}-normal.woff2`)})}@font-face{font-family:'IN';font-weight:${w};src:url(${staticFile(`fonts/inter-latin-${w}-normal.woff2`)});unicode-range:U+0000-00FF,U+2000-206F}@font-face{font-family:'NSH';font-weight:${w};src:url(${staticFile(`fonts/noto-sans-hebrew-hebrew-${w}-normal.woff2`)})}@font-face{font-family:'NSA';font-weight:${w};src:url(${staticFile(`fonts/noto-sans-arabic-arabic-${w}-normal.woff2`)})}`).join('');

// screen texts — taken verbatim from the route pages (ops/*-path.html) and nav.js
const S: Record<string, any> = {
  ru: {steps: ['Подготовка к операции', 'Ваша операция', 'Первые дни после операции в отделении', 'Выписка и дома', 'Реабилитация (шикум)'], menu: 'Меню', bar: 'Поиск по сайту', vid: '▶ Видео', alarm: 'Тревожные признаки', alarmS: 'Когда звонить 101 или срочно обращаться за помощью', disc: 'Это общая информация. Индивидуальные указания лечащего врача имеют приоритет над рекомендациями на этой странице.', c1: 'Подготовка к операции', c2: 'Поступление в отделение'},
  he: {steps: ['הכנה לניתוח', 'הניתוח שלכם', 'הימים הראשונים אחרי הניתוח במחלקה', 'שחרור ובבית', 'שיקום'], menu: 'תפריט', bar: 'חיפוש באתר', vid: '▶ סרטון', alarm: 'סימני אזהרה', alarmS: 'מתי להתקשר ל־101 או לפנות לעזרה דחופה', disc: 'זהו מידע כללי. להנחיות האישיות של הרופא המטפל יש עדיפות על ההמלצות בדף זה.', c1: 'הכנה לניתוח', c2: 'קבלה למחלקה'},
  ar: {steps: ['التحضير للعملية', 'عمليتكم', 'الأيام الأولى بعد العملية في القسم', 'الخروج من المستشفى وفي البيت', 'إعادة التأهيل'], menu: 'القائمة', bar: 'البحث في الموقع', vid: '▶ فيديو', alarm: 'علامات الخطر', alarmS: 'متى تتصلون بـ 101 أو تطلبون مساعدة عاجلة', disc: 'هذه معلومات عامة. تعليمات الطبيب المعالج الخاصة بحالتكم لها الأولوية على التوصيات الواردة في هذه الصفحة.', c1: 'التحضير للعملية', c2: 'الدخول إلى القسم'},
  en: {steps: ['Getting ready for surgery', 'Your operation', 'The first days after surgery on the ward', 'Discharge and at home', 'Rehabilitation'], menu: 'Menu', bar: 'Search the site', vid: '▶ Video', alarm: 'Warning signs', alarmS: 'When to call an ambulance on 101 or seek urgent care', disc: "This is general information. Your treating doctor's individual instructions take priority over the recommendations on this page.", c1: 'Getting ready for surgery', c2: 'Admission to the ward'},
};
const T = S[LANG];
const ease = (f: number, a: number, b: number) => interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});

const Icon: React.FC<{k: number; c?: string}> = ({k, c = '#fff'}) => {
  const p = {fill: 'none', stroke: c, strokeWidth: 3.2, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const};
  return (
    <svg width={54} height={54} viewBox="0 0 48 48" style={{direction: 'ltr'}}>
      {k === 0 && <g {...p}><rect x="11" y="8" width="26" height="34" rx="4" /><path d="M18 8v-2h12v2M17 20h14M17 27h14M17 34h8" /></g>}
      {k === 1 && <g {...p}><path d="M10 36l18-18 6 6-18 18H10z" /><path d="M28 18l5-5 6 6-5 5" /></g>}
      {k === 2 && <g {...p}><path d="M6 34V14M6 26h36v8M42 34v-8" /><rect x="10" y="18" width="10" height="8" rx="3" /><path d="M22 26v-6h14a6 6 0 016 6" /></g>}
      {k === 3 && <g {...p}><path d="M8 22L24 9l16 13" /><path d="M13 19v20h22V19" /><path d="M21 39V28h6v11" /></g>}
      {k === 4 && <g {...p}><circle cx="26" cy="9" r="4" /><path d="M26 14l-4 12 7 5 2 11M22 26l-6 16M23 18l-7 6M27 18l8 6" /></g>}
    </svg>
  );
};

const Steps: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const line = ease(f, 6, Math.min(d * 0.8, 6 + 5 * 22));
  return (
    <AbsoluteFill style={{padding: '170px 90px 0'}}>
      <div style={{position: 'absolute', top: 260, bottom: 640, [RTL ? 'right' : 'left']: 138, width: 8, borderRadius: 4, background: LINE}} />
      <div style={{position: 'absolute', top: 260, [RTL ? 'right' : 'left']: 138, width: 8, height: `${line * 1020}px`, borderRadius: 4, background: TEAL}} />
      {T.steps.map((s: string, i: number) => {
        const a = 10 + i * 22;
        const o = ease(f, a, a + 14);
        const sc = spring({frame: f - a, fps: FPS, config: {damping: 12}});
        return (
          <div key={i} style={{position: 'absolute', top: 210 + i * 250, [RTL ? 'right' : 'left']: 90, [RTL ? 'left' : 'right']: 70, display: 'flex', alignItems: 'center', gap: 34, opacity: o, transform: `translateX(${(1 - o) * (RTL ? -60 : 60)}px)`}}>
            <div style={{width: 104, height: 104, flex: 'none', borderRadius: 52, background: TEAL, boxShadow: '0 10px 30px rgba(31,122,112,.35)', display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${0.6 + 0.4 * sc})`, position: 'relative'}}>
              <Icon k={i} />
              <div style={{position: 'absolute', top: -10, [RTL ? 'left' : 'right']: -10, width: 44, height: 44, borderRadius: 22, background: '#fff', color: TEAL, fontFamily: "'IN', sans-serif", fontWeight: 800, fontSize: 26, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 2px 8px rgba(0,0,0,.15)'}}>{i + 1}</div>
            </div>
            <div style={{background: '#fff', borderRadius: 26, padding: '26px 32px', boxShadow: '0 8px 26px rgba(20,35,58,.08)', fontFamily: FONT, fontWeight: 700, fontSize: 44, color: INK, lineHeight: 1.2, flex: 1}}>{s}</div>
          </div>
        );
      })}
    </AbsoluteFill>
  );
};

const Tap: React.FC<{x: number; y: number; at: number}> = ({x, y, at}) => {
  const f = useCurrentFrame();
  const k = f - at;
  if (k < 0 || k > 36) return null;
  const r = interpolate(k, [0, 30], [20, 90], {extrapolateRight: 'clamp'});
  const o = interpolate(k, [0, 8, 36], [0, 0.9, 0], {extrapolateRight: 'clamp'});
  return <div style={{position: 'absolute', left: x - r, top: y - r, width: 2 * r, height: 2 * r, borderRadius: r, border: `8px solid ${TEAL}`, opacity: o}} />;
};

const Phone: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const o = ease(f, 0, 16);
  const t1 = Math.round(d * 0.12), t2 = Math.round(d * 0.45), t3 = Math.round(d * 0.72);
  const hi = (a: number, b: number) => (f >= a && f < b ? 1 : 0);
  const langs = ['Русский', 'עברית', 'العربية', 'English'];
  const cur = ['ru', 'he', 'ar', 'en'].indexOf(LANG);
  return (
    <AbsoluteFill style={{alignItems: 'center', paddingTop: 150, opacity: o, transform: `translateY(${(1 - o) * 60}px)`}}>
      <div style={{width: 700, height: 1260, borderRadius: 80, background: '#14233a', padding: 22, boxShadow: '0 30px 80px rgba(20,35,58,.25)', position: 'relative'}}>
        <div style={{width: '100%', height: '100%', borderRadius: 60, background: '#fbf7f0', overflow: 'hidden', position: 'relative', direction: RTL ? 'rtl' : 'ltr'}}>
          <div style={{display: 'flex', gap: 16, padding: '60px 26px 20px', alignItems: 'center', background: '#fff', boxShadow: '0 2px 10px rgba(0,0,0,.06)'}}>
            <div style={{background: TEAL, color: '#fff', borderRadius: 18, padding: '16px 22px', fontFamily: FONT, fontWeight: 700, fontSize: 28, outline: hi(t3, d) ? '6px solid #ffb020' : 'none'}}>☰ {T.menu}</div>
            <div style={{flex: 1, border: `3px solid ${LINE}`, borderRadius: 30, padding: '14px 22px', fontFamily: FONT, fontSize: 26, color: MUTE, outline: hi(t3, d) ? '6px solid #ffb020' : 'none'}}>⌕ {T.bar}</div>
          </div>
          <div style={{background: TEAL, padding: '26px 26px 34px'}}>
            <div style={{display: 'flex', gap: 10, direction: 'ltr', justifyContent: 'center', outline: hi(t2, t3) ? '6px solid #ffb020' : 'none', borderRadius: 18, padding: 6}}>
              {langs.map((l, i) => <div key={l} style={{flex: 1, textAlign: 'center', borderRadius: 16, padding: '14px 0', fontFamily: i === 1 ? "'NSH'" : i === 2 ? "'NSA'" : "'IN'", fontWeight: 700, fontSize: 24, background: i === cur ? '#fff' : 'transparent', color: i === cur ? TEAL : '#fff', border: '2px solid rgba(255,255,255,.6)'}}>{l}</div>)}
            </div>
          </div>
          <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 22, padding: 26}}>
            {[T.c1, T.c2, T.steps[1], T.steps[3]].map((c: string, i: number) => (
              <div key={i} style={{background: '#fff', borderRadius: 26, overflow: 'hidden', boxShadow: '0 6px 18px rgba(20,35,58,.08)', transform: i === 0 && hi(t1, t2) ? 'scale(1.04)' : undefined, outline: i === 0 && hi(t1, t2) ? '6px solid #ffb020' : 'none'}}>
                <div style={{height: 170, background: i % 2 ? '#dfeeea' : '#e6eef6', display: 'flex', alignItems: 'center', justifyContent: 'center'}}><div style={{transform: 'scale(1.6)'}}><Icon k={[0, 2, 1, 3][i]} c={TEAL} /></div></div>
                <div style={{padding: '18px 20px 22px', fontFamily: FONT, fontWeight: 700, fontSize: 26, color: INK, lineHeight: 1.25, minHeight: 70}}>{c}</div>
                <div style={{margin: '0 20px 22px', display: 'inline-block', background: TEAL, color: '#fff', borderRadius: 14, padding: '8px 16px', fontFamily: FONT, fontWeight: 700, fontSize: 22}}>{T.vid}</div>
              </div>
            ))}
          </div>
        </div>
        <div style={{position: 'absolute', left: 0, top: 0, width: '100%', height: '100%', direction: 'ltr'}}>
          <Tap x={RTL ? 530 : 190} y={600} at={t1 + 6} />
          <Tap x={350} y={225} at={t2 + 6} />
          <Tap x={RTL ? 590 : 110} y={110} at={t3 + 6} />
          <Tap x={RTL ? 280 : 420} y={110} at={t3 + 26} />
        </div>
      </div>
    </AbsoluteFill>
  );
};

const Alarm: React.FC<{d: number}> = () => {
  const f = useCurrentFrame();
  const o = ease(f, 0, 14);
  const pulse = 1 + 0.06 * Math.sin(f / 5);
  return (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', paddingBottom: 380}}>
      <div style={{opacity: o, transform: `scale(${0.9 + 0.1 * o})`, width: 900, background: '#fff1ef', border: `4px solid #f3c3bd`, borderRadius: 40, padding: '56px 50px', display: 'flex', gap: 36, alignItems: 'center', boxShadow: '0 20px 50px rgba(200,55,45,.15)'}}>
        <svg width={130} height={130} viewBox="0 0 48 48" style={{flex: 'none'}}><path d="M24 5L45 42H3z" fill="none" stroke={RED} strokeWidth={3.5} strokeLinejoin="round" /><path d="M24 18v12" stroke={RED} strokeWidth={4} strokeLinecap="round" /><circle cx="24" cy="36" r="2.4" fill={RED} /></svg>
        <div style={{fontFamily: FONT}}>
          <div style={{fontWeight: 800, fontSize: 60, color: RED}}>{T.alarm}</div>
          <div style={{fontWeight: 600, fontSize: 36, color: MUTE, marginTop: 14, lineHeight: 1.3}}>{T.alarmS}</div>
        </div>
      </div>
      <div style={{marginTop: 80, opacity: ease(f, 14, 26), transform: `scale(${pulse})`, background: RED, color: '#fff', borderRadius: 40, padding: '24px 70px', fontFamily: "'IN', sans-serif", fontWeight: 800, fontSize: 150, letterSpacing: 4, boxShadow: '0 20px 50px rgba(200,55,45,.35)'}}>101</div>
    </AbsoluteFill>
  );
};

const Disc: React.FC<{d: number}> = () => {
  const f = useCurrentFrame();
  const o = ease(f, 0, 16);
  return (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', paddingBottom: 380}}>
      <div style={{opacity: o, transform: `translateY(${(1 - o) * 40}px)`, width: 900, background: '#e6f3f0', borderRadius: 40, padding: '60px 56px', display: 'flex', gap: 34, alignItems: 'flex-start'}}>
        <svg width={96} height={96} viewBox="0 0 48 48" style={{flex: 'none'}}><circle cx="24" cy="24" r="20" fill="none" stroke={TEAL} strokeWidth={3.5} /><path d="M24 21v13" stroke={TEAL} strokeWidth={4} strokeLinecap="round" /><circle cx="24" cy="14" r="2.6" fill={TEAL} /></svg>
        <div style={{fontFamily: FONT, fontWeight: 700, fontSize: 46, color: INK, lineHeight: 1.35}}>{T.disc}</div>
      </div>
    </AbsoluteFill>
  );
};

const Cap: React.FC<{text: string; d: number}> = ({text, d}) => {
  const f = useCurrentFrame();
  const o = interpolate(f, [4, 12, d - 8, d], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <div style={{position: 'absolute', left: 70, right: 70, bottom: 300, opacity: o, display: 'flex', justifyContent: 'center'}}>
      <div style={{background: 'rgba(20,35,58,.88)', color: '#fff', borderRadius: 28, padding: '24px 34px', fontFamily: FONT, fontWeight: 600, fontSize: 38, lineHeight: 1.35, textAlign: 'center', direction: RTL ? 'rtl' : 'ltr'}}>{text}</div>
    </div>
  );
};

const MAP: Record<string, React.FC<{d: number}>> = {IN01: Steps, IN02: Phone, IN03: Alarm, IN04: Disc};
export const total = () => (DATA[LANG] as any[]).reduce((a, s) => a + Math.round(s.dur * FPS), 0);

export const Intro: React.FC = () => {
  const f = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  let from = 0;
  return (
    <AbsoluteFill style={{background: `linear-gradient(180deg, #eef5f4 0%, ${BG} 55%, #f2f6fb 100%)`, direction: RTL ? 'rtl' : 'ltr'}}>
      <style>{FF}</style>
      <div style={{position: 'absolute', width: 900, height: 900, borderRadius: 450, background: 'radial-gradient(circle, rgba(31,122,112,.10), rgba(31,122,112,0) 70%)', left: -300 + 40 * Math.sin(f / 60), top: -250}} />
      <div style={{position: 'absolute', width: 800, height: 800, borderRadius: 400, background: 'radial-gradient(circle, rgba(60,110,200,.08), rgba(60,110,200,0) 70%)', right: -300, bottom: 200 + 40 * Math.cos(f / 70)}} />
      {(DATA[LANG] as any[]).map((s) => {
        const d = Math.round(s.dur * FPS);
        const C = MAP[s.id];
        const el = (
          <Sequence key={s.id} from={from} durationInFrames={d}>
            <AbsoluteFill style={{opacity: interpolate(f - from, [0, 8, d - 8, d], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})}}><C d={d} /></AbsoluteFill>
            {s.id !== "IN04" && <Cap text={s.text} d={d} />}
            <Sequence from={6}><Audio src={staticFile(s.audio)} /></Sequence>
          </Sequence>
        );
        from += d;
        return el;
      })}
      <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 10, background: LINE}}><div style={{height: 10, width: `${(100 * f) / durationInFrames}%`, background: TEAL}} /></div>
    </AbsoluteFill>
  );
};
