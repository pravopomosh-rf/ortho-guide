import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition, openBrowser} from '@remotion/renderer';
import fs from 'fs';
const serveUrl = await bundle({entryPoint: 'src/index.ts'});
const browser = await openBrowser('chrome', {browserExecutable: '/opt/pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell'});
const L = process.argv[2] || 'ru'; const inputProps = {lang: L};
const c = await selectComposition({serveUrl, id: 'Comp', inputProps, puppeteerInstance: browser});
const D = JSON.parse(fs.readFileSync('src/comp_data.json','utf8'))[L]; let s = 0; fs.mkdirSync('cpv',{recursive:true});
for (const x of D) { const d = Math.round(x.dur*30); await renderStill({composition: c, serveUrl, inputProps, frame: s + Math.round(d*0.85), output: `cpv/${L}_${x.id}.jpg`, imageFormat: 'jpeg', scale: 0.4, puppeteerInstance: browser, overwrite: true}); s += d; }
await browser.close({silent: true}); console.log('ok');
