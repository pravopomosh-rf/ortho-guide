import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition, openBrowser} from '@remotion/renderer';
const serveUrl = await bundle({entryPoint: 'src/index.ts'});
const exe = '/opt/pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell';
const browser = await openBrowser('chrome', {browserExecutable: exe});
for (const L of ['ru','he','ar','en']) {
  const inputProps = {lang: L};
  const c = await selectComposition({serveUrl, id: 'Intro', inputProps, puppeteerInstance: browser});
  const n = c.durationInFrames; const D = JSON.parse((await import('fs')).readFileSync('src/data.json','utf8'))[L];
  let s = 0; const fr = [];
  for (const x of D) { const d = Math.round(x.dur*30); fr.push(s + Math.round(d*0.75)); s += d; }
  for (const f of fr) await renderStill({composition: c, serveUrl, inputProps, frame: f, output: `pv/${L}_${f}.jpg`, imageFormat: 'jpeg', scale: 0.4, puppeteerInstance: browser, overwrite: true});
}
await browser.close({silent: true}); console.log('ok');
