# putintro.py LANG VER — видео-введение в шаг «Введение» всех 6 *-path страниц
import sys,glob,re
L,V=sys.argv[1:3]; R='/home/claude/ortho-guide/'
n=0
for p in sorted(glob.glob(R+'ops/*-path.html')):
    s=open(p,encoding='utf8').read()
    if f'video/intro_{L}.mp4' in s: continue
    m=re.search(r'(<li class="pstep pintro" id="step0_%s">.*?<h2>[^<]*</h2>)'%L,s,re.S)
    if not m: print('NO',p,L); continue
    v=f'<video class="vid v9" width="1080" height="1920" style="aspect-ratio:1080/1920;max-width:360px;width:100%;border-radius:16px;margin:6px 0 10px" controls preload="none" playsinline poster="../video/c/intro_{L}.jpg?v={V}" src="../video/intro_{L}.mp4?v={V}"></video>'
    s=s[:m.end()]+v+s[m.end():]; open(p,'w',encoding='utf8').write(s); n+=1
print(L,n)
