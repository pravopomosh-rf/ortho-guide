L=$1; T=$2
cd /home/claude/ortho-guide && git fetch -q origin main && git checkout -q -B work origin/main
python3 /home/claude/tools/pubitem.py ops/achilles-repair.html achil $L "$T" 2711a | tail -1
cd /home/claude/cgen && ONLY=achil python3 build.py >/dev/null && python3 -c "
import json;D=json.load(open('data.json'));D=[o for o in D if o['l']=='$L'];json.dump(D,open('data.json','w'),ensure_ascii=False)" && NODE_PATH=$(npm root -g) node render.js achil && NODE_PATH=$(npm root -g) node render43.js achil && ffmpeg -v error -y -i out/achil_$L.png -vf scale=720:1280 -q:v 3 /home/claude/ortho-guide/video/c/achil_$L.jpg && ffmpeg -v error -y -i t/achil_$L.png -vf scale=800:600 -q:v 4 /home/claude/ortho-guide/video/t/achil_$L.jpg
cd /home/claude/ortho-guide && python3 tools/chipfix.py --apply | tail -1
git add ops/achilles-repair.html video/achil_$L.mp4 video/c/achil_$L.jpg video/t/achil_$L.jpg $(git diff --name-only) && git -c user.name="Claude" -c user.email="noreply@anthropic.com" commit -q -m "Шов ахиллова сухожилия ($L): ролик опубликован, заглушка снята

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01VMoaxAAFxHGkJG2aizoC6T" && git push -q origin HEAD:refs/heads/main && git log --oneline -1
