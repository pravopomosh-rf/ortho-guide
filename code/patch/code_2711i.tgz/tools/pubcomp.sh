L=$1; T=$2
cd /home/claude/intro/out && python3 /home/claude/tools/vcheck.py comp_$L.mp4 2>&1 | tail -1; bash /home/claude/tools/finish.sh comp_$L.mp4 comp $L >/dev/null
cd /home/claude/ortho-guide && git fetch -q origin main && git checkout -q -B work origin/main
cp /home/claude/out/comp_$L.mp4 video/ && python3 /home/claude/tools/putvfirst.py ops/compartment.html comp "Гипс и отёк: компартмент-синдром|גבס ונפיחות: תסמונת מדור|الجبس والتورّم: متلازمة الحيّز|Cast and swelling: compartment syndrome" $L
cd /home/claude/cgen && ONLY=comp python3 build.py >/dev/null && python3 -c "
import json;D=json.load(open('data.json'));D=[o for o in D if o['l']=='$L'];json.dump(D,open('data.json','w'),ensure_ascii=False)" && NODE_PATH=$(npm root -g) node render.js comp && NODE_PATH=$(npm root -g) node render43.js comp && ffmpeg -v error -y -i out/comp_$L.png -vf scale=720:1280 -q:v 3 /home/claude/ortho-guide/video/c/comp_$L.jpg && ffmpeg -v error -y -i t/comp_$L.png -vf scale=800:600 -q:v 4 /home/claude/ortho-guide/video/t/comp_$L.jpg
cd /home/claude/ortho-guide && python3 /home/claude/tools/compcard.py $L && python3 tools/mknav.py >/dev/null
git add index.html nav-*.js ops/compartment.html video/comp_$L.mp4 video/c/comp_$L.jpg video/t/comp_$L.jpg && git -c user.name="Claude" -c user.email="noreply@anthropic.com" commit -q -m "Компартмент-синдром ($L): ролик опубликован, карточка на главной

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01VMoaxAAFxHGkJG2aizoC6T" && git push -q origin HEAD:refs/heads/main && git log --oneline -1
