import sys,re
L=sys.argv[1]; T={'ru':'Гипс и отёк: компартмент-синдром','he':'גבס ונפיחות: תסמונת מדור','ar':'الجبس والتورّم: متلازمة الحيّز','en':'Cast and swelling: compartment syndrome'}
V={'ru':'▶ Видео','he':'▶ סרטון','ar':'▶ فيديو','en':'▶ Video'}
p='/home/claude/ortho-guide/index.html'; s=open(p).read()
if f'ops/compartment.html#lang={L}' in s: print('exists'); sys.exit()
m=re.search(r'(<a class="pc vd" href="ops/swelling.html#lang=%s">.*?</a>)'%L,s)
card=f'<a class="pc vd" href="ops/compartment.html#lang={L}"><span class="th"><img loading="lazy" decoding="async" src="video/t/comp_{L}.jpg" width="800" height="600" alt=""></span><span class="pt">{T[L]}</span><span class="chip v">{V[L]}</span></a>'
s=s[:m.end()]+card+s[m.end():]; open(p,'w').write(s); print('ok',L)
