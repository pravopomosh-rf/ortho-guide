# putant.py LANG VER — ролик thr_anterior_L первым в vids_L ops/thr-anterior.html (+главы), снять заглушку video_L
import sys,re,shutil,json
L,V=sys.argv[1:3]
CH={'he':['מה זה שחיקת מפרקים','מה זו גישה ואילו גישות יש','גישה קדמית: למה לצפות','החלמה: מה הראו המחקרים','חוסר תחושה בעור','הגבלות אחרי הניתוח','מתי לפנות לרופא ומתי להזמין אמבולנס (101)'],
 'ar':['ما هو الفُصال العظمي','ما هو المدخل الجراحي وما أنواعه','المدخل الأمامي: ماذا تتوقعون','التعافي: ماذا أظهرت الدراسات','خدر الجلد','القيود بعد العملية','متى تتواصلون مع الطبيب ومتى تطلبون الإسعاف (101)'],
 'en':['What is osteoarthritis','What an approach is and which ones exist','Anterior approach: what to expect','Recovery: what studies showed','Skin numbness','Restrictions after surgery','When to contact your doctor and when to call an ambulance (101)']}
T=json.load(open(f'/home/claude/ant/src/timing_{L}.json'));s=0;o={}
for x in T: o[x['id']]=int(s); s+=round(x['dur']*30)/30
ts=[o[k] for k in ['s2','a1','a5c','s5','s6','s7','w0']]
TT={'he':'החלפת מפרק הירך בגישה קדמית: החלמה','ar':'استبدال مفصل الورك عبر المدخل الأمامي: التعافي','en':'Hip replacement through the anterior approach: recovery'}
CHH={'he':'פרקי הסרטון','ar':'أقسام الفيديو','en':'Video chapters'}
R='/home/claude/ortho-guide/';p=R+'ops/thr-anterior.html';s=open(p,encoding='utf8').read()
shutil.copy(f'/home/claude/out/thr_anterior_{L}.mp4',R+f'video/thr_anterior_{L}.mp4')
s,n=re.subn(r'<section id="video_%s" class="vtop vdev">.*?</section>'%L,'',s,count=1,flags=re.S);assert n==1
assert f'thr_anterior_{L}.mp4' not in s
ol=''.join(f'<li><a href="#" onclick="return seek(\'{L}\',{t})">{c}</a></li>' for t,c in zip(ts,CH[L]))
it=(f'<div class="vitem"><div class="vlabel"><span class="vplay" aria-hidden="true"></span><span>{TT[L]}</span></div><video class="vid v9" width="1080" height="1920" style="aspect-ratio:1080/1920" id="v_{L}" controls preload="none" playsinline poster="../video/c/thr_anterior_{L}.jpg?v={V}" src="../video/thr_anterior_{L}.mp4?v={V}"></video>'
    f'<h2 style="font-size:16px;margin-top:12px">{CHH[L]}</h2><ol>{ol}</ol></div>')
m=re.search(r'(<section class="vfirst" id="vids_%s"><h2>[^<]*</h2>)'%L,s);assert m
s=s[:m.end()]+it+s[m.end():]
open(p,'w',encoding='utf8').write(s);print('ok',L,ts)
