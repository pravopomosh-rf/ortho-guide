import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition, openBrowser} from '@remotion/renderer';
import fs from 'fs';
const T = JSON.parse(fs.readFileSync('src/'+(process.env.TF||'timing.json'), 'utf8'));
const NATIVE = new Set(['a2a','a3a','a4h','a4a','a4b','a4c','a5a','a5b','s5','s7','w0','w4','w7','s9']);
const serveUrl = await bundle({entryPoint: 'src/index.ts'});
const exe = '/opt/pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell';
const browser = await openBrowser('chrome', {browserExecutable: exe});
fs.mkdirSync(process.env.PD, {recursive: true});
for (const s of T) {
  if (NATIVE.has(s.id)) continue;
  const n = Math.round(s.dur * 30);
  for (const part of ['text', 'vis', 'foot']) {
    const inputProps = {id: s.id, part, lang: process.env.LG};
    const composition = await selectComposition({serveUrl, id: 'Probe', inputProps, puppeteerInstance: browser});
    for (let fr = 0; fr < n; fr += 12) {
      await renderStill({composition, serveUrl, inputProps, frame: fr, output: `${process.env.PD}/${s.id}_${part}_${fr}.png`, imageFormat: 'png', puppeteerInstance: browser, overwrite: true});
    }
  }
  console.log(s.id);
}
await browser.close({silent: true}); console.log('ok');
