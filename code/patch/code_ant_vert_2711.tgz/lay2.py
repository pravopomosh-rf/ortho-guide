import sys; LG=sys.argv[1]
import json,glob,re
from PIL import Image
import numpy as np
T=json.load(open('src/timing_'+LG+'.json'))
NAT={'s2','a2a','a3a','a4h','a4a','a4b','a4c','a5a','a5b','s5','s7','w0','w4','w7','s9'}
def bbox(id,part):
    B=None
    for f in glob.glob(f'probe_{LG}/{id}_{part}_*.png'):
        a=np.array(Image.open(f))[:,:,3]
        ys,xs=np.where(a>10)
        if len(xs)==0: continue
        b=[xs.min(),ys.min(),xs.max()+1,ys.max()+1]
        B=b if B is None else [min(B[0],b[0]),min(B[1],b[1]),max(B[2],b[2]),max(B[3],b[3])]
    if B is None: return None
    p=10
    B=[max(0,B[0]-p),max(0,B[1]-p),min(1280,B[2]+p),min(720,B[3]+p)]
    return [int(B[0]),int(B[1]),int(B[2]-B[0]),int(B[3]-B[1])]
L={}
for s in T:
    i=s['id']
    if i in NAT: continue
    t=bbox(i,'text'); v=bbox(i,'vis'); f=bbox(i,'foot')
    # include tag at left: keep text starting from x>=0
    ts=min(1000/t[2],1.7); vs=min(1040/v[2],1.75)
    fs=None; fh=0
    if f:
        fs=min(1000/f[2],1.5); fh=f[3]*fs
    gap=40; top=50; bot=30
    avail=1920-top-bot-fh-(30 if f else 0)
    tot=t[3]*ts+gap+v[3]*vs
    if tot>avail:
        k=(avail-gap)/(t[3]*ts+v[3]*vs); ts*=k; vs*=k; tot=avail
    y0=top+(avail-tot)/2
    d=dict(t=t,ts=round(ts,4),tx=round(40 if LG not in ('he','ar') else 1080-40-t[2]*ts),ty=round(y0),v=v,vs=round(vs,4),vx=round((1080-v[2]*vs)/2),vy=round(y0+t[3]*ts+gap))
    if f: d.update(f=f,fs=round(fs,4),fx=round((1080-f[2]*fs)/2),fy=round(1920-bot-f[3]*fs))
    L[i]=d
    print(i,'t',t,round(ts,2),'v',v,round(vs,2),'f',f)
json.dump(L,open('src/vlayout_'+LG+'.json','w'),indent=0)
