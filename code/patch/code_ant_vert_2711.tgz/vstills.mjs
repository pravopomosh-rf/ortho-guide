import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition, openBrowser} from '@remotion/renderer';
import fs from 'fs';
const pv = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const outDir = process.argv[3]; fs.mkdirSync(outDir, {recursive: true});
const serveUrl = await bundle({entryPoint: 'src/index.ts'});
const exe = '/opt/pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell';
const browser = await openBrowser('chrome', {browserExecutable: exe});
const composition = await selectComposition({serveUrl, id: 'FilmV', inputProps: {lang: process.env.LG}, puppeteerInstance: browser});
for (const [id, fr] of pv) {
  try { await renderStill({composition, serveUrl, inputProps: {lang: process.env.LG}, frame: fr, output: `${outDir}/${String(fr).padStart(5,'0')}_${id}.png`, imageFormat: 'jpeg', jpegQuality: 80, scale: 0.4, puppeteerInstance: browser, overwrite: true}); }
  catch (e) { console.log('ERR', id, fr, String(e).slice(0, 120)); }
}
await browser.close({silent: true}); console.log('ok');
