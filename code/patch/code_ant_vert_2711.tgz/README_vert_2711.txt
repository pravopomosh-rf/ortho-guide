ant ВЕРТИКАЛЬ по языкам (27.11): Film.tsx = вертикальный FilmV (из D:\...\06_laminectomy\ant_vert_1411.tgz) + i18n (tx/accFor/RTL/шрифты).
Порядок на язык L: timing_L.json = длительность opus + 0.6 с (w0,w1,w2 +0.35), голос aud/voice_L.wav (adelay 0.2/0.1, apad, atrim, concat)
→ python3 mkjobs.py full timing_L.json → CD=clips_L node render3d_cd.mjs jobs/full.json x (свои клипы на язык; перед рендером переложить в public/clips)
→ TF=timing_L.json PD=probe_L LG=L node probe.mjs → python3 lay2.py L (src/vlayout_L.json; RTL текст справа)
→ npx remotion render src/index.ts FilmV out/fv_L.mp4 --muted --props='{"lang":"L"}' --concurrency=2 --crf=16
→ ffmpeg + voice → finish.sh → vcheck → putant.py L VER (tools; главы по timing) → обложка: ill кадр t≈9 c (s1), crop=1080:788:0:950.
Горизонтальный Film (1280x720) не публиковать — на сайте все ролики 9:16.
