import json
T='/home/claude/ttsrepo/turn.json'; S='/home/claude/night/lam/r/src'
tx=json.load(open(T))
H={
'ru':(['Сын спрашивает медсестру','Смена положения уменьшает давление','Положение с наклоном на бок','Не тяните человека по простыне','Сидя в кресле','Движение — одна из главных мер','Ночью — кнопка вызова','Белок необходим','Ест мало — сообщите персоналу','Семья очень помогает','Указания врача важнее'],
      [['Сын'],['положения'],['наклоном'],['Не тяните'],['кресле'],['Движение'],['кнопка вызова'],['Белок'],['сообщите'],['Семья'],['важнее']],'ПРОЛЕЖНИ'),
'en':(['His son asks the nurse','Changing position reduces pressure','Lying tilted onto the side','Do not drag them across the sheet','When sitting','Movement is one of the main ways','At night: the call button','Protein is essential','Eating little? Tell the staff','The family helps a lot','Your care team\'s instructions take priority'],
      [['son'],['Changing position'],['tilted'],['Do not drag'],['sitting'],['Movement'],['call button'],['Protein'],['Tell the staff'],['family'],['priority']],'PRESSURE ULCERS'),
'he':(['הבן שלו שואל את האחות','שינוי תנוחה מפחית את הלחץ','שכיבה בהטיה קלה לצד','אל תגררו אותו על הסדין','בישיבה','תנועה היא אחד האמצעים החשובים','בלילה — כפתור הקריאה','חלבון חיוני','אוכל מעט — ספרו לצוות','המשפחה עוזרת מאוד','הנחיות הרופא המטפל קודמות'],
      [['הבן'],['שינוי תנוחה'],['בהטיה'],['אל תגררו'],['בישיבה'],['תנועה'],['כפתור הקריאה'],['חלבון'],['ספרו לצוות'],['המשפחה'],['קודמות']],'פצעי לחץ'),
'ar':(['يسأل ابنه الممرضة','تغيير الوضعية يخفّف الضغط','الاستلقاء مع ميل خفيف على الجنب','لا تسحبوه على الشرشف','عند الجلوس','الحركة من أهم وسائل الوقاية','في الليل: زر الاستدعاء','البروتين ضروري','يأكل قليلًا — أخبروا الطاقم','العائلة تساعد كثيرًا','تعليمات الطبيب المعالج لها الأولوية'],
      [['ابنه'],['تغيير الوضعية'],['ميل'],['لا تسحبوه'],['الجلوس'],['الحركة'],['زر الاستدعاء'],['البروتين'],['أخبروا الطاقم'],['العائلة'],['الأولوية']],'قرح الفراش'),
}
for L,(heads,accs,lab) in H.items():
    tm=[]
    for i in range(11):
        id=f'T{i+1:02d}'
        assert all(a in heads[i] for a in accs[i]),(L,i)
        tm.append({'id':id,'dur':10,'text':tx[f'{L}_{id}'],'head':heads[i],'acc':accs[i],'label':lab})
    json.dump(tm,open(f'{S}/timing_turn'+('' if L=='ru' else '_'+L)+'.json','w'),ensure_ascii=False)
print('ok')
