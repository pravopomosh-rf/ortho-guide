// «Пролежни: чем может помочь семья» — второй ролик на ops/pressure-sores.html (9:16). Озвучка T01–T11 ОДОБРЕНО ChatGPT (tts-data turn.json).
// Надписи на экране — дословные фрагменты одобренного текста того же языка; подписи тела и наклона — из Press_<lang>.
import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Subtitle, Note, C, BODY, HEAD, ease, Word} from './kit';
import {Icon} from './Figures';
import {WardBed} from './DelirArt';
import {BedReal} from './WardArt';
import {Clip3D} from './Clip3D';
import {PressureBody, SheetDrag, FoodGrid} from './TurnArt';
import tRu from './timing_turn.json';
import tHe from './timing_turn_he.json';
import tAr from './timing_turn_ar.json';
import tEn from './timing_turn_en.json';

type TT = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const FPS = 30, PAD = 0.5;
const fr = (d: number, p: number) => Math.round(d * p);
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};

type Dict = {brand: string; rtl?: boolean; body: string[]; tilt: string[]; food: string[]; n: Record<string, string[]>; end: [string, string]};
const N: Record<string, Dict> = {
  ru: {
    brand: 'ОРТОПЕДИЯ · ПАЦИЕНТАМ',
    body: ['затылок', 'лопатки', 'локти', 'крестец', 'бёдра', 'пятки'],
    tilt: ['на спине', 'наклон ~30° вправо', 'наклон ~30° влево'],
    food: ['яйца', 'молочные продукты', 'рыба', 'мясо', 'курица', 'бобовые'],
    n: {
      T01: ['два дня назад — операция на бедре', 'почти весь день лежит на спине', 'Чем я могу помочь?'],
      T02: ['давление сдавливает кожу и ткани', 'нарушает кровоснабжение', 'иногда — за несколько часов'],
      T03: ['примерно на тридцать градусов', 'с поддержкой подушками', 'разгрузить крестец', 'Как часто и на какой бок поворачивать — скажет медсестра', 'Помогайте только так, как показал персонал'],
      T04: ['трение и сдвиг повреждают кожу', 'специальные скользящие простыни', 'Не пытайтесь самостоятельно поднимать или перетаскивать человека, если вас этому не обучили', 'Простыня должна быть ровной, без складок и крошек'],
      T05: ['давление — на ягодицы и крестец', 'Сколько сидеть — согласуйте с медсестрой', 'переносить вес с одной ягодицы на другую', 'специальная подушка, перераспределяющая давление', 'Стопы — на полу или на подставке'],
      T06: ['если врач и физиотерапевт разрешили', 'садиться в кресло и ходить — столько, сколько разрешено'],
      T07: ['нажмите кнопку вызова и попросите помощи', 'вставайте, только если это разрешила медицинская команда', 'туалет не заменяет смену положения по графику'],
      T08: ['Пейте достаточно, если врач не ограничил жидкость'],
      T09: ['ест мало · потерял аппетит · похудел', 'Диетолог оценит питание', 'белковые напитки — при необходимости', 'заболевания почек — белок индивидуально'],
      T10: ['напоминайте менять позу', 'помогайте есть', 'приносите разрешённую еду', 'стойкое покраснение · потемнение кожи · болезненный или горячий участок · ранка → сразу медсестре'],
      T11: [],
    },
    end: ['Указания врача важнее', 'Лечащий врач · персонал отделения'],
  },
  en: {
    brand: 'ORTHOPAEDICS · FOR PATIENTS',
    body: ['back of head', 'shoulder blades', 'elbows', 'base of spine', 'hips', 'heels'],
    tilt: ['on the back', 'tilt ~30° right', 'tilt ~30° left'],
    food: ['eggs', 'dairy', 'fish', 'meat', 'chicken', 'pulses'],
    n: {
      T01: ['hip surgery two days ago', 'lies on his back almost all day', 'How can I help?'],
      T02: ['pressure squeezes the skin and tissue', 'disrupts the blood supply', 'sometimes within just a few hours'],
      T03: ['about thirty degrees', 'supported with pillows', 'take pressure off the base of the spine', 'How often and onto which side to turn: the nurse will tell you', 'Help only in the way the staff have shown you'],
      T04: ['friction and shear damage the skin', 'special slide sheets', 'Do not try to lift or drag the person yourself unless you have been trained', 'The sheet should be smooth, without creases or crumbs'],
      T05: ['pressure on the buttocks and the base of the spine', 'Agree with the nurse how long to sit', 'shift weight from one buttock to the other', 'a special pressure-redistributing cushion', 'Feet on the floor or on a footrest'],
      T06: ['if the doctor and physiotherapist allow it', 'sitting in a chair and walking: as much as allowed'],
      T07: ['press the call button and ask for help', 'get up only if the medical team has allowed it', 'the toilet does not replace changing position on schedule'],
      T08: ['Drink enough, unless the doctor has limited fluids'],
      T09: ['eats little · lost appetite · lost weight', 'The dietitian will assess their nutrition', 'protein drinks, if needed', 'kidney disease: protein set individually'],
      T10: ['remind them to change position', 'help them eat', 'bring food that is allowed', 'redness that does not go away · unusual darkening · a painful or hot area · a sore → tell the nurse straight away'],
      T11: [],
    },
    end: ["Your care team's instructions take priority", 'Treating doctor · ward staff'],
  },
  he: {
    brand: 'אורתופדיה · למטופלים', rtl: true,
    body: ['עורף', 'שכמות', 'מרפקים', 'עצם העצה', 'ירכיים', 'עקבים'],
    tilt: ['על הגב', 'הטיה של כ־30° ימינה', 'הטיה של כ־30° שמאלה'],
    food: ['ביצים', 'מוצרי חלב', 'דגים', 'בשר', 'עוף', 'קטניות'],
    n: {
      T01: ['לפני יומיים — ניתוח בירך', 'שוכב על הגב כמעט כל היום', 'איך אני יכול לעזור'],
      T02: ['הלחץ מועך את העור ואת הרקמות', 'פוגע באספקת הדם', 'לפעמים תוך כמה שעות בלבד'],
      T03: ['בערך שלושים מעלות', 'עם תמיכה של כריות', 'להוריד את הלחץ מעצם העצה', 'כל כמה זמן ולאיזה צד להסתובב — האחות תגיד', 'עזרו רק כמו שהצוות הראה לכם'],
      T04: ['חיכוך וגזירה פוגעים בעור', 'סדיני החלקה מיוחדים', 'אל תנסו להרים או לגרור את האדם לבד אם לא לימדו אתכם', 'הסדין צריך להיות ישר, בלי קפלים ובלי פירורים'],
      T05: ['הלחץ נופל על הישבן ועל עצם העצה', 'כמה זמן לשבת — תאמו עם האחות', 'להעביר משקל מצד אחד של הישבן לצד השני', 'כרית מיוחדת שמפזרת את הלחץ', 'כפות הרגליים על הרצפה או על הדום'],
      T06: ['אם הרופא והפיזיותרפיסט הרשו', 'לשבת בכיסא וללכת ככל שמותר'],
      T07: ['לחצו על כפתור הקריאה ובקשו עזרה', 'קמים רק אם הצוות הרפואי הרשה', 'הליכה לשירותים לא מחליפה שינוי תנוחה לפי הלוח'],
      T08: ['שתו מספיק, אם הרופא לא הגביל את השתייה'],
      T09: ['אוכל מעט · איבד תיאבון · ירד במשקל', 'הדיאטנית תעריך את התזונה', 'משקאות חלבון — במידת הצורך', 'מחלות כליות — כמות החלבון באופן אישי'],
      T10: ['הזכירו לשנות תנוחה', 'עזרו לאכול', 'הביאו אוכל שמותר', 'אדמומיות שלא עוברת · התכהות חריגה של העור · אזור כואב או חם · פצע ← ספרו מיד לאחות'],
      T11: [],
    },
    end: ['הנחיות הרופא המטפל קודמות', 'הרופא המטפל · הצוות במחלקה'],
  },
  ar: {
    brand: 'جراحة العظام · للمرضى', rtl: true,
    body: ['مؤخرة الرأس', 'لوحا الكتف', 'المرفقان', 'العجز', 'الوركان', 'الكعبان'],
    tilt: ['على الظهر', 'ميل نحو 30° لليمين', 'ميل نحو 30° لليسار'],
    food: ['البيض', 'منتجات الحليب', 'السمك', 'اللحم', 'الدجاج', 'البقوليات'],
    n: {
      T01: ['قبل يومين — عملية في الورك', 'يستلقي على ظهره طوال اليوم تقريبًا', 'كيف يمكنني أن أساعد'],
      T02: ['يضغط الثقل على الجلد والأنسجة', 'يضعف وصول الدم', 'أحيانًا خلال ساعات قليلة فقط'],
      T03: ['بزاوية ثلاثين درجة تقريبًا', 'مع دعم بالوسائد', 'تخفيف الضغط عن العجز', 'كل كم من الوقت وإلى أي جانب — ستخبركم الممرضة', 'ساعدوا فقط بالطريقة التي أراكم إياها الطاقم'],
      T04: ['الاحتكاك والانزلاق يضرّان الجلد', 'شراشف انزلاق خاصة', 'لا تحاولوا رفع الشخص أو سحبه بأنفسكم إن لم تتدرّبوا على ذلك', 'يجب أن يكون الشرشف مستويًا، دون طيّات أو فتات'],
      T05: ['الضغط على الأرداف والعجز', 'مدّة الجلوس — اتفقوا مع الممرضة', 'نقل الوزن من ردف إلى الآخر', 'وسادة خاصة توزّع الضغط', 'القدمان على الأرض أو على مسند'],
      T06: ['إذا سمح الطبيب وأخصائي العلاج الطبيعي', 'الجلوس في الكرسي والمشي قدر ما هو مسموح'],
      T07: ['اضغطوا زر الاستدعاء واطلبوا المساعدة', 'لا تنهضوا إلا إذا سمح الفريق الطبي', 'الذهاب إلى المرحاض لا يغني عن تغيير الوضعية حسب الجدول'],
      T08: ['اشربوا ما يكفي ما لم يفرض الطبيب قيودًا على كمية السوائل'],
      T09: ['يأكل قليلًا · فقد شهيته · نقص وزنه', 'سيقيّم أخصائي التغذية الوضع الغذائي', 'مشروبات البروتين — عند الحاجة', 'أمراض الكلى — كمية البروتين لكل شخص'],
      T10: ['ذكّروا بتغيير الوضعية', 'ساعدوا في الأكل', 'أحضروا طعامًا مسموحًا', 'احمرار لا يزول · اسمرار غير معتاد · منطقة مؤلمة أو ساخنة · جرح ← أخبروا الممرضة فورًا'],
      T11: [],
    },
    end: ['تعليمات الطبيب المعالج لها الأولوية', 'الطبيب المعالج · طاقم القسم'],
  },
};

const NV = '#E3E7EF';
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]; size?: number}> = ({y, items, size = 30}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10), transform: `translateY(${(1 - ease(f, a, a + 10)) * 14}px)`}}><Note size={size} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const Row: React.FC<{y: number; at: number; icon: string; text: string; warn?: boolean; size?: number}> = ({y, at, icon, text, warn, size = 31}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at} style={warn ? {borderInlineStart: `10px solid ${C.blood}`} : undefined}>
    <div style={{display: 'flex', alignItems: 'center', gap: 24}}>
      <Icon k={icon} s={58} c={warn ? C.blood : C.acc} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: size, color: warn ? C.blood : C.ink, lineHeight: 1.25}}>{text}</div>
      {!warn && <div style={{opacity: ease(f, at + 14, at + 22)}}><Icon k="check" s={52} /></div>}
    </div>
  </Card>;
};
const Quote: React.FC<{y: number; at: number; text: string}> = ({y, at, text}) => {
  const f = useCurrentFrame(); const p = ease(f, at, at + 12);
  return <div style={{position: 'absolute', left: 120, right: 120, top: y, opacity: p, transform: `scale(${0.9 + 0.1 * p})`}}>
    <div style={{background: C.navy, color: '#fff', borderRadius: 34, padding: '30px 40px', fontFamily: HEAD, fontWeight: 800, fontSize: 46, textAlign: 'center', lineHeight: 1.2, boxShadow: '0 18px 40px rgba(20,40,60,.22)'}}>{text}</div>
  </div>;
};

const scene = (id: string, d: number, L: Dict) => {
  const n = L.n[id];
  const t = (p: number) => fr(d, p);
  const tl = (x: number) => L.tilt[x < 2.5 ? 0 : x < 7.6 ? 1 : 2];
  switch (id) {
    case 'T01': return <>
      <WardBed top={440} d={d} q={0} relative />
      <Notes y={950} items={[[n[0], t(0.08), C.navy, NV], [n[1], t(0.3), C.navy, NV]]} />
      <Quote y={1140} at={t(0.68)} text={n[2]} />
    </>;
    case 'T02': return <>
      <PressureBody top={470} d={d} labels={L.body} />
      <Notes y={900} items={[[n[0], t(0.06), C.navy, NV], [n[1], t(0.3), C.navy, NV], [n[2], t(0.55)]]} />
    </>;
    case 'T03': return <>
      <Clip3D src="c3/press_tilt.mp4" y={430} h={560} d={d} dur={12} label={tl} />
      <Notes y={1015} items={[[n[0], t(0.06), C.teal, C.tealL], [n[1], t(0.14), C.teal, C.tealL], [n[2], t(0.26)]]} size={28} />
      <Card x={64} y={1150} w={952} at={t(0.55)}><div style={{fontFamily: BODY, fontWeight: 700, fontSize: 29, color: C.navy, lineHeight: 1.3}}>{n[3]}</div></Card>
      <Notes y={1320} items={[[n[4], t(0.85), C.blood, C.bloodL]]} size={28} />
    </>;
    case 'T04': return <>
      <SheetDrag top={440} d={d} />
      <Row y={770} at={t(0.08)} icon="wound" text={n[0]} warn />
      <Row y={920} at={t(0.3)} icon="check" text={n[1]} />
      <Row y={1070} at={t(0.5)} icon="head" text={n[2]} warn size={28} />
      <Row y={1260} at={t(0.8)} icon="check" text={n[3]} size={28} />
    </>;
    case 'T05': return <>
      <Clip3D src="c3/falls_sitfeet.mp4" y={430} h={520} d={d} dur={7} />
      <Notes y={975} items={[[n[0], t(0.04)], [n[1], t(0.2), C.navy, NV], [n[2], t(0.4), C.teal, C.tealL], [n[3], t(0.75), C.teal, C.tealL], [n[4], t(0.9), C.navy, NV]]} size={28} />
    </>;
    case 'T06': return <>
      <Clip3D src="c3/walker_walk.mp4" y={430} h={640} d={d} dur={13.8} />
      <Notes y={1100} items={[[n[0], t(0.3), C.navy, NV], [n[1], t(0.55), C.teal, C.tealL]]} />
    </>;
    case 'T07': return <>
      <BedReal top={440} d={d} bell patient />
      <Notes y={960} items={[[n[0], t(0.1)], [n[1], t(0.35), C.navy, NV], [n[2], t(0.75), C.teal, C.tealL]]} />
    </>;
    case 'T08': return <>
      <FoodGrid top={450} d={d} items={L.food} rtl={L.rtl} />
      <Card x={64} y={1040} w={952} at={t(0.72)}>
        <div style={{display: 'flex', alignItems: 'center', gap: 24}}><Icon k="drop" s={58} c={C.teal} />
          <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink, lineHeight: 1.3}}>{n[0]}</div></div>
      </Card>
    </>;
    case 'T09': return <>
      <Row y={460} at={t(0.04)} icon="clock" text={n[0]} warn />
      <Row y={630} at={t(0.25)} icon="check" text={n[1]} />
      <Row y={800} at={t(0.45)} icon="drop" text={n[2]} />
      <Row y={970} at={t(0.7)} icon="check" text={n[3]} />
    </>;
    case 'T10': return <>
      <Row y={460} at={t(0.04)} icon="clock" text={n[0]} />
      <Row y={610} at={t(0.12)} icon="heart" text={n[1]} />
      <Row y={760} at={t(0.2)} icon="check" text={n[2]} />
      <Card x={64} y={930} w={952} at={t(0.4)} style={{border: `6px solid ${C.blood}`}}>
        <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 31, color: C.blood, lineHeight: 1.35}}>{n[3]}</div>
      </Card>
    </>;
    case 'T11': return <>
      <Card x={64} y={640} w={952} at={t(0.1)} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center', padding: '60px 40px'}}>
        <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 50, color: C.ink, marginBottom: 20, lineHeight: 1.2}}>{L.end[0]}</div>
        <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 34, color: C.mute}}>{L.end[1]}</div>
      </Card>
    </>;
  }
  return null;
};

export const mkTurn = (lang: string, timing: unknown) => {
  const TT = timing as TT;
  const L = N[lang];
  const total = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
  const Comp: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
    let at = 0;
    return <AbsoluteFill style={{direction: L.rtl ? 'rtl' : 'ltr'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={L.brand} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            {scene(x.id, d, L)}
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>;
  };
  return {Comp, total};
};
const ru = mkTurn('ru', tRu); export const Turn = ru.Comp; export const totalTurn = ru.total;
const he = mkTurn('he', tHe); export const TurnHe = he.Comp; export const totalTurnHe = he.total;
const ar = mkTurn('ar', tAr); export const TurnAr = ar.Comp; export const totalTurnAr = ar.total;
const en = mkTurn('en', tEn); export const TurnEn = en.Comp; export const totalTurnEn = en.total;

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
