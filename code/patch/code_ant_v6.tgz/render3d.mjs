import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition, openBrowser} from '@remotion/renderer';
import fs from 'fs';
// clips: [{name, comp:'Clip'|'Leg', props, frames:[...]} or {from, to}]
const clips = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const serveUrl = await bundle({entryPoint: 'src/index.ts'});
const browser = await openBrowser('chrome', {browserExecutable: '/opt/pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell', chromiumOptions: {gl: 'swangle'}});
for (const c of clips) {
  const inputProps = c.props;
  const composition = await selectComposition({serveUrl, id: c.comp || 'Clip', inputProps, puppeteerInstance: browser, timeoutInMilliseconds: 180000});
  const dir = `public/clips/${c.name}`;
  fs.mkdirSync(dir, {recursive: true});
  const frames = c.frames || Array.from({length: c.to - (c.from || 0)}, (_, i) => i + (c.from || 0));
  const t0 = Date.now();
  let k = 0;
  for (const fr of frames) {
    const out = `${dir}/${fr}.png`;
    if (fs.existsSync(out)) continue;
    await renderStill({composition, serveUrl, inputProps, frame: fr, output: out, imageFormat: 'png', puppeteerInstance: browser, chromiumOptions: {gl: 'swangle'}, overwrite: true, timeoutInMilliseconds: 180000});
    k++;
    if (k % 20 === 1) console.log(c.name, fr, ((Date.now() - t0) / k / 1000).toFixed(2) + 's/frame');
  }
}
await browser.close({silent: true});
console.log('done');
