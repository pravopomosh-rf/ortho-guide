import {bundle} from '@remotion/bundler';
import {renderFrames, selectComposition, openBrowser} from '@remotion/renderer';
import fs from 'fs';
const clips = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const tag = process.argv[3] || 'x';
const serveUrl = await bundle({entryPoint: 'src/index.ts'});
const exe = '/opt/pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell';
const browser = await openBrowser('chrome', {browserExecutable: exe, chromiumOptions: {gl: 'swangle'}});
for (const c of clips) {
  const inputProps = c.props;
  const dir = `public/clips/${c.name}`;
  fs.mkdirSync(dir, {recursive: true});
  const frames = c.frames || Array.from({length: c.to - (c.from || 0)}, (_, i) => i + (c.from || 0));
  const miss = frames.filter(f => !fs.existsSync(`${dir}/${f}.png`)).sort((a,b)=>a-b);
  if (!miss.length) continue;
  const runs = []; let s = miss[0], p = miss[0];
  for (const f of miss.slice(1)) { if (f === p + 1) { p = f; } else { runs.push([s, p]); s = p = f; } }
  runs.push([s, p]);
  const composition = await selectComposition({serveUrl, id: c.comp || 'Clip', inputProps, puppeteerInstance: browser, timeoutInMilliseconds: 180000});
  for (const [a, b] of runs) {
    // chunks of 40 so progress is saved often
    for (let x = a; x <= b; x += 40) {
      const y = Math.min(b, x + 39);
      const tmp = `/root/proj/tmpf_${tag}`;
      fs.rmSync(tmp, {recursive: true, force: true}); fs.mkdirSync(tmp);
      const t0 = Date.now();
      await renderFrames({composition, serveUrl, inputProps, frameRange: [x, y], outputDir: tmp, imageFormat: 'png', puppeteerInstance: browser, chromiumOptions: {gl: 'swangle'}, concurrency: 1, timeoutInMilliseconds: 180000, onStart: () => {}, onFrameUpdate: () => {}});
      const files = fs.readdirSync(tmp).filter(f => f.endsWith('.png')).sort();
      if (files.length !== y - x + 1) throw new Error(`count ${files.length} vs ${y-x+1}`);
      files.forEach((f, i) => fs.renameSync(`${tmp}/${f}`, `${dir}/${x + i}.png`));
      console.log(c.name, x, y, ((Date.now() - t0) / (y - x + 1) / 1000).toFixed(2) + 's/frame');
    }
  }
}
await browser.close({silent: true});
console.log('done');
