set -e
cd /root/proj/ant
npx remotion render src/index.ts Film out/film_v6_muted.mp4 --muted --concurrency=2 --crf=16 --log=error
OUT=out/TBS_peredniy_dostup_RU_v6.mp4
ffmpeg -v error -y -i out/film_v6_muted.mp4 -i aud/voice_v5.wav -map 0:v -map 1:a -c:v libx264 -preset slow -crf 24 -maxrate 1100k -bufsize 2200k -pix_fmt yuv420p -c:a aac -b:a 96k -ac 1 -shortest -movflags +faststart $OUT
ls -la $OUT
ffprobe -v error -show_entries format=duration -of csv=p=0 $OUT
echo "== silences >1.5s"; ffmpeg -i $OUT -af silencedetect=n=-40dB:d=1.5 -f null - 2>&1 | grep -oE 'silence_(start|end): [0-9.]+|silence_duration: [0-9.]+' | paste - - - || true
echo "== scene>0.3"; ffmpeg -i $OUT -vf "select='gt(scene,0.3)',showinfo" -f null - 2>&1 | grep -oE 'pts_time:[0-9.]+' || true
echo "== freeze>4s"; ffmpeg -i $OUT -vf freezedetect=n=0.0005:d=4 -map 0:v -f null - 2>&1 | grep -oE 'freeze_(start|end|duration): [0-9.]+' || true
