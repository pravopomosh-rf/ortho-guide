import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition, openBrowser} from '@remotion/renderer';
import fs from 'fs';
const pv = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const outDir = process.argv[3]; fs.mkdirSync(outDir, {recursive: true});
const serveUrl = await bundle({entryPoint: 'src/index.ts'});
const browser = await openBrowser('chrome', {browserExecutable: '/opt/pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell'});
const composition = await selectComposition({serveUrl, id: 'Film', inputProps: {}, puppeteerInstance: browser});
for (const [id, fr] of pv) {
  await renderStill({composition, serveUrl, frame: fr, output: `${outDir}/${String(fr).padStart(5,'0')}_${id}.png`, imageFormat: 'png', puppeteerInstance: browser, overwrite: true});
}
await browser.close({silent: true}); console.log('ok');
