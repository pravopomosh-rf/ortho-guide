import React from 'react';
import {Composition} from 'remotion';
import {Hip3D} from './Hip3D';
import {Leg3D} from './Leg3D';
import {Film, totalFrames} from './Film';
import timing from './timing.json';

const Clip: React.FC<any> = (p) => <Hip3D mode={p.mode} len={p.len} start={p.start} spin={p.spin} width={p.w} height={p.h} />;
const Leg: React.FC<any> = (p) => <Leg3D mode={p.mode} len={p.len} width={p.w} height={p.h} />;

export const Root: React.FC = () => (
  <>
    <Composition id="Film" component={Film} durationInFrames={totalFrames(timing as any)} fps={30} width={1280} height={720} />
    <Composition id="Clip" component={Clip} durationInFrames={1000} fps={30} width={600} height={600}
      defaultProps={{mode: 'anatomy', len: 240, start: 0, spin: 0.5, w: 600, h: 600}}
      calculateMetadata={({props}: any) => ({width: props.w, height: props.h})} />
    <Composition id="Leg" component={Leg} durationInFrames={1000} fps={30} width={560} height={640}
      defaultProps={{mode: 'approaches', len: 240, w: 560, h: 640}}
      calculateMetadata={({props}: any) => ({width: props.w, height: props.h})} />
  </>
);
