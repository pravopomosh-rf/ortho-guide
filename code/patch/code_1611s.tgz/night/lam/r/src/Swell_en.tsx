// «Отёк ноги» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import {Clip3D} from './Clip3D';
import timing from './timing_swell_en.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalSwell_en = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'ORTHOPAEDICS · FOR PATIENTS';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Отёк: сцены E01–E09 ----
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10)}}><Note size={28} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const Box: React.FC<{y: number; at: number; text: string; color?: string; bg?: string; label?: string}> = ({y, at, text, color, bg, label}) =>
  <Card x={64} y={y} w={952} at={at} label={label} style={color ? {border: `4px solid ${color}`, background: bg || '#fff'} : {}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink, lineHeight: 1.3}}>{text}</div>
  </Card>;
const Cross: React.FC<{y: number; at: number; text: string}> = ({y, at, text}) => <Box y={y} at={at} text={`✕ ${text}`} color={C.acc} />;
const S01: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={470} w={420} label="PATIENT" at={4}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>Patient</div>
    
  </Card>
  <Card x={540} y={470} w={476} label="A WEEK AGO" at={14}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>knee replacement</div>
  </Card>
  <Notes y={720} items={[['sat a lot, leg down', fr(d, 0.35), C.navy, '#E3E7EF'], ['by evening · very swollen', fr(d, 0.62)]]} />
</>;
const S02: React.FC<{d: number}> = ({d}) => <>
  <Box y={480} at={fr(d, 0.03)} text="Swelling after leg surgery · common" color={C.teal} bg={C.tealL} />
  <CheckRow y={650} at={fr(d, 0.22)} icon="clock" text="Worse in the evening and after activity" />
  <CheckRow y={810} at={fr(d, 0.4)} icon="check" text="Eases over weeks and months" />
  <Box y={980} at={fr(d, 0.7)} text="Warning signs · at the end of the video" color={C.acc} />
</>;
const S03: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame(); const p = ease(f, fr(d, 0.1), fr(d, 0.35));
  return <>
    <Clip3D src="c3/swell_elevate.mp4" y={430} d={d} dur={8} label={(t) => t > 3.4 ? '― heart level ―' : null} />
    <CheckRow y={1195} at={fr(d, 0.35)} icon="check" text="Leg on pillows, foot above heart, knee straight" />
    <Cross y={1355} at={fr(d, 0.72)} text="Pillow under the knee only" />
  </>;
};
const S04: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={460} at={fr(d, 0.03)} icon="therm" text="Cold · in a towel, not on bare skin" />
  <CheckRow y={620} at={fr(d, 0.35)} icon="clock" text="15–20 minutes, at least an hour’s break" />
  <Box y={790} at={fr(d, 0.65)} text="Skin bright red, white or numb · remove the cold pack immediately" color={C.acc} />
</>;
const S05: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={260} at={fr(d, 0.03)} title="Ask your doctor first" color="#B45309" bg="#FFF7ED"
    items={[['head', 'reduced feeling'], ['heart', 'poor circulation in the leg'], ['drop', 'diabetes with nerve damage']]} />
  <Cross y={780} at={fr(d, 0.62)} text="Cold pack · not on an open wound" />
  <CheckRow y={940} at={fr(d, 0.8)} icon="wound" text="Dressing · dry" />
</>;
const S06: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame(); const a = 18 * Math.sin(f / 6);
  return <>
    <Clip3D src="c3/swell_pump.mp4" y={430} d={d} dur={9} />
    <CheckRow y={1195} at={fr(d, 0.05)} icon="leg" text="Foot pump · several times an hour" />
    <CheckRow y={1355} at={fr(d, 0.45)} icon="check" text="Physiotherapy exercises" />
  </>;
};
const S07: React.FC<{d: number}> = ({d}) => <>
  <Cross y={470} at={fr(d, 0.03)} text="Standing or sitting for long with the leg down" />
  <CheckRow y={640} at={fr(d, 0.3)} icon="clock" text="Alternate: walking · exercises · leg up" />
  <CheckRow y={800} at={fr(d, 0.65)} icon="leg" text="Compression stockings · as prescribed" />
</>;
const S08: React.FC<{d: number}> = ({d}) => <>
  <Tier y={460} h={360} at={fr(d, 0.02)} title="See a doctor urgently" color="#B45309" bg="#FFF7ED"
    items={[['calf', 'calf: pain, swelling, heat, redness'], ['leg', 'swelling increasing quickly'], ['leg', 'swelling not easing after raising the leg'], ['wound', 'wound redness increasing'], ['wound', 'wound discharge'], ['therm', 'high temperature, chills']]} />
  <Tier y={860} h={220} at={fr(d, 0.8)} title="101" color={C.blood} bg="#FDECEC"
    items={[['lungs', 'sudden breathlessness'], ['heart', 'chest pain']]} />
</>;
const S09: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>These are general recommendations</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>Individual instructions from your doctor, physiotherapist and medical team take priority</div>
  </Card>
);
const SC: Record<string, React.FC<{d: number}>> = {E01: S01, E02: S02, E03: S03, E04: S04, E05: S05, E06: S06, E07: S07, E08: S08, E09: S09};

export const Swell_en: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
