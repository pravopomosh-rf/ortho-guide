// «Ампутация ноги: первые недели» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import timing from './timing_amp_ar.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalAmp_ar = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'جراحة العظام · للمرضى';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Ампутация: сцены M01–M14 ----
const SKIN = '#E4E7EC', SKINS = '#C9CED6', BONE = '#EFE6D8', BONES = '#C9B79C';
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10)}}><Note size={28} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
// нога сбоку (бедро-колено-голень); cut: 0 — нога целиком, 1 — культя ниже колена; phantom — пунктир отсутствующей части
const LegSide: React.FC<{cut: number; phantom?: number; top?: number; spark?: number}> = ({cut, phantom = 0, top = 640, spark = 0}) => {
  const f = useCurrentFrame();
  return <svg width={1080} height={760} style={{position: 'absolute', left: 0, top}}>
    <path d="M 300 80 C 360 60 520 60 560 90 L 600 300 C 610 330 600 350 580 360 L 330 360 C 310 300 300 200 300 80 Z" fill={SKIN} stroke={SKINS} strokeWidth={4} />
    <circle cx={470} cy={350} r={58} fill={SKIN} stroke={SKINS} strokeWidth={4} />
    {/* культя: верхняя треть голени */}
    <path d="M 420 380 L 530 380 C 532 430 530 470 520 500 C 500 528 450 528 430 500 C 420 470 418 430 420 380 Z" fill={SKIN} stroke={SKINS} strokeWidth={4} />
    <g opacity={1 - cut}><path d="M 430 500 L 520 500 C 522 560 520 620 512 660 L 560 700 L 560 730 L 420 730 L 430 660 C 426 600 426 560 430 500 Z" fill={SKIN} stroke={SKINS} strokeWidth={4} /></g>
    <g opacity={phantom}><path d="M 430 500 L 520 500 C 522 560 520 620 512 660 L 560 700 L 560 730 L 420 730 L 430 660 C 426 600 426 560 430 500 Z" fill="none" stroke={C.acc} strokeWidth={4} strokeDasharray="12 10" />
      {[[470, 580], [500, 650], [450, 700], [530, 712]].map(([x, y], i) => <text textAnchor="end" key={i} x={x} y={y} fontSize={34} fill={C.acc} opacity={0.4 + 0.6 * Math.abs(Math.sin((f + i * 9) / 8)) * spark}>✦</text>)}</g>
    <text textAnchor="end" x={620} y={360} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.mute}>الركبة</text>
  </svg>;
};

const S01: React.FC<{d: number}> = ({d}) => {
  const c = ease(useCurrentFrame(), fr(d, 0.4), fr(d, 0.7));
  return <>
    <Card x={64} y={470} w={420} label="المريض" at={4}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>مريض</div>
      
    </Card>
    <Card x={540} y={470} w={476} label="السبب" at={14}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>سكري · عدوى · ضعف التروية الدموية</div>
    </Card>
    <LegSide cut={c} top={700} />
    <Notes y={1460} items={[['بتر تحت الركبة', fr(d, 0.6)]]} />
  </>;
};

const S02: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const m = ease(f, fr(d, 0.2), fr(d, 0.45)), b = ease(f, fr(d, 0.5), fr(d, 0.7));
  return <>
    <svg width={1080} height={700} style={{position: 'absolute', left: 0, top: 480}}>
      <path d="M 360 40 L 720 40 L 720 380 C 720 520 640 600 540 600 C 440 600 360 520 360 380 Z" fill={SKIN} stroke={SKINS} strokeWidth={4} />
      <path d={`M 420 40 L 560 40 L 560 ${330} C 560 370 530 390 490 390 C 450 390 420 370 420 330 Z`} fill={BONE} stroke={BONES} strokeWidth={4} />
      <path d="M 610 40 L 650 40 L 650 270 C 650 292 640 300 630 300 C 620 300 610 292 610 270 Z" fill={BONE} stroke={BONES} strokeWidth={4} />
      <path d="M 400 300 C 400 470 460 540 540 545 C 620 540 680 470 680 300" fill="none" stroke="#D99A9A" strokeWidth={28} opacity={m} strokeLinecap="round" />
      <path d="M 370 380 C 370 520 450 590 540 592 C 630 590 710 520 710 380" fill="none" stroke="#fff" strokeWidth={22} opacity={b * 0.95} strokeLinecap="round" />
      <text textAnchor="end" x={760} y={150} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.mute}>الظنبوب</text>
      <text textAnchor="end" x={760} y={250} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.mute}>الشظية (أقصر)</text>
      <text textAnchor="end" x={760} y={460} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.mute} opacity={m}>العضلات</text>
      <text textAnchor="end" x={760} y={560} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.mute} opacity={b}>الضماد</text>
    </svg>
    <div style={{position: 'absolute', left: 64, top: 1190, fontFamily: BODY, fontWeight: 600, fontSize: 22, color: C.mute}}>رسم الجذع، ليس بالمقياس</div>
    <Notes y={1240} items={[['أطراف العظام مغطاة بالعضلات والجلد', fr(d, 0.3)], ['أحيانًا · أنبوب تصريف', fr(d, 0.6), C.navy, '#E3E7EF'], ['في المستشفى يغيّر الطاقم الضمادة', fr(d, 0.78), C.teal, C.tealL]]} />
  </>;
};

const S03: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const v = Math.round(7 - 4 * ease(f, fr(d, 0.3), fr(d, 0.7)));
  return <>
    <Card x={64} y={480} w={952} label="الألم 0–10" at={4}>
      <div style={{display: 'flex', gap: 8, marginTop: 10}}>{Array.from({length: 11}, (_, i) => <div key={i} style={{flex: 1, height: 70, borderRadius: 14, background: i <= v ? (i > 6 ? C.acc : i > 3 ? '#F2A65A' : C.teal) : C.bg2, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: HEAD, fontWeight: 800, fontSize: 24, color: i <= v ? '#fff' : C.mute}}>{i}</div>)}</div>
    </Card>
    <CheckRow y={760} at={fr(d, 0.3)} icon="pills" text="حسب الخطة · بانتظام أو عند الحاجة" />
    <CheckRow y={980} at={fr(d, 0.6)} icon="clock" text="قبل العلاج الطبيعي · ناقشوا مع الممرضة · إن لم يزل · أخبروا" />
  </>;
};

const S04: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <LegSide cut={1} phantom={ease(f, fr(d, 0.1), fr(d, 0.3))} spark={1} top={480} />
    <Notes y={1250} items={[['يبدو أن الساق لا تزال موجودة', fr(d, 0.15)], ['هذه أحاسيس حقيقية', fr(d, 0.45), C.navy, '#E3E7EF'], ['غالبًا ما تخفّ', fr(d, 0.6), C.teal, C.tealL], ['ألم الطرف الشبحي يُعالج', fr(d, 0.8)]]} />
  </>;
};

const S05: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const moon = ease(f, 0, 12);
  return <>
    <svg width={1080} height={560} style={{position: 'absolute', left: 0, top: 480}}>
      <rect x={0} y={0} width={1080} height={560} fill="#1B2333" opacity={0.92 * moon} rx={28} />
      <circle cx={900} cy={100} r={46} fill="#F4E3A6" opacity={moon} /><circle cx={922} cy={86} r={42} fill="#1B2333" opacity={moon} />
      <rect x={160} y={300} width={620} height={60} rx={14} fill="#3A4459" /><rect x={160} y={360} width={20} height={120} fill="#3A4459" /><rect x={760} y={360} width={20} height={120} fill="#3A4459" />
      <rect x={180} y={270} width={160} height={40} rx={18} fill="#56617A" />
      <circle cx={660} cy={250} r={34} fill="#F4D9C6" opacity={moon} />
      <path d="M 660 284 L 660 380 L 700 380" stroke="#F4D9C6" strokeWidth={22} fill="none" strokeLinecap="round" opacity={moon} />
      <circle cx={860} cy={360} r={34} fill={C.acc} opacity={ease(f, fr(d, 0.7), fr(d, 0.8))} />
      <text x={860} y={372} textAnchor="middle" fontFamily="'Body'" fontWeight={700} fontSize={26} fill="#fff" opacity={ease(f, fr(d, 0.7), fr(d, 0.8))}>!</text>
    </svg>
    <Notes y={1080} items={[['في الليل يسهل نسيان أن الساق غير موجودة', fr(d, 0.1)], ['توقفوا قبل أن تنهضوا', fr(d, 0.5), C.navy, '#E3E7EF'], ['في المستشفى · زر الاستدعاء', fr(d, 0.72), C.teal, C.tealL]]} />
  </>;
};

const DoDont: React.FC<{y: number; at: number; ok: boolean; text: string; children: React.ReactNode}> = ({y, at, ok, text, children}) => <Card x={64} y={y} w={952} at={at} style={{border: `4px solid ${ok ? C.green : C.acc}`}}>
  <div style={{display: 'flex', alignItems: 'center', gap: 24}}>
    <svg width={260} height={140} viewBox="0 0 260 140">{children}</svg>
    <div style={{flex: 1}}><div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 28, color: ok ? C.green : C.acc}}>{ok ? 'مسموح' : 'ممنوع'}</div>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.ink, marginTop: 6}}>{text}</div></div>
  </div>
</Card>;
const S06: React.FC<{d: number}> = ({d}) => <>
  <DoDont y={470} at={fr(d, 0.03)} ok={false} text="وسادة تحت الجذع، سرير مثني تحت الركبة">
    <rect x={10} y={100} width={240} height={20} rx={8} fill="#C9CED6" /><ellipse cx={170} cy={92} rx={50} ry={16} fill="#F4E3A6" />
    <path d="M 30 90 L 120 90 L 170 62 L 200 72" stroke={SKINS} strokeWidth={26} fill="none" strokeLinecap="round" />
  </DoDont>
  <DoDont y={720} at={fr(d, 0.35)} ok={true} text="الركبة مستقيمة والساق ممدودة">
    <rect x={10} y={100} width={240} height={20} rx={8} fill="#C9CED6" /><path d="M 30 82 L 200 82" stroke={SKINS} strokeWidth={26} fill="none" strokeLinecap="round" />
  </DoDont>
  <DoDont y={970} at={fr(d, 0.55)} ok={true} text="على الكرسي · الجذع على مسند">
    <rect x={20} y={40} width={90} height={80} rx={10} fill="#C9CED6" /><rect x={110} y={70} width={130} height={14} rx={6} fill="#8E99A8" /><path d="M 70 62 L 200 62" stroke={SKINS} strokeWidth={24} strokeLinecap="round" />
  </DoDont>
  <Notes y={1230} items={[['على البطن · حسب تعليمات أخصائي العلاج الطبيعي', fr(d, 0.8), C.navy, '#E3E7EF']]} />
</>;

const S07: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.02)} icon="leg" text="عادةً من اليوم التالي · تمارين في السرير" />
  <CheckRow y={700} at={fr(d, 0.3)} icon="check" text="تعلّم الانتقال بأمان إلى الكرسي المتحرك" />
  <Card x={64} y={920} w={952} at={fr(d, 0.62)} style={{border: `4px solid ${C.acc}`}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>لا يُنصح بالقفز على ساق واحدة بالعكازات · خطر السقوط</div>
  </Card>
</>;

const S08: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={470} w={952} at={fr(d, 0.02)} label="طالما الجرح يلتئم">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>لا تلمسوه · في المستشفى يغيّر الطاقم الضمادة</div>
  </Card>
  <CheckRow y={700} at={fr(d, 0.3)} icon="shower" text="بعد ذلك · الغسل يوميًا بصابون لطيف بلا رائحة والتجفيف جيدًا" />
  <CheckRow y={940} at={fr(d, 0.55)} icon="check" text="فحص الجذع يوميًا" />
  <Notes y={1180} items={[['التورّم في الأسابيع الأولى · أمر طبيعي', fr(d, 0.78), C.teal, C.tealL]]} />
</>;

const S09: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.02)} icon="check" text="فحص قدم الساق الأخرى يوميًا" />
  <CheckRow y={690} at={fr(d, 0.2)} icon="check" text="حذاء مريح" />
  <CheckRow y={900} at={fr(d, 0.38)} icon="check" text="بانتظام · أخصائي القدم" />
  <Card x={64} y={1110} w={952} at={fr(d, 0.62)} label="التدخين">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>يضعف التروية والالتئام · ناقشوا التوقف مع الطبيب</div>
  </Card>
</>;

const S10: React.FC<{d: number}> = ({d}) => {
  const items = ['التئام الجرح', 'قوة العضلات', 'الحالة العامة'];
  return <>
    {items.map((t, i) => <Slot key={i} x={64} y={480 + i * 170} w={952} h={140} at={fr(d, 0.05 + i * 0.12)}>
      <Icon k="check" s={56} /><div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>{t}</div></Slot>)}
    <Card x={64} y={1010} w={952} at={fr(d, 0.5)} label="الطرف الاصطناعي">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>يتطلب جهدًا كبيرًا · لا يناسب الجميع</div>
    </Card>
    <Card x={64} y={1220} w={952} at={fr(d, 0.75)} style={{background: C.navy}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: '#fff'}}>من دون طرف اصطناعي · استقلالية بالكرسي المتحرك</div>
    </Card>
  </>;
};

const S11: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <svg width={1080} height={420} style={{position: 'absolute', left: 0, top: 500}}>
      {[[380, '#C9CED6'], [700, '#BFD9E6']].map(([x, c], i) => <g key={i} opacity={ease(f, 4 + i * 8, 16 + i * 8)}>
        <circle cx={x as number} cy={120} r={60} fill={c as string} /><path d={`M ${(x as number) - 90} 380 C ${(x as number) - 90} 230 ${(x as number) + 90} 230 ${(x as number) + 90} 380 Z`} fill={c as string} /></g>)}
      <path d="M 470 90 C 520 50 560 50 610 90" stroke={C.teal} strokeWidth={6} fill="none" opacity={ease(f, fr(d, 0.3), fr(d, 0.4))} strokeLinecap="round" />
    </svg>
    <Notes y={980} items={[['حزن، قلق، انخفاض المزاج · ردّ فعل طبيعي', fr(d, 0.1)], ['تحدّثوا مع الأقارب والفريق', fr(d, 0.45), C.navy, '#E3E7EF'], ['أخصائي نفسي · لقاء من مرّوا بذلك', fr(d, 0.7), C.teal, C.tealL]]} />
  </>;
};

const S12: React.FC<{d: number}> = ({d}) => <>
  <svg width={1080} height={460} style={{position: 'absolute', left: 0, top: 480}}>
    <rect x={240} y={120} width={600} height={320} rx={18} fill="#fff" stroke={C.line} strokeWidth={4} />
    {Array.from({length: 8}, (_, i) => <rect key={i} x={280 + (i % 4) * 140} y={160 + Math.floor(i / 4) * 110} width={90} height={70} rx={8} fill="#DDF3F0" />)}
    <rect x={500} y={360} width={80} height={80} rx={8} fill={C.teal} />
    <path d="M 520 60 h40 v-40 h20 v40 h40 v20 h-40 v40 h-20 v-40 h-40 Z" fill={C.teal} transform="translate(-30 30)" />
  </svg>
  <Notes y={1000} items={[['عادةً · إلى مستشفى تأهيلي', fr(d, 0.1)], ['تعلّم التنقل والعناية بالنفس', fr(d, 0.45), C.navy, '#E3E7EF'], ['يُحضَّرون للعودة إلى البيت', fr(d, 0.7), C.teal, C.tealL]]} />
</>;

const S13: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={340} at={fr(d, 0.02)} title="إلى الطبيب في اليوم نفسه" color="#B45309" bg="#FFF7ED"
    items={[['wound', 'الجذع أحمر أو ساخن أو مؤلم'], ['drop', 'التورّم يزداد'], ['wound', 'إفرازات أو قيح من الجرح'], ['calf', 'ألم أو تورّم في ربلة الساق الأخرى']]} />
  <Tier y={840} h={230} at={fr(d, 0.6)} title="101 فورًا" color={C.blood} bg="#FDECEC"
    items={[['lungs', 'ضيق نفس مفاجئ'], ['heart', 'ألم في الصدر']]} />
</>;

const S14: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>هذه توصيات عامة</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>تعليمات طبيبكم والفريق الطبي الخاصة بكم لها الأولوية</div>
  </Card>
);

const SC: Record<string, React.FC<{d: number}>> = {M01: S01, M02: S02, M03: S03, M04: S04, M05: S05, M06: S06, M07: S07, M08: S08, M09: S09, M10: S10, M11: S11, M12: S12, M13: S13, M14: S14};

export const Amp_ar: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill style={{direction: 'rtl'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
