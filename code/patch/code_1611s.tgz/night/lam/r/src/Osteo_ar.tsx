// «Операция при переломе: остеосинтез» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import timing from './timing_osteo_ar.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalOsteo_ar = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'جراحة العظام · للمرضى';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Остеосинтез: сцены O01–O12 ----
const BONE = '#EFE6D8', BONES = '#C9B79C', MET = '#5B6B82';
// схема голени спереди: большеберцовая кость с косым переломом, малоберцовая рядом
const Leg: React.FC<{top?: number; disp?: number; plate?: number; nail?: number; wire?: number; wound?: number; heal?: number; left?: number; sc?: number}> =
  ({top = 470, disp = 0, plate = 0, nail = 0, wire = 0, wound = 0, heal = 0, left = 0, sc = 1}) => {
  const lower = `translate(${44 * disp} ${22 * disp}) rotate(${7 * disp} 512 412)`;
  const screwsUp = [270, 330], screwsDn = [500, 570];
  return <svg width={1080} height={900} viewBox="0 0 1080 900" style={{position: 'absolute', left, top, transform: `scale(${sc})`, transformOrigin: 'top center'}}>
    {/* кожа голени */}
    <path d="M 360 20 C 350 200 380 380 400 560 C 410 680 420 800 430 890 L 700 890 C 705 800 715 680 725 560 C 745 380 760 200 750 20 Z" fill="#F6E7DC" stroke="#E7CDBB" strokeWidth={4} />
    {/* малоберцовая */}
    <path d="M 640 70 L 664 70 L 668 870 L 644 870 Z" fill={BONE} stroke={BONES} strokeWidth={4} />
    {/* верхний отломок */}
    <path d="M 420 40 L 610 40 C 610 95 572 125 566 170 L 568 392 L 456 432 L 458 170 C 452 125 420 95 420 40 Z" fill={BONE} stroke={BONES} strokeWidth={4} />
    <rect x={494} y={150} width={36} height={250} rx={18} fill="#F7F1E7" />
    {/* нижний отломок */}
    <g transform={lower}>
      <path d="M 456 434 L 568 394 L 566 770 C 572 815 600 835 600 870 L 428 870 C 428 835 456 815 458 770 Z" fill={BONE} stroke={BONES} strokeWidth={4} />
      <rect x={494} y={440} width={36} height={320} rx={18} fill="#F7F1E7" />
    </g>
    {/* линия перелома */}
    <line x1={452} y1={433} x2={572} y2={392} stroke={C.acc} strokeWidth={5} opacity={(1 - heal) * (0.5 + 0.5 * disp)} />
    {heal > 0 && <ellipse cx={512} cy={412} rx={80} ry={34} fill="#EADBC2" opacity={0.85 * heal} />}
    {/* стержень внутри кости + блокирующие винты */}
    {nail > 0 && <g opacity={nail}>
      <rect x={501} y={60} width={22} height={760 * nail} rx={11} fill={MET} />
      {nail > 0.95 && [120, 165, 730, 775].map((y) => <line key={y} x1={450} y1={y} x2={576} y2={y} stroke={MET} strokeWidth={9} strokeLinecap="round" />)}
    </g>}
    {/* пластина с винтами */}
    {plate > 0 && <g opacity={plate}>
      {[...screwsUp, ...screwsDn].map((y) => <line key={y} x1={450} y1={y} x2={574} y2={y} stroke={MET} strokeWidth={8} strokeLinecap="round" />)}
      <rect x={492} y={235} width={40} height={370} rx={14} fill="#7C8BA1" stroke={MET} strokeWidth={4} />
      {[...screwsUp, ...screwsDn].map((y) => <circle key={y} cx={512} cy={y} r={11} fill={MET} />)}
    </g>}
    {/* спицы */}
    {wire > 0 && <g opacity={wire}><line x1={430} y1={350} x2={600} y2={470} stroke={MET} strokeWidth={6} /><line x1={600} y1={340} x2={432} y2={470} stroke={MET} strokeWidth={6} /></g>}
    {/* рана над переломом */}
    {wound > 0 && <g opacity={wound}><path d="M 395 400 C 405 392 420 392 430 402" stroke={C.blood} strokeWidth={10} fill="none" strokeLinecap="round" />
      <circle cx={412} cy={400} r={34} fill="none" stroke={C.blood} strokeWidth={4} strokeDasharray="8 8" /></g>}
  </svg>;
};

const S01: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Card x={64} y={470} w={420} label="المريض" at={4}>
      <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 52, color: C.ink}}>مريض</div>
      <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 28, color: C.mute}}>سقط على الدرج</div>
    </Card>
    <Card x={540} y={470} w={476} label="الصورة" at={14}>
      <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 40, color: C.acc}}>كسر مع انزياح</div>
    </Card>
    <Leg top={700} sc={0.78} disp={ease(f, fr(d, 0.45), fr(d, 0.7))} />
    <div style={{position: 'absolute', left: 64, top: 1420, display: 'flex', gap: 12, flexWrap: 'wrap'}}>
      {['ألم', 'تورّم', 'لا يستطيع الدوس'].map((t, i) => <div key={t} style={{opacity: ease(f, fr(d, 0.25) + i * 8, fr(d, 0.25) + 10 + i * 8)}}><Note size={28}>{t}</Note></div>)}
    </div>
  </>;
};
const S02: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const red = ease(f, fr(d, 0.08), fr(d, 0.28));
  const pl = ease(f, fr(d, 0.3), fr(d, 0.42)) * (1 - ease(f, fr(d, 0.58), fr(d, 0.64)));
  const nl = ease(f, fr(d, 0.64), fr(d, 0.82));
  return <>
    <Leg top={440} sc={0.85} disp={1 - red} plate={pl} nail={nl} />
    <div style={{position: 'absolute', left: 64, top: 1240, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
      <div style={{opacity: red}}><Note color={C.teal} bg={C.tealL} size={28}>الأجزاء أُعيدت إلى مكانها</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.32), fr(d, 0.4))}}><Note color={C.navy} bg="#E3E7EF" size={28}>صفيحة + براغٍ</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.66), fr(d, 0.74))}}><Note color={C.navy} bg="#E3E7EF" size={28}>قضيب داخل العظم</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.8), fr(d, 0.86))}}><Note color={C.navy} bg="#E3E7EF" size={28}>أسلاك: في بعض الكسور الأخرى</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.86), fr(d, 0.94))}}><Note size={28}>العظم يلتئم بنفسه</Note></div>
    </div>
    <div style={{position: 'absolute', left: 64, top: 1200, fontFamily: BODY, fontWeight: 600, fontSize: 22, color: C.mute}}>رسم توضيحي، ليس بالمقياس · خيارات التثبيت</div>
  </>;
};
const S03: React.FC<{d: number}> = ({d}) => {
  const items = ['انزياح كبير', 'كسر غير مستقر', 'تضرّر سطح المفصل مع انزياح'];
  return <>
    {items.map((t, i) => <Slot key={t} x={64} y={470 + i * 150} w={952} h={130} at={fr(d, 0.15 + i * 0.1)}>
      <Icon k="check" s={64} /><div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>{t}</div></Slot>)}
    <Card x={64} y={950} w={952} at={fr(d, 0.02)} style={{background: C.navy}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: '#fff'}}>يقرّر الجرّاح حسب الفحص والصور</div>
    </Card>
    <Card x={64} y={1140} w={952} at={fr(d, 0.7)} label="دون انزياح">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>غالبًا دون جراحة: جبس أو دعامة أو ضماد</div>
    </Card>
  </>;
};
const S04: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Leg top={440} sc={0.6} left={-250} wound={ease(f, fr(d, 0.05), fr(d, 0.2))} />
    <div style={{position: 'absolute', left: 560, top: 470, width: 456, display: 'flex', flexDirection: 'column', gap: 16}}>
      {[['جرح قرب الكسر: قد يكون الكسر مفتوحًا', C.blood], ['لا يلزم أن يظهر العظم', C.ink], ['لا تغسل الجرح العميق', C.ink], ['لا تُرجع العظم', C.ink], ['ضماد نظيف', C.teal]].map(([t, c], i) =>
        <div key={i} style={{opacity: ease(f, fr(d, 0.1 + i * 0.12), fr(d, 0.18 + i * 0.12)), fontFamily: BODY, fontWeight: 700, fontSize: 30, color: c as string, background: '#fff', borderRadius: 18, padding: '14px 18px'}}>{t}</div>)}
    </div>
    <Card x={64} y={1100} w={952} at={fr(d, 0.75)} style={{background: '#FDECEC', border: `4px solid ${C.blood}`}}>
      <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.blood}}>101 فورًا</div>
    </Card>
  </>;
};
const S05: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={470} at={fr(d, 0.02)} icon="leg" text="جبيرة أو جبس · الطرف مرفوع" />
  <CheckRow y={690} at={fr(d, 0.18)} icon="therm" text="الأصابع: اللون، الحرارة، الإحساس، الحركة" />
  <Card x={64} y={910} w={952} at={fr(d, 0.4)} style={{border: `4px solid #B45309`, background: '#FFF7ED'}} label="أخبر الطاقم فورًا">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>اشتد الألم كثيرًا · أو خدر، وخز، أصابع باردة أو شاحبة أو مزرقّة</div>
  </Card>
  <Card x={64} y={1180} w={952} at={fr(d, 0.75)} label="حساسية من المعادن">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>خاصةً النيكل: أخبر الجرّاح</div>
  </Card>
</>;
const S06: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={470} at={fr(d, 0.02)} icon="drop" text="تخدير عام أو ناحي: يشرح طبيب التخدير الاختيار" />
  <CheckRow y={700} at={fr(d, 0.35)} icon="clock" text="أشعة أثناء العملية: الأجزاء والمعدن" />
  <CheckRow y={930} at={fr(d, 0.7)} icon="wound" text="غرز أو دبابيس · ضماد" />
</>;
const S07: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={470} at={fr(d, 0.02)} icon="leg" text="الذراع أو الساق مرفوعة · حرّك الأصابع" />
  <Card x={64} y={700} w={952} at={fr(d, 0.25)} style={{background: C.navy}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 40, color: '#fff'}}>التحميل فقط بإذن الجرّاح</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 28, color: '#DCE3EE', marginTop: 10}}>التحميل المبكر قد يزيح الأجزاء أو يكسر التثبيت</div>
  </Card>
  <CheckRow y={1000} at={fr(d, 0.7)} icon="leg" text="المشّاية أو العكازان: يعلّمك المعالج الفيزيائي" />
</>;
const S08: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={470} at={fr(d, 0.02)} icon="pills" text="المسكّنات حسب الخطة · لا تُضِف بنفسك" />
  <Card x={64} y={700} w={952} at={fr(d, 0.35)} label="الجلطات">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>بعد كسر الساق الخطر أعلى · الفريق يقرّر الوقاية، ليس للجميع</div>
  </Card>
  <Card x={64} y={960} w={952} at={fr(d, 0.7)} style={{border: `4px solid ${C.acc}`}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>لا توقف هذه الأدوية ولا تُضِفها بنفسك</div>
  </Card>
</>;
const S09: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Leg top={440} sc={0.62} left={-250} plate={1} heal={ease(f, fr(d, 0.05), fr(d, 0.6))} />
    <Card x={560} y={470} w={456} label="التئام العظم" at={4}>
      <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 40, color: C.ink}}>أسابيع ← أشهر</div>
      <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 26, color: C.mute}}>وأحيانًا أكثر</div>
    </Card>
    <Card x={560} y={720} w={456} at={fr(d, 0.3)} style={{border: `4px solid ${C.acc}`}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.ink}}>يزول الألم قبل أن يقوى العظم</div>
    </Card>
    <CheckRow y={1060} at={fr(d, 0.55)} icon="clock" text="مواعيد المتابعة والصور" />
    <CheckRow y={1270} at={fr(d, 0.8)} icon="wound" text="جرح نظيف · ضماد حسب التعليمات" />
  </>;
};
const S10: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={470} w={952} at={fr(d, 0.02)} label="المعدن">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>غالبًا يبقى في العظم إذا لم يسبّب مشكلة · الإزالة يقرّرها الجرّاح</div>
  </Card>
  <Card x={64} y={730} w={952} at={fr(d, 0.35)} style={{border: `4px solid ${C.navy}`}} label="الرنين المغناطيسي">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>أخبر الطاقم مسبقًا أن لديك معدنًا</div>
  </Card>
  <Card x={64} y={990} w={952} at={fr(d, 0.68)} label="هشاشة العظام">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>كسر بعد سقوط بسيط: ناقش الفحص مع طبيب العائلة</div>
  </Card>
</>;
const S11: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={230} at={fr(d, 0.02)} title="101 فورًا" color={C.blood} bg="#FDECEC"
    items={[['lungs', 'ضيق نفس مفاجئ'], ['heart', 'ألم في الصدر']]} />
  <Tier y={730} h={360} at={fr(d, 0.2)} title="فورًا: مساعدة طارئة" color="#B45309" bg="#FFF7ED"
    items={[['leg', 'ألم شديد يزداد: لا يخف بالمسكّن أو يشتد بتحريك الأصابع'], ['leg', 'تنمّل'], ['therm', 'أصابع باردة أو شاحبة أو مزرقّة'], ['leg', 'الجبس يضغط بشدة'], ['faint', 'لا تقُد · لا تستطيع الوصول بأمان؟ 101']]} />
  <Tier y={1120} h={300} at={fr(d, 0.65)} title="إلى الطبيب في اليوم نفسه" color={C.navy} bg="#fff"
    items={[['therm', '38 °م أو أكثر'], ['wound', 'احمرار، تورّم، إفرازات من الجرح'], ['calf', 'ألم جديد أو تورّم في ربلة الساق']]} />
</>;
const S12: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>هذه توصيات عامة</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>تعليمات طبيبكم والفريق الطبي الخاصة بكم لها الأولوية</div>
  </Card>
);

const SC: Record<string, React.FC<{d: number}>> = {O01: S01, O02: S02, O03: S03, O04: S04, O05: S05, O06: S06, O07: S07, O08: S08, O09: S09, O10: S10, O11: S11, O12: S12};

export const Osteo_ar: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill style={{direction: 'rtl'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
