// «Пролежни» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import {Clip3D} from './Clip3D';
import timing from './timing_press_en.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalPress_en = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'ORTHOPAEDICS · FOR PATIENTS';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Пролежни: сцены R01–R11 ----
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10)}}><Note size={28} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const Box: React.FC<{y: number; at: number; text: string; color?: string; bg?: string; label?: string}> = ({y, at, text, color, bg, label}) =>
  <Card x={64} y={y} w={952} at={at} label={label} style={color ? {border: `4px solid ${color}`, background: bg || '#fff'} : {}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink, lineHeight: 1.3}}>{text}</div>
  </Card>;
const SKINS = '#C9CED6';
const S01: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame(); const r = ease(f, fr(d, 0.55), fr(d, 0.7));
  return <>
    <Card x={64} y={470} w={420} label="PATIENT" at={4}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>Patient</div>
      
    </Card>
    <Card x={540} y={470} w={476} label="3 DAYS AGO" at={14}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>surgery: hip fracture</div>
    </Card>
    <svg width={1080} height={460} style={{position: 'absolute', left: 0, top: 700}}>
      <path d="M 300 60 L 560 60 Q 600 60 600 110 L 600 250 Q 600 330 680 340 L 800 350 Q 840 360 830 400 L 400 400 Q 300 400 300 320 Z" fill="#E4E7EC" stroke={SKINS} strokeWidth={6} />
      <ellipse cx={380} cy={370} rx={70 + 6 * r} ry={34 + 4 * r} fill={C.acc} opacity={0.75 * r} />
    </svg>
    <Notes y={1200} items={[['hardly changes position', fr(d, 0.3), C.navy, '#E3E7EF'], ['red patch on the heel', fr(d, 0.6)], ['doesn’t go pale when pressed', fr(d, 0.8)]]} />
  </>;
};
const S02: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const pts: [number, number, string][] = [[150, 150, 'back of head'], [300, 165, 'shoulder blades'], [470, 175, 'elbows'], [560, 165, 'base of spine'], [700, 150, 'hips'], [900, 170, 'heels']];
  return <>
    <svg width={1080} height={340} style={{position: 'absolute', left: 0, top: 520}}>
      <rect x={60} y={190} width={960} height={40} rx={14} fill="#C9CED6" />
      <path d="M 110 150 Q 110 110 160 110 Q 210 110 210 150 L 600 140 Q 640 130 680 140 L 940 150 Q 960 160 940 185 L 140 190 Q 110 185 110 150 Z" fill="#E4E7EC" stroke={SKINS} strokeWidth={5} />
      {pts.map(([x, y, t], i) => <g key={i} opacity={ease(f, fr(d, 0.35 + i * 0.07), fr(d, 0.4 + i * 0.07))}>
        <circle cx={x} cy={y + 10} r={20} fill={C.acc} opacity={0.8} />
        <text x={x} y={y - 30 - (i % 2) * 34} textAnchor="middle" fontFamily="'Body'" fontWeight={700} fontSize={26} fill={C.ink}>{t}</text></g>)}
    </svg>
    <Box y={920} at={fr(d, 0.05)} text="Pressure, especially with shear · damage to skin and tissue" color={C.navy} />
    <Notes y={1100} items={[['sometimes · within hours', fr(d, 0.82)]]} />
  </>;
};
const S03: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const items: [string, string][] = [['leg', 'moves little'], ['clock', 'after surgery'], ['heart', 'older age'], ['drop', 'poor nutrition'], ['head', 'reduced sensation'], ['head', 'confusion'], ['bladder', 'incontinence'], ['wound', 'thin or moist skin'], ['wound', 'previous pressure ulcers']];
  return <>{items.map(([k, t], i) => <div key={i} style={{position: 'absolute', left: 64 + (i % 2) * 480, top: 470 + Math.floor(i / 2) * 120, display: 'flex', alignItems: 'center', gap: 16, opacity: ease(f, fr(d, 0.05 + i * 0.08), fr(d, 0.1 + i * 0.08))}}><Icon k={k} s={52} c={C.mute} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink, width: 380}}>{t}</span></div>)}</>;
};
const S04: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={460} at={fr(d, 0.03)} icon="wound" text="Lasting patch · does not go pale when pressed" />
  <CheckRow y={620} at={fr(d, 0.2)} icon="wound" text="On darker skin · darker, bluish or purple" />
  <CheckRow y={780} at={fr(d, 0.42)} icon="therm" text="Warmer or cooler, firmer or softer than usual" />
  <CheckRow y={940} at={fr(d, 0.62)} icon="head" text="Pain or itching in the area" />
  <Box y={1110} at={fr(d, 0.82)} text="Tell the nurse straight away" color={C.acc} />
</>;
const S05: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame(); const ph = Math.floor((f / Math.max(1, d)) * 3) % 3;
  const lab = ['on the back', 'tilt ~30° right', 'tilt ~30° left'];
  return <>
    <Clip3D src="c3/press_tilt.mp4" y={430} h={600} d={d} dur={12} label={(t) => ['on the back', 'tilt ~30° right', 'tilt ~30° left'][t < 2.5 ? 0 : t < 7.6 ? 1 : 2]} />
    <Box y={1050} at={fr(d, 0.25)} text="How often and how to lie · the staff will say" color={C.navy} />
    <CheckRow y={1210} at={fr(d, 0.5)} icon="check" text="Can't turn alone · staff help" />
    <CheckRow y={1370} at={fr(d, 0.75)} icon="leg" text="Move yourself as much as allowed" />
  </>;
};
const S06: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame(); const p = ease(f, fr(d, 0.3), fr(d, 0.5));
  return <>
    <Clip3D src="c3/press_heel.mp4" y={430} d={d} dur={7} />
    <Notes y={1195} items={[['pillow · under the whole lower leg', fr(d, 0.35), C.teal, C.tealL], ['heel not touching the bed', fr(d, 0.5)], ['sometimes · special devices', fr(d, 0.68), C.navy, '#E3E7EF'], ['within post-operative restrictions', fr(d, 0.82), C.navy, '#E3E7EF']]} />
  </>;
};
const S07: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={470} at={fr(d, 0.03)} icon="shower" text="Clean, dry skin" />
  <Box y={640} at={fr(d, 0.2)} text="Don't rub or massage red areas" color={C.acc} />
  <CheckRow y={800} at={fr(d, 0.55)} icon="check" text="Sheets without creases or crumbs" />
  <Box y={960} at={fr(d, 0.78)} text="Don't drag the person across the bed" color={C.acc} />
</>;
const S08: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.05)} icon="check" text="Varied diet" />
  <CheckRow y={660} at={fr(d, 0.25)} icon="drop" text="Drink enough, if no restriction" />
  <Box y={840} at={fr(d, 0.55)} text="Poor appetite · tell the staff" color="#B45309" bg="#FFF7ED" />
  <Notes y={1000} items={[['a dietitian may be needed', fr(d, 0.8), C.navy, '#E3E7EF']]} />
</>;
const S09: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <svg width={1080} height={260} style={{position: 'absolute', left: 0, top: 480}}>
      {Array.from({length: 12}, (_, i) => <rect key={i} x={70 + i * 78} y={80 + 12 * Math.sin(f / 8 + i)} width={70} height={110} rx={20} fill={C.tealL} stroke={C.teal} strokeWidth={4} />)}
    </svg>
    <Box y={780} at={fr(d, 0.05)} text="Pressure-spreading mattress · chosen by staff" color={C.teal} bg={C.tealL} />
    <Box y={960} at={fr(d, 0.6)} text="Position must still be changed regularly" color={C.acc} />
  </>;
};
const S10: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={240} at={fr(d, 0.02)} title="Doctor or nurse · the same day" color="#B45309" bg="#FFF7ED"
    items={[['wound', 'patch doesn’t go pale when pressed'], ['wound', 'unusual darkening of skin'], ['wound', 'sore over a bone']]} />
  <Tier y={750} h={300} at={fr(d, 0.45)} title="Urgent assessment" color={C.blood} bg="#FDECEC"
    items={[['therm', 'skin hot, swollen'], ['wound', 'pus'], ['therm', 'fever'], ['head', 'pain getting worse']]} />
</>;
const S11: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>These are general recommendations</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>Individual instructions from your doctor and medical team take priority</div>
  </Card>
);
const SC: Record<string, React.FC<{d: number}>> = {R01: S01, R02: S02, R03: S03, R04: S04, R05: S05, R06: S06, R07: S07, R08: S08, R09: S09, R10: S10, R11: S11};

export const Press_en: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
