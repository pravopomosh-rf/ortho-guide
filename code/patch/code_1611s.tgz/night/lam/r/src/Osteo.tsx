// «Операция при переломе: остеосинтез» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import {Clip3D} from './Clip3D';
import timing from './timing_osteo.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalOsteo = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'ОРТОПЕДИЯ · ПАЦИЕНТАМ';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Остеосинтез: сцены O01–O12 ----
const BONE = '#EFE6D8', BONES = '#C9B79C', MET = '#5B6B82';
// схема голени спереди: большеберцовая кость с косым переломом, малоберцовая рядом
const Leg: React.FC<{top?: number; disp?: number; plate?: number; nail?: number; wire?: number; wound?: number; heal?: number; left?: number; sc?: number}> =
  ({top = 470, disp = 0, plate = 0, nail = 0, wire = 0, wound = 0, heal = 0, left = 0, sc = 1}) => {
  const lower = `translate(${44 * disp} ${22 * disp}) rotate(${7 * disp} 512 412)`;
  const screwsUp = [270, 330], screwsDn = [500, 570];
  return <svg width={1080} height={900} viewBox="0 0 1080 900" style={{position: 'absolute', left, top, transform: `scale(${sc})`, transformOrigin: 'top center'}}>
    {/* кожа голени */}
    <path d="M 360 20 C 350 200 380 380 400 560 C 410 680 420 800 430 890 L 700 890 C 705 800 715 680 725 560 C 745 380 760 200 750 20 Z" fill="#F6E7DC" stroke="#E7CDBB" strokeWidth={4} />
    {/* малоберцовая */}
    <path d="M 640 70 L 664 70 L 668 870 L 644 870 Z" fill={BONE} stroke={BONES} strokeWidth={4} />
    {/* верхний отломок */}
    <path d="M 420 40 L 610 40 C 610 95 572 125 566 170 L 568 392 L 456 432 L 458 170 C 452 125 420 95 420 40 Z" fill={BONE} stroke={BONES} strokeWidth={4} />
    <rect x={494} y={150} width={36} height={250} rx={18} fill="#F7F1E7" />
    {/* нижний отломок */}
    <g transform={lower}>
      <path d="M 456 434 L 568 394 L 566 770 C 572 815 600 835 600 870 L 428 870 C 428 835 456 815 458 770 Z" fill={BONE} stroke={BONES} strokeWidth={4} />
      <rect x={494} y={440} width={36} height={320} rx={18} fill="#F7F1E7" />
    </g>
    {/* линия перелома */}
    <line x1={452} y1={433} x2={572} y2={392} stroke={C.acc} strokeWidth={5} opacity={(1 - heal) * (0.5 + 0.5 * disp)} />
    {heal > 0 && <ellipse cx={512} cy={412} rx={80} ry={34} fill="#EADBC2" opacity={0.85 * heal} />}
    {/* стержень внутри кости + блокирующие винты */}
    {nail > 0 && <g opacity={nail}>
      <rect x={501} y={60} width={22} height={760 * nail} rx={11} fill={MET} />
      {nail > 0.95 && [120, 165, 730, 775].map((y) => <line key={y} x1={450} y1={y} x2={576} y2={y} stroke={MET} strokeWidth={9} strokeLinecap="round" />)}
    </g>}
    {/* пластина с винтами */}
    {plate > 0 && <g opacity={plate}>
      {[...screwsUp, ...screwsDn].map((y) => <line key={y} x1={450} y1={y} x2={574} y2={y} stroke={MET} strokeWidth={8} strokeLinecap="round" />)}
      <rect x={492} y={235} width={40} height={370} rx={14} fill="#7C8BA1" stroke={MET} strokeWidth={4} />
      {[...screwsUp, ...screwsDn].map((y) => <circle key={y} cx={512} cy={y} r={11} fill={MET} />)}
    </g>}
    {/* спицы */}
    {wire > 0 && <g opacity={wire}><line x1={430} y1={350} x2={600} y2={470} stroke={MET} strokeWidth={6} /><line x1={600} y1={340} x2={432} y2={470} stroke={MET} strokeWidth={6} /></g>}
    {/* рана над переломом */}
    {wound > 0 && <g opacity={wound}><path d="M 395 400 C 405 392 420 392 430 402" stroke={C.blood} strokeWidth={10} fill="none" strokeLinecap="round" />
      <circle cx={412} cy={400} r={34} fill="none" stroke={C.blood} strokeWidth={4} strokeDasharray="8 8" /></g>}
  </svg>;
};

const S01: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Card x={64} y={470} w={420} label="ПАЦИЕНТ" at={4}>
      <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 52, color: C.ink}}>Пациент</div>
      <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 28, color: C.mute}}>упал с лестницы</div>
    </Card>
    <Card x={540} y={470} w={476} label="СНИМОК" at={14}>
      <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 40, color: C.acc}}>перелом со смещением</div>
    </Card>
    <Leg top={700} sc={0.78} disp={ease(f, fr(d, 0.45), fr(d, 0.7))} />
    <div style={{position: 'absolute', left: 64, top: 1420, display: 'flex', gap: 12, flexWrap: 'wrap'}}>
      {['боль', 'отёк', 'не наступить'].map((t, i) => <div key={t} style={{opacity: ease(f, fr(d, 0.25) + i * 8, fr(d, 0.25) + 10 + i * 8)}}><Note size={28}>{t}</Note></div>)}
    </div>
  </>;
};
const S02: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const red = ease(f, fr(d, 0.08), fr(d, 0.28));
  const pl = ease(f, fr(d, 0.3), fr(d, 0.42)) * (1 - ease(f, fr(d, 0.58), fr(d, 0.64)));
  const nl = ease(f, fr(d, 0.64), fr(d, 0.82));
  return <>
    <Leg top={440} sc={0.85} disp={1 - red} plate={pl} nail={nl} />
    <div style={{position: 'absolute', left: 64, top: 1240, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
      <div style={{opacity: red}}><Note color={C.teal} bg={C.tealL} size={28}>отломки сопоставлены</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.32), fr(d, 0.4))}}><Note color={C.navy} bg="#E3E7EF" size={28}>пластина + винты</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.66), fr(d, 0.74))}}><Note color={C.navy} bg="#E3E7EF" size={28}>стержень внутри кости</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.8), fr(d, 0.86))}}><Note color={C.navy} bg="#E3E7EF" size={28}>спицы — при некоторых других переломах</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.86), fr(d, 0.94))}}><Note size={28}>кость срастается сама</Note></div>
    </div>
    <div style={{position: 'absolute', left: 64, top: 1200, fontFamily: BODY, fontWeight: 600, fontSize: 22, color: C.mute}}>схема, не в масштабе · варианты фиксации</div>
  </>;
};
const S03: React.FC<{d: number}> = ({d}) => {
  const items = ['значительное смещение', 'нестабильный перелом', 'повреждение суставной поверхности со смещением'];
  return <>
    {items.map((t, i) => <Slot key={t} x={64} y={470 + i * 150} w={952} h={130} at={fr(d, 0.15 + i * 0.1)}>
      <Icon k="check" s={64} /><div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>{t}</div></Slot>)}
    <Card x={64} y={950} w={952} at={fr(d, 0.02)} style={{background: C.navy}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: '#fff'}}>Решает хирург по осмотру и снимкам</div>
    </Card>
    <Card x={64} y={1140} w={952} at={fr(d, 0.7)} label="БЕЗ СМЕЩЕНИЯ">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>Часто без операции: гипс, ортез или повязка</div>
    </Card>
  </>;
};
const S04: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Leg top={440} sc={0.6} left={-250} wound={ease(f, fr(d, 0.05), fr(d, 0.2))} />
    <div style={{position: 'absolute', left: 560, top: 470, width: 456, display: 'flex', flexDirection: 'column', gap: 16}}>
      {[['рана рядом — перелом может быть открытым', C.blood], ['кость не обязательно видна', C.ink], ['не промывать глубокую рану', C.ink], ['не вправлять кость', C.ink], ['чистая повязка', C.teal]].map(([t, c], i) =>
        <div key={i} style={{opacity: ease(f, fr(d, 0.1 + i * 0.12), fr(d, 0.18 + i * 0.12)), fontFamily: BODY, fontWeight: 700, fontSize: 30, color: c as string, background: '#fff', borderRadius: 18, padding: '14px 18px'}}>{t}</div>)}
    </div>
    <Card x={64} y={1100} w={952} at={fr(d, 0.75)} style={{background: '#FDECEC', border: `4px solid ${C.blood}`}}>
      <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.blood}}>101 — сразу</div>
    </Card>
  </>;
};
const S05: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={470} at={fr(d, 0.02)} icon="leg" text="Шина или гипс · конечность на возвышении" />
  <CheckRow y={690} at={fr(d, 0.18)} icon="therm" text="Пальцы: цвет, тепло, чувствительность, движения" />
  <Card x={64} y={910} w={952} at={fr(d, 0.4)} style={{border: `4px solid #B45309`, background: '#FFF7ED'}} label="СРАЗУ СКАЖИТЕ ПЕРСОНАЛУ">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>Боль резко усилилась · или онемение, покалывание, холодные, бледные или синеватые пальцы</div>
  </Card>
  <Card x={64} y={1180} w={952} at={fr(d, 0.75)} label="АЛЛЕРГИЯ НА МЕТАЛЛ">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>Особенно на никель — сообщите хирургу</div>
  </Card>
</>;
const S06: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={470} at={fr(d, 0.02)} icon="drop" text="Общая или регионарная анестезия — объяснит анестезиолог" />
  <CheckRow y={700} at={fr(d, 0.35)} icon="clock" text="Рентген во время операции: отломки и металл" />
  <CheckRow y={930} at={fr(d, 0.7)} icon="wound" text="Швы или скобы · повязка" />
</>;
const S07: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={470} at={fr(d, 0.02)} icon="leg" text="Рука или нога на возвышении · двигайте пальцами" />
  <Card x={64} y={630} w={952} at={fr(d, 0.25)} style={{background: C.navy}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 40, color: '#fff'}}>Нагрузка — только по разрешению хирурга</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 28, color: '#DCE3EE', marginTop: 10}}>Ранняя нагрузка может сместить отломки или сломать конструкцию</div>
  </Card>
  <CheckRow y={900} at={fr(d, 0.7)} icon="leg" text="Ходунки или костыли — научит физиотерапевт" />
  <Clip3D src="c3/walker_walk.mp4" y={1040} h={430} pos="50% 15%" d={d} dur={6} at={fr(d, 0.66)} />
</>;
const S08: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={470} at={fr(d, 0.02)} icon="pills" text="Обезболивающие — по схеме · не добавлять самим" />
  <Card x={64} y={700} w={952} at={fr(d, 0.35)} label="ТРОМБЫ">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>После перелома ноги риск выше · профилактику решает команда, не всем</div>
  </Card>
  <Card x={64} y={960} w={952} at={fr(d, 0.7)} style={{border: `4px solid ${C.acc}`}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>Не отменяйте и не добавляйте такие препараты сами</div>
  </Card>
</>;
const S09: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Leg top={440} sc={0.62} left={-250} plate={1} heal={ease(f, fr(d, 0.05), fr(d, 0.6))} />
    <Card x={560} y={470} w={456} label="СРАЩЕНИЕ" at={4}>
      <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 40, color: C.ink}}>недели → месяцы</div>
      <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 26, color: C.mute}}>иногда дольше</div>
    </Card>
    <Card x={560} y={720} w={456} at={fr(d, 0.3)} style={{border: `4px solid ${C.acc}`}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.ink}}>Боль проходит раньше, чем кость станет прочной</div>
    </Card>
    <CheckRow y={1060} at={fr(d, 0.55)} icon="clock" text="Контрольные осмотры и снимки" />
    <CheckRow y={1270} at={fr(d, 0.8)} icon="wound" text="Рана чистая · повязка по указаниям" />
  </>;
};
const S10: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={470} w={952} at={fr(d, 0.02)} label="МЕТАЛЛ">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>Часто остаётся в кости, если не мешает · удаление решает хирург</div>
  </Card>
  <Card x={64} y={730} w={952} at={fr(d, 0.35)} style={{border: `4px solid ${C.navy}`}} label="МРТ">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>Заранее скажите персоналу, что у вас есть металл</div>
  </Card>
  <Card x={64} y={990} w={952} at={fr(d, 0.68)} label="ОСТЕОПОРОЗ">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>Перелом после небольшого падения — обсудите обследование с семейным врачом</div>
  </Card>
</>;
const S11: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={230} at={fr(d, 0.02)} title="101 — сразу" color={C.blood} bg="#FDECEC"
    items={[['lungs', 'внезапная одышка'], ['heart', 'боль в груди']]} />
  <Tier y={730} h={360} at={fr(d, 0.2)} title="Немедленно — экстренная помощь" color="#B45309" bg="#FFF7ED"
    items={[['leg', 'сильная нарастающая боль: не проходит от обезболивающего или усиливается при движении пальцами'], ['leg', 'онемение'], ['therm', 'холодные, бледные или синеватые пальцы'], ['leg', 'гипс сильно давит'], ['faint', 'за руль не садиться · не добраться безопасно — 101']]} />
  <Tier y={1120} h={300} at={fr(d, 0.65)} title="В тот же день к врачу" color={C.navy} bg="#fff"
    items={[['therm', '38 °C и выше'], ['wound', 'покраснение, отёк, выделения из раны'], ['calf', 'новая боль или отёк икры']]} />
</>;
const S12: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>Это общие рекомендации</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>Индивидуальные указания вашего врача и медицинской команды имеют приоритет</div>
  </Card>
);

const SC: Record<string, React.FC<{d: number}>> = {O01: S01, O02: S02, O03: S03, O04: S04, O05: S05, O06: S06, O07: S07, O08: S08, O09: S09, O10: S10, O11: S11, O12: S12};

export const Osteo: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
