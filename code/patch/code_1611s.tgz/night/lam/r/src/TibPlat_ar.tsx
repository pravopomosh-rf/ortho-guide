// «Перелом плато большеберцовой кости» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {KneeFront, SchatzkerGrid, KneeTests, CompartmentLeg, BraceNoWeight, ExFixKnee} from './TibArt';
import {CallBell} from './WardArt';
import {Clip3D} from './Clip3D';
import {Person, Icon} from './Figures';
import {WalkDaily} from './LimbArt';
import timing from './timing_tibplat_ar.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalTibPlat_ar = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'جراحة العظام · للمرضى';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Плато: сцены TP01–TP12 ----
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10)}}><Note size={28} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const Hint: React.FC<{t: string; y: number}> = ({t, y}) => <div style={{position: 'absolute', left: 64, right: 64, top: y, fontFamily: BODY, fontWeight: 600, fontSize: 24, color: C.mute}}>{t}</div>;
const S01: React.FC<{d: number}> = ({d}) => { const f = useCurrentFrame();
  return <><Card x={64} y={470} w={420} label='المريض' at={4}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>مريض</div>
      </Card>
    <Card x={540} y={470} w={476} label='السبب' at={14}><div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink}}>سقوط عن سلّم</div></Card>
    <KneeFront top={700} h={480} frac={ease(f, fr(d, 0.6), fr(d, 0.75))} />
    <Notes y={1200} items={[['تورّم شديد', fr(d, 0.3)], ['لا يمكن الوقوف عليها', fr(d, 0.42)], ['كسر هضبة الظنبوب', fr(d, 0.75)]]} /></>; };
const S02: React.FC<{d: number}> = ({d}) => { const f = useCurrentFrame();
  return <><KneeFront top={470} frac={ease(f, fr(d, 0.6), fr(d, 0.75))} />
  <Hint t='الركبة اليمنى من الأمام · رسم توضيحي، ليس بالمقياس' y={1080} />
  <Notes y={1120} items={[['الهضبة · السطح المفصلي السفلي للركبة', fr(d, 0.25), C.navy, '#E3E7EF'], ['مغطّاة بالغضروف', fr(d, 0.45), C.teal, C.tealL], ['كسر داخل المفصل', fr(d, 0.75)]]} /></>; };
const S03: React.FC<{d: number}> = ({d}) => <>
  <SchatzkerGrid top={470} d={d} />
  <Hint t='تصنيف شاتزكر · رسم توضيحي' y={1070} />
</>;
const S04: React.FC<{d: number}> = ({d}) => <>
  <KneeTests top={470} d={d} />
  <Notes y={920} items={[['الأشعة السينية', fr(d, 0.05), C.navy, '#E3E7EF'], ['التصوير المقطعي المحوسب · رؤية الشظايا بدقة', fr(d, 0.3), C.navy, '#E3E7EF'], ['الجلد · نبض القدم · الإحساس', fr(d, 0.6), C.teal, C.tealL]]} />
</>;
const S05: React.FC<{d: number}> = ({d}) => <>
  <CompartmentLeg top={470} d={d} />
  <Tier y={950} h={300} at={fr(d, 0.15)} title='أبلغوا الطاقم فورًا' color={C.blood} bg="#FDECEC"
    items={[['head', 'ألم شديد على غير العادة أو يشتدّ بسرعة'], ['leg', 'شعور بالضغط والانتفاخ في الساق'], ['leg', 'خدر جديد في القدم']]} />
  <CallBell x={900} y={1290} s={0.6} at={fr(d, 0.7)} press={fr(d, 0.78)} />
</>;
const S06: React.FC<{d: number}> = ({d}) => <>
  <BraceNoWeight top={470} d={d} />
  <Notes y={950} items={[['الشظايا لم تتحرّك تقريبًا · المفصل مستوٍ', fr(d, 0.05), C.navy, '#E3E7EF'], ['جبيرة أو جبس', fr(d, 0.35), C.teal, C.tealL], ['لا تحميل على الساق', fr(d, 0.55)]]} />
</>;
const S07: React.FC<{d: number}> = ({d}) => { const f = useCurrentFrame(); const up = ease(f, fr(d, 0.25), fr(d, 0.45));
  return <><KneeFront top={470} frac={1} dep={24 * (1 - up)} graft={ease(f, fr(d, 0.6), fr(d, 0.7))} plate={ease(f, fr(d, 0.45), fr(d, 0.6))} />
  <Notes y={1090} items={[['إعادة بناء سطح المفصل', fr(d, 0.25), C.navy, '#E3E7EF'], ['صفيحة وبراغٍ', fr(d, 0.5), C.teal, C.tealL], ['أحيانًا · طُعم عظمي أو بديل للعظم', fr(d, 0.68)]]} /></>; };
const S08: React.FC<{d: number}> = ({d}) => <>
  <ExFixKnee top={470} d={d} />
  <Notes y={1000} items={[['تورّم · فقاعات · إصابة الأنسجة الرخوة', fr(d, 0.05)], ['يُؤجَّل التثبيت النهائي أحيانًا', fr(d, 0.3), C.navy, '#E3E7EF'], ['مثبّت خارجي مؤقّت · في الحالات المعقّدة', fr(d, 0.6), C.teal, C.tealL]]} />
</>;
const S09: React.FC<{d: number}> = ({d}) => <>
  <Clip3D src="c3/swell_pump.mp4" y={470} h={440} d={d} dur={6} at={fr(d, 0.02)} />
  <Notes y={940} items={[['الساق مرفوعة · تحريك الأصابع والقدم', fr(d, 0.05), C.teal, C.tealL], ['التبريد والمسكّنات · حسب التعليمات', fr(d, 0.3), C.navy, '#E3E7EF'], ['الركبة · حسب برنامج المعالج الفيزيائي', fr(d, 0.5), C.navy, '#E3E7EF'], ['الجلطات · أدوية بحسب تقييم الطبيب، غالبًا حقن', fr(d, 0.7)]]} />
</>;
const S10: React.FC<{d: number}> = ({d}) => <>
  <Clip3D src="c3/walker_walk.mp4" y={470} h={440} d={d} dur={6} at={fr(d, 0.02)} />
  <Notes y={940} items={[['في البداية يُمنع التحميل أو يُقيَّد كثيرًا', fr(d, 0.05)], ['أسابيع · أحيانًا ثلاثة أشهر أو أكثر', fr(d, 0.3), C.navy, '#E3E7EF'], ['عكّازان أو مشّاية · يعلّمكم المعالج الفيزيائي', fr(d, 0.5), C.teal, C.tealL], ['متى وكم · الجرّاح يقرّر', fr(d, 0.75), C.navy, '#E3E7EF']]} />
</>;
const S11: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={330} at={fr(d, 0.02)} title='فورًا · مساعدة طبية عاجلة' color={C.blood} bg="#FDECEC"
    items={[['head', 'ألم ضاغط يشتدّ'], ['leg', 'خدر جديد'], ['drop', 'القدم باردة أو شاحبة']]} />
  <Tier y={830} h={220} at={fr(d, 0.45)} title='اتصلوا 101' color={C.blood} bg="#fff"
    items={[['lungs', 'ضيق تنفّس مفاجئ'], ['heart', 'ألم في الصدر']]} />
  <Tier y={1080} h={220} at={fr(d, 0.75)} title='إلى الطبيب في اليوم نفسه' color="#B45309" bg="#FFF7ED"
    items={[['therm', 'حرارة'], ['wound', 'إفرازات من الجرح']]} />
</>;
const S12: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>هذه توصيات عامة</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>التعليمات الفردية من طبيبكم والفريق الطبي لها الأولوية</div>
  </Card>
);
const SC: Record<string, React.FC<{d: number}>> = {TP01: S01, TP02: S02, TP03: S03, TP04: S04, TP05: S05, TP06: S06, TP07: S07, TP08: S08, TP09: S09, TP10: S10, TP11: S11, TP12: S12};

export const TibPlat_ar: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
