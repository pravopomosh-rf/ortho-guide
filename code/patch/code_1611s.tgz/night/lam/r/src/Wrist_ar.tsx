// «Перелом запястья» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import timing from './timing_wrist_ar.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalWrist_ar = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'جراحة العظام · للمرضى';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Перелом дистального отдела лучевой кости: сцены Z01–Z10 ----
const SKIN = '#E4E7EC', SKINS = '#C9CED6', BONE = '#EFE6D8', BONES = '#C9B79C';
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10)}}><Note size={28} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const Hint: React.FC<{t: string; y?: number}> = ({t, y = 1200}) => <div style={{position: 'absolute', left: 64, top: y, fontFamily: BODY, fontWeight: 600, fontSize: 22, color: C.mute}}>{t}</div>;
// предплечье ладонью вверх, горизонтально: локоть слева, кисть справа; лучевая кость сверху (сторона большого пальца)
const Forearm: React.FC<{frac?: number; top?: number; plate?: number; pins?: number; exfix?: number; cast?: number; labels?: boolean}> = ({frac = 0, top = 520, plate = 0, pins = 0, exfix = 0, cast = 0, labels = true}) => <svg width={1080} height={520} style={{position: 'absolute', left: 0, top}}>
  <path d="M 60 150 C 300 130 600 130 760 150 L 820 140 L 1000 120 L 1040 250 L 1000 330 L 820 320 L 760 310 C 600 330 300 330 60 310 Z" fill={SKIN} stroke={SKINS} strokeWidth={4} />
  <path d="M 100 190 C 400 175 640 172 770 182 L 790 168 L 805 230 L 770 225 C 640 215 400 215 100 225 Z" fill={BONE} stroke={BONES} strokeWidth={4} />
  <path d="M 100 245 C 400 250 640 255 760 262 L 775 290 L 760 296 C 640 290 400 285 100 280 Z" fill={BONE} stroke={BONES} strokeWidth={4} />
  {frac > 0 && <path d="M 726 168 L 734 186 L 728 204 L 738 224" stroke={C.acc} strokeWidth={6} fill="none" strokeLinecap="round" opacity={frac} />}
  <g opacity={plate}><path d="M 630 192 L 760 186 L 795 176 L 800 222 L 760 214 L 630 210 Z" fill="#8E99A8" stroke="#5B6575" strokeWidth={3} opacity={0.9} />{[[655, 201], [700, 199], [745, 197], [775, 190], [780, 210]].map(([x, y]) => <circle key={x + '' + y} cx={x} cy={y} r={6} fill={C.navy} />)}</g>
  <g opacity={pins}>{[[700, 150, 800, 230], [720, 150, 790, 240]].map(([a, b, c, d], i) => <line key={i} x1={a} y1={b} x2={c} y2={d} stroke="#5B6575" strokeWidth={6} strokeLinecap="round" />)}</g>
  <g opacity={exfix}><rect x={560} y={80} width={420} height={18} rx={8} fill="#8E99A8" />{[600, 640, 900, 940].map((x) => <line key={x} x1={x} y1={98} x2={x} y2={200} stroke="#5B6575" strokeWidth={8} />)}</g>
  <g opacity={cast}><path d="M 380 140 L 900 125 L 900 330 L 380 325 Z" fill="#F4F6F9" stroke="#AEB6C2" strokeWidth={5} opacity={0.92} /></g>
  {labels && <g fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.mute}><text textAnchor="end" x={110} y={120}>عظم الكعبرة</text><text textAnchor="end" x={110} y={370}>عظم الزند</text><text textAnchor="end" x={60} y={460}>المرفق</text><text textAnchor="end" x={940} y={460}>اليد</text></g>}
</svg>;

const S01: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Card x={64} y={470} w={420} label="المريضة" at={4}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>مريضة</div>
      
    </Card>
    <Card x={540} y={470} w={476} label="السبب" at={14}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>سقوط على يد ممدودة</div>
    </Card>
    <Forearm frac={ease(f, fr(d, 0.65), fr(d, 0.8))} top={720} labels={false} />
    <Notes y={1300} items={[['ألم', fr(d, 0.35)], ['تورّم', fr(d, 0.42)], ['اعوجاج', fr(d, 0.5)], ['كسر قرب الرسغ', fr(d, 0.8)]]} />
  </>;
};
const S02: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Forearm frac={ease(f, fr(d, 0.3), fr(d, 0.45))} top={500} />
    <Hint t="رسم توضيحي، ليس بالمقياس · الساعد وراحة اليد للأعلى" y={1060} />
    <Notes y={1110} items={[['أكثر مواضع كسور الذراع شيوعًا', fr(d, 0.35)], ['مع هشاشة العظام · حتى بعد سقوط بسيط', fr(d, 0.7), C.navy, '#E3E7EF']]} />
  </>;
};
const S03: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Forearm frac={1} cast={ease(f, fr(d, 0.4), fr(d, 0.6))} top={500} labels={false} />
    <Notes y={1060} items={[['ردّ دون شق مع تسكين الألم', fr(d, 0.2)], ['أولًا جبيرة · ثم جبس', fr(d, 0.5), C.navy, '#E3E7EF'], ['صور متكررة', fr(d, 0.8), C.teal, C.tealL]]} />
  </>;
};
const Mini: React.FC<{y: number; at: number; t: string; plate?: number; pins?: number; exfix?: number}> = ({y, at, t, plate = 0, pins = 0, exfix = 0}) => {
  const f = useCurrentFrame(); const p = ease(f, at, at + 14);
  return <div style={{position: 'absolute', left: 64, top: y, width: 952, height: 230, opacity: p, background: '#fff', borderRadius: 24, boxShadow: '0 14px 34px rgba(20,24,32,.08)', overflow: 'hidden'}}>
    <div style={{position: 'absolute', left: -260, top: -70, transform: 'scale(0.62)', transformOrigin: '700px 200px'}}><Forearm top={0} frac={1} plate={plate} pins={pins} exfix={exfix} labels={false} /></div>
    <div style={{position: 'absolute', left: 30, bottom: 18, fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>{t}</div>
  </div>;
};
const S04: React.FC<{d: number}> = ({d}) => <>
  <Mini y={470} at={fr(d, 0.35)} t="صفيحة وبراغٍ" plate={1} />
  <Mini y={720} at={fr(d, 0.47)} t="أسلاك" pins={1} />
  <Mini y={970} at={fr(d, 0.59)} t="مثبّت خارجي" exfix={1} />
  <Card x={64} y={1220} w={952} at={fr(d, 0.8)} style={{background: C.navy}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: '#fff'}}>يختار الجرّاح الطريقة</div>
  </Card>
</>;
const S05: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.02)} icon="check" text="الذراع مرفوعة · اليد أعلى من المرفق" />
  <CheckRow y={700} at={fr(d, 0.35)} icon="shower" text="جبس جاف · تغطيته بكيس عند الاستحمام" />
  <Card x={64} y={920} w={952} at={fr(d, 0.7)} style={{border: `4px solid ${C.acc}`}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>لا تُدخلوا شيئًا تحت الجبس</div>
  </Card>
</>;
const S06: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame(); const k = (Math.sin(f / 7) + 1) / 2;
  return <>
    <svg width={1080} height={420} style={{position: 'absolute', left: 0, top: 480}}>
      <rect x={180} y={140} width={420} height={160} rx={30} fill="#F4F6F9" stroke="#AEB6C2" strokeWidth={5} />
      {[0, 1, 2, 3].map((i) => <rect key={i} x={600} y={150 + i * 36} width={60 + 80 * (1 - k)} height={28} rx={14} fill={SKIN} stroke={SKINS} strokeWidth={3} />)}
      <rect x={560} y={110} width={70 + 40 * (1 - k)} height={30} rx={15} fill={SKIN} stroke={SKINS} strokeWidth={3} transform="rotate(-20 560 125)" />
    </svg>
    <CheckRow y={960} at={fr(d, 0.05)} icon="check" text="تحريك الأصابع · في أقرب وقت" />
    <Card x={64} y={1170} w={952} at={fr(d, 0.5)} style={{border: `4px solid #B45309`, background: '#FFF7ED'}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.ink}}>صعوبة تحريك الأصابع بالجبس · لا تنتظروا يومًا: اطلبوا المساعدة فورًا</div>
    </Card>
  </>;
};
const S07: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={400} at={fr(d, 0.02)} title="مساعدة طبية عاجلة" color="#B45309" bg="#FFF7ED"
    items={[['drop', 'خدر أو وخز في الأصابع، أو شحوب أو ازرقاق أو برودة'], ['head', 'ألم شديد لا يزول أو يزداد'], ['head', 'ألم شديد عند فرد الأصابع بلطف'], ['leg', 'ضعف في الإبهام أو السبابة']]} />
</>;
const S08: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const pts: [string, string, number][] = [['4–6 أسابيع', 'يُنزع الجبس', 0.1], ['نحو 3 أشهر', 'اليد لكل الأعمال', 0.45], ['نحو سنة', 'التعافي · أحيانًا أطول', 0.75]];
  return <>
    <div style={{position: 'absolute', left: 120, top: 560, width: 840, height: 8, borderRadius: 4, background: C.line}} />
    <div style={{position: 'absolute', left: 120, top: 560, width: 840 * ease(f, fr(d, 0.05), fr(d, 0.85)), height: 8, borderRadius: 4, background: C.teal}} />
    {pts.map(([a, b, p], i) => <div key={i} style={{position: 'absolute', left: 70 + i * 340, top: 600, width: 280, opacity: ease(f, fr(d, p), fr(d, p) + 10)}}>
      <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 34, color: C.ink}}>{a}</div>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.mute, marginTop: 6}}>{b}</div></div>)}
    <Notes y={900} items={[['العلاج الطبيعي', fr(d, 0.2), C.navy, '#E3E7EF'], ['التيبّس يخفّ على مدى أشهر', fr(d, 0.4), C.teal, C.tealL]]} />
  </>;
};
const S09: React.FC<{d: number}> = ({d}) => <>
  <svg width={1080} height={420} style={{position: 'absolute', left: 0, top: 480}}>
    <rect x={340} y={40} width={400} height={340} rx={40} fill={BONE} stroke={BONES} strokeWidth={4} />
    {Array.from({length: 24}, (_, i) => <circle key={i} cx={380 + (i % 6) * 64} cy={90 + Math.floor(i / 6) * 76} r={10 + (i * 7) % 12} fill="#fff" stroke={BONES} strokeWidth={2} />)}
  </svg>
  <Notes y={960} items={[['قد يكون أول علامة على هشاشة العظام', fr(d, 0.1)], ['خطر الكسر التالي أعلى', fr(d, 0.4)], ['كثافة العظام', fr(d, 0.65), C.navy, '#E3E7EF'], ['الوقاية من السقوط', fr(d, 0.8), C.teal, C.tealL]]} />
</>;
const S10: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>هذه توصيات عامة</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>تعليمات طبيبكم والفريق الطبي الخاصة بكم لها الأولوية</div>
  </Card>
);
const SC: Record<string, React.FC<{d: number}>> = {Z01: S01, Z02: S02, Z03: S03, Z04: S04, Z05: S05, Z06: S06, Z07: S07, Z08: S08, Z09: S09, Z10: S10};

export const Wrist_ar: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill style={{direction: 'rtl'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
