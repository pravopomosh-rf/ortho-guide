// «Артроскопия колена» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import {Clip3D} from './Clip3D';
import timing from './timing_arth_en.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalArth_en = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'ORTHOPAEDICS · FOR PATIENTS';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Артроскопия колена: сцены A01–A05, A07–A11 ----
const BONE = '#EFE6D8', BONES = '#C9B79C', MEN = '#F2D27A', MENS = '#C99A1E';
// колено спереди (схема): бедро сверху с двумя мыщелками, большеберцовая снизу, два мениска-клина между ними
const Knee: React.FC<{tear?: number; repair?: number; trim?: number; glow?: number; children?: React.ReactNode; top?: number; label?: boolean}> = ({tear = 0, repair = 0, trim = 0, glow = 0, children, top = 470, label = true}) => (
  <svg width={1080} height={760} viewBox="140 0 800 563" style={{position: 'absolute', left: 0, top}}>
    {/* бедренная кость */}
    <path d="M 450 0 L 630 0 L 640 150 C 700 170 720 210 700 245 C 680 270 620 268 590 250 L 540 228 L 490 250 C 460 268 400 270 380 245 C 360 210 380 170 440 150 Z" fill={BONE} stroke={BONES} strokeWidth={4} />
    {/* большеберцовая кость */}
    <path d="M 360 300 L 720 300 C 730 330 700 350 660 360 L 640 560 L 440 560 L 420 360 C 380 350 350 330 360 300 Z" fill={BONE} stroke={BONES} strokeWidth={4} />
    {/* хрящ */}
    <path d="M 382 250 C 400 268 460 266 490 250" stroke="#BFE3E8" strokeWidth={8} fill="none" />
    <path d="M 590 250 C 620 266 680 268 698 250" stroke="#BFE3E8" strokeWidth={8} fill="none" />
    {/* мениски: клинья у краёв, тоньше к центру */}
    <path d="M 360 300 L 365 262 C 380 270 420 280 470 292 L 470 300 Z" fill={MEN} stroke={MENS} strokeWidth={3} />
    <path d={`M 720 300 L 715 262 C ${700 - 0} 270 660 280 ${610 + 40 * trim} 292 L ${610 + 40 * trim} 300 Z`} fill={MEN} stroke={MENS} strokeWidth={3} />
    {tear > 0 && <path d="M 640 268 L 655 300" stroke={C.acc} strokeWidth={5 * tear} strokeLinecap="round" opacity={tear * (1 - repair)} />}
    {repair > 0 && <g opacity={repair}>{[0, 1, 2].map((i) => <path key={i} d={`M ${632 + i * 10} 270 L ${648 + i * 10} 298`} stroke={C.teal} strokeWidth={4} strokeLinecap="round" />)}</g>}
    {glow > 0 && <circle cx={540} cy={280} r={150} fill={C.acc} opacity={0.18 * glow} />}
    {children}
    {label && <text x={150} y={540} fontFamily="'Body'" fontWeight={700} fontSize={22} fill={C.mute}>diagram, not to scale · front view, kneecap not shown</text>}
  </svg>
);

const S01: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const pulse = ease(f, fr(d, 0.35), fr(d, 0.45)) * (0.6 + 0.4 * Math.sin(f / 5));
  return <>
    <Card x={64} y={470} w={420} label="PATIENT" at={4}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>Patient</div>
      
    </Card>
    <Card x={540} y={470} w={476} label="INJURY" at={14}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>sharp twist on one leg</div>
    </Card>
    <Knee glow={pulse} top={700} label={false} />
    <div style={{position: 'absolute', left: 64, top: 1415, display: 'flex', gap: 14}}>
      {['pain', 'swelling', 'locking'].map((t, i) => <div key={t} style={{opacity: ease(f, fr(d, 0.45) + i * 8, fr(d, 0.45) + 10 + i * 8)}}><Note size={30}>{t}</Note></div>)}
    </div>
  </>;
};

const TibiaTop: React.FC<{tear: number}> = ({tear}) => (
  <svg width={1080} height={620} viewBox="0 0 1080 620" style={{position: 'absolute', left: 0, top: 470}}>
    <path d="M 160 320 C 160 120 400 70 540 110 C 680 70 920 120 920 320 C 920 470 760 540 540 520 C 320 540 160 470 160 320 Z" fill={BONE} stroke={BONES} strokeWidth={5} />
    {/* медиальный мениск (C-образный, слева на схеме) */}
    <path d="M 500 150 C 300 130 200 230 210 330 C 220 440 340 490 500 480 L 490 430 C 360 430 280 390 275 320 C 270 240 340 190 495 205 Z" fill={MEN} stroke={MENS} strokeWidth={4} />
    {/* латеральный мениск (почти кольцо, справа) */}
    <path d="M 585 150 C 760 120 880 220 870 330 C 860 440 740 490 585 470 L 600 420 C 720 430 800 390 805 320 C 810 240 730 190 595 205 Z" fill={MEN} stroke={MENS} strokeWidth={4} />
    {tear > 0 && <path d="M 228 300 C 250 340 262 380 300 420" stroke={C.acc} strokeWidth={7} fill="none" strokeLinecap="round" opacity={tear} />}
    <text x={250} y={600} fontFamily="'Body'" fontWeight={700} fontSize={26} fill={C.mute}>medial</text>
    <text x={680} y={600} fontFamily="'Body'" fontWeight={700} fontSize={26} fill={C.mute}>lateral</text>
  </svg>
);
const S02: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <TibiaTop tear={ease(f, fr(d, 0.15), fr(d, 0.3))} />
    <div style={{position: 'absolute', left: 640, top: 1130, width: 1080, height: 760, transform: 'scale(0.36)', transformOrigin: '0 0', opacity: ease(f, fr(d, 0.5), fr(d, 0.6))}}><div style={{position: 'relative'}}><Knee tear={1} top={0} label={false} /></div></div>
    <div style={{position: 'absolute', left: 700, top: 1410, fontFamily: BODY, fontWeight: 600, fontSize: 20, color: C.mute, opacity: ease(f, fr(d, 0.5), fr(d, 0.6))}}>front view: menisci between the bones</div>
    <div style={{position: 'absolute', left: 64, top: 1110, fontFamily: BODY, fontWeight: 600, fontSize: 22, color: C.mute}}>diagram, not to scale · shin bone, top view</div>
    <div style={{position: 'absolute', left: 64, top: 1160, width: 560, display: 'flex', gap: 16, flexWrap: 'wrap'}}>
      <div style={{opacity: ease(f, fr(d, 0.15), fr(d, 0.25))}}><Note size={30}>meniscus tear</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.4), fr(d, 0.5))}}><Note color="#9A7410" bg="#FBF0D0" size={30}>the meniscus spreads the load and protects cartilage</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.7), fr(d, 0.8))}}><Note color={C.navy} bg="#E3E7EF" size={30}>examination + scans → surgeon decides</Note></div>
    </div>
  </>;
};

const S03: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const items = ['some meniscus tears', 'rebuilding the anterior cruciate ligament', 'loose fragments in the joint'];
  return <>
    {items.map((t, i) => <Slot key={i} x={64} y={480 + i * 190} w={952} h={160} at={fr(d, 0.08 + i * 0.16)}>
      <Icon k="check" s={64} /><div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink, lineHeight: 1.2}}>{t}</div></Slot>)}
    <Card x={64} y={1080} w={952} at={fr(d, 0.62)} style={{background: '#F1F2F4'}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.mute}}>Not every meniscus tear needs surgery</div>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink, marginTop: 10}}>For osteoarthritis, washing out or "cleaning" the joint is not recommended</div>
    </Card>
  </>;
};

const Scope: React.FC<{p: number; q: number}> = ({p, q}) => <g>
  {/* артроскоп слева-снизу, инструмент справа-снизу */}
  <line x1={260} y1={420} x2={260 + (500 - 260) * p} y2={420 + (285 - 420) * p} stroke="#6B7686" strokeWidth={12} strokeLinecap="round" />
  <rect x={225} y={410} width={46} height={40} rx={8} fill={C.navy} transform="rotate(-30 248 430)" />
  <line x1={820} y1={420} x2={820 + (600 - 820) * q} y2={420 + (285 - 420) * q} stroke="#9AA5AE" strokeWidth={8} strokeLinecap="round" />
  <circle cx={430} cy={330} r={9} fill={C.acc} opacity={p > 0 ? 1 : 0} /><circle cx={680} cy={330} r={9} fill={C.acc} opacity={q > 0 ? 1 : 0} />
</g>;
const Screen: React.FC<{o: number; tear: number; repair?: number}> = ({o, tear, repair = 0}) => (
  <div style={{position: 'absolute', left: 620, top: 470, width: 400, height: 300, borderRadius: 24, background: '#1B2333', opacity: o, overflow: 'hidden', boxShadow: '0 14px 34px rgba(20,24,32,.2)'}}>
    <svg width={400} height={300}><circle cx={200} cy={150} r={130} fill="#E9B8A6" />
      <path d="M 90 190 C 150 120 250 120 310 190 L 290 200 C 240 150 160 150 110 200 Z" fill={MEN} stroke={MENS} strokeWidth={3} />
      {tear > 0 && <path d="M 200 140 L 215 175" stroke={C.acc} strokeWidth={5} opacity={1 - repair} />}
      {repair > 0 && [0, 1, 2].map((i) => <path key={i} d={`M ${192 + i * 9} 140 L ${206 + i * 9} 172`} stroke={C.teal} strokeWidth={4} opacity={repair} />)}
    </svg>
    <div style={{position: 'absolute', left: 16, top: 12, fontFamily: MONO, fontWeight: 700, fontSize: 18, color: '#fff'}}>SCREEN</div>
  </div>
);
const S04: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const p = ease(f, fr(d, 0.15), fr(d, 0.35)), q = ease(f, fr(d, 0.35), fr(d, 0.5)), s = ease(f, fr(d, 0.6), fr(d, 0.7));
  return <>
    <Knee tear={1} top={715}><Scope p={p} q={q} /></Knee>
    <Screen o={s} tear={1} />
    <div style={{position: 'absolute', left: 64, top: 480, display: 'flex', flexDirection: 'column', gap: 14, width: 520}}>
      <div style={{opacity: p}}><Note color={C.navy} bg="#E3E7EF" size={28}>usually 2–3 small cuts</Note></div>
      <div style={{opacity: p}}><Note size={28}>arthroscope with a camera</Note></div>
      <div style={{opacity: q}}><Note color="#4B5563" bg="#E5E7EB" size={28}>thin instruments</Note></div>
      <div style={{opacity: s}}><Note color={C.teal} bg={C.tealL} size={28}>sterile fluid</Note></div>
    </div>
  </>;
};

const S05: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const r = ease(f, fr(d, 0.15), fr(d, 0.4));
  return <>
    <Knee tear={1} repair={r} top={715}><Scope p={1} q={1} /></Knee>
    <Screen o={1} tear={1} repair={r} />
    <div style={{position: 'absolute', left: 64, top: 480, display: 'flex', flexDirection: 'column', gap: 14, width: 520}}>
      <div style={{opacity: r}}><Note color={C.teal} bg={C.tealL} size={28}>stitch the meniscus</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.3), fr(d, 0.4))}}><Note size={28}>or remove the part that cannot be saved</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.5), fr(d, 0.6))}}><Note color={C.navy} bg="#E3E7EF" size={28}>the meniscus is preserved when possible</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.8), fr(d, 0.9))}}><Note color="#9A7410" bg="#FBF0D0" size={28}>often a day operation</Note></div>
    </div>
  </>;
};

const S06: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={500} at={fr(d, 0.02)} icon="pills" text="Blood thinners: tell your doctor, do not stop them yourself" />
  <CheckRow y={720} at={fr(d, 0.3)} icon="razor" text="Do not shave your leg before surgery" />
  <Card x={64} y={940} w={952} at={fr(d, 0.6)} label="ANAESTHESIA">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>General, spinal or sometimes local, chosen by the anaesthetist</div>
  </Card>
</>;

const S07: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const up = ease(f, 6, fr(d, 0.3));
  return <>
    <Clip3D src="c3/swell_elevate_nl.mp4" y={430} h={520} d={d} dur={8} />
    <Card x={64} y={980} w={952} at={fr(d, 0.4)} label="COLD">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>Through a cloth · 20 min every 2–3 h · once feeling returns</div>
    </Card>
    <div style={{position: 'absolute', left: 64, top: 1230, opacity: ease(f, fr(d, 0.8), fr(d, 0.9))}}><Note size={30}>severe pain or not easing — seek help</Note></div>
  </>;
};

const S08: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const a = Math.sin(f / 7) * 0.5 + 0.5;
  return <>
    <Clip3D src="c3/swell_pump.mp4" y={430} h={410} d={d} dur={9} label={() => 'foot up and down · tighten thigh muscles'} />
    <Card x={64} y={860} w={952} at={fr(d, 0.55)} label="MEDICINES AGAINST CLOTS">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>Not everyone needs them · if prescribed, follow the plan exactly</div>
    </Card>
  </>;
};

const S09: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Card x={64} y={480} w={952} at={2} style={{borderLeft: `8px solid ${C.teal}`}}>
      <div style={{fontFamily: MONO, fontWeight: 700, fontSize: 20, color: C.teal, letterSpacing: 2}}>SMALL ARTHROSCOPY</div>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink, marginTop: 8}}>Often you can put weight on it early, sometimes with crutches</div>
    </Card>
    <Card x={64} y={760} w={952} at={fr(d, 0.4)} style={{borderLeft: `8px solid ${C.acc}`}}>
      <div style={{fontFamily: MONO, fontWeight: 700, fontSize: 20, color: C.acc, letterSpacing: 2}}>MENISCUS REPAIR · LIGAMENT</div>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink, marginTop: 8}}>Weight-bearing and bending may be limited, or a brace prescribed</div>
    </Card>
    <div style={{position: 'absolute', left: 64, top: 1060, opacity: ease(f, fr(d, 0.8), fr(d, 0.9))}}><Note color={C.navy} bg="#E3E7EF" size={32}>follow your own plan</Note></div>
  </>;
};

const S10: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.02)} icon="clock" text="An adult with you the first day · at least 24 h no driving, no alcohol" />
  <CheckRow y={700} at={fr(d, 0.45)} icon="wound" text="Dressing clean and dry · do not soak the knee" />
  <CheckRow y={920} at={fr(d, 0.8)} icon="leg" text="Drive only with doctor's approval · exercises per your plan" />
</>;

const S11: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={430} at={fr(d, 0.02)} title="Call 101 immediately" color={C.blood} bg="#FDECEC"
    items={[['lungs', 'sudden shortness of breath'], ['heart', 'chest pain'], ['drop', 'severe pain getting worse quickly'], ['leg', 'foot cold, pale or bluish'], ['leg', 'hard to move the toes']]} />
  <Tier y={930} h={330} at={fr(d, 0.25)} title="See a doctor the same day" color={C.navy} bg="#fff"
    items={[['therm', 'temperature 38 °C or higher, chills'], ['wound', 'redness, swelling, discharge from the wound'], ['calf', 'new calf pain or swelling']]} />
</>;

const S12: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>These are general recommendations</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>Individual instructions from your doctor and medical team come first</div>
  </Card>
);

const SC: Record<string, React.FC<{d: number}>> = {A01: S01, A02: S02, A03: S03, A04: S04, A05: S05, A06: S06, A07: S07, A08: S08, A09: S09, A10: S10, A11: S11, A12: S12};

export const Arth_en: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
