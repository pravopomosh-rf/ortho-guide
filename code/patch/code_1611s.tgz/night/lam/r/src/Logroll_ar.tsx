// «Техника бревна» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import {Clip3D} from './Clip3D';
import timing from './timing_logroll_ar.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalLogroll_ar = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'جراحة العظام · للمرضى';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Бревно: сцены G01–G09 ----
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10)}}><Note size={28} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const Box: React.FC<{y: number; at: number; text: string; color?: string; bg?: string; label?: string}> = ({y, at, text, color, bg, label}) =>
  <Card x={64} y={y} w={952} at={at} label={label} style={color ? {border: `4px solid ${color}`, background: bg || '#fff'} : {}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink, lineHeight: 1.3}}>{text}</div>
  </Card>;
const Cross: React.FC<{y: number; at: number; text: string}> = ({y, at, text}) => <Box y={y} at={at} text={`✕ ${text}`} color={C.acc} />;
const Step: React.FC<{y: number; at: number; n: string; text: string}> = ({y, at, n, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 24}}>
      <div style={{width: 64, height: 64, borderRadius: 32, background: C.acc, color: '#fff', fontFamily: HEAD, fontWeight: 800, fontSize: 34, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: ease(f, at, at + 8)}}>{n}</div>
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink, lineHeight: 1.25}}>{text}</div>
    </div>
  </Card>;
};
const Fig: React.FC<{k: number; y: number}> = ({k, y}) => {
  // k: 0 на спине с согнутыми коленями, 1 на боку, 2 сидя на краю
  return <svg width={1080} height={360} style={{position: 'absolute', left: 0, top: y}}>
    <rect x={120} y={250} width={620} height={40} rx={14} fill="#C9CED6" />
    {k === 0 && <g stroke="#C9CED6" strokeLinecap="round" fill="none"><circle cx={200} cy={215} r={30} fill="#E4E7EC" strokeWidth={5} /><line x1={235} y1={225} x2={470} y2={225} strokeWidth={40} /><path d="M 470 225 L 560 150 L 640 225" strokeWidth={30} strokeLinejoin="round" /></g>}
    {k === 1 && <g stroke="#C9CED6" strokeLinecap="round" fill="none"><circle cx={200} cy={200} r={30} fill="#E4E7EC" strokeWidth={5} /><line x1={235} y1={215} x2={470} y2={215} strokeWidth={46} /><path d="M 470 215 L 580 170 L 650 225" strokeWidth={30} strokeLinejoin="round" /></g>}
    {k === 2 && <g stroke="#C9CED6" strokeLinecap="round" fill="none"><circle cx={700} cy={40} r={30} fill="#E4E7EC" strokeWidth={5} /><line x1={700} y1={80} x2={700} y2={230} strokeWidth={40} /><path d="M 700 230 L 800 240 L 800 340" strokeWidth={30} strokeLinejoin="round" /></g>}
  </svg>;
};
const S01: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={470} w={420} label="المريض" at={4}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>مريض</div>
    
  </Card>
  <Card x={540} y={470} w={476} label="أمس" at={14}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>عملية في أسفل العمود الفقري</div>
  </Card>
  <Cross y={740} at={fr(d, 0.5)} text="الجلوس بحركة مفاجئة مباشرة من السرير" />
</>;
const S02: React.FC<{d: number}> = ({d}) => <>
  <Box y={480} at={fr(d, 0.05)} text="الكتفان · الحوض · الساقان · معًا" color={C.teal} bg={C.tealL} />
  <Cross y={650} at={fr(d, 0.3)} text="لفّ الظهر" />
  <CheckRow y={810} at={fr(d, 0.55)} icon="leg" text="سيُريكم المعالج الطبيعي الطريقة" />
  <Box y={980} at={fr(d, 0.62)} text="المرة الأولى · فقط مع الطاقم" color={C.acc} />
  <Box y={1130} at={fr(d, 0.82)} text="النهوض · فقط بإذن الفريق" color={C.navy} />
</>;
const S03: React.FC<{d: number}> = ({d}) => <>
  <Clip3D src="c3/logroll_getup.mp4" y={430} d={d} from={0.6} dur={2.8} />
  <Step y={1190} at={fr(d, 0.05)} n="1" text="الركبتان منثنيتان والقدمان على السرير" />
  <Notes y={1370} items={[['شدّ عضلات البطن', fr(d, 0.6), C.navy, '#E3E7EF']]} />
</>;
const S04: React.FC<{d: number}> = ({d}) => <>
  <Clip3D src="c3/logroll_getup.mp4" y={430} d={d} from={3.2} dur={2.4} />
  <Step y={1190} at={fr(d, 0.05)} n="2" text="على الجنب بحركة واحدة · الكتفان والحوض معًا" />
  <Cross y={1370} at={fr(d, 0.55)} text="مدّ اليد إلى الحاجز من فوق الجسم" />
</>;
const S05: React.FC<{d: number}> = ({d}) => <>
  <Clip3D src="c3/logroll_getup.mp4" y={430} d={d} from={5.6} dur={4.2} />
  <Step y={1190} at={fr(d, 0.05)} n="3" text="الساقان إلى الأسفل + الدفع بالمرفق والكفّ" />
  <Notes y={1370} items={[['الظهر مستقيم', fr(d, 0.7), C.teal, C.tealL]]} />
</>;
const S06: React.FC<{d: number}> = ({d}) => <>
  <Step y={480} at={fr(d, 0.03)} n="4" text="الجلوس على الحافة والقدمان على الأرض" />
  <Box y={660} at={fr(d, 0.15)} text="دوار · لا تنهضوا، نادوا الطاقم" color="#B45309" bg="#FFF7ED" />
  <CheckRow y={820} at={fr(d, 0.45)} icon="check" text="النهوض: الدفع باليدين على السرير" />
  <CheckRow y={980} at={fr(d, 0.65)} icon="leg" text="المشّاية · فقط بعد الوقوف" />
  <Cross y={1140} at={fr(d, 0.82)} text="سحب النفس بالمشّاية" />
</>;
const S07: React.FC<{d: number}> = ({d}) => <>
  <Clip3D src="c3/logroll_liedown.mp4" y={430} d={d} dur={9.4} label={(t) => t < 2.8 ? '1 · الجلوس على حافة السرير' : t < 6.4 ? '2 · على الجنب بالاستناد إلى اليد + الساقان إلى السرير' : '3 · على الظهر · مثل جذع الشجرة'} />
</>;
const S08: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={440} at={fr(d, 0.02)} title="تقييم عاجل: في المستشفى · الطاقم · في البيت · الطوارئ / 101" color={C.blood} bg="#FDECEC"
    items={[['leg', 'ضعف جديد أو خدر في الساقين'], ['head', 'خدر حول الأعضاء التناسلية أو فتحة الشرج'], ['bladder', 'عدم القدرة على التبوّل، فقدان السيطرة على البول أو البراز']]} />
  <Box y={880} at={fr(d, 0.82)} text="اشتدّ الألم كثيرًا · إلى الطبيب بشكل عاجل" color="#B45309" bg="#FFF7ED" />
</>;
const S09: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>هذه توصيات عامة</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>التعليمات الشخصية من طبيبكم والمعالج الطبيعي والفريق الطبي لها الأولوية</div>
  </Card>
);
const SC: Record<string, React.FC<{d: number}>> = {G01: S01, G02: S02, G03: S03, G04: S04, G05: S05, G06: S06, G07: S07, G08: S08, G09: S09};

export const Logroll_ar: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill style={{direction: 'rtl'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
