// «Как не упасть» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import {Clip3D} from './Clip3D';
import {CallBell} from './WardArt';
import timing from './timing_falls_he.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalFalls_he = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'אורתופדיה · למטופלים';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Падения: сцены Q01–Q11 ----
const SKIN = '#E4E7EC', SKINS = '#C9CED6';
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10)}}><Note size={28} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const Walker: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => <g transform={`translate(${x} ${y}) scale(${s})`} stroke="#6B7686" strokeWidth={8} fill="none" strokeLinecap="round">
  <path d="M 0 0 L 120 0 M 10 0 L 0 200 M 110 0 L 120 200 M 5 100 L 115 100" /></g>;
const Room: React.FC<{top?: number; dark?: number; d?: number}> = ({top = 700, dark = 0}) => <svg width={1080} height={520} style={{position: 'absolute', left: 0, top}}>
  <rect x={0} y={0} width={1080} height={520} rx={28} fill="#1B2333" opacity={0.9 * dark} />
  <rect x={120} y={260} width={560} height={50} rx={14} fill="#C9CED6" /><rect x={120} y={310} width={18} height={130} fill="#C9CED6" /><rect x={662} y={310} width={18} height={130} fill="#C9CED6" />
  <rect x={150} y={225} width={150} height={40} rx={18} fill="#fff" stroke={SKINS} strokeWidth={3} />
  <Walker x={880} y={240} s={0.9} />
  <rect x={760} y={120} width={80} height={320} rx={8} fill="none" stroke="#8E99A8" strokeWidth={6} strokeDasharray="10 8" opacity={0.6} />
  <text textAnchor="end" x={760} y={110} fontFamily="'Body'" fontWeight={700} fontSize={22} fill={dark > 0.5 ? '#fff' : C.mute}>שירותים</text>
</svg>;
const S01: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Card x={64} y={470} w={420} label="מטופלת" at={4}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>מטופלת</div>
      
    </Card>
    <Card x={540} y={470} w={476} label="לפני יומיים" at={14}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>החלפת מפרק ירך</div>
    </Card>
    <Room top={720} dark={ease(f, fr(d, 0.3), fr(d, 0.5))} />
    <Notes y={1280} items={[['בלילה · לבד · בלי הליכון · בלי אור', fr(d, 0.5)]]} />
  </>;
};
const S02: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const items: [string, string][] = [['leg', 'חולשה'], ['head', 'סחרחורת'], ['pills', 'משככי כאבים ותרופות שינה'], ['head', 'חדר לא מוכר'], ['tube', 'עירוי וצינורות'], ['clock', 'לשירותים בלילה']];
  return <>{items.map(([k, t], i) => <div key={i} style={{position: 'absolute', left: 64 + (i % 2) * 480, top: 480 + Math.floor(i / 2) * 160, display: 'flex', alignItems: 'center', gap: 16, opacity: ease(f, fr(d, 0.05 + i * 0.1), fr(d, 0.1 + i * 0.1))}}><Icon k={k} s={56} c={C.mute} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink, width: 380}}>{t}</span></div>)}
    <Notes y={1000} items={[['נפילה · סיכון לפציעה חדשה', fr(d, 0.75)]]} /></>;
};
const S03: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame(); const p = ease(f, fr(d, 0.2), fr(d, 0.3)) * (1 - ease(f, fr(d, 0.35), fr(d, 0.45)));
  return <>
    <CallBell x={400} y={430} s={0.95} at={fr(d, 0.05)} press={fr(d, 0.3)} />
    <Notes y={960} items={[['הלחצן · בהישג יד', fr(d, 0.1)], ['ללחוץ ולחכות לצוות', fr(d, 0.45), C.navy, '#E3E7EF'], ['זו עבודה רגילה של המחלקה', fr(d, 0.75), C.teal, C.tealL]]} />
  </>;
};
const S04: React.FC<{d: number}> = ({d}) => <>
  <Clip3D src="c3/falls_sitfeet.mp4" y={430} h={600} d={d} dur={7} />
  <CheckRow y={1050} at={fr(d, 0.02)} icon="check" text="לשבת על קצה המיטה ולהזיז את כפות הרגליים" />
  <Card x={64} y={1200} w={952} at={fr(d, 0.35)} style={{border: `4px solid #B45309`, background: '#FFF7ED'}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>סחרחורת · לשכב ולקרוא לצוות</div>
  </Card>
  <CheckRow y={1340} at={fr(d, 0.7)} icon="check" text="לקום · כשהסחרחורת חלפה; עם עזרה, אם הונחיתם" />
</>;
const S05: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.02)} icon="check" text="הליכון או קביים · ליד המיטה" />
  <Card x={64} y={700} w={952} at={fr(d, 0.45)} style={{border: `4px solid ${C.acc}`}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>לא להישען על שידה, שולחן על גלגלים, מעמד עירוי</div>
  </Card>
</>;
const S06: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.02)} icon="check" text="נעליים סגורות במידה, סוליה לא מחליקה" />
  <CheckRow y={700} at={fr(d, 0.4)} icon="check" text="משקפיים ומכשיר שמיעה · אם צריך" />
  <CheckRow y={920} at={fr(d, 0.7)} icon="check" text="בלילה · אור" />
</>;
const S07: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={480} w={952} at={fr(d, 0.02)} style={{border: `4px solid ${C.acc}`}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>לפנות שטיחונים, חוטים וחפצים מיותרים</div>
  </Card>
  <CheckRow y={700} at={fr(d, 0.3)} icon="shower" text="אמבטיה: שטיחון נגד החלקה ומאחזי יד" />
  <CheckRow y={900} at={fr(d, 0.55)} icon="check" text="בלילה · אור בדרך לשירותים" />
  <CheckRow y={1100} at={fr(d, 0.78)} icon="check" text="הטלפון · עליכם" />
</>;
const S08: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={480} w={952} at={fr(d, 0.02)} label="תרופות">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>ישנוניות או סחרחורת · לדבר עם רופא או רוקח, לא להפסיק לבד</div>
  </Card>
  <CheckRow y={780} at={fr(d, 0.65)} icon="check" text="לבדוק ראייה ושמיעה באופן קבוע" />
</>;
const S09: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.02)} icon="leg" text="תרגילי כוח ושיווי משקל · כשהרופא יתיר" />
  <CheckRow y={700} at={fr(d, 0.6)} icon="drop" text="לשתות מספיק, אם אין הגבלה" />
</>;
const S10: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={220} at={fr(d, 0.02)} title="בבית החולים" color={C.navy} bg="#fff"
    items={[['head', 'לא לקום לבד · לחצן הקריאה']]} />
  <Tier y={720} h={340} at={fr(d, 0.35)} title="בבית · 101" color={C.blood} bg="#FDECEC"
    items={[['head', 'כאב חזק, במיוחד במפרק המנותח'], ['head', 'חשד לפגיעה בראש, בצוואר, בגב או בירך'], ['leg', 'לא מצליחים לקום · לא לנסות לקום לבד']]} />
  <Card x={64} y={1040} w={952} at={fr(d, 0.75)}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>על כל נפילה · ספרו לרופא</div>
  </Card>
</>;
const S11: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>אלה המלצות כלליות</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>ההוראות האישיות של הרופא ושל הצוות הרפואי קודמות</div>
  </Card>
);
const SC: Record<string, React.FC<{d: number}>> = {Q01: S01, Q02: S02, Q03: S03, Q04: S04, Q05: S05, Q06: S06, Q07: S07, Q08: S08, Q09: S09, Q10: S10, Q11: S11};

export const Falls_he: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill style={{direction: 'rtl'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
