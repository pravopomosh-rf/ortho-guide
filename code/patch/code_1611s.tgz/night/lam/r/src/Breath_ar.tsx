// «Дыхательные упражнения» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import {Clip3D} from './Clip3D';
import timing from './timing_breath_ar.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalBreath_ar = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'جراحة العظام · للمرضى';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Дыхание: сцены L01–L10 ----
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10)}}><Note size={28} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const Box: React.FC<{y: number; at: number; text: string; color?: string; bg?: string; label?: string}> = ({y, at, text, color, bg, label}) =>
  <Card x={64} y={y} w={952} at={at} label={label} style={color ? {border: `4px solid ${color}`, background: bg || '#fff'} : {}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink, lineHeight: 1.3}}>{text}</div>
  </Card>;
const Lungs: React.FC<{k: number; y: number; mucus?: number}> = ({k, y, mucus = 0}) => <svg width={1080} height={420} style={{position: 'absolute', left: 0, top: y}}>
  <line x1={540} y1={20} x2={540} y2={120} stroke="#8E99A8" strokeWidth={14} strokeLinecap="round" />
  <path d={`M 530 120 Q ${400 - 40 * k} 120 ${380 - 50 * k} 260 Q ${370 - 50 * k} ${380 + 20 * k} 500 ${370 + 20 * k} Q 525 300 530 120 Z`} fill={C.accL} stroke={C.acc} strokeWidth={5} />
  <path d={`M 550 120 Q ${680 + 40 * k} 120 ${700 + 50 * k} 260 Q ${710 + 50 * k} ${380 + 20 * k} 580 ${370 + 20 * k} Q 555 300 550 120 Z`} fill={C.accL} stroke={C.acc} strokeWidth={5} />
  {[[505, 150], [470, 190], [575, 150], [610, 190]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r={11} fill="#B9A24A" opacity={mucus} />)}
  <path d={`M ${400 - 50 * k} 300 Q ${420 - 30 * k} 340 470 340`} stroke="#8E99A8" strokeWidth={4} strokeDasharray="8 8" fill="none" opacity={mucus} />
</svg>;
const S01: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={470} w={420} label="المريض" at={4}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>مريض</div>
    
  </Card>
  <Card x={540} y={470} w={476} label="قبل يومين" at={14}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>استبدال مفصل الورك</div>
  </Card>
  <Notes y={720} items={[['استلقى كثيرًا', fr(d, 0.25), C.navy, '#E3E7EF'], ['تنفّس بسطحية', fr(d, 0.35), C.navy, '#E3E7EF'], ['يكاد لا يسعل', fr(d, 0.45), C.navy, '#E3E7EF']]} />
  <Box y={900} at={fr(d, 0.68)} label="اليوم الثالث" text="حرارة، سعال مع بلغم" color={C.acc} />
</>;
const S02: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Lungs k={0.15 * Math.sin(f / 10)} y={440} mucus={ease(f, fr(d, 0.25), fr(d, 0.45))} />
    <Notes y={880} items={[['تنفّس سطحي', fr(d, 0.05), C.navy, '#E3E7EF'], ['أجزاء من الرئتين تتمدّد أقل', fr(d, 0.25)], ['البلغم يبقى في القصبات', fr(d, 0.35)], ['خطر مضاعفات الرئة', fr(d, 0.48)]]} />
    <CheckRow y={1060} at={fr(d, 0.62)} icon="lungs" text="تنفّس عميق" />
    <CheckRow y={1190} at={fr(d, 0.72)} icon="check" text="السعال" />
    <CheckRow y={1320} at={fr(d, 0.82)} icon="leg" text="الحركة" />
  </>;
};
const S03: React.FC<{d: number}> = ({d}) => <>
  <Clip3D src="c3/breath_breathe.mp4" y={430} d={d} dur={8} />
  <CheckRow y={1190} at={fr(d, 0.03)} icon="check" text="جلوسًا: على كرسي أو مع رفع مسند السرير إن كان مسموحًا" />
  <CheckRow y={1320} at={fr(d, 0.5)} icon="check" text="الكتفان مرتخيان" />
  <Box y={1430} at={fr(d, 0.75)} text="لا تنزلقوا إلى أسفل السرير" color={C.acc} />
</>;
const S04: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const a = fr(d, 0.05), b = fr(d, 0.35), c = fr(d, 0.5), e = fr(d, 0.75);
  const k = f < b ? ease(f, a, b) : f < c ? 1 : 1 - ease(f, c, e);
  const lab = f < b ? 'شهيق · من الأنف' : f < c ? 'توقّف · نحو 3 ثوانٍ' : 'زفير · من الفم';
  return <>
    <Lungs k={k} y={440} />
    <div style={{position: 'absolute', left: 0, right: 0, top: 900, textAlign: 'center', fontFamily: HEAD, fontWeight: 800, fontSize: 52, color: C.acc}}>{lab}</div>
    <Notes y={1020} items={[['3 إلى 5 مرات، ثم راحة', fr(d, 0.82), C.teal, C.tealL]]} />
  </>;
};
const S05: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.05)} icon="lungs" text="السعال إذا كان هناك بلغم" />
  <CheckRow y={660} at={fr(d, 0.4)} icon="check" text="مؤلم · شهيق عميق، ثم زفير قوي من فم مفتوح، كأنكم تُضبّبون مرآة" />
  <Box y={860} at={fr(d, 0.75)} text="عادةً لا يضرّ السعال بالغرز" color={C.teal} bg={C.tealL} />
</>;
const S06: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.05)} icon="clock" text="عدة مرات في الساعة أثناء اليقظة" />
  <Notes y={680} items={[['أو كما يقول المعالج الطبيعي', fr(d, 0.35), C.navy, '#E3E7EF']]} />
  <Box y={800} at={fr(d, 0.62)} text="دوار · توقّفوا وتنفّسوا بهدوء" color="#B45309" bg="#FFF7ED" />
</>;
const S07: React.FC<{d: number}> = ({d}) => <>
  <Box y={520} at={fr(d, 0.05)} text="التنفّس العميق أو السعال مؤلم · أخبروا الممرضة" color={C.acc} />
  <CheckRow y={720} at={fr(d, 0.6)} icon="pills" text="تسكين الألم يساعد على أداء التمارين" />
</>;
const S08: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.05)} icon="leg" text="الجلوس والمشي · عندما يسمح الفريق" />
  <Box y={680} at={fr(d, 0.6)} text="المرة الأولى · فقط مع الطاقم" color={C.navy} />
</>;
const S09: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={300} at={fr(d, 0.02)} title="أخبروا الممرضة فورًا" color="#B45309" bg="#FFF7ED"
    items={[['lungs', 'ضيق نفس'], ['heart', 'ألم في الصدر'], ['therm', 'حرارة'], ['lungs', 'سعال مع بلغم'], ['head', 'الشعور بأنكم أسوأ']]} />
  <Tier y={810} h={220} at={fr(d, 0.62)} title="في البيت · 101" color={C.blood} bg="#FDECEC"
    items={[['lungs', 'ضيق نفس مفاجئ'], ['heart', 'ألم في الصدر']]} />
</>;
const S10: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>هذه توصيات عامة</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>التعليمات الشخصية من طبيبكم والمعالج الطبيعي والفريق الطبي لها الأولوية</div>
  </Card>
);
const SC: Record<string, React.FC<{d: number}>> = {L01: S01, L02: S02, L03: S03, L04: S04, L05: S05, L06: S06, L07: S07, L08: S08, L09: S09, L10: S10};

export const Breath_ar: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill style={{direction: 'rtl'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
