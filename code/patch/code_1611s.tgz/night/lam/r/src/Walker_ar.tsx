// «Ходунки» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, OffthreadVideo, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import timing from './timing_walker_ar.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalWalker_ar = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'جراحة العظام · للمرضى';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Ходунки: сцены W01–W10 ----
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10)}}><Note size={28} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const Box: React.FC<{y: number; at: number; text: string; color?: string; bg?: string; label?: string}> = ({y, at, text, color, bg, label}) =>
  <Card x={64} y={y} w={952} at={at} label={label} style={color ? {border: `4px solid ${color}`, background: bg || '#fff'} : {}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink, lineHeight: 1.3}}>{text}</div>
  </Card>;
const WF: React.FC<{x: number; y: number; s?: number; c?: string}> = ({x, y, s = 1, c = '#6B7686'}) => <g transform={`translate(${x} ${y}) scale(${s})`} stroke={c} strokeWidth={9} fill="none" strokeLinecap="round">
  <path d="M 0 0 L 140 0 M 10 0 L 0 230 M 130 0 L 140 230 M 5 110 L 135 110" /></g>;
const Cross: React.FC<{y: number; at: number; text: string}> = ({y, at, text}) => <Box y={y} at={at} text={`✕ ${text}`} color={C.acc} />;
const S01: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={470} w={420} label="المريض" at={4}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>مريض</div>
    
  </Card>
  <Card x={540} y={470} w={476} label="مؤخرًا" at={14}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>استبدال مفصل الركبة</div>
  </Card>
  <Cross y={720} at={fr(d, 0.3)} text="المشّاية بعيدة جدًا إلى الأمام" />
  <Cross y={880} at={fr(d, 0.62)} text="النهوض بالإمساك بالمشّاية" />
</>;
const S02: React.FC<{d: number}> = ({d}) => <>
  <Box y={480} at={fr(d, 0.03)} text="التحميل على الساق · يحدّده الطبيب" color={C.navy} />
  <CheckRow y={650} at={fr(d, 0.35)} icon="leg" text="كيف تمشون · يُريكم المعالج الطبيعي" />
  <Notes y={820} items={[['مشّاية دون عجلات، 4 أرجل', fr(d, 0.55), C.navy, '#E3E7EF'], ['مع عجلات · طريقة مختلفة', fr(d, 0.65), C.navy, '#E3E7EF']]} />
  <Box y={960} at={fr(d, 0.82)} text="المرة الأولى · فقط مع الطاقم" color={C.acc} />
</>;
// 3D-вставка clay3d: клип 1080×840, скорость подгоняется под длительность сцены; подпись шага поверх клипа по времени клипа
const Clip3D: React.FC<{src: string; y: number; d: number; dur: number; at?: number; label?: (t: number) => string | null}> = ({src, y, d, dur, at = 2, label}) => {
  const f = useCurrentFrame();
  const rate = Math.min(1.25, Math.max(0.75, dur * 30 / Math.max(1, d - at - 6)));
  const t = Math.max(0, (f - at) / 30 * rate);
  const o = ease(f, at, at + 10);
  const lab = label ? label(Math.min(t, dur - 0.05)) : null;
  return <div style={{position: 'absolute', left: 64, top: y, width: 952, height: 741, borderRadius: 34, overflow: 'hidden', boxShadow: '0 18px 50px rgba(20,40,60,.14)', opacity: o, transform: `translateY(${(1 - o) * 30}px)`}}>
    <Sequence from={at} layout="none"><OffthreadVideo src={staticFile(src)} playbackRate={rate} muted style={{width: 952, height: 741, objectFit: 'cover'}} /></Sequence>
    {lab && <div style={{position: 'absolute', left: 24, right: 24, bottom: 24, background: 'rgba(255,255,255,.92)', borderRadius: 22, padding: '16px 24px', fontFamily: BODY, fontWeight: 800, fontSize: 32, color: C.ink, lineHeight: 1.22, textAlign: 'center'}}>{lab}</div>}
  </div>;
};
const cyc = (t: number) => { const u = t - 0.6; if (u < 0) return 0; const k = u % 4.2; return k < 1.15 ? 1 : k < 2.55 ? 2 : 3; };
// Вид сверху: поворот маленькими шагами вместе с ходунками (4 шага по 22°)
const TurnTop: React.FC<{y: number; d: number}> = ({y, d}) => {
  const f = useCurrentFrame();
  const T0 = fr(d, 0.05), st = Math.max(24, Math.round((d * 0.55) / 4));
  let ang = 0, kL = 0, kR = 0;
  for (let i = 0; i < 4; i++) { const a = T0 + i * st; ang += 22 * ease(f, a, a + st * 0.35); kL = Math.max(kL, f > a + st * 0.35 && f < a + st * 0.65 ? Math.sin(Math.PI * (f - a - st * 0.35) / (st * 0.3)) : 0); kR = Math.max(kR, f > a + st * 0.65 && f < a + st * 0.95 ? Math.sin(Math.PI * (f - a - st * 0.65) / (st * 0.3)) : 0); }
  const o = ease(f, 2, 12);
  return <div style={{position: 'absolute', left: 64, top: y, width: 952, height: 560, borderRadius: 34, background: '#EEF2F4', overflow: 'hidden', opacity: o}}>
    <svg width={952} height={560}>
      <g opacity={0.35}>{[0, 1, 2, 3, 4].map((i) => <path key={i} d={`M476 300 m ${Math.cos((-90 + i * 22) * Math.PI / 180) * 230} ${Math.sin((-90 + i * 22) * Math.PI / 180) * 230} l 0 0`} stroke={C.teal} strokeWidth={14} strokeLinecap="round" />)}</g>
      <path d="M 476 300 m 0 -240 A 240 240 0 0 1 690 190" fill="none" stroke={C.teal} strokeWidth={4} strokeDasharray="10 10" opacity={0.6} />
      <g transform={`translate(476 300) rotate(${ang})`}>
        <path d="M -95 -40 L -95 -190 L 95 -190 L 95 -40" fill="none" stroke="#8E99A3" strokeWidth={14} strokeLinejoin="round" strokeLinecap="round" />
        {[[-95, -40], [-95, -190], [95, -190], [95, -40]].map(([x, yy], i) => <circle key={i} cx={x} cy={yy} r={11} fill="#59636D" />)}
        <rect x={-108} y={-120} width={26} height={60} rx={10} fill="#3B4652" /><rect x={82} y={-120} width={26} height={60} rx={10} fill="#3B4652" />
        <ellipse cx={0} cy={20} rx={78} ry={44} fill="#F4F1EC" stroke="#D9D3C9" strokeWidth={4} />
        <circle cx={0} cy={14} r={34} fill="#F4F1EC" stroke="#D9D3C9" strokeWidth={4} />
        <rect x={-48 - 0} y={-14 - 26 * kL} width={34} height={76} rx={16} fill="#3CC4AA" />
        <rect x={14} y={-14 - 26 * kR} width={34} height={76} rx={16} fill="#FAFAFA" stroke="#CBD2D9" strokeWidth={3} />
      </g>
      <text x={476} y={540} textAnchor="middle" fontFamily="Inter, sans-serif" fontWeight={800} fontSize={30} fill={C.ink}>{Math.round(ang)}°</text>
    </svg>
  </div>;
};
const S03: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Clip3D src="c3/walker_height.mp4" y={430} d={d} dur={6} />
    <Notes y={1200} items={[['المقابض · بمستوى ثنية الرسغ', fr(d, 0.35), C.teal, C.tealL], ['المرفقان منثنيان قليلًا', fr(d, 0.6)], ['الظهر مستقيم', fr(d, 0.75), C.navy, '#E3E7EF']]} />
  </>;
};
const Step: React.FC<{y: number; at: number; n: string; text: string}> = ({y, at, n, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 24}}>
      <div style={{width: 64, height: 64, borderRadius: 32, background: C.acc, color: '#fff', fontFamily: HEAD, fontWeight: 800, fontSize: 34, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: ease(f, at, at + 8)}}>{n}</div>
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink, lineHeight: 1.25}}>{text}</div>
    </div>
  </Card>;
};
const S04: React.FC<{d: number}> = ({d}) => <>
  <Clip3D src="c3/walker_walk.mp4" y={430} d={d} dur={13.8} label={(t) => ['1 · المشّاية · قليلًا إلى الأمام، الأرجل الأربع على الأرض', '1 · المشّاية · قليلًا إلى الأمام، الأرجل الأربع على الأرض', '2 · اليدان على المقابض · قدّموا الساق التي خضعت للجراحة إلى الوسط، لا حتى العارضة الأمامية', '3 · الاتكاء على المقابض · تقريب الساق السليمة'][cyc(t)]} />
  <Notes y={1200} items={[['خطوات صغيرة', fr(d, 0.3), C.teal, C.tealL]]} />
</>;
const S05: React.FC<{d: number}> = ({d}) => <>
  <TurnTop y={430} d={d} />
  <CheckRow y={1010} at={fr(d, 0.1)} icon="check" text="الاستدارة ببطء، بخطوات صغيرة، مع المشّاية" />
  <Cross y={1180} at={fr(d, 0.45)} text="فجأة على ساق واحدة" />
  <CheckRow y={1300} at={fr(d, 0.72)} icon="check" text="النظر إلى الأمام لا إلى القدمين" />
</>;
const S06: React.FC<{d: number}> = ({d}) => <>
  <Clip3D src="c3/walker_sit.mp4" y={430} d={d} dur={7} label={(t) => t < 1 ? '1 · الظهر إلى كرسي ثابت حتى تشعر الساقان بالمقعد' : t < 2.9 ? '2 · اليدان من المشّاية · إلى المسندين، واحدة تلو الأخرى' : '3 · الجلوس ببطء'} />
  <Cross y={1200} at={fr(d, 0.7)} text="الإمساك بالمشّاية أثناء الجلوس" />
</>;
const S07: React.FC<{d: number}> = ({d}) => <>
  <Clip3D src="c3/walker_stand.mp4" y={430} d={d} dur={7} label={(t) => t < 4.1 ? 'الدفع باليدين على مسندي الذراعين أو المقعد' : 'وقفتم مستقيمين · أمسكوا المقابض'} />
  <Cross y={1200} at={fr(d, 0.55)} text="سحب المشّاية نحوكم · قد تنقلب" />
</>;
const S08: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={440} at={fr(d, 0.03)} icon="check" text="إزالة السجاد والأسلاك والأغراض الزائدة" />
  <CheckRow y={600} at={fr(d, 0.25)} icon="check" text="ليلًا · ضوء" />
  <CheckRow y={760} at={fr(d, 0.4)} icon="shower" text="الحمّام: سجادة مانعة للانزلاق، مقابض" />
  <Cross y={930} at={fr(d, 0.65)} text="الدرج والسلّم المتحرّك بالمشّاية" />
</>;
const S09: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={240} at={fr(d, 0.02)} title="إلى الطبيب بشكل عاجل" color="#B45309" bg="#FFF7ED"
    items={[['leg', 'سقطتم'], ['calf', 'اشتدّ ألم ربلة الساق'], ['calf', 'تورّم الساق يزداد'], ['leg', 'المشي أصعب']]} />
  <Tier y={750} h={280} at={fr(d, 0.5)} title="101" color={C.blood} bg="#FDECEC"
    items={[['therm', 'ألم شديد بعد السقوط'], ['leg', 'لا تستطيعون النهوض'], ['lungs', 'ضيق نفس مفاجئ'], ['heart', 'ألم في الصدر']]} />
</>;
const S10: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>هذه توصيات عامة</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>التعليمات الشخصية من طبيبكم والمعالج الطبيعي والفريق الطبي لها الأولوية</div>
  </Card>
);
const SC: Record<string, React.FC<{d: number}>> = {W01: S01, W02: S02, W03: S03, W04: S04, W05: S05, W06: S06, W07: S07, W08: S08, W09: S09, W10: S10};

export const Walker_ar: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill style={{direction: 'rtl'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
