// «Не терпите боль в суставе годами» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import {Phone101} from './UrgentArt';
import timing from './timing_wait.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalWait = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'ОРТОПЕДИЯ · ПАЦИЕНТАМ';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Не терпите боль годами: сцены W01–W11 ----
const BONE = '#EFE6D8', BONES = '#C9B79C', CART = '#9CD3DF';
// колено спереди: бедренная кость сверху, большеберцовая снизу; хрящ k (1 здоровый → 0 истончён), остеофиты o, протез p
const Knee: React.FC<{top?: number; k?: number; o?: number; p?: number; sc?: number; left?: number}> = ({top = 480, k = 1, o = 0, p = 0, sc = 1, left = 0}) => {
  const ct = 6 + 16 * k;
  return <svg width={1080} height={760} viewBox="0 0 1080 760" style={{position: 'absolute', left, top, transform: `scale(${sc})`, transformOrigin: 'top center'}}>
    {/* бедренная */}
    <path d="M 450 0 L 630 0 L 640 220 C 700 250 740 300 730 350 C 722 385 690 395 640 380 C 600 370 570 372 540 386 C 510 372 480 370 440 380 C 390 395 358 385 350 350 C 340 300 380 250 440 220 Z" fill={BONE} stroke={BONES} strokeWidth={5} opacity={1 - p} />
    {/* большеберцовая */}
    <path d="M 340 470 C 340 440 380 430 440 430 L 640 430 C 700 430 740 440 740 470 C 740 520 690 540 650 560 L 630 760 L 450 760 L 430 560 C 390 540 340 520 340 470 Z" fill={BONE} stroke={BONES} strokeWidth={5} opacity={1 - p} />
    {/* хрящ */}
    {p < 1 && <g opacity={1 - p}>
      <path d={`M 360 352 C 380 ${388 + ct / 2} 430 ${384 + ct / 2} 470 ${374 + ct / 2} C 500 ${368 + ct / 2} 520 ${376 + ct / 2} 540 ${388 + ct / 2} C 560 ${376 + ct / 2} 580 ${368 + ct / 2} 610 ${374 + ct / 2} C 650 ${384 + ct / 2} 700 ${388 + ct / 2} 722 352`} stroke={CART} strokeWidth={ct} fill="none" strokeLinecap="round" />
      <path d={`M 360 ${436 - ct / 2} L 720 ${436 - ct / 2}`} stroke={CART} strokeWidth={ct} strokeLinecap="round" />
    </g>}
    {/* остеофиты */}
    {o > 0 && <g fill={BONE} stroke={C.acc} strokeWidth={4} opacity={o}>
      <path d="M 352 330 L 322 352 L 356 360 Z" /><path d="M 728 330 L 760 352 L 724 360 Z" />
      <path d="M 344 450 L 312 440 L 342 470 Z" /><path d="M 736 450 L 768 440 L 738 470 Z" />
    </g>}
    {/* протез */}
    {p > 0 && <g opacity={p}>
      <path d="M 450 0 L 630 0 L 640 220 C 700 250 740 300 730 350 C 722 385 690 395 640 380 C 600 370 570 372 540 386 C 510 372 480 370 440 380 C 390 395 358 385 350 350 C 340 300 380 250 440 220 Z" fill={BONE} stroke={BONES} strokeWidth={5} />
      <path d="M 352 300 C 350 360 380 392 440 384 C 480 374 510 376 540 390 C 570 376 600 374 640 384 C 700 392 730 360 728 300" stroke="#A9B4C2" strokeWidth={26} fill="none" />
      <path d="M 340 470 C 340 440 380 430 440 430 L 640 430 C 700 430 740 440 740 470 C 740 520 690 540 650 560 L 630 760 L 450 760 L 430 560 C 390 540 340 520 340 470 Z" fill={BONE} stroke={BONES} strokeWidth={5} />
      <rect x={350} y={404} width={380} height={18} rx={9} fill="#E8EEF4" stroke="#A9B4C2" strokeWidth={3} />
      <rect x={350} y={422} width={380} height={18} rx={6} fill="#A9B4C2" />
      <rect x={520} y={440} width={40} height={130} rx={10} fill="#A9B4C2" />
    </g>}
  </svg>;
};
const Organs: React.FC<{y: number; d: number; start: number}> = ({y, d, start}) => {
  const f = useCurrentFrame();
  const it: [string, string][] = [['drop', 'желудок, кишечник: язвы, кровотечения'], ['bladder', 'почки'], ['therm', 'давление'], ['heart', 'сердце и сосуды']];
  return <>{it.map(([k, t], i) => <div key={i} style={{position: 'absolute', left: 64, width: 952, top: y + i * 112, display: 'flex', alignItems: 'center', gap: 20, background: '#fff', borderRadius: 22, padding: '16px 24px', boxSizing: 'border-box', opacity: ease(f, fr(d, start + i * 0.08), fr(d, start + i * 0.08) + 10)}}>
    <Icon k={k} s={52} c={C.acc} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>{t}</span></div>)}</>;
};

const S01: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Card x={64} y={470} w={420} label="ПАЦИЕНТКА" at={4}>
      <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink}}>Пациентка</div>
      <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 28, color: C.mute}}>колено</div>
    </Card>
    <Card x={540} y={470} w={476} label="БОЛЬ" at={14}>
      <div><Counter from={0} to={5} a={fr(d, 0.15)} b={fr(d, 0.4)} size={78} suffix=" лет" /></div>
    </Card>
    <div style={{position: 'absolute', left: 64, top: 740, display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 14, width: 952}}>
      {Array.from({length: 28}, (_, i) => <div key={i} style={{height: 84, borderRadius: 16, background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: ease(f, fr(d, 0.35) + i * 2, fr(d, 0.35) + i * 2 + 6)}}>
        {i % 9 !== 4 && <Icon k="pills" s={44} c={C.acc} />}</div>)}
    </div>
    <div style={{position: 'absolute', left: 64, top: 1250, display: 'flex', gap: 12}}>
      {['обезболивающие почти каждый день', 'всё реже выходит'].map((t, i) => <div key={t} style={{opacity: ease(f, fr(d, 0.6) + i * 10, fr(d, 0.6) + 10 + i * 10)}}><Note size={28}>{t}</Note></div>)}
    </div>
  </>;
};
const S02: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const k = 1 - ease(f, fr(d, 0.15), fr(d, 0.45));
  const o = ease(f, fr(d, 0.35), fr(d, 0.55));
  return <>
    <Knee top={470} sc={0.95} k={k} o={o} />
    <div style={{position: 'absolute', left: 64, top: 1200, fontFamily: BODY, fontWeight: 600, fontSize: 22, color: C.mute}}>схема, не в масштабе · колено спереди</div>
    <div style={{position: 'absolute', left: 64, top: 1240, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
      <div style={{opacity: ease(f, fr(d, 0.2), fr(d, 0.3))}}><Note color={C.teal} bg={C.tealL} size={28}>хрящ истончается</Note></div>
      <div style={{opacity: o}}><Note size={28}>костные разрастания</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.75), fr(d, 0.85))}}><Note color={C.navy} bg="#E3E7EF" size={28}>есть лечение без операции</Note></div>
    </div>
  </>;
};
const S03: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={470} w={952} at={4} label="ПРОТИВОВОСПАЛИТЕЛЬНЫЕ">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>ибупрофен · напроксен · диклофенак</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 28, color: C.mute, marginTop: 8}}>месяцами — только с оценкой врача</div>
  </Card>
  <Organs y={700} d={d} start={0.35} />
  <div style={{position: 'absolute', left: 64, top: 1170, opacity: ease(useCurrentFrame(), fr(d, 0.8), fr(d, 0.88))}}><Note size={28}>иногда без предварительных симптомов</Note></div>
</>;
const S04: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Card x={64} y={470} w={952} at={4} label="СВЕЧИ С ДИКЛОФЕНАКОМ">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>лекарство всасывается в кровь → желудок не защищён</div>
    </Card>
    <Card x={64} y={700} w={952} at={fr(d, 0.25)} style={{border: `4px solid ${C.acc}`}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>Не сочетайте сами два противовоспалительных обезболивающих</div>
    </Card>
    <Card x={64} y={920} w={952} at={fr(d, 0.45)} label="ОБСУДИТЕ С ВРАЧОМ">
      {['язва или кровотечение в прошлом', 'сердце, почки, печень', 'пожилой возраст', 'препараты, разжижающие кровь'].map((t, i) =>
        <div key={t} style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink, marginTop: 6, opacity: ease(f, fr(d, 0.5 + i * 0.08), fr(d, 0.56 + i * 0.08))}}>· {t}</div>)}
    </Card>
  </>;
};
const S05: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={470} w={952} at={4} style={{background: C.tealL}} label="ОСНОВА ЛЕЧЕНИЯ">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.teal}}>Лечебные упражнения · снижение веса при его избытке</div>
  </Card>
  <CheckRow y={700} at={fr(d, 0.25)} icon="drop" text="Колено, если нужны лекарства: сначала противовоспалительный гель" />
  <CheckRow y={920} at={fr(d, 0.45)} icon="pills" text="Таблетки — если гель не помог · минимальная эффективная доза, как можно короче" />
  <Card x={64} y={1140} w={952} at={fr(d, 0.7)} label="ЗАЩИТА ЖЕЛУДКА">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>Предлагает врач вместе с таблетками · остальные риски не устраняет</div>
  </Card>
</>;
const S06: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={380} at={fr(d, 0.02)} title="101 — сразу · следующую дозу не принимать" color={C.blood} bg="#FDECEC"
    items={[['drop', 'рвота кровью'], ['drop', 'чёрный дегтеобразный стул'], ['drop', 'кровь в стуле'], ['faint', 'обморок · резкая слабость — подозрение на кровотечение']]} />
  <Tier y={880} h={240} at={fr(d, 0.62)} title="Срочно к врачу · приём прекратить" color="#B45309" bg="#FFF7ED"
    items={[['wound', 'сильная или не проходящая боль в животе']]} />
  <Phone101 y={1170} at={fr(d, 0.8)} s={0.62} />
</>;
const S07: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={330} at={fr(d, 0.02)} title="101 — сразу" color={C.blood} bg="#FDECEC"
    items={[['heart', 'боль в груди'], ['lungs', 'внезапная одышка'], ['faint', 'слабость в одной половине тела'], ['head', 'нарушение речи']]} />
  <Phone101 y={860} at={fr(d, 0.25)} s={1} />
</>;
const S08: React.FC<{d: number}> = ({d}) => {
  const items = ['боль, скованность или деформация сильно ухудшают жизнь', 'лечение без операции не помогает или не подходит'];
  return <>
    {items.map((t, i) => <Slot key={t} x={64} y={470 + i * 170} w={952} h={150} at={fr(d, 0.05 + i * 0.15)}>
      <Icon k="check" s={64} /><div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>{t}</div></Slot>)}
    <Card x={64} y={830} w={952} at={fr(d, 0.4)}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>Возраст, вес, курение, другие болезни — сами по себе не исключают, но влияют на риски</div>
    </Card>
    <Card x={64} y={1060} w={952} at={fr(d, 0.75)} style={{background: C.navy}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: '#fff'}}>Решают пациент и хирург вместе</div>
    </Card>
  </>;
};
const S09: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame(); const p = ease(f, fr(d, 0.1), fr(d, 0.45));
  return <>
    <Card x={64} y={470} w={952} h={420} at={4} label="ВО ВРЕМЯ ОЖИДАНИЯ · В СРЕДНЕМ · В ОТДЕЛЬНЫХ ГРУППАХ">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.ink, marginTop: 6}}>функция сустава и качество жизни ↓</div>
      <svg width={880} height={260} style={{marginTop: 4, direction: 'ltr'}}>
        <line x1={40} y1={260} x2={860} y2={260} stroke="#CBD2DC" strokeWidth={3} />
        <path d={`M 40 70 C 260 90 520 150 ${40 + 820 * p} ${80 + 150 * p}`} stroke={C.acc} strokeWidth={8} fill="none" strokeLinecap="round" />
        
      </svg>
    </Card>
    <div style={{position: 'absolute', left: 64, top: 910, opacity: ease(f, fr(d, 0.3), fr(d, 0.38))}}><Note color={C.navy} bg="#E3E7EF" size={22}>Cooper и соавт., 2024 · 89 996 участников всего · ожидание оценивали в отдельных группах</Note></div>
    <Card x={64} y={1000} w={952} at={fr(d, 0.45)}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.ink}}>Влияет ли длительность ожидания на результат — надёжно не установлено</div>
    </Card>
    <Card x={64} y={1200} w={952} at={fr(d, 0.75)} style={{borderLeft: `10px solid ${C.teal}`}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.ink}}>Операция не обязательно нужна сразу · не ждите годами без повторной оценки</div>
    </Card>
  </>;
};
const S10: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Knee top={430} sc={0.62} left={-250} k={0.2} o={1} p={ease(f, fr(d, 0.05), fr(d, 0.3))} />
    <Card x={560} y={480} w={456} at={fr(d, 0.4)} label="ДОВОЛЬНЫ · КАНАДА, 2010">
      <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 56, color: C.ink}}><Counter from={0} to={89} a={fr(d, 0.45)} b={fr(d, 0.6)} size={64} suffix="%" /></div>
      <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 26, color: C.mute}}>тазобедренный</div>
      <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 56, color: C.ink, marginTop: 10}}><Counter from={0} to={81} a={fr(d, 0.55)} b={fr(d, 0.7)} size={64} suffix="%" /></div>
      <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 26, color: C.mute}}>коленный</div>
    </Card>
    <div style={{position: 'absolute', left: 64, top: 1000, display: 'flex', gap: 12, flexWrap: 'wrap'}}>
      <div style={{opacity: ease(f, fr(d, 0.15), fr(d, 0.25))}}><Note color={C.teal} bg={C.tealL} size={28}>меньше боли · лучше подвижность</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.82), fr(d, 0.9))}}><Note size={28}>не гарантия · есть риски</Note></div>
    </div>
  </>;
};
const S11: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={620} w={952} at={4} style={{background: C.tealL}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 40, color: C.teal}}>Помогает ли ваше лечение? Обсудите с врачом</div>
  </Card>
  <Card x={64} y={840} w={952} at={fr(d, 0.4)} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>Индивидуальные указания вашего врача и медицинской команды имеют приоритет</div>
  </Card>
</>;

const SC: Record<string, React.FC<{d: number}>> = {W01: S01, W02: S02, W03: S03, W04: S04, W05: S05, W06: S06, W07: S07, W08: S08, W09: S09, W10: S10, W11: S11};

export const Wait: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
