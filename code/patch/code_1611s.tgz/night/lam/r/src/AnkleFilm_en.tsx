// «Перелом лодыжки» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import {Clip3D} from './Clip3D';
import {A3, ALbl, WomanTwist} from './A3';
import timing from './timing_ankle_en.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalAnkleFilm_en = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'ORTHOPAEDICS · FOR PATIENTS';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Перелом лодыжки: сцены F01–F11 ----
const BONE = '#EFE6D8', BONES = '#C9B79C';
// голеностоп спереди (правая нога): большеберцовая медиально (слева на схеме), малоберцовая латерально (справа), таранная снизу
const Ankle: React.FC<{lat?: number; med?: number; shift?: number; synd?: number; fix?: number; hl?: number; top?: number; label?: boolean; glow?: number}> = ({lat = 0, med = 0, shift = 0, synd = 0, fix = 0, hl = 0, top = 470, label = true, glow = 0}) => {
  const sx = shift * 40;
  return <svg width={1080} height={800} viewBox="140 0 800 593" style={{position: 'absolute', left: 0, top}}>
    {/* большеберцовая */}
    <path d="M 400 0 L 540 0 C 545 150 560 250 590 300 L 595 372 L 430 372 L 428 440 C 420 458 392 460 382 445 L 372 380 C 368 300 390 200 400 0 Z" fill={BONE} stroke={hl ? C.acc : BONES} strokeWidth={4} />
    {/* малоберцовая */}
    <path d="M 615 0 L 645 0 C 648 150 650 260 655 320 C 672 345 680 420 668 470 C 655 492 628 488 618 462 C 608 420 604 360 608 320 C 610 250 612 150 615 0 Z" fill={BONE} stroke={hl ? C.acc : BONES} strokeWidth={4} />
    {/* синдесмоз */}
    <g opacity={0.4 + 0.6 * synd}>{[300, 320, 340].map((y) => <line key={y} x1={586} y1={y} x2={612} y2={y + 4} stroke={synd > 0.5 ? C.acc : '#C98C6E'} strokeWidth={5} />)}</g>
    {/* таранная */}
    <g transform={`translate(${sx},0)`}><path d="M 432 378 C 470 368 560 368 598 378 C 606 410 602 450 585 480 L 450 480 C 432 455 428 410 432 378 Z" fill="#E8DCC6" stroke={BONES} strokeWidth={4} /></g>
    {/* линии перелома */}
    {lat > 0 && <path d="M 604 400 L 664 360" stroke={C.acc} strokeWidth={6 * lat} strokeLinecap="round" />}
    {med > 0 && <path d="M 368 368 L 432 380" stroke={C.acc} strokeWidth={6 * med} strokeLinecap="round" />}
    {/* фиксация */}
    {fix > 0 && <g opacity={fix}>
      <rect x={664} y={240} width={24} height={200} rx={10} fill="#9AA5AE" stroke="#6B7686" strokeWidth={3} />
      {[260, 300, 340, 380, 420].map((y) => <line key={y} x1={676} y1={y} x2={618} y2={y} stroke={C.navy} strokeWidth={6} strokeLinecap="round" />)}
      {[0, 1].map((i) => <line key={i} x1={396 + i * 16} y1={440 - i * 6} x2={420 + i * 16} y2={330} stroke={C.navy} strokeWidth={7} strokeLinecap="round" />)}
      <line x1={690} y1={318} x2={500} y2={318} stroke={C.teal} strokeWidth={7} strokeLinecap="round" />
    </g>}
    {glow > 0 && <circle cx={520} cy={400} r={140} fill={C.acc} opacity={0.18 * glow} />}
    {label && <text x={150} y={575} fontFamily="'Body'" fontWeight={700} fontSize={22} fill={C.mute}>diagram, not to scale · right ankle, front view</text>}
  </svg>;
};

const S01: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const pulse = ease(f, fr(d, 0.3), fr(d, 0.4)) * (0.6 + 0.4 * Math.sin(f / 5));
  return <>
    <Card x={64} y={470} w={420} label="PATIENT" at={4}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>Patient</div>
      
    </Card>
    <Card x={540} y={470} w={476} label="INJURY" at={14}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>tripped and twisted her foot</div>
    </Card>
    <WomanTwist y={650} h={740} d={d} />
    <div style={{position: 'absolute', left: 64, top: 1420, display: 'flex', gap: 12, flexWrap: 'wrap'}}>
      {['pain', 'swelling', 'bruise', 'cannot bear weight'].map((t, i) => <div key={t} style={{opacity: ease(f, fr(d, 0.45) + i * 8, fr(d, 0.45) + 10 + i * 8)}}><Note size={28}>{t}</Note></div>)}
    </div>
  </>;
};

const Lbl: React.FC<{x: number; y: number; o: number; c?: string; children: React.ReactNode}> = ({x, y, o, c = C.navy, children}) =>
  <div style={{position: 'absolute', left: x, top: y, opacity: o, fontFamily: BODY, fontWeight: 700, fontSize: 26, color: c, background: '#fff', borderRadius: 14, padding: '6px 14px', boxShadow: '0 6px 18px rgba(20,24,32,.08)'}}>{children}</div>;
const S02: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <A3 n="anat" y={470} d={d} />
    <ALbl n="anat" y={470} d={d} k="tibia" side="r" o={ease(f, fr(d, 0.1), fr(d, 0.2)) * (1 - ease(f, fr(d, 0.74), fr(d, 0.78)))}>shin bone (tibia)</ALbl>
    <ALbl n="anat" y={470} d={d} k="fibula" side="l" o={ease(f, fr(d, 0.1), fr(d, 0.2)) * (1 - ease(f, fr(d, 0.74), fr(d, 0.78)))}>fibula</ALbl>
    <ALbl n="anat" y={470} d={d} k="talus" side="r" dy={60} o={ease(f, fr(d, 0.2), fr(d, 0.3)) * (1 - ease(f, fr(d, 0.74), fr(d, 0.78)))} c="#6B5A3A">talus</ALbl>
    <ALbl n="anat" y={470} d={d} k="med" side="r" o={ease(f, fr(d, 0.6), fr(d, 0.66)) * (1 - ease(f, fr(d, 0.74), fr(d, 0.78)))} c={C.acc}>inner ankle bone</ALbl>
    <ALbl n="anat" y={470} d={d} k="post" side="l" o={ease(f, fr(d, 0.8), fr(d, 0.86))} c={C.acc}>posterior malleolus</ALbl>
    <ALbl n="anat" y={470} d={d} k="lat" side="l" o={ease(f, fr(d, 0.42), fr(d, 0.5)) * (1 - ease(f, fr(d, 0.74), fr(d, 0.78)))} c={C.acc}>outer ankle bone</ALbl>
    <div style={{position: 'absolute', left: 64, top: 1300, opacity: ease(f, fr(d, 0.7), fr(d, 0.8))}}><Note color={C.navy} bg="#E3E7EF" size={28}>posterior malleolus: back edge of the shin bone</Note></div>
  </>;
};

const S03: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const a = ease(f, fr(d, 0.05), fr(d, 0.2)), b = ease(f, fr(d, 0.35), fr(d, 0.5)), s = ease(f, fr(d, 0.7), fr(d, 0.8));
  return <>
    <A3 n="frac" y={470} d={d} />
    <div style={{position: 'absolute', left: 64, top: 1300, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
      <div style={{opacity: a * (1 - b)}}><Note color={C.teal} bg={C.tealL} size={28}>outer only: often stable</Note></div>
      <div style={{opacity: b}}><Note size={28}>two or three malleoli: often unstable, dislocation</Note></div>
      <div style={{opacity: s}}><Note color={C.navy} bg="#E3E7EF" size={28}>syndesmosis: ligaments between the bones</Note></div>
    </div>
  </>;
};

const S04: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={480} w={952} at={fr(d, 0.05)} label="THE SURGEON DECIDES">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>examination + X-rays</div>
  </Card>
  <Card x={64} y={680} w={460} at={fr(d, 0.2)} style={{borderTop: `8px solid ${C.acc}`}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>Displaced or unstable</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 26, color: C.mute, marginTop: 8}}>usually surgery</div>
  </Card>
  <Card x={556} y={680} w={460} at={fr(d, 0.38)} style={{borderTop: `8px solid ${C.teal}`}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>Stable, not displaced</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 26, color: C.mute, marginTop: 8}}>often a cast or boot</div>
  </Card>
  <Card x={64} y={960} w={952} at={fr(d, 0.62)} style={{background: '#FDECEC', border: `4px solid ${C.blood}`}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 32, color: C.blood}}>Wound over the fracture</div>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink, marginTop: 8}}>may be an open fracture: get help immediately</div>
  </Card>
</>;

const S05: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const up = ease(f, 6, fr(d, 0.25));
  return <>
    <Clip3D src="c3/swell_elevate_hf.mp4" y={430} h={450} d={d} dur={8} label={(t) => t > 3.4 ? '― heart level ―' : null} />
    <Card x={64} y={900} w={952} at={fr(d, 0.3)} label="SWELLING">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>With severe swelling surgery is sometimes delayed · with dislocation or deformity: urgent realignment and temporary fixation</div>
    </Card>
    <Card x={64} y={1150} w={952} at={fr(d, 0.62)} style={{border: `4px solid #B45309`, background: '#FFF7ED'}} label="TELL STAFF AT ONCE">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.ink}}>pain under the splint ↑ · numbness · tingling · cold or pale foot</div>
    </Card>
  </>;
};

const S06: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const fx = ease(f, fr(d, 0.15), fr(d, 0.45)), sy = ease(f, fr(d, 0.5), fr(d, 0.65));
  return <>
    <A3 n="fix" y={470} d={d} />
    <div style={{position: 'absolute', left: 64, top: 1300, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
      <div style={{opacity: fx}}><Note color={C.navy} bg="#E3E7EF" size={28}>plate and screws</Note></div>
      <div style={{opacity: sy}}><Note color={C.teal} bg={C.tealL} size={28}>syndesmosis: screw or cord with buttons</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.75), fr(d, 0.85))}}><Note size={28}>then a splint, cast or brace</Note></div>
    </div>
  </>;
};

const S07: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <CheckRow y={480} at={fr(d, 0.02)} icon="leg" text="Leg raised · move your toes" />
    <Card x={64} y={700} w={460} at={fr(d, 0.25)} style={{borderTop: `8px solid ${C.teal}`}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>Some: early weight-bearing</div>
    </Card>
    <Card x={556} y={700} w={460} at={fr(d, 0.35)} style={{borderTop: `8px solid ${C.acc}`}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>Others: no weight for now</div>
    </Card>
    <Card x={64} y={920} w={952} at={fr(d, 0.55)} style={{background: C.navy}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: '#fff'}}>Only per the surgeon's written instructions</div>
    </Card>
    <div style={{position: 'absolute', left: 64, top: 1130, opacity: ease(f, fr(d, 0.45), fr(d, 0.55))}}><Note color={C.teal} bg={C.tealL} size={30}>crutches or a walker: the physiotherapist will teach you</Note></div>
    <Card x={64} y={1230} w={952} at={fr(d, 0.72)} label="CLOT PREVENTION">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.ink}}>Not everyone needs it · if prescribed, follow the plan, do not stop it yourself</div>
    </Card>
  </>;
};

const S08: React.FC<{d: number}> = ({d}) => {
  const items: [string, string][] = [['drop', 'pain not relieved by painkillers'], ['leg', 'numbness, tingling, pale or cold foot'], ['wound', 'dressing soaking through'], ['calf', 'calf pain or swelling'], ['lungs', 'sudden shortness of breath or chest pain']];
  return <>{items.map(([k, t], i) => <Slot key={i} x={64} y={480 + i * 190} w={952} h={160} at={fr(d, 0.06 + i * 0.16)}>
    <Icon k={k} s={64} /><div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink, lineHeight: 1.2}}>{t}</div></Slot>)}</>;
};

const S09: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.02)} icon="drop" text="Keep the cast dry · put nothing inside" />
  <Card x={64} y={700} w={952} at={fr(d, 0.25)} style={{border: `4px solid #B45309`, background: '#FFF7ED'}} label="WITHOUT DELAY: WARD OR EMERGENCY">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>cast wet, broken or rubbing badly · smell or discharge</div>
  </Card>
  <Card x={64} y={1000} w={952} at={fr(d, 0.7)} label="SMOKING">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>Raises the risk of complications: discuss stopping, at least during treatment</div>
  </Card>
</>;

const S10: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const rows: [string, string][] = [['≥ 6 wk', 'early healing'], ['10–12 wk', 'full healing'], ['3–4 mo', 'normal activity for most people']];
  return <>
    {rows.map(([h, t], i) => <Card key={i} x={64} y={480 + i * 200} w={952} at={fr(d, 0.05 + i * 0.2)}>
      <div style={{display: 'flex', alignItems: 'center', gap: 30}}><div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 52, color: C.acc, minWidth: 300}}>{h}</div>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>{t}</div></div></Card>)}
    <div style={{position: 'absolute', left: 64, top: 1110, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
      <div style={{opacity: ease(f, fr(d, 0.6), fr(d, 0.7))}}><Note size={28}>swelling and stiffness: several months</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.85), fr(d, 0.95))}}><Note color={C.navy} bg="#E3E7EF" size={28}>driving only with your doctor's agreement, when safe</Note></div>
    </div>
  </>;
};

const S11: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={520} at={fr(d, 0.02)} title="101 emergency help" color={C.blood} bg="#FDECEC"
    items={[['lungs', 'sudden shortness of breath'], ['heart', 'chest pain'], ['leg', 'foot cold, pale or blue'], ['leg', 'marked numbness'], ['drop', 'sharply worsening pain'], ['wound', 'cast very tight']]} />
  <div style={{position: 'absolute', left: 64, top: 1010, opacity: ease(useCurrentFrame(), fr(d, 0.45), fr(d, 0.55))}}><Note size={28}>do not drive yourself</Note></div>
  <Tier y={1090} h={300} at={fr(d, 0.7)} title="See a doctor the same day" color={C.navy} bg="#fff"
    items={[['therm', 'temperature 38 °C or higher'], ['wound', 'redness or discharge from the wound'], ['calf', 'new calf pain or swelling']]} />
</>;

const S12: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>These are general recommendations</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>Individual instructions from your doctor and medical team come first</div>
  </Card>
);

const SC: Record<string, React.FC<{d: number}>> = {F01: S01, F02: S02, F03: S03, F04: S04, F05: S05, F06: S06, F07: S07, F08: S08, F09: S09, F10: S10, F11: S11, F12: S12};

export const AnkleFilm_en: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
