// «Делирий: памятка для близких» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import {WardBed, RoomDayNight, AidItems} from './DelirArt';
import timing from './timing_delir.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalDelir = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'ОРТОПЕДИЯ · ПАЦИЕНТАМ';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Делирий: сцены D01–D11 ----
const SKIN = '#E4E7EC', SKINS = '#C9CED6';
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10)}}><Note size={28} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const BedScene: React.FC<{top?: number; q?: number; d?: number}> = ({top = 700, q = 0}) => {
  const f = useCurrentFrame();
  return <svg width={1080} height={520} style={{position: 'absolute', left: 0, top}}>
    <rect x={120} y={260} width={620} height={50} rx={14} fill="#C9CED6" /><rect x={120} y={310} width={18} height={130} fill="#C9CED6" /><rect x={722} y={310} width={18} height={130} fill="#C9CED6" />
    <rect x={150} y={225} width={150} height={40} rx={18} fill="#fff" stroke={SKINS} strokeWidth={3} />
    <circle cx={230} cy={205} r={42} fill={SKIN} stroke={SKINS} strokeWidth={3} />
    <rect x={270} y={220} width={440} height={50} rx={22} fill="#DDF3F0" />
    <circle cx={860} cy={150} r={44} fill="#F4D9C6" />
    <path d="M 800 470 C 800 300 920 300 920 470 Z" fill="#BFD9E6" />
    {[0, 1, 2].map((i) => <text key={i} x={200 + i * 50} y={120 - 10 * Math.sin((f + i * 10) / 9)} fontFamily="'Head'" fontWeight={800} fontSize={54} fill={C.acc} opacity={q}>?</text>)}
  </svg>;
};
const S01: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Card x={64} y={470} w={420} label="ПАЦИЕНТ" at={4}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>Пациент</div>
      
    </Card>
    <Card x={540} y={470} w={476} label="ВЧЕРА" at={14}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>операция при переломе бедра</div>
    </Card>
    <WardBed d={d} q={ease(f, fr(d, 0.35), fr(d, 0.5))} top={720} />
    <Notes y={1280} items={[['не понимает, где находится', fr(d, 0.4)], ['то сонлив, то беспокоен', fr(d, 0.55)], ['может быть делирий', fr(d, 0.8), C.navy, '#E3E7EF']]} />
  </>;
};
const S02: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame(); const p = ease(f, fr(d, 0.05), fr(d, 0.6));
  const pts = Array.from({length: 61}, (_, i) => { const x = 100 + i * 14.5; const y = 260 - 60 * Math.sin(i / 5) - (i > 40 ? (i - 40) * 4 : 0); return `${x},${y}`; }).join(' ');
  return <>
    <svg width={1080} height={460} style={{position: 'absolute', left: 0, top: 480}}>
      <rect x={100} y={60} width={880} height={330} rx={20} fill="#fff" />
      <polyline points={pts} fill="none" stroke={C.acc} strokeWidth={6} strokeDasharray="2000" strokeDashoffset={2000 * (1 - p)} />
      <text x={110} y={430} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.mute}>утро</text>
      <text x={500} y={430} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.mute}>день</text>
      <text x={860} y={430} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.mute}>вечер · ночь</text>
    </svg>
    <Notes y={1000} items={[['внезапно', fr(d, 0.1)], ['меняется в течение дня', fr(d, 0.35)], ['хуже вечером и ночью', fr(d, 0.55)], ['частый · обычно временный', fr(d, 0.8), C.teal, C.tealL]]} />
  </>;
};
const S03: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={470} w={460} h={380} at={fr(d, 0.05)} label="БЕСПОКОЙНЫЙ">
    {['путает время и место', 'плохо понимает речь', 'видит то, чего нет', 'возбуждён'].map((t, i) => <div key={i} style={{fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.ink, marginTop: 18}}>• {t}</div>)}
  </Card>
  <Card x={556} y={470} w={460} h={380} at={fr(d, 0.55)} label="«ТИХИЙ»" style={{border: `4px solid #B45309`}}>
    {['необычно сонлив', 'вялый', 'мало реагирует', 'легко пропустить'].map((t, i) => <div key={i} style={{fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.ink, marginTop: 18}}>• {t}</div>)}
  </Card>
</>;
const S04: React.FC<{d: number}> = ({d}) => {
  const items = ['пожилой возраст', 'деменция или нарушения памяти', 'тяжёлая болезнь', 'перелом бедра, большие операции'];
  return <>{items.map((t, i) => <Slot key={i} x={64} y={480 + i * 170} w={952} h={140} at={fr(d, 0.05 + i * 0.15)}><Icon k="check" s={52} c={C.mute} /><div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>{t}</div></Slot>)}</>;
};
const S05: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const items: [string, string][] = [['therm', 'инфекция'], ['head', 'боль'], ['drop', 'обезвоживание'], ['pills', 'некоторые лекарства'], ['bladder', 'запор или задержка мочи'], ['clock', 'нарушение сна'], ['head', 'незнакомая обстановка'], ['head', 'плохое зрение или слух']];
  return <>{items.map(([k, t], i) => <div key={i} style={{position: 'absolute', left: 64 + (i % 2) * 480, top: 480 + Math.floor(i / 2) * 150, display: 'flex', alignItems: 'center', gap: 16, opacity: ease(f, fr(d, 0.05 + i * 0.08), fr(d, 0.1 + i * 0.08))}}><Icon k={k} s={56} c={C.mute} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink, width: 380}}>{t}</span></div>)}
    <Notes y={1120} items={[['часто несколько причин и факторов риска', fr(d, 0.8), C.navy, '#E3E7EF']]} /></>;
};
const S06: React.FC<{d: number}> = ({d}) => <>
  <WardBed d={d} top={520} relative />
  <Card x={64} y={1040} w={952} at={fr(d, 0.2)} style={{border: `4px solid #B45309`, background: '#FFF7ED'}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>Внезапно стал другим — сразу скажите персоналу</div>
  </Card>
  <Notes y={1240} items={[['вы знаете его лучше всех', fr(d, 0.7), C.teal, C.tealL]]} />
</>;
const S07: React.FC<{d: number}> = ({d}) => <>
  {['инфекция', 'боль', 'жидкость', 'лекарства', 'кишечник и мочевой пузырь'].map((t, i) => <CheckRow key={i} y={470 + i * 150} at={fr(d, 0.04 + i * 0.1)} icon="check" text={t} />)}
  <Card x={64} y={1230} w={952} at={fr(d, 0.7)} label="ЛЕКАРСТВА — РЕДКО">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.ink}}>Сильное страдание или опасность · сначала без лекарств · короткий курс, минимальная доза</div>
  </Card>
</>;
const S08: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={470} at={fr(d, 0.02)} icon="check" text="Спокойно, коротко, просто" />
  <CheckRow y={660} at={fr(d, 0.2)} icon="check" text="Напоминать: где он, какой день, почему в больнице" />
  <Card x={64} y={870} w={952} at={fr(d, 0.4)} style={{border: `4px solid ${C.acc}`}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>Не спорить</div>
  </Card>
  <AidItems y={1060} d={d} />
  <Notes y={1290} items={[['очки', fr(d, 0.6)], ['слуховой аппарат', fr(d, 0.65)], ['зубные протезы', fr(d, 0.7)], ['знакомые вещи и фото', fr(d, 0.78), C.teal, C.tealL]]} />
</>;
const S09: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={470} w={952} at={fr(d, 0.02)} label="ДЕНЬ" style={{background: '#FFFBEB'}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>Свет · часы и календарь на виду · сидеть и двигаться, как разрешено</div>
  </Card>
  <Card x={64} y={700} w={952} at={fr(d, 0.4)} label="НОЧЬ" style={{background: C.navy}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: '#fff'}}>Тишина и сон</div>
  </Card>
  <RoomDayNight top={1080} d={d} nightAt={fr(d, 0.4)} />
  <CheckRow y={920} at={fr(d, 0.7)} icon="drop" text="Помогать пить и есть, если разрешено" />
</>;
const S10: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <div style={{position: 'absolute', left: 120, top: 560, width: 840, height: 8, borderRadius: 4, background: C.line}} />
    <div style={{position: 'absolute', left: 120, top: 560, width: 840 * ease(f, fr(d, 0.05), fr(d, 0.6)), height: 8, borderRadius: 4, background: C.teal}} />
    {([['дни', 'обычно', 0.1], ['недели', 'у некоторых', 0.3], ['месяцы', 'иногда', 0.5]] as [string, string, number][]).map(([a, b, p], i) => <div key={i} style={{position: 'absolute', left: 70 + i * 340, top: 600, width: 280, opacity: ease(f, fr(d, p), fr(d, p) + 10)}}>
      <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 38, color: C.ink}}>{a}</div><div style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.mute, marginTop: 6}}>{b}</div></div>)}
    <Notes y={860} items={[['может плохо помнить этот период', fr(d, 0.4), C.navy, '#E3E7EF'], ['сохраняется после выписки — к врачу', fr(d, 0.6)], ['внезапно или резко хуже дома — 101', fr(d, 0.8), C.blood, '#FDECEC']]} />
  </>;
};
const S11: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>Это общие рекомендации</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>Индивидуальные указания вашего врача и медицинской команды имеют приоритет</div>
  </Card>
);
const SC: Record<string, React.FC<{d: number}>> = {D01: S01, D02: S02, D03: S03, D04: S04, D05: S05, D06: S06, D07: S07, D08: S08, D09: S09, D10: S10, D11: S11};

export const Delir: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
