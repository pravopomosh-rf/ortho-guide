// «Грыжа диска и спондилодез» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import {Phone101} from './UrgentArt';
import {Clip3D} from './Clip3D';
import timing from './timing_fusion.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalFusion = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'ОРТОПЕДИЯ · ПАЦИЕНТАМ';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Грыжа диска и спондилодез: сцены D01–D11 ----
const BONE = '#EFE6D8', BONES = '#C9B79C';
// межпозвонковый диск сверху: спереди вверху, сзади внизу; позвоночный канал сзади с дуральным мешком и корешками
const DiscTop: React.FC<{h: number; rem?: number; top?: number; press?: number}> = ({h, rem = 0, top = 470, press = 0}) => {
  const hv = h * (1 - rem);
  return <svg width={1080} height={760} viewBox="0 0 1080 760" style={{position: 'absolute', left: 0, top}}>
    {/* фиброзное кольцо */}
    <path d="M 260 300 C 260 140 420 90 540 110 C 660 90 820 140 820 300 C 820 380 760 420 690 425 C 640 430 600 410 540 410 C 480 410 440 430 390 425 C 320 420 260 380 260 300 Z" fill="#DCEAF0" stroke="#9CC9D3" strokeWidth={5} />
    {/* пульпозное ядро */}
    <ellipse cx={540} cy={260} rx={150} ry={90} fill="#BFD9E6" />
    {/* грыжа: задне-боковая слева */}
    {hv > 0 && <path d="M 485 402 C 482 440 462 462 440 466 C 418 468 404 452 408 428 C 414 410 440 402 485 402 Z" transform={`translate(450 404) scale(${0.3 + 0.7 * hv} ${hv}) translate(-450 -404)`} fill="#BFD9E6" stroke={C.acc} strokeWidth={4} />}
    {/* дужка позвонка (задние элементы) */}
    <path d="M 380 440 C 360 520 400 600 470 640 L 540 700 L 610 640 C 680 600 720 520 700 440 L 660 445 C 670 520 640 580 540 600 C 440 580 410 520 420 445 Z" fill={BONE} stroke={BONES} strokeWidth={4} />
    {/* дуральный мешок */}
    <ellipse cx={540} cy={510} rx={100} ry={70} fill="#E3F1F7" stroke="#8CC3D6" strokeWidth={4} />
    {[500, 540, 580].map((x) => <circle key={x} cx={x} cy={515} r={10} fill="#F2D27A" />)}
    {/* корешки */}
    <circle cx={425 - 0 * press} cy={470 + 12 * press * hv} r={16} fill="#F2D27A" stroke={hv * press > 0.5 ? C.acc : '#C99A1E'} strokeWidth={4} />
    <circle cx={655} cy={470} r={16} fill="#F2D27A" stroke="#C99A1E" strokeWidth={4} />
  </svg>;
};

const S01: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const p = ease(f, fr(d, 0.25), fr(d, 0.55));
  return <>
    <Card x={64} y={470} w={420} label="ПАЦИЕНТ" at={4}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>Пациент</div>
      
    </Card>
    <Card x={540} y={470} w={476} label="БОЛЬ ОТДАЁТ В НОГУ" at={14}>
      <div><Counter from={0} to={2} a={fr(d, 0.3)} b={fr(d, 0.6)} size={78} suffix=" мес." /></div>
    </Card>
    <svg width={1080} height={760} style={{position: 'absolute', left: 0, top: 700}}>
      {/* силуэт сбоку: таз и нога */}
      <path d="M 470 40 C 520 30 600 40 620 90 L 640 200 C 650 260 630 320 610 360 L 600 560 L 640 690 L 560 700 L 540 560 L 520 380 C 500 330 470 260 460 200 Z" fill="#E4E7EC" stroke="#C9CED6" strokeWidth={4} />
      <path d={`M 560 150 C 590 220 600 300 585 380 C 575 460 570 540 590 ${560 + 120 * p}`} stroke={C.acc} strokeWidth={10} fill="none" strokeLinecap="round" strokeDasharray="900" strokeDashoffset={900 * (1 - p)} opacity={0.85} />
      <circle cx={560} cy={150} r={26} fill={C.acc} opacity={0.35 * p} />
    </svg>
    <div style={{position: 'absolute', left: 64, top: 1420, display: 'flex', gap: 12, flexWrap: 'wrap'}}>
      {['боль в ноге', 'онемение', 'без операции не прошло'].map((t, i) => <div key={t} style={{opacity: ease(f, fr(d, 0.5) + i * 8, fr(d, 0.5) + 10 + i * 8)}}><Note size={28}>{t}</Note></div>)}
    </div>
  </>;
};

const S02: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const h = ease(f, fr(d, 0.1), fr(d, 0.4));
  return <>
    <DiscTop h={h} press={h} />
    <div style={{position: 'absolute', left: 64, top: 1230, fontFamily: BODY, fontWeight: 600, fontSize: 22, color: C.mute}}>схема, не в масштабе · вид сверху, спина внизу</div>
    <div style={{position: 'absolute', left: 64, top: 1280, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
      <div style={{opacity: h}}><Note size={28}>грыжа давит на корешок</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.6), fr(d, 0.7))}}><Note color={C.teal} bg={C.tealL} size={28}>чаще проходит без операции</Note></div>
    </div>
  </>;
};

const S03: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const items = ['ишиас', 'лечение без операции не помогло', 'снимки соответствуют симптомам'];
  return <>
    {items.map((t, i) => <Slot key={i} x={64} y={480 + i * 190} w={952} h={160} at={fr(d, 0.08 + i * 0.18)}>
      <Icon k="check" s={64} /><div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>{t}</div></Slot>)}
    <Card x={64} y={1080} w={952} at={fr(d, 0.75)} style={{background: C.navy}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: '#fff'}}>Решает спинальный хирург после обследования</div>
    </Card>
  </>;
};

const S04: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const r = ease(f, fr(d, 0.2), fr(d, 0.5));
  return <>
    <DiscTop h={1} rem={r} press={1} />
    <div style={{position: 'absolute', left: 64, top: 1230, fontFamily: BODY, fontWeight: 600, fontSize: 22, color: C.mute}}>схема, не в масштабе · вид сверху, спина внизу</div>
    <div style={{position: 'absolute', left: 64, top: 1280, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
      <div style={{opacity: ease(f, fr(d, 0.05), fr(d, 0.15))}}><Note color={C.navy} bg="#E3E7EF" size={28}>небольшой разрез или эндоскоп</Note></div>
      <div style={{opacity: r}}><Note color={C.teal} bg={C.tealL} size={28}>корешок свободен</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.7), fr(d, 0.8))}}><Note size={28}>часть диска остаётся — грыжа может повториться</Note></div>
    </div>
  </>;
};

const S05: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const scr = ease(f, fr(d, 0.3), fr(d, 0.45)), graft = ease(f, fr(d, 0.15), fr(d, 0.3));
  const Vt = (y: number) => <g>
    <rect x={250} y={y} width={260} height={160} rx={30} fill={BONE} stroke={BONES} strokeWidth={4} />
    <path d={`M 505 ${y + 40} L 600 ${y + 30} L 600 ${y + 90} L 505 ${y + 95} Z`} fill={BONE} stroke={BONES} strokeWidth={4} />
    <path d={`M 600 ${y + 20} L 650 ${y + 10} L 790 ${y + 60} L 800 ${y + 100} L 650 ${y + 110} L 600 ${y + 100} Z`} fill={BONE} stroke={BONES} strokeWidth={4} />
  </g>;
  const screw = (y: number) => <g><line x1={640} y1={y + 62} x2={330} y2={y + 82} stroke={C.navy} strokeWidth={14} strokeLinecap="round" /><circle cx={650} cy={y + 62} r={20} fill={C.navy} /></g>;
  return <>
    <svg width={1080} height={640} style={{position: 'absolute', left: 0, top: 480}}>
      {Vt(100)}{Vt(380)}
      <rect x={265} y={272} width={230} height={96} rx={22} fill="#D7E9EE" stroke="#9CC9D3" strokeWidth={3} />
      <g opacity={graft}>{Array.from({length: 15}, (_, i) => <circle key={i} cx={290 + (i % 5) * 45} cy={292 + Math.floor(i / 5) * 26} r={10} fill="#F2D27A" stroke="#C99A1E" strokeWidth={2} />)}</g>
      <g opacity={scr}>{screw(100)}{screw(380)}<line x1={672} y1={150} x2={672} y2={455} stroke="#6B7686" strokeWidth={16} strokeLinecap="round" /></g>
      <text x={250} y={80} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.mute}>вид сбоку</text>
      <text x={250} y={118} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.teal}>← спереди</text>
      <text x={720} y={118} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.teal}>сзади →</text>
    </svg>
    <div style={{position: 'absolute', left: 64, top: 1130, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
      <div style={{opacity: graft}}><Note color="#9A7410" bg="#FBF0D0" size={28}>костный трансплантат</Note></div>
      <div style={{opacity: scr}}><Note color={C.navy} bg="#E3E7EF" size={28}>винты через ножки дуг + стержень</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.65), fr(d, 0.75))}}><Note size={28}>нестабильность · спондилолистез · деформации · переломы</Note></div>
    </div>
  </>;
};

const S06: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={560} w={952} at={fr(d, 0.05)} style={{borderTop: `8px solid ${C.acc}`}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink}}>Неспецифическая боль в пояснице без хирургического показания</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 30, color: C.mute, marginTop: 12}}>не рекомендуют — кроме рандомизированных исследований</div>
  </Card>
  <Card x={64} y={900} w={952} at={fr(d, 0.6)} style={{background: C.navy}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: '#fff'}}>Нужна ли операция вам — решает лечащий врач</div>
  </Card>
</>;

const S07: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.02)} icon="shower" text="Голодание, душ, лекарства — по памятке «Подготовка к операции»" />
  <CheckRow y={720} at={fr(d, 0.25)} icon="pills" text="Разжижающие кровь — только по указанию врача" />
  <Card x={64} y={960} w={952} at={fr(d, 0.55)} label="КУРЕНИЕ">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>Повышает риск, что кости не срастутся — обсудите отказ с врачом</div>
  </Card>
</>;

const S08: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.02)} icon="leg" text="Начать двигаться и ходить — с персоналом, когда безопасно" />
  <Card x={64} y={640} w={952} at={fr(d, 0.3)} label="НАГРУЗКА · КОРСЕТ · ОГРАНИЧЕНИЯ">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>Определяют лечащий врач и реабилитационная команда</div>
  </Card>
  <Card x={64} y={820} w={952} at={fr(d, 0.62)} label="ТРОМБЫ">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>Профилактика — индивидуально · препараты сами не начинать</div>
  </Card>
  <Clip3D src="c3/logroll_getup.mp4" y={1000} h={440} d={d} dur={7} at={fr(d, 0.05)} />
</>;

const S09: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const items: [string, string][] = [['wound', 'инфекция раны'], ['calf', 'тромбы в венах ног'], ['leg', 'повреждение нервных структур'], ['drop', 'кровотечение'], ['head', 'подтекание спинномозговой жидкости']];
  return <>
    {items.map(([k, t], i) => <div key={i} style={{position: 'absolute', left: 64, top: 480 + i * 120, opacity: ease(f, fr(d, 0.05 + i * 0.08), fr(d, 0.12 + i * 0.08)), display: 'flex', alignItems: 'center', gap: 18}}><Icon k={k} s={56} c={C.mute} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>{t}</span></div>)}
    <div style={{position: 'absolute', left: 64, top: 1090, opacity: ease(f, fr(d, 0.5), fr(d, 0.6))}}><Note color={C.teal} bg={C.tealL} size={30}>не у каждого</Note></div>
    <Card x={64} y={1180} w={952} at={fr(d, 0.7)} label="ПОСЛЕ СПОНДИЛОДЕЗА">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.ink}}>Иногда кости не срастаются — чаще у курящих, при диабете, в пожилом возрасте</div>
    </Card>
  </>;
};

const S10: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={520} at={fr(d, 0.02)} title="Немедленно в приёмное отделение" color="#B45309" bg="#FFF7ED"
    items={[['leg', 'новая или быстро нарастающая слабость одной или обеих ног'], ['bladder', 'онемение: половые органы, между ног, вокруг заднего прохода'], ['bladder', 'трудности с мочеиспусканием'], ['bladder', 'потеря контроля мочевого пузыря или кишечника']]} />
  <Card x={64} y={1020} w={952} at={fr(d, 0.7)} style={{background: '#FDECEC', border: `4px solid ${C.blood}`}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>Не садитесь за руль сами · не можете безопасно добраться — 101</div>
  </Card>
  <Phone101 y={1180} at={fr(d, 0.76)} s={0.62} />
</>;

const S11: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={230} at={fr(d, 0.02)} title="101 — сразу" color={C.blood} bg="#FDECEC"
    items={[['lungs', 'внезапная одышка'], ['heart', 'боль в груди']]} />
  <Tier y={730} h={300} at={fr(d, 0.25)} title="Срочно в приёмное отделение" color="#B45309" bg="#FFF7ED"
    items={[['wound', 'прозрачная водянистая жидкость из раны'], ['head', 'новая головная боль сидя или стоя, легче лёжа']]} />
  <Tier y={1060} h={300} at={fr(d, 0.65)} title="В тот же день к врачу" color={C.navy} bg="#fff"
    items={[['therm', 'температура'], ['wound', 'покраснение или выделения из раны'], ['calf', 'новая боль или отёк одной голени']]} />
</>;

const S12: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>Это общие рекомендации</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>Индивидуальные указания вашего врача и медицинской команды имеют приоритет</div>
  </Card>
);

const SC: Record<string, React.FC<{d: number}>> = {D01: S01, D02: S02, D03: S03, D04: S04, D05: S05, D06: S06, D07: S07, D08: S08, D09: S09, D10: S10, D11: S11, D12: S12};

export const Fusion: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
