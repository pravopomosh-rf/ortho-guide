// «Перелом плеча у сустава» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import {DressAnim, WristElev, FingerFlex, SharpsBin, ArmLimits} from './LimbArt';
import timing from './timing_shoulder_en.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalShoulder_en = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'ORTHOPAEDICS · FOR PATIENTS';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Перелом проксимального отдела плечевой кости: сцены U01–U13 ----
const SKIN = '#E4E7EC', SKINS = '#C9CED6', BONE = '#EFE6D8', BONES = '#C9B79C';
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10)}}><Note size={28} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
// скелет правого плеча спереди: ключица, лопатка (суставная впадина), плечевая кость до локтя; frac — линия перелома хирургической шейки
const ArmBones: React.FC<{frac?: number; top?: number; plate?: number; nail?: number; prost?: number; labels?: boolean}> = ({frac = 0, top = 480, plate = 0, nail = 0, prost = 0, labels = true}) => <svg width={1080} height={760} style={{position: 'absolute', left: 0, top}}>
  <path d="M 200 120 C 300 90 420 100 520 130" stroke={BONES} strokeWidth={30} strokeLinecap="round" fill="none" />
  <path d="M 200 120 C 300 90 420 100 520 130" stroke={BONE} strokeWidth={22} strokeLinecap="round" fill="none" />
  <path d="M 330 150 L 520 170 L 560 230 L 520 420 L 360 330 Z" fill={BONE} stroke={BONES} strokeWidth={4} opacity={0.8} />
  <ellipse cx={560} cy={215} rx={18} ry={44} fill="#D7E9EE" stroke="#9CC9D3" strokeWidth={3} />
  <g opacity={1 - prost}><circle cx={608} cy={215} r={52} fill={BONE} stroke={BONES} strokeWidth={4} /></g>
  <g opacity={prost}><circle cx={604} cy={215} r={48} fill="#C9D2DC" stroke="#6B7686" strokeWidth={4} /><rect x={612} y={250} width={22} height={200} rx={10} fill="#C9D2DC" stroke="#6B7686" strokeWidth={4} /></g>
  <path d="M 590 250 C 600 280 640 290 650 270 L 660 680 C 660 700 600 700 600 680 Z" fill={BONE} stroke={BONES} strokeWidth={4} />
  <ellipse cx={630} cy={700} rx={60} ry={26} fill={BONE} stroke={BONES} strokeWidth={4} />
  {frac > 0 && <path d="M 588 300 L 610 292 L 624 306 L 642 296 L 662 304" stroke={C.acc} strokeWidth={6} fill="none" strokeLinecap="round" opacity={frac} />}
  <g opacity={plate}><rect x={662} y={200} width={22} height={260} rx={10} fill="#8E99A8" stroke="#5B6575" strokeWidth={3} />
    {[225, 265, 330, 390, 430].map((y) => <line key={y} x1={684} y1={y} x2={600} y2={y + 4} stroke={C.navy} strokeWidth={8} strokeLinecap="round" />)}</g>
  <g opacity={nail}><rect x={618} y={190} width={18} height={420} rx={9} fill="#8E99A8" stroke="#5B6575" strokeWidth={3} /></g>
  {labels && <g fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.mute}>
    <text x={180} y={80}>collarbone</text><text x={300} y={380}>shoulder blade</text><text x={700} y={560}>upper arm bone</text><text x={700} y={710}>elbow</text></g>}
</svg>;

const S01: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Card x={64} y={470} w={420} label="PATIENT" at={4}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>Patient</div>
      
    </Card>
    <Card x={540} y={470} w={476} label="CAUSE" at={14}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink}}>fall at home</div>
    </Card>
    <ArmBones frac={ease(f, fr(d, 0.6), fr(d, 0.75))} top={680} labels={false} />
    <Notes y={1360} items={[['pain', fr(d, 0.3)], ['swelling', fr(d, 0.38)], ['hard to move', fr(d, 0.46)], ['fracture near the joint', fr(d, 0.75)]]} />
  </>;
};
const S02: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <ArmBones frac={ease(f, fr(d, 0.4), fr(d, 0.55))} />
    <Hint t="diagram, not to scale · right shoulder from the front" y={1250} />
    <Notes y={1300} items={[['top part of the upper arm bone', fr(d, 0.45)], ['mostly older people after a fall', fr(d, 0.7), C.navy, '#E3E7EF']]} />
  </>;
};
const Hint: React.FC<{t: string; y?: number}> = ({t, y = 1200}) => <div style={{position: 'absolute', left: 64, top: y, fontFamily: BODY, fontWeight: 600, fontSize: 22, color: C.mute}}>{t}</div>;
const Sling: React.FC<{top?: number}> = ({top = 500}) => <svg width={1080} height={560} style={{position: 'absolute', left: 0, top}}>
  <circle cx={540} cy={80} r={58} fill={SKIN} stroke={SKINS} strokeWidth={4} />
  <path d="M 420 150 L 660 150 L 690 520 L 390 520 Z" fill={SKIN} stroke={SKINS} strokeWidth={4} />
  <path d="M 600 160 L 640 330 L 470 380" stroke={SKINS} strokeWidth={46} fill="none" strokeLinecap="round" strokeLinejoin="round" />
  <path d="M 450 340 L 660 300 L 680 400 L 470 430 Z" fill={C.teal} opacity={0.85} />
  <path d="M 500 150 L 470 360 M 650 160 L 670 320" stroke={C.teal} strokeWidth={10} />
</svg>;
const S03: React.FC<{d: number}> = ({d}) => <>
  <Sling top={480} />
  <Card x={64} y={1060} w={952} at={fr(d, 0.55)} label="PROFHER STUDY">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>Over 2 years: no significant difference in shoulder function</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 24, color: C.mute, marginTop: 8}}>adults · displaced surgical neck fracture</div>
  </Card>
</>;
const Mini: React.FC<{x: number; at: number; t: string; plate?: number; nail?: number; prost?: number}> = ({x, at, t, plate = 0, nail = 0, prost = 0}) => {
  const f = useCurrentFrame(); const p = ease(f, at, at + 14);
  return <div style={{position: 'absolute', left: x, top: 470, width: 310, opacity: p}}>
    <div style={{position: 'relative', width: 310, height: 520, overflow: 'hidden', borderRadius: 24, background: '#fff', boxShadow: '0 14px 34px rgba(20,24,32,.08)'}}>
      <div style={{position: 'absolute', left: -470, top: -150, transform: 'scale(0.82)', transformOrigin: '630px 360px'}}><ArmBones top={0} frac={plate + nail > 0 ? 1 : 0} plate={plate} nail={nail} prost={prost} labels={false} /></div>
    </div>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink, textAlign: 'center', marginTop: 12}}>{t}</div>
  </div>;
};
const S04: React.FC<{d: number}> = ({d}) => <>
  <Mini x={50} at={fr(d, 0.3)} t="plate and screws" plate={1} />
  <Mini x={385} at={fr(d, 0.42)} t="rod" nail={1} />
  <Mini x={720} at={fr(d, 0.55)} t="joint replacement" prost={1} />
  <Card x={64} y={1120} w={952} at={fr(d, 0.8)} style={{background: C.navy}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: '#fff'}}>The surgeon decides together with you</div>
  </Card>
</>;
const S05: React.FC<{d: number}> = ({d}) => <>
  <Sling top={480} />
  <Notes y={1060} items={[['usually several weeks · as your doctor says', fr(d, 0.1)], ['remove for: washing, dressing, exercises · if allowed', fr(d, 0.4), C.navy, '#E3E7EF'], ['wear the sling as shown on the ward', fr(d, 0.72)]]} />
</>;
const S06: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame(); const b = ease(f, fr(d, 0.35), fr(d, 0.7));
  return <>
    <svg width={1080} height={600} style={{position: 'absolute', left: 0, top: 480}}>
      <path d="M 420 40 C 520 20 600 30 620 80 L 640 520 C 640 560 560 560 560 520 L 520 120 Z" fill={SKIN} stroke={SKINS} strokeWidth={4} />
      <ellipse cx={575} cy={120 + 300 * b} rx={50} ry={70 + 40 * b} fill="#8E6BB5" opacity={0.35} />
      <ellipse cx={565} cy={100} rx={46} ry={56} fill="#8E6BB5" opacity={0.35 * (1 - b * 0.5)} />
      <text x={680} y={130} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.mute}>shoulder</text>
      <text x={680} y={480} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.mute}>elbow</text>
    </svg>
    <Notes y={1120} items={[['painkillers · as prescribed', fr(d, 0.1)], ['bruise moves down to the elbow · normal', fr(d, 0.5), C.teal, C.tealL], ['sleep half sitting up, with pillows', fr(d, 0.78), C.navy, '#E3E7EF']]} />
  </>;
};
const S07: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame(); const sw = Math.sin(f / 10) * 14 * ease(f, fr(d, 0.5), fr(d, 0.6));
  return <>
    <CheckRow y={480} at={fr(d, 0.02)} icon="check" text="Fingers, hand, elbow · from the first days, unless told not to" />
    <svg width={1080} height={480} style={{position: 'absolute', left: 0, top: 720}}>
      <circle cx={380} cy={90} r={40} fill={SKIN} stroke={SKINS} strokeWidth={4} />
      <path d="M 410 120 L 620 200" stroke={SKINS} strokeWidth={40} strokeLinecap="round" />
      <path d="M 620 200 L 640 420" stroke={SKINS} strokeWidth={34} strokeLinecap="round" />
      <rect x={720} y={150} width={200} height={20} rx={8} fill="#C9CED6" /><rect x={900} y={170} width={16} height={260} fill="#C9CED6" />
      <g transform={`rotate(${sw} 470 140)`}><path d="M 470 140 L 470 400" stroke={C.acc} strokeWidth={30} strokeLinecap="round" /></g>
      <text x={250} y={460} fontFamily="'Body'" fontWeight={700} fontSize={26} fill={C.mute}>pendulum: the arm hangs and gently swings</text>
    </svg>
    <Notes y={1240} items={[['shoulder · physio programme', fr(d, 0.7), C.navy, '#E3E7EF']]} />
  </>;
};
const S08: React.FC<{d: number}> = ({d}) => <>
  <DressAnim top={470} d={d} />
  <div style={{position: 'absolute', left: 0, top: 440, width: 1080, height: 1920}}><S08c d={d} /></div>
</>;
const S08c: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={540} at={fr(d, 0.05)} icon="check" text="Dressing · injured arm first" />
  <CheckRow y={780} at={fr(d, 0.45)} icon="check" text="Undressing · uninjured arm first" />
</>;
const S09: React.FC<{d: number}> = ({d}) => <>
  <ArmLimits top={1000} d={d} />
  <Card x={64} y={480} w={952} at={fr(d, 0.02)} label="FIRST WEEKS">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>Load only as your doctor allows · no pushing or pulling</div>
  </Card>
  <Card x={64} y={740} w={952} at={fr(d, 0.55)} label="DRIVING">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>Only when safe and your doctor allows</div>
  </Card>
</>;
const S10: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const pts: [string, string, number][] = [['weeks', 'most improvement', 0.1], ['months', 'shoulder movement', 0.4], ['up to a year', 'strength', 0.7]];
  return <>
    <div style={{position: 'absolute', left: 120, top: 560, width: 840, height: 8, borderRadius: 4, background: C.line}} />
    <div style={{position: 'absolute', left: 120, top: 560, width: 840 * ease(f, fr(d, 0.05), fr(d, 0.8)), height: 8, borderRadius: 4, background: C.teal}} />
    {pts.map(([a, b, p], i) => <div key={i} style={{position: 'absolute', left: 70 + i * 340, top: 600, width: 280, opacity: ease(f, fr(d, p), fr(d, p) + 10)}}>
      <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 38, color: C.ink}}>{a}</div>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.mute, marginTop: 6}}>{b}</div></div>)}
    <Notes y={900} items={[['not everyone regains full movement', fr(d, 0.75), C.navy, '#E3E7EF'], ['usually little effect on daily life', fr(d, 0.85), C.teal, C.tealL]]} />
  </>;
};
const S11: React.FC<{d: number}> = ({d}) => <>
  <svg width={1080} height={420} style={{position: 'absolute', left: 0, top: 480}}>
    <rect x={340} y={40} width={400} height={340} rx={40} fill={BONE} stroke={BONES} strokeWidth={4} />
    {Array.from({length: 24}, (_, i) => <circle key={i} cx={380 + (i % 6) * 64} cy={90 + Math.floor(i / 6) * 76} r={10 + (i * 7) % 12} fill="#fff" stroke={BONES} strokeWidth={2} />)}
  </svg>
  <Notes y={960} items={[['fracture after a simple fall · possibly osteoporosis', fr(d, 0.1)], ['bone check', fr(d, 0.5), C.navy, '#E3E7EF'], ['falls prevention', fr(d, 0.7), C.teal, C.tealL]]} />
</>;
const S12: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={360} at={fr(d, 0.02)} title="Urgent medical help" color="#B45309" bg="#FFF7ED"
    items={[['wound', 'hand or fingers numb or tingling'], ['drop', 'pale, bluish or cold'], ['head', 'pain much worse']]} />
  <Tier y={860} h={240} at={fr(d, 0.5)} title="After surgery · the same day" color={C.navy} bg="#fff"
    items={[['therm', 'fever'], ['wound', 'redness or discharge from the wound']]} />
  <Tier y={1130} h={200} at={fr(d, 0.8)} title="Call 101 immediately" color={C.blood} bg="#FDECEC"
    items={[['lungs', 'sudden shortness of breath'], ['heart', 'chest pain']]} />
</>;
const S13: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>These are general recommendations</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>Individual instructions from your doctor and medical team come first</div>
  </Card>
);
const SC: Record<string, React.FC<{d: number}>> = {U01: S01, U02: S02, U03: S03, U04: S04, U05: S05, U06: S06, U07: S07, U08: S08, U09: S09, U10: S10, U11: S11, U12: S12, U13: S13};

export const Shoulder_en: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
