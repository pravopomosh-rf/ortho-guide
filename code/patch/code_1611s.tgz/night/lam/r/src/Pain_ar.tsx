// «Боль после операции» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import {NightBed, FaceScale} from './PainArt';
import {Clip3D} from './Clip3D';
import timing from './timing_pain_ar.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalPain_ar = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'جراحة العظام · للمرضى';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Боль: сцены B01–B11 ----
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10)}}><Note size={28} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const Box: React.FC<{y: number; at: number; text: string; color?: string; bg?: string; label?: string}> = ({y, at, text, color, bg, label}) =>
  <Card x={64} y={y} w={952} at={at} label={label} style={color ? {border: `4px solid ${color}`, background: bg || '#fff'} : {}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink, lineHeight: 1.3}}>{text}</div>
  </Card>;
const S01: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame(); const n = ease(f, fr(d, 0.3), fr(d, 0.45));
  return <>
    <Card x={64} y={470} w={420} label="المريض" at={4}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>مريض</div>
      
    </Card>
    <Card x={540} y={470} w={476} label="أمس" at={14}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>استبدال مفصل الركبة</div>
    </Card>
    <NightBed top={740} d={d} />
    <Notes y={1260} items={[['تحمّل', fr(d, 0.35)], ['لم يخبر أحدًا', fr(d, 0.45)], ['في الصباح لم يستطع أداء التمارين', fr(d, 0.7), C.navy, '#E3E7EF']]} />
  </>;
};
const S02: React.FC<{d: number}> = ({d}) => <>
  <Box y={480} at={fr(d, 0.02)} text="بعض الألم بعد العملية · متوقَّع" color={C.teal} bg={C.tealL} />
  <Tier y={680} h={220} at={fr(d, 0.3)} title="الألم الشديد يعيق" color={C.acc} bg="#fff" items={[['leg', 'الحركة'], ['lungs', 'التنفس العميق'], ['clock', 'النوم']]} />
  <CheckRow y={940} at={fr(d, 0.7)} icon="check" text="الهدف · ألم محتمل وحركة" />
</>;
const S03: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const col = (i: number) => `hsl(${120 - i * 12}, 62%, ${i < 5 ? 42 : 48}%)`;
  return <>
    <div style={{position: 'absolute', left: 64, top: 560, display: 'flex', gap: 8}}>
      {Array.from({length: 11}, (_, i) => <div key={i} style={{width: 80, height: 110, borderRadius: 16, background: col(i), opacity: ease(f, fr(d, 0.04 + i * 0.03), fr(d, 0.08 + i * 0.03)), display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: HEAD, fontWeight: 800, fontSize: 40, color: '#fff'}}>{i}</div>)}
    </div>
    <Notes y={720} items={[['0 · لا ألم', fr(d, 0.4), C.green, '#E7F6EC'], ['10 · أشدّ ألم', fr(d, 0.55)]]} />
    <FaceScale d={d} ptrY={500} faceY={960} rtl />
    <Notes y={810} items={[['أجيبوا بصدق', fr(d, 0.8), C.navy, '#E3E7EF']]} />
  </>;
};
const S04: React.FC<{d: number}> = ({d}) => <>
  <Box y={480} at={fr(d, 0.02)} text="لا تنتظروا حتى يشتدّ الألم كثيرًا" color={C.acc} />
  <CheckRow y={680} at={fr(d, 0.3)} icon="check" text="إخبار الطاقم عندما يبدأ الألم بالازدياد" />
  <CheckRow y={900} at={fr(d, 0.62)} icon="leg" text="المسكّن مسبقًا · قبل التمارين أو النهوض" />
</>;
const S05: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={470} at={fr(d, 0.05)} icon="pills" text="الباراسيتامول" />
  <CheckRow y={640} at={fr(d, 0.15)} icon="pills" text="مضادات الالتهاب · إذا كانت مناسبة" />
  <CheckRow y={810} at={fr(d, 0.25)} icon="pills" text="الأفيونيات · للألم الشديد" />
  <Notes y={1000} items={[['معًا · تعمل بشكل أفضل', fr(d, 0.45), C.teal, C.tealL], ['أحيانًا · إحصار عصبي', fr(d, 0.65), C.navy, '#E3E7EF'], ['الطبيب يحدّد الخطة', fr(d, 0.82)]]} />
</>;
const S06: React.FC<{d: number}> = ({d}) => <>
  <Tier y={480} h={240} at={fr(d, 0.2)} title="آثار جانبية محتملة" color={C.acc} bg="#fff" items={[['head', 'نعاس'], ['faint', 'غثيان'], ['wound', 'حكة'], ['bladder', 'إمساك']]} />
  <Box y={770} at={fr(d, 0.65)} text="لفترة قصيرة · التخفيض حسب تعليمات الطبيب" color={C.navy} />
</>;
const S07: React.FC<{d: number}> = ({d}) => <>
  <Box y={460} at={fr(d, 0.12)} text="الملين · ناقشوه مسبقًا" color={C.navy} />
  <CheckRow y={630} at={fr(d, 0.42)} icon="drop" text="شرب ما يكفي إن لم يكن هناك تقييد" />
  <CheckRow y={790} at={fr(d, 0.58)} icon="leg" text="الحركة · حسب إذن الطبيب" />
  <CheckRow y={950} at={fr(d, 0.7)} icon="check" text="أطعمة غنية بالألياف" />
  <Box y={1120} at={fr(d, 0.85)} text="لا تبرّز · أخبروا الطاقم" color="#B45309" bg="#FFF7ED" />
</>;
const S08: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.1)} icon="therm" text="البرودة عبر قماش · المدة التي سمح بها الطاقم" />
  <CheckRow y={620} at={fr(d, 0.35)} icon="leg" text="رفع الساق أو الذراع" />
  <CheckRow y={760} at={fr(d, 0.55)} icon="clock" text="الراحة بين التمارين" />
  <Notes y={900} items={[['إذا لم يمنعه الطبيب', fr(d, 0.8), C.navy, '#E3E7EF']]} />
  <Clip3D src="c3/swell_elevate_nl.mp4" y={990} h={460} d={d} dur={8} at={fr(d, 0.35)} />
</>;
const S09: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={430} at={fr(d, 0.03)} icon="pills" text="تمامًا كما وُصف · دون تجاوز الجرعة" />
  <CheckRow y={575} at={fr(d, 0.16)} icon="check" text="هل يوجد باراسيتامول في أدوية أخرى" />
  <Box y={730} at={fr(d, 0.3)} text="مضادات الالتهاب والمنوّمات · فقط بموافقة الطبيب" color={C.acc} />
  <Box y={895} at={fr(d, 0.5)} text="دون كحول · لا قيادة مع المسكّنات القوية" color={C.acc} />
  <CheckRow y={1030} at={fr(d, 0.7)} icon="check" text="الحفظ بعيدًا عن الأطفال" />
  <CheckRow y={1170} at={fr(d, 0.85)} icon="check" text="الأدوية الزائدة · اسألوا في الصيدلية" />
</>;
const S10: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={300} at={fr(d, 0.02)} title="طارئ: في المستشفى · الطاقم فورًا · في البيت · 101" color={C.blood} bg="#FDECEC"
    items={[['head', 'صعوبة الإيقاظ'], ['lungs', 'تنفّس بطيء أو سطحي'], ['lungs', 'ضيق نفس مفاجئ'], ['heart', 'ألم في الصدر']]} />
  <Tier y={810} h={220} at={fr(d, 0.7)} title="إلى الطبيب بشكل عاجل" color="#B45309" bg="#FFF7ED"
    items={[['therm', 'ألم اشتدّ فجأة'], ['pills', 'لا يخفّ بالأدوية']]} />
</>;
const S11: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>هذه توصيات عامة</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>التعليمات الشخصية من طبيبكم والفريق الطبي لها الأولوية</div>
  </Card>
);
const SC: Record<string, React.FC<{d: number}>> = {B01: S01, B02: S02, B03: S03, B04: S04, B05: S05, B06: S06, B07: S07, B08: S08, B09: S09, B10: S10, B11: S11};

export const Pain_ar: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill style={{direction: 'rtl'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
