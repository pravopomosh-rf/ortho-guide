// «Грыжа диска и спондилодез» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import {Phone101} from './UrgentArt';
import {Clip3D} from './Clip3D';
import timing from './timing_fusion_he.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalFusion_he = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'אורתופדיה · למטופלים';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Грыжа диска и спондилодез: сцены D01–D11 ----
const BONE = '#EFE6D8', BONES = '#C9B79C';
// межпозвонковый диск сверху: спереди вверху, сзади внизу; позвоночный канал сзади с дуральным мешком и корешками
const DiscTop: React.FC<{h: number; rem?: number; top?: number; press?: number}> = ({h, rem = 0, top = 470, press = 0}) => {
  const hv = h * (1 - rem);
  return <svg width={1080} height={760} viewBox="0 0 1080 760" style={{position: 'absolute', left: 0, top}}>
    {/* фиброзное кольцо */}
    <path d="M 260 300 C 260 140 420 90 540 110 C 660 90 820 140 820 300 C 820 380 760 420 690 425 C 640 430 600 410 540 410 C 480 410 440 430 390 425 C 320 420 260 380 260 300 Z" fill="#DCEAF0" stroke="#9CC9D3" strokeWidth={5} />
    {/* пульпозное ядро */}
    <ellipse cx={540} cy={260} rx={150} ry={90} fill="#BFD9E6" />
    {/* грыжа: задне-боковая слева */}
    {hv > 0 && <path d="M 485 402 C 482 440 462 462 440 466 C 418 468 404 452 408 428 C 414 410 440 402 485 402 Z" transform={`translate(450 404) scale(${0.3 + 0.7 * hv} ${hv}) translate(-450 -404)`} fill="#BFD9E6" stroke={C.acc} strokeWidth={4} />}
    {/* дужка позвонка (задние элементы) */}
    <path d="M 380 440 C 360 520 400 600 470 640 L 540 700 L 610 640 C 680 600 720 520 700 440 L 660 445 C 670 520 640 580 540 600 C 440 580 410 520 420 445 Z" fill={BONE} stroke={BONES} strokeWidth={4} />
    {/* дуральный мешок */}
    <ellipse cx={540} cy={510} rx={100} ry={70} fill="#E3F1F7" stroke="#8CC3D6" strokeWidth={4} />
    {[500, 540, 580].map((x) => <circle key={x} cx={x} cy={515} r={10} fill="#F2D27A" />)}
    {/* корешки */}
    <circle cx={425 - 0 * press} cy={470 + 12 * press * hv} r={16} fill="#F2D27A" stroke={hv * press > 0.5 ? C.acc : '#C99A1E'} strokeWidth={4} />
    <circle cx={655} cy={470} r={16} fill="#F2D27A" stroke="#C99A1E" strokeWidth={4} />
  </svg>;
};

const S01: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const p = ease(f, fr(d, 0.25), fr(d, 0.55));
  return <>
    <Card x={64} y={470} w={420} label="מטופל" at={4}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>מטופל</div>
      
    </Card>
    <Card x={540} y={470} w={476} label="כאב שמקרין לרגל" at={14}>
      <div><Counter from={0} to={2} a={fr(d, 0.3)} b={fr(d, 0.6)} size={78} suffix=" חודשים" /></div>
    </Card>
    <svg width={1080} height={760} style={{position: 'absolute', left: 0, top: 700}}>
      {/* силуэт сбоку: таз и нога */}
      <path d="M 470 40 C 520 30 600 40 620 90 L 640 200 C 650 260 630 320 610 360 L 600 560 L 640 690 L 560 700 L 540 560 L 520 380 C 500 330 470 260 460 200 Z" fill="#E4E7EC" stroke="#C9CED6" strokeWidth={4} />
      <path d={`M 560 150 C 590 220 600 300 585 380 C 575 460 570 540 590 ${560 + 120 * p}`} stroke={C.acc} strokeWidth={10} fill="none" strokeLinecap="round" strokeDasharray="900" strokeDashoffset={900 * (1 - p)} opacity={0.85} />
      <circle cx={560} cy={150} r={26} fill={C.acc} opacity={0.35 * p} />
    </svg>
    <div style={{position: 'absolute', left: 64, top: 1420, display: 'flex', gap: 12, flexWrap: 'wrap'}}>
      {['כאב ברגל', 'חוסר תחושה', 'לא חלף ללא ניתוח'].map((t, i) => <div key={t} style={{opacity: ease(f, fr(d, 0.5) + i * 8, fr(d, 0.5) + 10 + i * 8)}}><Note size={28}>{t}</Note></div>)}
    </div>
  </>;
};

const S02: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const h = ease(f, fr(d, 0.1), fr(d, 0.4));
  return <>
    <DiscTop h={h} press={h} />
    <div style={{position: 'absolute', left: 64, top: 1230, fontFamily: BODY, fontWeight: 600, fontSize: 22, color: C.mute}}>תרשים, לא בקנה מידה · מבט מלמעלה, הגב למטה</div>
    <div style={{position: 'absolute', left: 64, top: 1280, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
      <div style={{opacity: h}}><Note size={28}>הפריצה לוחצת על השורש</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.6), fr(d, 0.7))}}><Note color={C.teal} bg={C.tealL} size={28}>לרוב חולף ללא ניתוח</Note></div>
    </div>
  </>;
};

const S03: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const items = ['סיאטיקה', 'טיפול ללא ניתוח לא עזר', 'ההדמיה תואמת את התסמינים'];
  return <>
    {items.map((t, i) => <Slot key={i} x={64} y={480 + i * 190} w={952} h={160} at={fr(d, 0.08 + i * 0.18)}>
      <Icon k="check" s={64} /><div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>{t}</div></Slot>)}
    <Card x={64} y={1080} w={952} at={fr(d, 0.75)} style={{background: C.navy}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: '#fff'}}>המנתח מחליט אחרי בדיקה</div>
    </Card>
  </>;
};

const S04: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const r = ease(f, fr(d, 0.2), fr(d, 0.5));
  return <>
    <DiscTop h={1} rem={r} press={1} />
    <div style={{position: 'absolute', left: 64, top: 1230, fontFamily: BODY, fontWeight: 600, fontSize: 22, color: C.mute}}>תרשים, לא בקנה מידה · מבט מלמעלה, הגב למטה</div>
    <div style={{position: 'absolute', left: 64, top: 1280, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
      <div style={{opacity: ease(f, fr(d, 0.05), fr(d, 0.15))}}><Note color={C.navy} bg="#E3E7EF" size={28}>חתך קטן או אנדוסקופ</Note></div>
      <div style={{opacity: r}}><Note color={C.teal} bg={C.tealL} size={28}>השורש משוחרר</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.7), fr(d, 0.8))}}><Note size={28}>חלק מהדיסק נשאר · הפריצה עלולה לחזור</Note></div>
    </div>
  </>;
};

const S05: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const scr = ease(f, fr(d, 0.3), fr(d, 0.45)), graft = ease(f, fr(d, 0.15), fr(d, 0.3));
  const Vt = (y: number) => <g>
    <rect x={250} y={y} width={260} height={160} rx={30} fill={BONE} stroke={BONES} strokeWidth={4} />
    <path d={`M 505 ${y + 40} L 600 ${y + 30} L 600 ${y + 90} L 505 ${y + 95} Z`} fill={BONE} stroke={BONES} strokeWidth={4} />
    <path d={`M 600 ${y + 20} L 650 ${y + 10} L 790 ${y + 60} L 800 ${y + 100} L 650 ${y + 110} L 600 ${y + 100} Z`} fill={BONE} stroke={BONES} strokeWidth={4} />
  </g>;
  const screw = (y: number) => <g><line x1={640} y1={y + 62} x2={330} y2={y + 82} stroke={C.navy} strokeWidth={14} strokeLinecap="round" /><circle cx={650} cy={y + 62} r={20} fill={C.navy} /></g>;
  return <>
    <svg width={1080} height={640} style={{position: 'absolute', left: 0, top: 480}}>
      {Vt(100)}{Vt(380)}
      <rect x={265} y={272} width={230} height={96} rx={22} fill="#D7E9EE" stroke="#9CC9D3" strokeWidth={3} />
      <g opacity={graft}>{Array.from({length: 15}, (_, i) => <circle key={i} cx={290 + (i % 5) * 45} cy={292 + Math.floor(i / 5) * 26} r={10} fill="#F2D27A" stroke="#C99A1E" strokeWidth={2} />)}</g>
      <g opacity={scr}>{screw(100)}{screw(380)}<line x1={672} y1={150} x2={672} y2={455} stroke="#6B7686" strokeWidth={16} strokeLinecap="round" /></g>
      <text textAnchor="end" x={250} y={80} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.mute}>מבט מהצד</text>
      <text textAnchor="end" x={250} y={118} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.teal}>קדימה</text>
      <text textAnchor="end" x={720} y={118} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.teal}>אחורה</text>
    </svg>
    <div style={{position: 'absolute', left: 64, top: 1130, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
      <div style={{opacity: graft}}><Note color="#9A7410" bg="#FBF0D0" size={28}>שתל עצם</Note></div>
      <div style={{opacity: scr}}><Note color={C.navy} bg="#E3E7EF" size={28}>ברגים דרך הפדיקלים + מוט</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.65), fr(d, 0.75))}}><Note size={28}>אי יציבות · החלקת חוליה · עיוותים · שברים</Note></div>
    </div>
  </>;
};

const S06: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={560} w={952} at={fr(d, 0.05)} style={{borderTop: `8px solid ${C.acc}`}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink}}>כאב גב תחתון לא ספציפי ללא התוויה ניתוחית</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 30, color: C.mute, marginTop: 12}}>לא מומלץ, למעט ניסויים קליניים אקראיים</div>
  </Card>
  <Card x={64} y={900} w={952} at={fr(d, 0.6)} style={{background: C.navy}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: '#fff'}}>האם אתם צריכים ניתוח? המנתח מחליט</div>
  </Card>
</>;

const S07: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.02)} icon="shower" text="צום, מקלחת, תרופות: לפי דף ההכנה לניתוח" />
  <CheckRow y={720} at={fr(d, 0.25)} icon="pills" text="מדללי דם: רק לפי הוראת הרופא" />
  <Card x={64} y={960} w={952} at={fr(d, 0.55)} label="עישון">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>מעלה את הסיכון שהעצמות לא יתאחו · שוחחו עם הרופא על הפסקה</div>
  </Card>
</>;

const S08: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.02)} icon="leg" text="להתחיל לזוז וללכת עם הצוות, כשזה בטוח" />
  <Card x={64} y={640} w={952} at={fr(d, 0.3)} label="פעילות מותרת · מחוך · הגבלות">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>קובעים המנתח וצוות השיקום</div>
  </Card>
  <Card x={64} y={820} w={952} at={fr(d, 0.62)} label="קרישי דם">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>מניעה מותאמת אישית · לא להתחיל תרופות לבד</div>
  </Card>
  <Clip3D src="c3/logroll_getup.mp4" y={1000} h={440} d={d} dur={7} at={fr(d, 0.05)} />
</>;

const S09: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const items: [string, string][] = [['wound', 'זיהום בפצע'], ['calf', 'קרישים בוורידי הרגליים'], ['leg', 'פגיעה במבנים עצביים'], ['drop', 'דימום'], ['head', 'דליפת נוזל השדרה']];
  return <>
    {items.map(([k, t], i) => <div key={i} style={{position: 'absolute', left: 64, top: 480 + i * 120, opacity: ease(f, fr(d, 0.05 + i * 0.08), fr(d, 0.12 + i * 0.08)), display: 'flex', alignItems: 'center', gap: 18}}><Icon k={k} s={56} c={C.mute} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>{t}</span></div>)}
    <div style={{position: 'absolute', left: 64, top: 1090, opacity: ease(f, fr(d, 0.5), fr(d, 0.6))}}><Note color={C.teal} bg={C.tealL} size={30}>לא אצל כל אחד</Note></div>
    <Card x={64} y={1180} w={952} at={fr(d, 0.7)} label="אחרי קיבוע חוליות">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.ink}}>לפעמים העצמות לא מתאחות · יותר אצל מעשנים, בסוכרת ובגיל מבוגר</div>
    </Card>
  </>;
};

const S10: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={520} at={fr(d, 0.02)} title="מיד לחדר המיון" color="#B45309" bg="#FFF7ED"
    items={[['leg', 'חולשה חדשה או מחמירה במהירות ברגל אחת או בשתיהן'], ['bladder', 'חוסר תחושה: איברי המין, בין הרגליים, סביב פי הטבעת'], ['bladder', 'קושי במתן שתן'], ['bladder', 'אובדן שליטה על השלפוחית או המעיים']]} />
  <Card x={64} y={1020} w={952} at={fr(d, 0.7)} style={{background: '#FDECEC', border: `4px solid ${C.blood}`}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>אל תנהגו בעצמכם · אין דרך בטוחה להגיע? 101</div>
  </Card>
  <Phone101 y={1180} at={fr(d, 0.76)} s={0.62} />
</>;

const S11: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={230} at={fr(d, 0.02)} title="101 מיד" color={C.blood} bg="#FDECEC"
    items={[['lungs', 'קוצר נשימה פתאומי'], ['heart', 'כאב בחזה']]} />
  <Tier y={730} h={300} at={fr(d, 0.25)} title="בדחיפות לחדר המיון" color="#B45309" bg="#FFF7ED"
    items={[['wound', 'נוזל שקוף ומימי מהפצע'], ['head', 'כאב ראש חדש בישיבה או בעמידה, קל יותר בשכיבה']]} />
  <Tier y={1060} h={300} at={fr(d, 0.65)} title="לרופא באותו יום" color={C.navy} bg="#fff"
    items={[['therm', 'חום'], ['wound', 'אודם או הפרשה מהפצע'], ['calf', 'כאב חדש או נפיחות בשוק אחת']]} />
</>;

const S12: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>אלה המלצות כלליות</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>ההוראות האישיות של הרופא ושל הצוות הרפואי קודמות</div>
  </Card>
);

const SC: Record<string, React.FC<{d: number}>> = {D01: S01, D02: S02, D03: S03, D04: S04, D05: S05, D06: S06, D07: S07, D08: S08, D09: S09, D10: S10, D11: S11, D12: S12};

export const Fusion_he: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill style={{direction: 'rtl'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
