// Рисунки для ролика «Дома после эндопротезирования ТБС» (thrhome). Только схемы; все надписи приходят из Thrhome.tsx (одобренный текст thrhome.json, vis_* ОДОБРЕНО).
// Люди — объёмные фигуры (не «палочки»): конечности-трубки с бликом, одежда, лицо; ноги и руки считаются обратной кинематикой.
import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C, ease, BODY} from './kit';
import {Frame, Tag} from './ShreplArt';

const fr = (d: number, p: number) => Math.round(d * p);
type P = [number, number];
const SKIN = '#EBC8AB', SKINS = '#C99B7A', HAIR = '#5A4636';
const WOOD = '#E4D2B8', WOODS = '#C8AF8C', MET = '#9AA6B4', METS = '#6B7686';

// 2-звенная ИК: от a к b длинами l1,l2; side=+1 — средний сустав «вперёд/вверх» относительно направления a→b
const ik = (a: P, b: P, l1: number, l2: number, side: number): P => {
  const dx = b[0] - a[0], dy = b[1] - a[1];
  let d = Math.hypot(dx, dy); d = Math.min(d, l1 + l2 - 0.5);
  const ca = (l1 * l1 + d * d - l2 * l2) / (2 * l1 * d);
  const ang = Math.atan2(dy, dx) + side * Math.acos(Math.max(-1, Math.min(1, ca)));
  return [a[0] + Math.cos(ang) * l1, a[1] + Math.sin(ang) * l1];
};
const Tube: React.FC<{a: P; b: P; w: number; c: string; hi?: string; o?: number}> = ({a, b, w, c, hi = 'rgba(255,255,255,.28)', o = 1}) => <g opacity={o}>
  <line x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke={c} strokeWidth={w} strokeLinecap="round" />
  <line x1={a[0] - w * 0.18} y1={a[1] - w * 0.12} x2={b[0] - w * 0.18} y2={b[1] - w * 0.12} stroke={hi} strokeWidth={w * 0.28} strokeLinecap="round" />
</g>;

export type Look = {shirt: string; pants: string; hair?: string; shoe?: string};
export const PAT: Look = {shirt: '#7FA7C9', pants: '#45536A', hair: '#6B5B4B'};
export const COMP: Look = {shirt: '#E7A977', pants: '#6E7F73', hair: '#3E2E22'};

// Фигура сбоку, лицом вправо. hip — таз; lean — наклон корпуса (рад, + вперёд); ankles/hands [ближняя, дальняя]
export const Body: React.FC<{hip: P; lean?: number; an: P; af: P; hn: P; hf: P; look?: Look; glow?: number; s?: number; legN?: string}> = ({hip, lean = 0, an, af, hn, hf, look = PAT, glow = 0, legN}) => {
  const T = 150, sh: P = [hip[0] + Math.sin(lean) * T, hip[1] - Math.cos(lean) * T];
  const hd: P = [hip[0] + Math.sin(lean) * (T + 56), hip[1] - Math.cos(lean) * (T + 56)];
  const kn = ik(hip, an, 122, 128, -1), kf = ik(hip, af, 122, 128, -1);
  const en = ik(sh, hn, 78, 72, 1), ef = ik(sh, hf, 78, 72, 1);
  const leg = (k: P, a: P, far: boolean, col: string) => <g opacity={far ? 0.82 : 1}>
    <Tube a={hip} b={k} w={44} c={col} /><Tube a={k} b={a} w={36} c={col} />
    <ellipse cx={a[0] + 16} cy={a[1] + 8} rx={30} ry={13} fill={far ? '#D9DDE3' : look.shoe || '#F4F4F4'} stroke="#AEB5BF" strokeWidth={2} />
  </g>;
  const arm = (e: P, h: P, far: boolean) => <g opacity={far ? 0.82 : 1}>
    <Tube a={sh} b={e} w={30} c={far ? '#6F92B0' : look.shirt} /><Tube a={e} b={h} w={22} c={SKIN} />
    <circle cx={h[0]} cy={h[1]} r={13} fill={SKIN} stroke={SKINS} strokeWidth={2} />
  </g>;
  return <g>
    {leg(kf, af, true, look.pants)}
    {arm(ef, hf, true)}
    <Tube a={hip} b={sh} w={78} c={look.shirt} />
    <circle cx={hd[0]} cy={hd[1]} r={40} fill={SKIN} stroke={SKINS} strokeWidth={2} />
    <path d={`M ${hd[0] - 42} ${hd[1] + 2} a 42 42 0 0 1 80 -14 q -26 -4 -44 8 q -16 -8 -36 6 Z`} fill={look.hair || HAIR} />
    <circle cx={hd[0] + 22} cy={hd[1] - 4} r={4} fill="#3a2a20" />
    <path d={`M ${hd[0] + 38} ${hd[1] + 2} q 8 6 0 12`} stroke={SKINS} strokeWidth={3} fill="none" />
    <path d={`M ${hd[0] + 14} ${hd[1] + 18} q 10 6 18 0`} stroke="#A0705A" strokeWidth={3} fill="none" strokeLinecap="round" />
    {glow > 0 && <g opacity={glow}>
      <line x1={hip[0]} y1={hip[1]} x2={kn[0]} y2={kn[1]} stroke={C.teal} strokeWidth={62} strokeLinecap="round" opacity={0.35} />
      <line x1={kn[0]} y1={kn[1]} x2={an[0]} y2={an[1]} stroke={C.teal} strokeWidth={54} strokeLinecap="round" opacity={0.35} />
    </g>}
    {leg(kn, an, false, legN || look.pants)}
    {arm(en, hn, false)}
  </g>;
};
export const kneeOf = (hip: P, an: P) => ik(hip, an, 122, 128, -1);

// Комната: стена, плинтус, деревянный пол, окно
export const Room: React.FC<{w?: number; h: number; floor: number; win?: number}> = ({w = 952, h, floor, win = 620}) => <g>
  <defs>
    <linearGradient id="thWall" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#FBFBF8" /><stop offset="1" stopColor="#EEF1F2" /></linearGradient>
    <linearGradient id="thFloor" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#E8D9C2" /><stop offset="1" stopColor="#D9C3A2" /></linearGradient>
  </defs>
  <rect x={0} y={0} width={w} height={floor} fill="url(#thWall)" />
  <rect x={0} y={floor} width={w} height={h - floor} fill="url(#thFloor)" />
  {[0, 1, 2, 3].map((i) => <line key={i} x1={0} y1={floor + 14 + i * 14} x2={w} y2={floor + 14 + i * 14} stroke={WOODS} strokeWidth={1.5} opacity={0.5} />)}
  <rect x={0} y={floor - 12} width={w} height={12} fill="#E1E4E8" />
  {win > 0 && <g><rect x={win} y={40} width={200} height={170} rx={10} fill="#DCEFFA" stroke="#C3CED8" strokeWidth={6} />
    <line x1={win + 100} y1={40} x2={win + 100} y2={210} stroke="#C3CED8" strokeWidth={5} /><line x1={win} y1={125} x2={win + 200} y2={125} stroke="#C3CED8" strokeWidth={5} />
    <path d={`M ${win + 20} 190 q 40 -60 80 -40`} stroke="#fff" strokeWidth={8} opacity={0.6} fill="none" /></g>}
</g>;

// Ходунки сбоку (ручки на высоте рук)
export const WalkerSide: React.FC<{x: number; floor: number; s?: number}> = ({x, floor, s = 1}) => <g transform={`translate(${x} ${floor}) scale(${s})`}>
  <g stroke={METS} strokeWidth={9} fill="none" strokeLinecap="round">
    <line x1={0} y1={0} x2={10} y2={-190} /><line x1={90} y1={0} x2={80} y2={-190} /><line x1={10} y1={-190} x2={80} y2={-190} /><line x1={4} y1={-90} x2={86} y2={-90} />
  </g>
  <rect x={0} y={-200} width={36} height={16} rx={8} fill="#3E4A5C" />
  <circle cx={90} cy={-6} r={10} fill="#3E4A5C" /><rect x={-8} y={-6} width={16} height={8} rx={3} fill="#3E4A5C" />
</g>;

// Стул сбоку: жёсткое сиденье, спинка, подлокотник. Лицом вправо, спинка слева
export const Chair: React.FC<{x: number; floor: number; seat: number; hl?: number; low?: boolean}> = ({x, floor, seat, hl = 0}) => {
  const y = floor - seat;
  return <g>
    <g stroke={WOODS} strokeWidth={10} strokeLinecap="round"><line x1={x + 6} y1={y} x2={x + 6} y2={floor} /><line x1={x + 134} y1={y} x2={x + 134} y2={floor} /></g>
    <rect x={x - 6} y={y - 14} width={152} height={22} rx={6} fill={WOOD} stroke={WOODS} strokeWidth={3} />
    <rect x={x - 8} y={y - 170} width={20} height={170} rx={8} fill={WOOD} stroke={WOODS} strokeWidth={3} />
    <rect x={x - 4} y={y - 78} width={130} height={14} rx={7} fill={WOOD} stroke={WOODS} strokeWidth={3} />
    <line x1={x + 118} y1={y - 66} x2={x + 118} y2={y - 14} stroke={WOODS} strokeWidth={8} />
    {hl > 0 && <rect x={x - 14} y={y - 180} width={168} height={seat + 186} rx={18} fill="none" stroke={C.teal} strokeWidth={5} strokeDasharray="14 10" opacity={hl} />}
  </g>;
};

export const Badge: React.FC<{x: number; y: number; ok: boolean; o?: number; r?: number}> = ({x, y, ok, o = 1, r = 34}) => <g opacity={o} transform={`translate(${x} ${y})`}>
  <circle r={r} fill={ok ? C.green : C.blood} />
  {ok ? <path d={`M ${-r * 0.45} 0 L ${-r * 0.1} ${r * 0.35} L ${r * 0.5} ${-r * 0.35}`} stroke="#fff" strokeWidth={r * 0.22} fill="none" strokeLinecap="round" strokeLinejoin="round" />
    : <path d={`M ${-r * 0.38} ${-r * 0.38} L ${r * 0.38} ${r * 0.38} M ${r * 0.38} ${-r * 0.38} L ${-r * 0.38} ${r * 0.38}`} stroke="#fff" strokeWidth={r * 0.22} strokeLinecap="round" />}
</g>;
const Warn: React.FC<{x: number; y: number; o?: number}> = ({x, y, o = 1}) => <g transform={`translate(${x} ${y})`} opacity={o}>
  <path d="M 0 -34 L 36 30 L -36 30 Z" fill={C.blood} stroke="#fff" strokeWidth={4} strokeLinejoin="round" />
  <rect x={-4} y={-14} width={8} height={26} rx={4} fill="#fff" /><circle cx={0} cy={21} r={4.5} fill="#fff" />
</g>;

const walkAnk = (f: number, x: number, floor: number, k: number): [P, P] => {
  const ph = f / 9;
  const a = (s: number): P => [x + Math.sin(ph + s) * 34 * k, floor - 12 - Math.max(0, Math.cos(ph + s)) * 14 * k];
  return [a(0), a(Math.PI)];
};

// TH01: пациент с ходунками и близкий человек входят домой
export const HomeArrive: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const H = 560, FL = 500;
  const go = ease(f, fr(d, 0.02), fr(d, 0.6));
  const x = 120 + go * 300, moving = go > 0.01 && go < 0.99 ? 1 : 0;
  const [an, af] = walkAnk(f, x + 10, FL, moving);
  const hip: P = [x, FL - 244 - Math.abs(Math.sin(f / 9)) * 4 * moving];
  const cx = x - 150;
  const [cn, cf] = walkAnk(f + 4, cx + 10, FL, moving);
  return <Frame top={top} h={H}>
    <svg width={952} height={H} style={{position: 'absolute', left: 0, top: 0, direction: 'ltr'}}>
      <Room h={H} floor={FL} win={640} />
      {/* дверь */}
      <rect x={20} y={110} width={150} height={FL - 110} fill="#F3EDE3" stroke="#D4C6B0" strokeWidth={6} /><circle cx={150} cy={320} r={8} fill="#B8A07C" />
      <Body hip={[cx, FL - 246]} lean={0.02} an={cn} af={cf} hn={[cx + 70, FL - 300]} hf={[cx + 40, FL - 196]} look={COMP} />
      <WalkerSide x={x + 70} floor={FL} />
      <Body hip={hip} lean={0.16} an={an} af={af} hn={[x + 84, FL - 196]} hf={[x + 76, FL - 198]} />
    </svg>
  </Frame>;
};

// TH02: подготовка дома — коврик и провод исчезают, вещи на среднюю полку, столик у кресла
export const PrepHome: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const H = 560, FL = 470;
  const rug = 1 - ease(f, fr(d, 0.2), fr(d, 0.3)), rugX = ease(f, fr(d, 0.1), fr(d, 0.16)) * (1 - ease(f, fr(d, 0.24), fr(d, 0.3)));
  const cab = 1 - ease(f, fr(d, 0.3), fr(d, 0.4)), cabX = ease(f, fr(d, 0.24), fr(d, 0.3)) * (1 - ease(f, fr(d, 0.36), fr(d, 0.4)));
  const path = ease(f, fr(d, 0.4), fr(d, 0.48));
  const up = ease(f, fr(d, 0.5), fr(d, 0.64));
  const tbl = ease(f, fr(d, 0.75), fr(d, 0.84));
  const it = (i: number) => { const y0 = FL - 40, y1 = FL - 200; return y0 + (y1 - y0) * ease(f, fr(d, 0.5 + i * 0.03), fr(d, 0.6 + i * 0.03)); };
  return <Frame top={top} h={H}>
    <svg width={952} height={H} style={{position: 'absolute', left: 0, top: 0, direction: 'ltr'}}>
      <Room h={H} floor={FL} win={360} />
      {/* стеллаж */}
      <g><rect x={40} y={FL - 320} width={190} height={320} fill="none" stroke={WOODS} strokeWidth={8} />
        {[FL - 230, FL - 160, FL - 20].map((y, i) => <rect key={i} x={40} y={y} width={190} height={10} fill={WOOD} stroke={WOODS} strokeWidth={2} />)}
        {[0, 1, 2].map((i) => <rect key={i} x={60 + i * 56} y={it(i) - 0} width={40} height={50} rx={8} fill={['#7FA7C9', '#E7A977', '#9BC7A4'][i]} stroke="rgba(0,0,0,.15)" strokeWidth={2} transform={`translate(0 ${-50 + 30})`} />)}
        <rect x={34} y={FL - 210} width={202} height={60} rx={10} fill="none" stroke={C.teal} strokeWidth={5} strokeDasharray="12 8" opacity={up * (1 - ease(f, fr(d, 0.72), fr(d, 0.78)))} />
      </g>
      {/* проход */}
      <rect x={270} y={FL + 14} width={380} height={60} rx={14} fill={C.green} opacity={0.18 * path} />
      {/* коврик со складкой */}
      <g opacity={rug}><path d={`M 300 ${FL + 30} L 560 ${FL + 30} L 580 ${FL + 60} L 290 ${FL + 60} Z`} fill="#C8664F" /><path d={`M 520 ${FL + 30} q 20 -16 40 0`} stroke="#A8503C" strokeWidth={6} fill="none" /></g>
      <Badge x={430} y={FL - 30} ok={false} o={rugX} />
      {/* провод */}
      <g opacity={cab}><path d={`M 600 ${FL - 20} q 20 30 -30 50 q -60 20 -120 10`} stroke="#2F3542" strokeWidth={7} fill="none" /><rect x={590} y={FL - 44} width={22} height={28} rx={4} fill="#fff" stroke="#9AA6B4" strokeWidth={3} /></g>
      <Badge x={560} y={FL - 60} ok={false} o={cabX} />
      {/* кресло */}
      <g><rect x={700} y={FL - 230} width={40} height={230} rx={14} fill="#8FB6A8" /><rect x={700} y={FL - 120} width={200} height={70} rx={20} fill="#A6C8BB" />
        <rect x={860} y={FL - 170} width={44} height={120} rx={16} fill="#8FB6A8" /><rect x={710} y={FL - 50} width={14} height={50} fill={WOODS} /><rect x={880} y={FL - 50} width={14} height={50} fill={WOODS} /></g>
      {/* столик на высоте сиденья */}
      <g opacity={tbl} transform={`translate(0 ${(1 - tbl) * 30})`}><rect x={600} y={FL - 124} width={90} height={14} rx={5} fill={WOOD} stroke={WOODS} strokeWidth={3} />
        <line x1={645} y1={FL - 110} x2={645} y2={FL} stroke={WOODS} strokeWidth={8} /><rect x={620} y={FL - 150} width={22} height={26} rx={4} fill="#fff" stroke="#9AA6B4" strokeWidth={2} />
        <line x1={600} y1={FL - 117} x2={910} y2={FL - 117} stroke={C.teal} strokeWidth={4} strokeDasharray="10 8" /></g>
    </svg>
  </Frame>;
};

// TH03: стул с линейкой высоты + кровать на подставках
export const ChairBed: React.FC<{top: number; d: number; h: string}> = ({top, d, h}) => {
  const f = useCurrentFrame();
  const H = 560, FL = 500, SEAT = 125;
  const meas = ease(f, fr(d, 0.3), fr(d, 0.42));
  const bed = ease(f, fr(d, 0.55), fr(d, 0.65));
  const rs = ease(f, fr(d, 0.78), fr(d, 0.88));
  return <div style={{position: 'absolute', left: 0, top, width: 1080, height: H}}>
    <Frame top={0} h={H}>
      <svg width={952} height={H} style={{position: 'absolute', left: 0, top: 0, direction: 'ltr'}}>
        <Room h={H} floor={FL} win={0} />
        <g transform="translate(70 0)"><Chair x={60} floor={FL} seat={SEAT} hl={ease(f, fr(d, 0.04), fr(d, 0.12)) * (1 - ease(f, fr(d, 0.26), fr(d, 0.3)))} /></g>
        {/* линейка */}
        <g opacity={meas}><line x1={300} y1={FL} x2={300} y2={FL - SEAT * meas} stroke={C.teal} strokeWidth={6} />
          {[0, 1, 2, 3, 4, 5].map((i) => <line key={i} x1={292} y1={FL - i * 25} x2={308} y2={FL - i * 25} stroke={C.teal} strokeWidth={3} opacity={i * 25 < SEAT * meas ? 1 : 0} />)}
          <path d={`M 286 ${FL - SEAT} h 28`} stroke={C.teal} strokeWidth={6} opacity={meas > 0.98 ? 1 : 0} /></g>
        {/* кровать на закреплённых подставках */}
        <g opacity={bed}>
          <rect x={460} y={FL - SEAT - 40} width={440} height={46} rx={14} fill="#F7F9FB" stroke="#C9D2DC" strokeWidth={4} />
          <rect x={460} y={FL - SEAT + 6} width={440} height={34} rx={6} fill={WOOD} stroke={WOODS} strokeWidth={3} />
          <rect x={846} y={FL - SEAT - 150} width={30} height={150} rx={10} fill={WOOD} stroke={WOODS} strokeWidth={3} />
          <rect x={790} y={FL - SEAT - 74} width={90} height={34} rx={14} fill="#fff" stroke="#C9D2DC" strokeWidth={3} />
          {[480, 850].map((x) => <g key={x}><rect x={x} y={FL - SEAT + 40} width={18} height={SEAT - 80} fill={WOODS} />
            <g opacity={rs}><path d={`M ${x - 16} ${FL} L ${x + 34} ${FL} L ${x + 26} ${FL - 44} L ${x - 8} ${FL - 44} Z`} fill={C.tealL} stroke={C.teal} strokeWidth={4} /></g></g>)}
          <line x1={420} y1={FL - SEAT} x2={460} y2={FL - SEAT} stroke={C.teal} strokeWidth={4} strokeDasharray="8 6" />
        </g>
      </svg>
    </Frame>
    <Tag x={394} y={FL - SEAT - 30} at={fr(d, 0.4)} t={h} col={C.teal} size={28} />
  </div>;
};

// Сидящий человек на стуле заданной высоты; возвращает и точки таза/колена для подсказок
const seatPose = (x: number, FL: number, seat: number, lean = 0.04) => {
  const hip: P = [x + 44, FL - seat - 30];
  const an: P = [x + 210, FL - 12];
  return {hip, an, af: [an[0] - 14, an[1]] as P, kn: kneeOf(hip, an), hn: [x + 150, FL - seat - 46] as P, hf: [x + 140, FL - seat - 40] as P, lean};
};

// TH04: колени не выше таза — высокий стул ✓ / низкий стул ⚠
export const KneesHip: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const H = 560, FL = 470;
  const panel = (k: 'ok' | 'bad', x0: number, at: number) => {
    const seat = k === 'ok' ? 132 : 70;
    const p = seatPose(30, FL, seat);
    const o = ease(f, at, at + 10), ln = ease(f, at + 12, at + 26), bd = ease(f, at + 22, at + 32);
    return <g transform={`translate(${x0} 0)`} opacity={o}>
      <rect x={0} y={0} width={466} height={H} rx={30} fill="#fff" />
      <rect x={0} y={FL} width={466} height={H - FL} fill="#E8D9C2" />
      <Chair x={30} floor={FL} seat={seat} />
      <Body hip={p.hip} lean={p.lean} an={p.an} af={p.af} hn={p.hn} hf={p.hf} glow={0.6} />
      <line x1={p.hip[0] - 40} y1={p.hip[1]} x2={440} y2={p.hip[1]} stroke={C.navy} strokeWidth={4} strokeDasharray="12 8" opacity={ln} />
      <circle cx={p.hip[0]} cy={p.hip[1]} r={11} fill={C.navy} opacity={ln} />
      <circle cx={p.kn[0]} cy={p.kn[1]} r={11} fill={k === 'ok' ? C.green : C.blood} opacity={ln} />
      {k === 'ok' ? <Badge x={400} y={70} ok o={bd} /> : <Warn x={400} y={74} o={bd} />}
    </g>;
  };
  return <Frame top={top} h={H}>
    <svg width={952} height={H} style={{position: 'absolute', left: 0, top: 0, direction: 'ltr'}}>
      <rect width={952} height={H} fill="#EEF3F6" />
      {panel('ok', 0, fr(d, 0.06))}{panel('bad', 486, fr(d, 0.3))}
    </svg>
  </Frame>;
};

// TH05: унитаз с насадкой и поручнями; человек медленно садится, держась за поручни
export const ToiletScene: React.FC<{top: number; d: number; tag: string}> = ({top, d, tag}) => {
  const f = useCurrentFrame();
  const H = 560, FL = 500;
  const ins = ease(f, fr(d, 0.06), fr(d, 0.16));
  const rail = ease(f, fr(d, 0.34), fr(d, 0.44));
  const sit = ease(f, fr(d, 0.5), fr(d, 0.85));
  const seatY = FL - 100 - 28 * ins;
  const hip: P = [330 + 60 * sit, seatY - 24 - (1 - sit) * 120];
  const an: P = [470, FL - 12];
  return <div style={{position: 'absolute', left: 0, top, width: 1080, height: H}}>
    <Frame top={0} h={H}>
      <svg width={952} height={H} style={{position: 'absolute', left: 0, top: 0, direction: 'ltr'}}>
        <rect width={952} height={FL} fill="#F4F8FA" />{Array.from({length: 12}, (_, i) => <line key={i} x1={i * 80} y1={0} x2={i * 80} y2={FL} stroke="#E1E9EE" strokeWidth={3} />)}
        <rect x={0} y={FL} width={952} height={H - FL} fill="#DCE3E8" />
        {/* бачок и унитаз (сбоку, лицом вправо) */}
        <rect x={210} y={FL - 250} width={70} height={140} rx={14} fill="#fff" stroke="#C9D2DC" strokeWidth={4} />
        <path d={`M 240 ${FL - 100} L 430 ${FL - 100} Q 430 ${FL - 30} 360 ${FL - 20} L 330 ${FL} L 280 ${FL} L 270 ${FL - 40} Q 240 ${FL - 60} 240 ${FL - 100} Z`} fill="#fff" stroke="#C9D2DC" strokeWidth={4} />
        {/* насадка */}
        <g opacity={ins} transform={`translate(0 ${(1 - ins) * -30})`}><rect x={236} y={FL - 130} width={200} height={30} rx={12} fill={C.tealL} stroke={C.teal} strokeWidth={4} /></g>
        <g opacity={ins}><line x1={470} y1={FL - 100} x2={470} y2={FL - 130} stroke={C.teal} strokeWidth={4} /><path d={`M 462 ${FL - 108} l 8 -10 l 8 10 M 462 ${FL - 122} l 8 10 l 8 -10`} stroke={C.teal} strokeWidth={3} fill="none" /></g>
        {/* поручни, закреплённые к стене/полу */}
        <g opacity={rail}><g stroke={METS} strokeWidth={14} strokeLinecap="round" fill="none"><path d={`M 520 ${FL} L 520 ${FL - 190} L 340 ${FL - 190}`} /></g>
          <g stroke={MET} strokeWidth={8} strokeLinecap="round" fill="none"><path d={`M 520 ${FL} L 520 ${FL - 190} L 340 ${FL - 190}`} /></g>
          <rect x={505} y={FL - 8} width={30} height={10} rx={3} fill={METS} /></g>
        <g transform="translate(0 0)"><Body hip={hip} lean={0.25 * (1 - sit) + 0.06} an={an} af={[an[0] - 16, an[1]]} hn={rail > 0.5 ? [480, FL - 192] : [hip[0] + 90, hip[1] - 20]} hf={rail > 0.5 ? [460, FL - 194] : [hip[0] + 80, hip[1] - 10]} /></g>
      </svg>
    </Frame>
    <Tag x={564} y={FL - 168} at={fr(d, 0.16)} t={tag} col={C.teal} size={26} />
  </div>;
};

// TH06: ванная — скамья-переходник, стул в душе, коврик, поручень; раковина и полотенцедержатель ✗; губка на длинной ручке
export const BathScene: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const H = 560, FL = 470;
  const a1 = ease(f, fr(d, 0.04), fr(d, 0.14)), a2 = ease(f, fr(d, 0.14), fr(d, 0.24));
  const mat = ease(f, fr(d, 0.5), fr(d, 0.58)), rail = ease(f, fr(d, 0.56), fr(d, 0.64));
  const nx = ease(f, fr(d, 0.68), fr(d, 0.76)), sp = ease(f, fr(d, 0.84), fr(d, 0.92));
  return <Frame top={top} h={H}>
    <svg width={952} height={H} style={{position: 'absolute', left: 0, top: 0, direction: 'ltr'}}>
      <rect width={952} height={FL} fill="#F2F7FA" />{Array.from({length: 13}, (_, i) => <line key={i} x1={i * 76} y1={0} x2={i * 76} y2={FL} stroke="#E0E9EF" strokeWidth={3} />)}
      <rect x={0} y={FL} width={952} height={H - FL} fill="#DCE3E8" />
      {/* ванна + скамья-переходник (ножки внутри и снаружи ванны) */}
      <g><path d={`M 30 ${FL - 150} L 360 ${FL - 150} L 340 ${FL} L 50 ${FL} Z`} fill="#fff" stroke="#C9D2DC" strokeWidth={5} />
        <g opacity={a1} transform={`translate(0 ${(1 - a1) * -26})`}>
          <rect x={150} y={FL - 196} width={300} height={22} rx={8} fill={C.tealL} stroke={C.teal} strokeWidth={4} />
          <rect x={160} y={FL - 290} width={16} height={100} rx={6} fill={C.teal} />
          {[190, 300].map((x) => <line key={x} x1={x} y1={FL - 174} x2={x} y2={FL - 150} stroke={C.teal} strokeWidth={8} />)}
          {[400, 440].map((x) => <line key={x} x1={x} y1={FL - 174} x2={x} y2={FL} stroke={C.teal} strokeWidth={8} />)}
        </g></g>
      {/* душевой стул */}
      <g opacity={a2} transform={`translate(0 ${(1 - a2) * -26})`}>
        <rect x={560} y={FL - 112} width={130} height={20} rx={8} fill="#fff" stroke={C.teal} strokeWidth={4} />
        <rect x={560} y={FL - 220} width={16} height={110} rx={6} fill="#fff" stroke={C.teal} strokeWidth={4} />
        {[570, 680].map((x) => <line key={x} x1={x} y1={FL - 92} x2={x + (x > 600 ? 8 : -8)} y2={FL} stroke={C.teal} strokeWidth={8} />)}
        <g transform="translate(720 70)"><path d="M 0 0 h 50 a 14 14 0 0 1 14 14" stroke={METS} strokeWidth={8} fill="none" /><rect x={50} y={14} width={34} height={12} rx={4} fill={METS} />
          {[0, 1, 2].map((i) => <line key={i} x1={56 + i * 10} y1={34} x2={52 + i * 10} y2={60 + ((f + i * 5) % 20)} stroke="#4E9BD1" strokeWidth={4} strokeLinecap="round" opacity={0.7} />)}</g>
      </g>
      {/* нескользящий коврик */}
      <g opacity={mat}><rect x={530} y={FL + 6} width={200} height={26} rx={10} fill={C.tealL} stroke={C.teal} strokeWidth={3} />
        {Array.from({length: 9}, (_, i) => <circle key={i} cx={548 + i * 21} cy={FL + 19} r={5} fill={C.teal} opacity={0.6} />)}</g>
      {/* настенный поручень */}
      <g opacity={rail}><rect x={760} y={FL - 330} width={18} height={180} rx={9} fill={MET} stroke={METS} strokeWidth={3} />
        {[FL - 326, FL - 160].map((y) => <rect key={y} x={750} y={y} width={38} height={14} rx={4} fill={METS} />)}</g>
      {/* раковина и полотенцедержатель — не опора */}
      <g><path d={`M 820 ${FL - 230} L 940 ${FL - 230} L 930 ${FL - 190} L 830 ${FL - 190} Z`} fill="#fff" stroke="#C9D2DC" strokeWidth={4} />
        <rect x={850} y={FL - 330} width={80} height={8} rx={4} fill={METS} /><rect x={860} y={FL - 322} width={60} height={60} rx={6} fill="#F6E3C8" opacity={0.9} />
        <Badge x={885} y={FL - 140} ok={false} o={nx} r={30} /></g>
      {/* губка на длинной ручке */}
      <g opacity={sp} transform={`translate(600 ${FL - 280}) rotate(${-30 + Math.sin(f / 8) * 6})`}>
        <rect x={0} y={-6} width={200} height={12} rx={6} fill="#8B9BB0" /><ellipse cx={214} cy={0} rx={28} ry={20} fill="#F6D56B" stroke="#D9B23C" strokeWidth={3} /></g>
    </svg>
  </Frame>;
};

// Инструменты: захват, приспособление для носков, эластичные шнурки, длинная ложка для обуви, губка
export const ToolIcon: React.FC<{k: string; s?: number}> = ({k, s = 110}) => <svg width={s} height={s} viewBox="0 0 110 110" style={{direction: 'ltr'}}>
  {k === 'reach' && <g><line x1={20} y1={96} x2={88} y2={20} stroke="#6B7686" strokeWidth={7} strokeLinecap="round" /><path d="M 14 88 l 14 -6 l 6 14" stroke="#3E4A5C" strokeWidth={8} fill="none" strokeLinecap="round" /><path d="M 82 16 q 12 -4 14 8 M 82 16 q -2 -12 10 -10" stroke={C.teal} strokeWidth={6} fill="none" strokeLinecap="round" /></g>}
  {k === 'sock' && <g><path d="M 30 20 h 40 v 40 q 0 30 -20 30 q -20 0 -20 -30 Z" fill={C.tealL} stroke={C.teal} strokeWidth={5} /><path d="M 36 22 q -20 30 -24 80 M 64 22 q 20 30 24 80" stroke="#6B7686" strokeWidth={4} fill="none" strokeLinecap="round" /></g>}
  {k === 'lace' && <g><path d="M 14 78 q 8 -36 40 -40 l 40 6 q 6 20 -4 34 Z" fill="#EAEFF4" stroke="#6B7686" strokeWidth={4} />{[0, 1, 2].map((i) => <path key={i} d={`M ${48 + i * 12} 44 q 4 10 0 22`} stroke={C.acc} strokeWidth={5} fill="none" strokeLinecap="round" />)}<path d="M 40 54 q 30 -10 50 2" stroke={C.acc} strokeWidth={4} fill="none" strokeDasharray="4 4" /></g>}
  {k === 'horn' && <g><line x1={30} y1={10} x2={54} y2={74} stroke="#6B7686" strokeWidth={7} strokeLinecap="round" /><path d="M 48 70 q 6 30 22 30 q 8 -10 0 -36 Z" fill="#C9D2DC" stroke="#6B7686" strokeWidth={4} /><circle cx={30} cy={12} r={6} fill="none" stroke="#6B7686" strokeWidth={4} /></g>}
  {k === 'sponge' && <g><line x1={16} y1={96} x2={70} y2={30} stroke="#8B9BB0" strokeWidth={7} strokeLinecap="round" /><ellipse cx={80} cy={22} rx={22} ry={15} fill="#F6D56B" stroke="#D9B23C" strokeWidth={3} /></g>}
  {k === 'raiser' && <g><path d="M 20 94 L 90 94 L 80 50 L 30 50 Z" fill={C.tealL} stroke={C.teal} strokeWidth={5} /></g>}
  {k === 'toilet' && <g><rect x={20} y={40} width={70} height={18} rx={8} fill={C.tealL} stroke={C.teal} strokeWidth={4} /><path d="M 26 58 h 58 q 0 30 -24 34 h -14 Z" fill="#fff" stroke="#C9D2DC" strokeWidth={4} /></g>}
</svg>;

// Ряд инструментов с подписями (HTML — RTL-текст корректно)
export const ToolRow: React.FC<{top: number; at: number; step: number; items: [string, string][]; size?: number}> = ({top, at, step, items, size = 24}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top, display: 'flex', gap: 14}}>
    {items.map(([k, t], i) => { const a = at + i * step, p = ease(f, a, a + 10);
      return <div key={i} style={{flex: 1, opacity: p, transform: `translateY(${(1 - p) * 18}px)`, background: '#fff', borderRadius: 22, boxShadow: '0 10px 24px rgba(20,40,60,.10)', padding: '10px 8px 14px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6}}>
        <ToolIcon k={k} s={100} />
        <div style={{fontFamily: BODY, fontWeight: 800, fontSize: size, color: C.ink, lineHeight: 1.18, textAlign: 'center'}}>{t}</div>
      </div>; })}
  </div>;
};

// TH07: одеваемся сидя — брюки сначала на оперированную ногу (1), потом на здоровую (2)
export const DressSit: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const H = 470, FL = 420, seat = 128;
  const p = seatPose(150, FL, seat, 0.06);
  const t1 = ease(f, fr(d, 0.1), fr(d, 0.24)), t2 = ease(f, fr(d, 0.26), fr(d, 0.38));
  const off = ease(f, fr(d, 0.42), fr(d, 0.5));
  const kn = p.kn, kf = kneeOf(p.hip, p.af);
  const trouser = (k: P, a: P, t: number, near: boolean) => {
    const pt: P = [a[0] + (k[0] - a[0]) * t, a[1] + (k[1] - a[1]) * t];
    return t > 0.02 ? <line x1={a[0]} y1={a[1] - 6} x2={pt[0]} y2={pt[1]} stroke={near ? C.teal : '#5E8FB9'} strokeWidth={near ? 42 : 38} strokeLinecap="round" opacity={0.9} /> : null;
  };
  return <Frame top={top} h={H}>
    <svg width={952} height={H} style={{position: 'absolute', left: 0, top: 0, direction: 'ltr'}}>
      <Room h={H} floor={FL} win={600} />
      <Chair x={150} floor={FL} seat={seat} />
      <Body hip={p.hip} lean={0.12} an={p.an} af={p.af} hn={[kn[0] + 20, kn[1] + 30]} hf={[kf[0] + 10, kf[1] + 40]} glow={0.7 * (1 - off)} legN="#C9B8A6" look={{...PAT, pants: '#C9B8A6'}} />
      {trouser(kf, p.af, t2, false)}{trouser(kn, p.an, t1, true)}
      {[[kn, '1', t1 > 0.05 ? 1 : 0], [kf, '2', t2 > 0.05 ? 1 : 0]].map(([k, n, o], i) => <g key={i} opacity={(o as number) * (1 - off)} transform={`translate(${(k as P)[0] + 60} ${(k as P)[1] - 70 - i * 70})`}>
        <circle r={30} fill={i === 0 ? C.teal : C.navy} /><text y={11} textAnchor="middle" fontFamily="'Head'" fontWeight={800} fontSize={32} fill="#fff">{n as string}</text></g>)}
    </svg>
  </Frame>;
};

// Сидящий спереди: ноги скрещены / колени врозь
const FrontSit: React.FC<{cross?: boolean; apart?: boolean}> = ({cross, apart}) => {
  const g = apart ? 70 : 34;
  return <g>
    <rect x={-110} y={60} width={220} height={22} rx={8} fill={WOOD} stroke={WOODS} strokeWidth={3} />
    <rect x={-104} y={-150} width={208} height={30} rx={10} fill={WOOD} stroke={WOODS} strokeWidth={3} opacity={0.6} />
    <path d="M -62 -100 Q -66 50 -54 60 L 54 60 Q 66 50 62 -100 Q 0 -124 -62 -100 Z" fill={PAT.shirt} />
    <circle cx={0} cy={-150} r={40} fill={SKIN} stroke={SKINS} strokeWidth={2} /><path d="M -42 -152 a 42 42 0 0 1 84 0 q -40 -16 -84 0 Z" fill={PAT.hair} />
    <circle cx={-14} cy={-150} r={4} fill="#3a2a20" /><circle cx={14} cy={-150} r={4} fill="#3a2a20" />
    {cross ? <>
      <Tube a={[-g, 60]} b={[-g - 6, 200]} w={42} c={PAT.pants} />
      <Tube a={[g, 54]} b={[-20, 96]} w={46} c={PAT.pants} /><Tube a={[-20, 96]} b={[-70, 190]} w={38} c={PAT.pants} />
      <ellipse cx={-g - 10} cy={212} rx={26} ry={12} fill="#F4F4F4" stroke="#AEB5BF" strokeWidth={2} />
      <ellipse cx={-84} cy={200} rx={24} ry={12} fill="#F4F4F4" stroke="#AEB5BF" strokeWidth={2} transform="rotate(-30 -84 200)" />
    </> : <>
      {[-1, 1].map((s) => <g key={s}><Tube a={[s * 30, 60]} b={[s * g, 90]} w={46} c={PAT.pants} /><Tube a={[s * g, 90]} b={[s * (g + 10), 206]} w={38} c={PAT.pants} />
        <ellipse cx={s * (g + 12)} cy={218} rx={26} ry={12} fill="#F4F4F4" stroke="#AEB5BF" strokeWidth={2} /></g>)}
    </>}
    {[-1, 1].map((s) => <g key={s}><Tube a={[s * 58, -86]} b={[s * 80, 10]} w={28} c="#6F92B0" /><Tube a={[s * 80, 10]} b={[s * 60, 56]} w={22} c={SKIN} /></g>)}
  </g>;
};

// TH08: условные ограничения — нога на ногу ✗, колени врозь ✓, наклон вперёд > 90° в ТБС ⚠
export const Restrict: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const H = 520;
  const a = [fr(d, 0.3), fr(d, 0.38), fr(d, 0.74)];
  const lean = 0.06 + 0.72 * ease(f, a[2] + 8, a[2] + 30);
  const FL = 440, hip: P = [96, FL - 156];
  const sh: P = [hip[0] + Math.sin(lean) * 150, hip[1] - Math.cos(lean) * 150];
  const an: P = [hip[0] + 170, FL - 12];
  const kn = kneeOf(hip, an);
  const thA = Math.atan2(kn[1] - hip[1], kn[0] - hip[0]), trA = Math.atan2(sh[1] - hip[1], sh[0] - hip[0]);
  const flex = Math.round(180 - Math.abs((trA - thA) * 180 / Math.PI));
  const arcR = 70;
  const arc = `M ${hip[0] + Math.cos(thA) * arcR} ${hip[1] + Math.sin(thA) * arcR} A ${arcR} ${arcR} 0 0 0 ${hip[0] + Math.cos(trA) * arcR} ${hip[1] + Math.sin(trA) * arcR}`;
  const card = (x: number, w: number, at: number, ch: React.ReactNode) => { const o = ease(f, at, at + 10);
    return <g opacity={o} transform={`translate(${x} ${(1 - o) * 20})`}><rect width={w} height={H} rx={26} fill="#fff" />{ch}</g>; };
  return <Frame top={top} h={H}>
    <svg width={952} height={H} style={{position: 'absolute', left: 0, top: 0, direction: 'ltr'}}>
      <rect width={952} height={H} fill="#EEF3F6" />
      {card(0, 300, a[0], <><g transform="translate(150 220) scale(0.95)"><FrontSit cross /></g><Badge x={250} y={56} ok={false} o={ease(f, a[0] + 10, a[0] + 18)} /></>)}
      {card(316, 300, a[1], <><g transform="translate(150 220) scale(0.95)"><FrontSit apart /></g><Badge x={250} y={56} ok o={ease(f, a[1] + 10, a[1] + 18)} /></>)}
      {card(632, 320, a[2], <g transform="translate(10 0)">
        <rect x={0} y={FL} width={300} height={H - FL} fill="#E8D9C2" />
        <Chair x={20} floor={FL} seat={126} />
        <Body hip={hip} lean={lean} an={an} af={[an[0] - 14, an[1]]} hn={[sh[0] + 60, Math.min(FL - 30, sh[1] + 150)]} hf={[sh[0] + 50, Math.min(FL - 30, sh[1] + 140)]} glow={0.6} />
        <path d={arc} stroke={flex > 90 ? C.blood : C.teal} strokeWidth={8} fill="none" opacity={ease(f, a[2] + 4, a[2] + 12)} />
        <Warn x={262} y={60} o={ease(f, a[2] + 28, a[2] + 36)} />
      </g>)}
    </svg>
    <div style={{position: 'absolute', left: 632 + 30, top: 26, opacity: ease(f, a[2] + 20, a[2] + 30), fontFamily: "'Head'", fontWeight: 800, fontSize: 40, color: C.blood, direction: 'ltr'}}>{'>'} 90°</div>
  </Frame>;
};

// TH09: стоя — захват вместо наклона; разворот небольшими шагами; лёжа — подушка между ногами (если назначено)
export const StandLie: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const H = 520;
  const a = [fr(d, 0.14), fr(d, 0.42), fr(d, 0.66)];
  const pick = ease(f, a[0] + 10, a[0] + 40);
  const FL = 470, hip: P = [120, FL - 236];
  const reachEnd: P = [270, FL - 10 - 10 * pick];
  const hand: P = [190, FL - 196];
  const card = (x: number, w: number, at: number, ch: React.ReactNode) => { const o = ease(f, at, at + 10);
    return <g opacity={o} transform={`translate(${x} ${(1 - o) * 20})`}><rect width={w} height={H} rx={26} fill="#fff" />{ch}</g>; };
  const turn = ease(f, a[1] + 6, a[1] + 60);
  const steps = [0, 1, 2, 3, 4, 5];
  return <Frame top={top} h={H}>
    <svg width={952} height={H} style={{position: 'absolute', left: 0, top: 0, direction: 'ltr'}}>
      <rect width={952} height={H} fill="#EEF3F6" />
      {card(0, 330, a[0], <>
        <rect x={0} y={FL} width={330} height={H - FL} fill="#E8D9C2" />
        <Body hip={hip} lean={0.1} an={[hip[0] + 14, FL - 12]} af={[hip[0] - 10, FL - 12]} hn={hand} hf={[150, FL - 226]} glow={0.5} />
        <line x1={hand[0]} y1={hand[1]} x2={reachEnd[0]} y2={reachEnd[1]} stroke="#6B7686" strokeWidth={7} strokeLinecap="round" />
        <rect x={reachEnd[0] - 4} y={reachEnd[1] - 4} width={36} height={22} rx={6} fill="#E7A977" stroke="#B9824F" strokeWidth={2} />
        <Badge x={290} y={56} ok o={ease(f, a[0] + 30, a[0] + 40)} />
      </>)}
      {card(346, 290, a[1], <g transform="translate(145 260)">
        {/* вид сверху: стопы разворачиваются вместе с телом небольшими шагами */}
        <circle r={110} fill="none" stroke="#C9D2DC" strokeWidth={3} strokeDasharray="8 8" />
        {steps.map((i) => { const ang = -90 + i * 18 * turn * 1.0; const on = i <= Math.floor(turn * 5);
          return <g key={i} opacity={on ? (i === Math.floor(turn * 5) ? 1 : 0.35) : 0} transform={`rotate(${ang})`}>
            <ellipse cx={-22} cy={0} rx={14} ry={30} fill={C.teal} /><ellipse cx={22} cy={0} rx={14} ry={30} fill={C.teal} opacity={0.8} />
          </g>; })}
        <path d="M 0 -150 A 150 150 0 0 1 106 -106" stroke={C.teal} strokeWidth={6} fill="none" opacity={turn} /><path d="M 106 -106 l -4 -22 M 106 -106 l -22 -2" stroke={C.teal} strokeWidth={6} strokeLinecap="round" opacity={turn} />
      </g>)}
      {card(652, 300, a[2], <g transform="translate(0 0)">
        {/* лёжа на спине; подушка между ногами — пунктир (только если назначена) */}
        <rect x={16} y={300} width={268} height={40} rx={12} fill="#F7F9FB" stroke="#C9D2DC" strokeWidth={4} />
        <rect x={16} y={340} width={268} height={26} rx={6} fill={WOOD} stroke={WOODS} strokeWidth={3} />
        <rect x={20} y={262} width={70} height={36} rx={14} fill="#fff" stroke="#C9D2DC" strokeWidth={3} />
        <circle cx={56} cy={256} r={30} fill={SKIN} stroke={SKINS} strokeWidth={2} />
        <Tube a={[90, 282]} b={[170, 282]} w={60} c={PAT.shirt} />
        <Tube a={[170, 270]} b={[270, 262]} w={34} c={PAT.pants} o={0.8} /><Tube a={[170, 292]} b={[270, 292]} w={36} c={PAT.pants} />
        <g opacity={ease(f, a[2] + 30, a[2] + 40)}><rect x={190} y={264} width={70} height={26} rx={12} fill={C.tealL} stroke={C.teal} strokeWidth={3} strokeDasharray="8 6" /></g>
      </g>)}
    </svg>
  </Frame>;
};

// TH10: приподнятая нога на подушке — отёк уменьшается; ходьба с ходунками; таблетки по расписанию (без названий)
export const SwellLie: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const H = 470;
  const up = ease(f, fr(d, 0.06), fr(d, 0.18));
  const sw = 1 - 0.55 * ease(f, fr(d, 0.2), fr(d, 0.5));
  const walk = ease(f, fr(d, 0.55), fr(d, 0.62));
  const pills = ease(f, fr(d, 0.8), fr(d, 0.88));
  const FL = 420;
  const wx = 560 + walk * 60 + (walk > 0.99 ? Math.min(60, (f - fr(d, 0.62)) * 0.6) : 0);
  const [an, af] = walkAnk(f, wx + 10, FL, walk > 0.5 ? 1 : 0);
  return <Frame top={top} h={H}>
    <svg width={952} height={H} style={{position: 'absolute', left: 0, top: 0, direction: 'ltr'}}>
      <Room h={H} floor={FL} win={0} />
      <g opacity={1 - walk * 0.7}>
        <rect x={30} y={250} width={440} height={40} rx={12} fill="#F7F9FB" stroke="#C9D2DC" strokeWidth={4} /><rect x={30} y={290} width={440} height={26} rx={6} fill={WOOD} stroke={WOODS} strokeWidth={3} />
        {[40, 450].map((x) => <rect key={x} x={x} y={316} width={14} height={FL - 316} fill={WOODS} />)}
        <rect x={34} y={212} width={80} height={36} rx={14} fill="#fff" stroke="#C9D2DC" strokeWidth={3} /><circle cx={76} cy={206} r={30} fill={SKIN} stroke={SKINS} strokeWidth={2} />
        <Tube a={[112, 232]} b={[210, 232]} w={60} c={PAT.shirt} />
        <Tube a={[210, 230]} b={[440, 230]} w={34} c={PAT.pants} o={0.75} />
        <rect x={330} y={232 - 22 * up} width={130} height={26 + 22 * up} rx={13} fill="#fff" stroke="#C9D2DC" strokeWidth={3} />
        <Tube a={[210, 240]} b={[440, 240 - 30 * up]} w={38} c={PAT.pants} />
        <ellipse cx={392} cy={238 - 26 * up} rx={46 * sw + 10} ry={24 * sw + 6} fill={C.acc} opacity={0.28} />
      </g>
      <g opacity={walk}><WalkerSide x={wx + 70} floor={FL} s={0.9} /><Body hip={[wx, FL - 230]} lean={0.16} an={an} af={af} hn={[wx + 80, FL - 184]} hf={[wx + 72, FL - 186]} /></g>
      <g opacity={pills} transform="translate(40 40)"><rect width={260} height={120} rx={18} fill="#fff" stroke="#C9D2DC" strokeWidth={4} />
        {Array.from({length: 7}, (_, i) => <g key={i}><rect x={16 + i * 34} y={24} width={28} height={72} rx={8} fill={i < 3 ? C.tealL : '#F2F5F8'} stroke={C.teal} strokeWidth={2} />
          {i < 3 && <circle cx={30 + i * 34} cy={60} r={7} fill={C.teal} />}</g>)}</g>
    </svg>
  </Frame>;
};

// TH11: нога спереди — подсветка икры, отёка, покраснения/тепла; термометр; рана с выделениями; область сустава
export const UrgentLeg: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const H = 400;
  const z = (p: number) => ease(f, fr(d, p), fr(d, p + 0.05));
  return <Frame top={top} h={H}>
    <svg width={952} height={H} style={{position: 'absolute', left: 0, top: 0, direction: 'ltr'}}>
      <rect width={952} height={H} fill="#F3F7FA" />
      <g transform="translate(80 20)">
        <path d="M 60 0 Q 120 -6 170 0 L 176 140 Q 170 190 150 220 L 140 330 Q 150 360 120 364 L 80 364 Q 64 350 74 330 L 66 220 Q 40 170 44 140 Z" fill={SKIN} stroke={SKINS} strokeWidth={3} />
        <ellipse cx={112} cy={262} rx={36 + 8 * z(0.12)} ry={60 + 6 * z(0.12)} fill={C.acc} opacity={0.3 * z(0.06)} />
        <ellipse cx={112} cy={262} rx={60} ry={90} fill="#E94B3C" opacity={0.18 * z(0.2)} />
        <rect x={150} y={30} width={14} height={80} rx={6} fill="#fff" stroke="#C9D2DC" strokeWidth={2} opacity={z(0.38)} />
        <circle cx={150} cy={40} r={34} fill="none" stroke={C.blood} strokeWidth={5} opacity={z(0.46)} strokeDasharray="10 8" />
      </g>
      <g transform="translate(360 70)" opacity={z(0.3)}><rect x={0} y={0} width={26} height={170} rx={13} fill="#fff" stroke={C.blood} strokeWidth={5} /><rect x={7} y={60} width={12} height={110} rx={6} fill={C.blood} /><circle cx={13} cy={190} r={26} fill={C.blood} /></g>
      <g transform="translate(470 110)" opacity={z(0.38)}><rect width={180} height={90} rx={18} fill="#fff" stroke="#C9D2DC" strokeWidth={4} /><line x1={30} y1={45} x2={150} y2={45} stroke="#B5838A" strokeWidth={5} strokeDasharray="10 6" />
        <path d="M 120 50 q 10 20 0 30 q -10 -10 0 -30 Z" fill="#E6C25A" /></g>
      <g transform="translate(720 70)" opacity={z(0.46)}><circle cx={80} cy={90} r={70} fill="none" stroke={C.blood} strokeWidth={6} /><path d="M 50 60 l 20 20 l -14 10 l 26 26" stroke={C.blood} strokeWidth={7} fill="none" strokeLinecap="round" strokeLinejoin="round" /></g>
    </svg>
  </Frame>;
};

// TH12: консультация у семейного врача; коробка с приспособлениями
export const AfterDis: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const H = 470, FL = 430;
  const box = ease(f, fr(d, 0.3), fr(d, 0.4));
  const DOC: Look = {shirt: '#FFFFFF', pants: '#5B6B82', hair: '#2E2A28'};
  const p = seatPose(40, FL, 126);
  return <Frame top={top} h={H}>
    <svg width={952} height={H} style={{position: 'absolute', left: 0, top: 0, direction: 'ltr'}}>
      <Room h={H} floor={FL} win={380} />
      <g opacity={1 - box * 0.6}>
        <Chair x={40} floor={FL} seat={126} />
        <Body hip={p.hip} lean={0.08} an={p.an} af={p.af} hn={[p.hip[0] + 130, p.hip[1] - 10]} hf={[p.hip[0] + 120, p.hip[1]]} />
        <rect x={290} y={FL - 190} width={180} height={16} rx={6} fill={WOOD} stroke={WOODS} strokeWidth={3} /><rect x={372} y={FL - 174} width={14} height={174} fill={WOODS} />
        <g transform="translate(700 0) scale(-1 1)"><Chair x={0} floor={FL} seat={126} /><Body hip={[44, FL - 156]} lean={0.06} an={[214, FL - 12]} af={[200, FL - 12]} hn={[180, FL - 196]} hf={[170, FL - 190]} look={DOC} /></g>
        <rect x={642} y={FL - 330} width={16} height={60} rx={8} fill={C.teal} opacity={0.0} />
      </g>
      <g opacity={box} transform={`translate(${590 + (1 - box) * 60} ${FL - 130}) scale(0.8)`}>
        <path d="M 0 40 L 340 40 L 320 160 L 20 160 Z" fill="#E9D7BB" stroke="#C8AF8C" strokeWidth={4} />
        <path d="M 0 40 L 40 0 L 300 0 L 340 40" fill="#F3E6D0" stroke="#C8AF8C" strokeWidth={4} />
        <g transform="translate(30 -60)"><ToolIconG k="reach" /></g><g transform="translate(120 -50)"><ToolIconG k="sock" /></g><g transform="translate(210 -60)"><ToolIconG k="horn" /></g>
      </g>
    </svg>
  </Frame>;
};
const ToolIconG: React.FC<{k: string}> = ({k}) => <foreignObject width={110} height={110}><ToolIcon k={k} /></foreignObject>;
