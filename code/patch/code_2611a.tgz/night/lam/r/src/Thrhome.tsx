// «Дома после замены тазобедренного сустава» — ролик для пациентов (9:16), сверху ops/thr-home.html. Тексты и vis_* TH01–TH12 ОДОБРЕНО ChatGPT 25.11 (tts-data thrhome.json);
// все надписи — фрагменты одобренного текста. Рисунки — ThrhomeArt.tsx.
import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Subtitle, Note, C, BODY, HEAD, ease, Word} from './kit';
import {Phone101} from './UrgentArt';
import {HomeArrive, PrepHome, ChairBed, KneesHip, ToiletScene, BathScene, DressSit, ToolRow, Restrict, StandLie, SwellLie, UrgentLeg, AfterDis} from './ThrhomeArt';
import tRu from './timing_thrhome.json';
import tHe from './timing_thrhome_he.json';
import tAr from './timing_thrhome_ar.json';
import tEn from './timing_thrhome_en.json';

type TT = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const FPS = 30, PAD = 0.5;
const fr = (d: number, p: number) => Math.round(d * p);
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};

type Dict = {brand: string; rtl?: boolean; n: Record<string, string[]>; end: string};
const N: Record<string, Dict> = {
  ru: {
    brand: 'ОРТОПЕДИЯ · ПАЦИЕНТАМ',
    n: {
      TH01: ['проще и безопаснее', 'как подготовить дом', 'приспособления на первые недели', 'Какие ограничения нужны именно вам и как долго их соблюдать, скажут травматолог-ортопед, физиотерапевт или эрготерапевт'],
      TH02: ['уберите коврики', 'провода и удлинители', 'освободите проходы', 'вещи на каждый день — на удобную высоту', 'столик на высоте сиденья'],
      TH03: ['устойчивый', 'жёсткое сиденье', 'спинка', 'подлокотники', '≈ 45–50 см', 'точную высоту подбирают индивидуально с учётом роста', 'устойчивая твёрдая подушка или надёжно закреплённые подставки'],
      TH04: ['если запрещено сгибать тазобедренный сустав больше 90°', 'колени не выше уровня тазобедренных суставов'],
      TH05: ['насадка повышает сиденье унитаза', '≈ 10 см', 'поручни с одной или обеих сторон', 'тип и расположение — с эрготерапевтом'],
      TH06: ['скамья-переходник для ванны', 'устойчивый стул в душе', 'только если врач разрешил', 'не погружайте рану в воду', 'нескользящий коврик · поручни на стене', 'не опирайтесь на раковину и полотенцедержатель', 'губка на длинной ручке'],
      TH07: ['захват на длинной ручке', 'приспособление для носков', 'эластичные шнурки', 'длинная ложка для обуви', 'одевайтесь сидя', 'надевать — сначала на оперированную ногу', 'снимать — сначала со здоровой ноги'],
      TH08: ['ограничения нужны не всем', 'чаще — после заднего доступа', 'после переднего — уточните у врача', 'не скрещивать ноги', 'колени врозь', 'не подтягивать ногу к груди', 'стопу — не на высокую подставку', 'не больше 90°, если врач ограничил сгибание'],
      TH09: ['предметы с пола — захватом', 'разворачивайтесь небольшими шагами всем телом', 'подушка между ногами — если назначено', 'можно ли спать на боку — уточните у медицинской команды'],
      TH10: ['приподнятая нога может уменьшить отёк', 'ходить по рекомендации команды', 'назначенные препараты'],
      TH11: ['отёк ноги резко усиливается', 'новая боль в икре', 'покраснение или необычное тепло кожи', 'температура', 'выделения из раны', 'нарастает боль в области сустава', 'внезапная одышка или боль в груди → 101'],
      TH12: ['семейный врач', 'продолжить лечение и наблюдение', '«Яд Сара» — во временное пользование', 'магазины ортопедических товаров', 'базы «Азарим» и «Мильбат»'],
    },
    end: 'Указания вашего врача важнее общих советов',
  },
  en: {
    brand: 'ORTHOPAEDICS · FOR PATIENTS',
    n: {
      TH01: ['easier and safer', 'preparing your home', 'aids for the first few weeks', 'Your orthopaedic surgeon, physiotherapist or occupational therapist will tell you which restrictions apply to you and for how long'],
      TH02: ['remove rugs', 'cables and extension leads', 'clear walkways', 'everyday things at a comfortable height', 'a small table at seat height'],
      TH03: ['stable', 'firm seat', 'backrest', 'armrests', '≈ 45–50 cm', 'the exact height must be adjusted to suit you', 'a firm, stable cushion or securely fixed furniture raisers'],
      TH04: ['if you must not bend your hip beyond 90°', 'knees no higher than your hips'],
      TH05: ['raised toilet seat', '≈ 10 cm', 'grab rails on one or both sides', 'agree the type and position with an occupational therapist'],
      TH06: ['bath transfer bench', 'stable shower chair', 'only if your doctor has approved', 'do not immerse your wound in water', 'non-slip mat · wall grab rails', 'do not lean on the sink or towel rail', 'long-handled sponge'],
      TH07: ['long-handled reacher', 'sock aid', 'elastic laces', 'long shoehorn', 'get dressed sitting down', 'putting on: operated leg first', 'taking off: other leg first'],
      TH08: ['not everyone needs restrictions', 'more common after a posterior approach', 'anterior approach: ask your doctor', 'do not cross your legs', 'keep your knees apart', 'do not pull the leg up to your chest', 'no foot on a high stool', 'not beyond 90° if your doctor has restricted it'],
      TH09: ['use a reacher for things on the floor', 'turn with small steps, moving your whole body', 'pillow between your legs — if recommended', 'ask your team whether you may sleep on your side'],
      TH10: ['raising your leg may help reduce swelling', "walk as the team advises", 'take your prescribed medicines'],
      TH11: ['leg suddenly more swollen', 'new calf pain', 'redness or unusual warmth', 'fever', 'discharge from the wound', 'increasing pain around the joint', 'sudden shortness of breath or chest pain → 101'],
      TH12: ['family doctor', 'continue treatment and follow-up', 'Yad Sarah: borrow equipment', 'orthopaedic supply shops', 'Azarim and Milbat databases'],
    },
    end: "Your doctor's individual instructions take priority",
  },
  he: {
    brand: 'אורתופדיה · למטופלים', rtl: true,
    n: {
      TH01: ['פשוטה ובטוחה יותר', 'הכנת הבית', 'אביזרי עזר לשבועות הראשונים', 'אילו הגבלות נחוצות לכם ולכמה זמן, יגידו לכם האורתופד המנתח, הפיזיותרפיסט או המרפא בעיסוק'],
      TH02: ['הוציאו שטיחונים', 'כבלים וכבלים מאריכים', 'פנו את המעברים', 'חפצים יומיומיים בגובה נוח', 'שולחן קטן בגובה המושב'],
      TH03: ['יציב', 'מושב קשיח', 'משענת גב', 'משענות ידיים', 'כ־45 עד 50 ס״מ', 'את הגובה המדויק יש להתאים אישית', 'כרית קשיחה ויציבה או מגביהים שמחוברים היטב'],
      TH04: ['אם אסור לכופף את מפרק הירך מעבר לתשעים מעלות', 'הברכיים לא מעל גובה מפרקי הירך'],
      TH05: ['מגביה אסלה יציב', 'בערך 10 ס״מ', 'מאחזים בצד אחד או בשני הצדדים', 'סוג ומיקום בתיאום עם מרפא בעיסוק'],
      TH06: ['ספסל מעבר לאמבטיה', 'כיסא רחצה יציב במקלחת', 'רק אם הרופא אישר', 'אל תטבלו את פצע הניתוח במים', 'שטיחון נגד החלקה · מאחזים בקיר', 'אל תישענו על הכיור או על מתלה המגבות', 'ספוג עם ידית ארוכה'],
      TH07: ['יד עזר ארוכה', 'אביזר לגריבת גרביים', 'שרוכים אלסטיים', 'כף נעליים ארוכה', 'התלבשו בישיבה', 'לבישה: קודם הרגל המנותחת', 'פשיטה: קודם הרגל הבריאה'],
      TH08: ['לא כולם זקוקים להגבלות', 'לעיתים קרובות יותר אחרי גישה אחורית', 'גישה קדמית: שאלו את הרופא', 'לא לשלב רגליים', 'ברכיים מרוחקות', 'לא למשוך את הרגל אל החזה', 'לא להניח את כף הרגל על הדום גבוה', 'לא מעבר לתשעים מעלות, אם הרופא הגביל'],
      TH09: ['אביזר אחיזה לחפצים מהרצפה', 'הסתובבו בצעדים קטנים עם כל הגוף', 'כרית בין הרגליים, אם הומלץ', 'שינה על הצד: בררו עם הצוות הרפואי'],
      TH10: ['הרמת הרגל יכולה להפחית נפיחות', 'ללכת לפי הנחיות הצוות', 'ליטול את התרופות שנרשמו לכם'],
      TH11: ['הנפיחות ברגל מחמירה בפתאומיות', 'כאב חדש בשוק', 'אדמומיות או חום חריג בעור', 'חום גוף גבוה', 'הפרשה מהפצע', 'כאב שמתגבר באזור המפרק', 'קוצר נשימה פתאומי או כאב בחזה ← 101'],
      TH12: ['רופא המשפחה', 'המשך הטיפול והמעקב', 'יד שרה: השאלת ציוד', 'חנויות למוצרים אורתופדיים', 'המאגרים עזרים ומילבת'],
    },
    end: 'ההנחיות האישיות של הרופא המטפל קודמות',
  },
  ar: {
    brand: 'جراحة العظام · للمرضى', rtl: true,
    n: {
      TH01: ['أسهل وأكثر أمانًا', 'تجهيز البيت', 'أدوات مساعدة في الأسابيع الأولى', 'سيحدّد لكم طبيب العظام وأخصائي العلاج الطبيعي أو أخصائي العلاج الوظيفي القيود المناسبة لكم ومدة الالتزام بها'],
      TH02: ['أزيلوا السجّاد الصغير', 'الأسلاك والوصلات الكهربائية', 'أخلوا الممرات', 'الأشياء اليومية على ارتفاع مريح', 'طاولة صغيرة بارتفاع المقعد'],
      TH03: ['ثابت', 'مقعد صلب', 'مسند للظهر', 'مسندان للذراعين', 'من 45 إلى 50 سم تقريبًا', 'يجب تحديد الارتفاع المناسب لكل شخص', 'وسادة صلبة وثابتة أو قواعد رفع مثبّتة بإحكام'],
      TH04: ['إذا طُلب منكم عدم ثني مفصل الورك أكثر من تسعين درجة', 'الركبتان لا ترتفعان فوق مستوى مفصلَي الورك'],
      TH05: ['قطعة ثابتة لرفع مقعد المرحاض', 'نحو 10 سم', 'مقابض من جهة واحدة أو من الجهتين', 'النوع والمكان مع أخصائي العلاج الوظيفي'],
      TH06: ['مقعد انتقال لحوض الاستحمام', 'كرسي ثابت للدش', 'فقط إذا سمح الطبيب', 'لا تغمروا جرح العملية في الماء', 'سجادة مانعة للانزلاق · مقابض على الجدار', 'لا تستندوا إلى المغسلة أو حامل المناشف', 'إسفنجة بمقبض طويل'],
      TH07: ['أداة التقاط بمقبض طويل', 'أداة لارتداء الجوارب', 'أربطة مطاطية', 'ملعقة أحذية طويلة', 'ارتدوا ملابسكم جلوسًا', 'اللبس: أولًا الساق التي أُجريت لها العملية', 'الخلع: أولًا الساق السليمة'],
      TH08: ['ليست القيود ضرورية للجميع', 'غالبًا بعد المدخل الخلفي', 'المدخل الأمامي: اسألوا الطبيب', 'لا تضعوا ساقًا فوق ساق', 'أبقوا الركبتين متباعدتين', 'لا تسحبوا الساق نحو الصدر', 'لا تضعوا القدم على مسند مرتفع', 'ليس أكثر من تسعين درجة، إذا طلب الطبيب'],
      TH09: ['أداة التقاط للأشياء على الأرض', 'استديروا بخطوات صغيرة مع الجسم كله', 'وسادة بين الساقين، إذا طُلب منكم', 'النوم على الجنب: اسألوا الفريق الطبي'],
      TH10: ['رفع الساق قد يخفف التورّم', 'المشي حسب تعليمات الفريق الطبي', 'الأدوية الموصوفة لكم'],
      TH11: ['ازدياد تورّم الساق فجأة', 'ألم جديد في ربلة الساق', 'احمرار أو سخونة غير معتادة في الجلد', 'ارتفاع حرارة الجسم', 'إفرازات من الجرح', 'ألم متزايد حول المفصل', 'ضيق تنفّس مفاجئ أو ألم في الصدر ← 101'],
      TH12: ['طبيب العائلة', 'استكمال العلاج والمتابعة', '«ياد سارة»: استعارة مؤقتة', 'متاجر المنتجات التقويمية', 'قواعد بيانات «عزاريم» و«ميلبات»'],
    },
    end: 'تعليمات طبيبكم المعالج لها الأولوية',
  },
};

const NV = '#E3E7EF';
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]; size?: number}> = ({y, items, size = 30}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10), transform: `translateY(${(1 - ease(f, a, a + 10)) * 14}px)`}}><Note size={size} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const WarnCard: React.FC<{y: number; at: number; text: string; red?: boolean; size?: number}> = ({y, at, text, red, size = 31}) =>
  <Card x={64} y={y} w={952} at={at} style={{borderInlineStart: `10px solid ${red ? C.blood : C.teal}`}}>
    <div style={{fontFamily: BODY, fontWeight: 800, fontSize: size, color: red ? C.blood : C.ink, lineHeight: 1.3}}>{text}</div>
  </Card>;
const End: React.FC<{at: number; text: string; y?: number}> = ({at, text, y = 1330}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, textAlign: 'center', opacity: ease(f, at, at + 10), fontFamily: HEAD, fontWeight: 800, fontSize: 36, color: C.teal}}>✓ {text}</div>;
};

const T1 = C.teal, T2 = C.tealL, B1 = C.blood, B2 = C.bloodL;
const scene = (id: string, d: number, L: Dict) => {
  const n = L.n[id];
  const t = (p: number) => fr(d, p);
  switch (id) {
    case 'TH01': return <>
      <HomeArrive top={440} d={d} />
      <Notes y={1030} items={[[n[0], t(0.1), T1, T2], [n[1], t(0.3), C.navy, NV], [n[2], t(0.45), C.navy, NV]]} />
      <WarnCard y={1150} at={t(0.68)} text={n[3]} size={29} />
    </>;
    case 'TH02': return <>
      <PrepHome top={440} d={d} />
      <Notes y={1030} items={[[n[0], t(0.12), B1, B2], [n[1], t(0.26), B1, B2], [n[2], t(0.4), T1, T2], [n[3], t(0.52), C.navy, NV], [n[4], t(0.76), T1, T2]]} />
    </>;
    case 'TH03': return <>
      <ChairBed top={440} d={d} h={n[4]} />
      <Notes y={1030} items={[[n[0], t(0.04), T1, T2], [n[1], t(0.08), T1, T2], [n[2], t(0.12), T1, T2], [n[3], t(0.16), T1, T2]]} />
      <WarnCard y={1130} at={t(0.46)} text={n[5]} />
      <Notes y={1270} size={27} items={[[n[6], t(0.78), C.navy, NV]]} />
    </>;
    case 'TH04': return <>
      <KneesHip top={440} d={d} />
      <Notes y={1030} size={28} items={[[n[0], t(0.02), C.navy, NV]]} />
      <WarnCard y={1120} at={t(0.55)} text={n[1]} />
    </>;
    case 'TH05': return <>
      <ToiletScene top={440} d={d} tag={n[1]} />
      <Notes y={1030} items={[[n[0], t(0.06), T1, T2], [n[2], t(0.36), T1, T2], [n[3], t(0.78), C.navy, NV]]} />
    </>;
    case 'TH06': return <>
      <BathScene top={440} d={d} />
      <Notes y={1020} size={27} items={[[n[0], t(0.04), T1, T2], [n[1], t(0.14), T1, T2], [n[2], t(0.22), C.navy, NV], [n[3], t(0.36), B1, B2], [n[4], t(0.52), T1, T2], [n[5], t(0.68), B1, B2], [n[6], t(0.84), T1, T2]]} />
    </>;
    case 'TH07': return <>
      <DressSit top={440} d={d} />
      <Notes y={930} size={28} items={[[n[4], t(0.02), C.navy, NV], [n[5], t(0.12), T1, T2], [n[6], t(0.4), C.navy, NV]]} />
      <ToolRow top={1110} at={t(0.6)} step={t(0.07)} items={[['reach', n[0]], ['sock', n[1]], ['lace', n[2]], ['horn', n[3]]]} size={L.rtl ? 23 : 22} />
    </>;
    case 'TH08': return <>
      <Restrict top={440} d={d} />
      <Notes y={980} size={27} items={[[n[0], t(0.02), C.navy, NV], [n[1], t(0.1), C.navy, NV], [n[2], t(0.18), C.navy, NV]]} />
      <Notes y={1140} size={27} items={[[n[3], t(0.32), B1, B2], [n[4], t(0.4), T1, T2], [n[5], t(0.48), B1, B2], [n[6], t(0.56), B1, B2], [n[7], t(0.76), B1, B2]]} />
    </>;
    case 'TH09': return <>
      <StandLie top={440} d={d} />
      <Notes y={980} size={28} items={[[n[0], t(0.16), T1, T2], [n[1], t(0.44), T1, T2], [n[2], t(0.7), C.navy, NV]]} />
      <WarnCard y={1200} at={t(0.84)} text={n[3]} size={28} />
    </>;
    case 'TH10': return <>
      <SwellLie top={440} d={d} />
      <Notes y={940} items={[[n[0], t(0.08), T1, T2], [n[1], t(0.56), T1, T2], [n[2], t(0.8), C.navy, NV]]} />
    </>;
    case 'TH11': return <>
      <UrgentLeg top={440} d={d} />
      <Notes y={860} size={26} items={[[n[0], t(0.04), B1, B2], [n[1], t(0.12), B1, B2], [n[2], t(0.2), B1, B2], [n[3], t(0.3), B1, B2], [n[4], t(0.38), B1, B2], [n[5], t(0.46), B1, B2]]} />
      <WarnCard y={1070} at={t(0.62)} text={n[6]} red size={29} />
      <Phone101 y={1180} at={t(0.7)} s={0.55} />
    </>;
    case 'TH12': return <>
      <AfterDis top={440} d={d} />
      <Notes y={930} size={28} items={[[n[0], t(0.04), T1, T2], [n[1], t(0.12), C.navy, NV], [n[2], t(0.34), C.navy, NV], [n[3], t(0.48), C.navy, NV], [n[4], t(0.6), C.navy, NV]]} />
      <End at={t(0.8)} text={L.end} y={1250} />
    </>;
  }
  return null;
};

export const mkThrhome = (lang: string, timing: unknown) => {
  const TT = timing as TT;
  const L = N[lang];
  const total = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
  const Comp: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
    let at = 0;
    return <AbsoluteFill style={{direction: L.rtl ? 'rtl' : 'ltr'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={L.brand} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} size={x.head.length > 34 ? 50 : x.head.length > 24 ? 58 : 66} />
            {scene(x.id, d, L)}
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>;
  };
  return {Comp, total};
};
const ru = mkThrhome('ru', tRu); export const Thrhome = ru.Comp; export const totalThrhome = ru.total;
const he = mkThrhome('he', tHe); export const ThrhomeHe = he.Comp; export const totalThrhomeHe = he.total;
const ar = mkThrhome('ar', tAr); export const ThrhomeAr = ar.Comp; export const totalThrhomeAr = ar.total;
const en = mkThrhome('en', tEn); export const ThrhomeEn = en.Comp; export const totalThrhomeEn = en.total;

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
