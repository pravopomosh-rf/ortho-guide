// node sheet.mjs Comp timing.json outdir [pct]
import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition} from '@remotion/renderer';
import fs from 'fs';
const [comp, tfile, out, pct='0.75'] = process.argv.slice(2);
const T = JSON.parse(fs.readFileSync(tfile));
const b = await bundle({entryPoint: '/home/claude/night/lam/r/src/index.ts'});
const BE='/opt/pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell';
const c = await selectComposition({serveUrl: b, id: comp, browserExecutable: BE});
fs.mkdirSync(out, {recursive: true});
let at = 0;
for (const x of T) { const d = Math.round((x.dur + 0.5) * 30); const fr = at + Math.round(d * +pct); at += d;
  await renderStill({composition: c, serveUrl: b, output: `${out}/${x.id}.png`, frame: fr, scale: 0.5, browserExecutable: BE}); console.log(x.id, fr); }
