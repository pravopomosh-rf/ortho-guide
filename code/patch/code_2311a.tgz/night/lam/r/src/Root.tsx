import React from 'react';
import {Composition} from 'remotion';
import {Demo} from './Demo';
import {Lam, totalLam} from './Lam';
import {Kyph, totalKyph} from './Kyph';
import {Kyph_en, totalKyph_en} from './Kyph_en';
import {Kyph_ar, totalKyph_ar} from './Kyph_ar';
import {Kyph_he, totalKyph_he} from './Kyph_he';
import {Arth, totalArth} from './Arth';
import {Enox, totalEnox} from './Enox';
import {Enox_en, totalEnox_en} from './Enox_en';
import {Enox_ar, totalEnox_ar} from './Enox_ar';
import {Enox_he, totalEnox_he} from './Enox_he';
import {Cuff, totalCuff} from './Cuff';
import {Cuff_he, totalCuff_he} from './Cuff_he';
import {Cuff_ar, totalCuff_ar} from './Cuff_ar';
import {Cuff_en, totalCuff_en} from './Cuff_en';
import {Fusion, totalFusion} from './Fusion';
import {Acdf, totalAcdf} from './Acdf';
import {Drain, totalDrain} from './Drain';
import {Cpe, totalCpe, CpeHe, totalCpeHe, CpeAr, totalCpeAr, CpeEn, totalCpeEn} from './Cpe';
import {Rehabv, totalRehabv, RehabvEn, totalRehabvEn, RehabvHe, totalRehabvHe, RehabvAr, totalRehabvAr} from './Rehabv';
import {Opday, totalOpday, OpdayHe, totalOpdayHe, OpdayEn, totalOpdayEn, OpdayAr, totalOpdayAr} from './Opday';
import {Admv, totalAdmv, AdmvHe, totalAdmvHe, AdmvAr, totalAdmvAr, AdmvEn, totalAdmvEn} from './Admv';
import {Cellv, totalCellv, CellvHe, totalCellvHe, CellvAr, totalCellvAr, CellvEn, totalCellvEn} from './Cellv';
import {Pjv, totalPjv, PjvHe, totalPjvHe, PjvAr, totalPjvAr, PjvEn, totalPjvEn} from './Pjv';
import {First, totalFirst, FirstHe, totalFirstHe, FirstAr, totalFirstAr, FirstEn, totalFirstEn} from './First';
import {Chlor, totalChlor} from './Chlor';
import {Dress, totalDress} from './Dress';
import {Stage, totalStage} from './Stage';
import {Dura, totalDura} from './Dura';
import {Spinelong, totalSpinelong, SpinelongHe, totalSpinelongHe, SpinelongAr, totalSpinelongAr, SpinelongEn, totalSpinelongEn} from './Spinelong';
import {Achil, totalAchil} from './Achil';
import {Achil_he, totalAchil_he} from './Achil_he';
import {Achil_ar, totalAchil_ar} from './Achil_ar';
import {Achil_en, totalAchil_en} from './Achil_en';
import {Dura_he, totalDura_he} from './Dura_he';
import {Dura_ar, totalDura_ar} from './Dura_ar';
import {Dura_en, totalDura_en} from './Dura_en';
import {Stage_he, totalStage_he} from './Stage_he';
import {Stage_ar, totalStage_ar} from './Stage_ar';
import {Stage_en, totalStage_en} from './Stage_en';

import {Dress_he, totalDress_he} from './Dress_he';
import {Dress_ar, totalDress_ar} from './Dress_ar';
import {Dress_en, totalDress_en} from './Dress_en';

import {Chlor_he, totalChlor_he} from './Chlor_he';
import {Chlor_ar, totalChlor_ar} from './Chlor_ar';
import {Chlor_en, totalChlor_en} from './Chlor_en';

import {SpinImp, totalSpinImp} from './SpinImp';
import {TibPlat, totalTibPlat} from './TibPlat';
import {TibPlat_he, totalTibPlat_he} from './TibPlat_he';
import {TibPlat_ar, totalTibPlat_ar} from './TibPlat_ar';
import {TibPlat_en, totalTibPlat_en} from './TibPlat_en';

import {SpinImp_he, totalSpinImp_he} from './SpinImp_he';
import {SpinImp_ar, totalSpinImp_ar} from './SpinImp_ar';
import {SpinImp_en, totalSpinImp_en} from './SpinImp_en';

import {Drain_he, totalDrain_he} from './Drain_he';
import {Drain_ar, totalDrain_ar} from './Drain_ar';
import {Drain_en, totalDrain_en} from './Drain_en';

import {Amp, totalAmp} from './Amp';
import {Shoulder, totalShoulder} from './Shoulder';
import {Wrist, totalWrist} from './Wrist';
import {Delir, totalDelir} from './Delir';
import {Falls, totalFalls} from './Falls';
import {Pain, totalPain} from './Pain';
import {Press, totalPress} from './Press';
import {Breath, totalBreath} from './Breath';
import {Walker, totalWalker} from './Walker';
import {Swell, totalSwell} from './Swell';
import {Logroll, totalLogroll} from './Logroll';
import {Logroll_en, totalLogroll_en} from './Logroll_en';
import {Logroll_ar, totalLogroll_ar} from './Logroll_ar';
import {Logroll_he, totalLogroll_he} from './Logroll_he';
import {Swell_en, totalSwell_en} from './Swell_en';
import {Swell_ar, totalSwell_ar} from './Swell_ar';
import {Swell_he, totalSwell_he} from './Swell_he';
import {Walker_en, totalWalker_en} from './Walker_en';
import {Walker_ar, totalWalker_ar} from './Walker_ar';
import {Walker_he, totalWalker_he} from './Walker_he';
import {Breath_en, totalBreath_en} from './Breath_en';
import {Breath_ar, totalBreath_ar} from './Breath_ar';
import {Breath_he, totalBreath_he} from './Breath_he';
import {Press_en, totalPress_en} from './Press_en';
import {Press_ar, totalPress_ar} from './Press_ar';
import {Press_he, totalPress_he} from './Press_he';
import {Pain_en, totalPain_en} from './Pain_en';
import {Pain_ar, totalPain_ar} from './Pain_ar';
import {Pain_he, totalPain_he} from './Pain_he';
import {Falls_en, totalFalls_en} from './Falls_en';
import {Falls_ar, totalFalls_ar} from './Falls_ar';
import {Falls_he, totalFalls_he} from './Falls_he';
import {Delir_en, totalDelir_en} from './Delir_en';
import {Delir_ar, totalDelir_ar} from './Delir_ar';
import {Delir_he, totalDelir_he} from './Delir_he';
import {Wrist_en, totalWrist_en} from './Wrist_en';
import {Wrist_ar, totalWrist_ar} from './Wrist_ar';
import {Wrist_he, totalWrist_he} from './Wrist_he';
import {Shoulder_en, totalShoulder_en} from './Shoulder_en';
import {Shoulder_ar, totalShoulder_ar} from './Shoulder_ar';
import {Shoulder_he, totalShoulder_he} from './Shoulder_he';
import {Amp_en, totalAmp_en} from './Amp_en';
import {Amp_ar, totalAmp_ar} from './Amp_ar';
import {Amp_he, totalAmp_he} from './Amp_he';
import {Acdf_en, totalAcdf_en} from './Acdf_en';
import {Acdf_ar, totalAcdf_ar} from './Acdf_ar';
import {Acdf_he, totalAcdf_he} from './Acdf_he';
import {Osteo, totalOsteo} from './Osteo';
import {Postop, totalPostop} from './Postop';
import {Anest, totalAnest} from './Anest';
import {Anest_en, totalAnest_en} from './Anest_en';
import {Anest_ar, totalAnest_ar} from './Anest_ar';
import {Anest_he, totalAnest_he} from './Anest_he';
import {Wait, totalWait} from './Wait';
import {Wait_en, totalWait_en} from './Wait_en';
import {Wait_ar, totalWait_ar} from './Wait_ar';
import {Wait_he, totalWait_he} from './Wait_he';
import {O2, totalO2} from './O2';
import {O2_he, totalO2_he} from './O2_he';
import {O2_ar, totalO2_ar} from './O2_ar';
import {O2_en, totalO2_en} from './O2_en';
import {Ward, totalWard} from './Ward';
import {Ward_en, totalWard_en} from './Ward_en';
import {Ward_ar, totalWard_ar} from './Ward_ar';
import {Ward_he, totalWard_he} from './Ward_he';
import {Postop_en, totalPostop_en} from './Postop_en';
import {Postop_ar, totalPostop_ar} from './Postop_ar';
import {Postop_he, totalPostop_he} from './Postop_he';
import {Osteo_en, totalOsteo_en} from './Osteo_en';
import {Osteo_ar, totalOsteo_ar} from './Osteo_ar';
import {Osteo_he, totalOsteo_he} from './Osteo_he';
import {Fusion_en, totalFusion_en} from './Fusion_en';
import {Fusion_ar, totalFusion_ar} from './Fusion_ar';
import {Fusion_he, totalFusion_he} from './Fusion_he';
import {AnkleFilm, totalAnkleFilm} from './AnkleFilm';
import {AnkleFilm_he, totalAnkleFilm_he} from './AnkleFilm_he';
import {AnkleFilm_ar, totalAnkleFilm_ar} from './AnkleFilm_ar';
import {AnkleFilm_en, totalAnkleFilm_en} from './AnkleFilm_en';
import {Arth_en, totalArth_en} from './Arth_en';
import {Arth_ar, totalArth_ar} from './Arth_ar';
import {Arth_he, totalArth_he} from './Arth_he';
import {Lam_en, totalLam_en} from './Lam_en';
import {Lam_ar, totalLam_ar} from './Lam_ar';
import {Lam_he, totalLam_he} from './Lam_he';
import {VarFlat} from './Variants';
export const Root: React.FC = () => (<>
  <Composition id="Demo" component={Demo} durationInFrames={280} fps={30} width={1080} height={1920} />
  <Composition id="Lam" component={Lam} durationInFrames={totalLam()} fps={30} width={1080} height={1920} />
  <Composition id="VarA" component={VarFlat} durationInFrames={300} fps={30} width={1080} height={1920} />
  <Composition id="VarC" component={VarFlat} durationInFrames={300} fps={30} width={1080} height={1920} defaultProps={{xray: true}} />
  <Composition id="Lam-he" component={Lam_he} durationInFrames={totalLam_he()} fps={30} width={1080} height={1920} />
  <Composition id="Lam-ar" component={Lam_ar} durationInFrames={totalLam_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Lam-en" component={Lam_en} durationInFrames={totalLam_en()} fps={30} width={1080} height={1920} />
  <Composition id="Kyph" component={Kyph} durationInFrames={totalKyph()} fps={30} width={1080} height={1920} />
  <Composition id="Arth" component={Arth} durationInFrames={totalArth()} fps={30} width={1080} height={1920} />
  <Composition id="Kyph-he" component={Kyph_he} durationInFrames={totalKyph_he()} fps={30} width={1080} height={1920} />
  <Composition id="Kyph-ar" component={Kyph_ar} durationInFrames={totalKyph_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Kyph-en" component={Kyph_en} durationInFrames={totalKyph_en()} fps={30} width={1080} height={1920} />
  <Composition id="Arth-he" component={Arth_he} durationInFrames={totalArth_he()} fps={30} width={1080} height={1920} />
  <Composition id="Arth-ar" component={Arth_ar} durationInFrames={totalArth_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Arth-en" component={Arth_en} durationInFrames={totalArth_en()} fps={30} width={1080} height={1920} />
  <Composition id="Ankle" component={AnkleFilm} durationInFrames={totalAnkleFilm()} fps={30} width={1080} height={1920} />
  <Composition id="AnkleFilm-he" component={AnkleFilm_he} durationInFrames={totalAnkleFilm_he()} fps={30} width={1080} height={1920} />
  <Composition id="AnkleFilm-ar" component={AnkleFilm_ar} durationInFrames={totalAnkleFilm_ar()} fps={30} width={1080} height={1920} />
  <Composition id="AnkleFilm-en" component={AnkleFilm_en} durationInFrames={totalAnkleFilm_en()} fps={30} width={1080} height={1920} />
  <Composition id="Cuff" component={Cuff} durationInFrames={totalCuff()} fps={30} width={1080} height={1920} />
  <Composition id="Cuff-he" component={Cuff_he} durationInFrames={totalCuff_he()} fps={30} width={1080} height={1920} />
  <Composition id="Cuff-ar" component={Cuff_ar} durationInFrames={totalCuff_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Cuff-en" component={Cuff_en} durationInFrames={totalCuff_en()} fps={30} width={1080} height={1920} />
  <Composition id="Fusion" component={Fusion} durationInFrames={totalFusion()} fps={30} width={1080} height={1920} />
  <Composition id="Enox" component={Enox} durationInFrames={totalEnox()} fps={30} width={1080} height={1920} />
  <Composition id="Fusion-he" component={Fusion_he} durationInFrames={totalFusion_he()} fps={30} width={1080} height={1920} />
  <Composition id="Fusion-ar" component={Fusion_ar} durationInFrames={totalFusion_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Fusion-en" component={Fusion_en} durationInFrames={totalFusion_en()} fps={30} width={1080} height={1920} />
  <Composition id="Osteo" component={Osteo} durationInFrames={totalOsteo()} fps={30} width={1080} height={1920} />
  <Composition id="Enox-he" component={Enox_he} durationInFrames={totalEnox_he()} fps={30} width={1080} height={1920} />
  <Composition id="Enox-ar" component={Enox_ar} durationInFrames={totalEnox_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Enox-en" component={Enox_en} durationInFrames={totalEnox_en()} fps={30} width={1080} height={1920} />
  <Composition id="Osteo-he" component={Osteo_he} durationInFrames={totalOsteo_he()} fps={30} width={1080} height={1920} />
  <Composition id="Osteo-ar" component={Osteo_ar} durationInFrames={totalOsteo_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Osteo-en" component={Osteo_en} durationInFrames={totalOsteo_en()} fps={30} width={1080} height={1920} />
  <Composition id="Anest" component={Anest} durationInFrames={totalAnest()} fps={30} width={1080} height={1920} />
  <Composition id="Anest-he" component={Anest_he} durationInFrames={totalAnest_he()} fps={30} width={1080} height={1920} />
  <Composition id="Anest-ar" component={Anest_ar} durationInFrames={totalAnest_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Anest-en" component={Anest_en} durationInFrames={totalAnest_en()} fps={30} width={1080} height={1920} />
  <Composition id="Postop" component={Postop} durationInFrames={totalPostop()} fps={30} width={1080} height={1920} />
  <Composition id="Postop-he" component={Postop_he} durationInFrames={totalPostop_he()} fps={30} width={1080} height={1920} />
  <Composition id="Postop-ar" component={Postop_ar} durationInFrames={totalPostop_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Postop-en" component={Postop_en} durationInFrames={totalPostop_en()} fps={30} width={1080} height={1920} />
  <Composition id="Wait" component={Wait} durationInFrames={totalWait()} fps={30} width={1080} height={1920} />
  <Composition id="O2" component={O2} durationInFrames={totalO2()} fps={30} width={1080} height={1920} />
  <Composition id="O2-he" component={O2_he} durationInFrames={totalO2_he()} fps={30} width={1080} height={1920} />
  <Composition id="O2-ar" component={O2_ar} durationInFrames={totalO2_ar()} fps={30} width={1080} height={1920} />
  <Composition id="O2-en" component={O2_en} durationInFrames={totalO2_en()} fps={30} width={1080} height={1920} />
  <Composition id="Ward" component={Ward} durationInFrames={totalWard()} fps={30} width={1080} height={1920} />
  <Composition id="Wait-he" component={Wait_he} durationInFrames={totalWait_he()} fps={30} width={1080} height={1920} />
  <Composition id="Wait-ar" component={Wait_ar} durationInFrames={totalWait_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Wait-en" component={Wait_en} durationInFrames={totalWait_en()} fps={30} width={1080} height={1920} />
  <Composition id="Ward-he" component={Ward_he} durationInFrames={totalWard_he()} fps={30} width={1080} height={1920} />
  <Composition id="Ward-ar" component={Ward_ar} durationInFrames={totalWard_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Ward-en" component={Ward_en} durationInFrames={totalWard_en()} fps={30} width={1080} height={1920} />
  <Composition id="TibPlat-he" component={TibPlat_he} durationInFrames={totalTibPlat_he()} fps={30} width={1080} height={1920} />
  <Composition id="TibPlat-ar" component={TibPlat_ar} durationInFrames={totalTibPlat_ar()} fps={30} width={1080} height={1920} />
  <Composition id="TibPlat-en" component={TibPlat_en} durationInFrames={totalTibPlat_en()} fps={30} width={1080} height={1920} />
  <Composition id="TibPlat" component={TibPlat} durationInFrames={totalTibPlat()} fps={30} width={1080} height={1920} />
  <Composition id="SpinImp" component={SpinImp} durationInFrames={totalSpinImp()} fps={30} width={1080} height={1920} />
  <Composition id="SpinImp-he" component={SpinImp_he} durationInFrames={totalSpinImp_he()} fps={30} width={1080} height={1920} />
  <Composition id="SpinImp-ar" component={SpinImp_ar} durationInFrames={totalSpinImp_ar()} fps={30} width={1080} height={1920} />
  <Composition id="SpinImp-en" component={SpinImp_en} durationInFrames={totalSpinImp_en()} fps={30} width={1080} height={1920} />
  <Composition id="Chlor-he" component={Chlor_he} durationInFrames={totalChlor_he()} fps={30} width={1080} height={1920} />
  <Composition id="Chlor-ar" component={Chlor_ar} durationInFrames={totalChlor_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Chlor-en" component={Chlor_en} durationInFrames={totalChlor_en()} fps={30} width={1080} height={1920} />
  <Composition id="Dress-he" component={Dress_he} durationInFrames={totalDress_he()} fps={30} width={1080} height={1920} />
  <Composition id="Dress-ar" component={Dress_ar} durationInFrames={totalDress_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Dress-en" component={Dress_en} durationInFrames={totalDress_en()} fps={30} width={1080} height={1920} />
  <Composition id="Stage-he" component={Stage_he} durationInFrames={totalStage_he()} fps={30} width={1080} height={1920} />
  <Composition id="Stage-ar" component={Stage_ar} durationInFrames={totalStage_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Stage-en" component={Stage_en} durationInFrames={totalStage_en()} fps={30} width={1080} height={1920} />
  <Composition id="Dura-he" component={Dura_he} durationInFrames={totalDura_he()} fps={30} width={1080} height={1920} />
  <Composition id="Dura-ar" component={Dura_ar} durationInFrames={totalDura_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Dura-en" component={Dura_en} durationInFrames={totalDura_en()} fps={30} width={1080} height={1920} />
  <Composition id="Achil-he" component={Achil_he} durationInFrames={totalAchil_he()} fps={30} width={1080} height={1920} />
  <Composition id="Achil-ar" component={Achil_ar} durationInFrames={totalAchil_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Achil-en" component={Achil_en} durationInFrames={totalAchil_en()} fps={30} width={1080} height={1920} />
  <Composition id="Achil" component={Achil} durationInFrames={totalAchil()} fps={30} width={1080} height={1920} />
  <Composition id="Dura" component={Dura} durationInFrames={totalDura()} fps={30} width={1080} height={1920} />
  <Composition id="Stage" component={Stage} durationInFrames={totalStage()} fps={30} width={1080} height={1920} />
  <Composition id="Dress" component={Dress} durationInFrames={totalDress()} fps={30} width={1080} height={1920} />
  <Composition id="Chlor" component={Chlor} durationInFrames={totalChlor()} fps={30} width={1080} height={1920} />
  <Composition id="First" component={First} durationInFrames={totalFirst()} fps={30} width={1080} height={1920} />
  <Composition id="First-he" component={FirstHe} durationInFrames={totalFirstHe()} fps={30} width={1080} height={1920} />
  <Composition id="First-ar" component={FirstAr} durationInFrames={totalFirstAr()} fps={30} width={1080} height={1920} />
  <Composition id="First-en" component={FirstEn} durationInFrames={totalFirstEn()} fps={30} width={1080} height={1920} />
  <Composition id="Cpe" component={Cpe} durationInFrames={totalCpe()} fps={30} width={1080} height={1920} />
  <Composition id="Cpe-he" component={CpeHe} durationInFrames={totalCpeHe()} fps={30} width={1080} height={1920} />
  <Composition id="Cpe-ar" component={CpeAr} durationInFrames={totalCpeAr()} fps={30} width={1080} height={1920} />
  <Composition id="Cpe-en" component={CpeEn} durationInFrames={totalCpeEn()} fps={30} width={1080} height={1920} />
  <Composition id="Spinelong" component={Spinelong} durationInFrames={totalSpinelong()} fps={30} width={1080} height={1920} />
  <Composition id="Spinelong-he" component={SpinelongHe} durationInFrames={totalSpinelongHe()} fps={30} width={1080} height={1920} />
  <Composition id="Spinelong-ar" component={SpinelongAr} durationInFrames={totalSpinelongAr()} fps={30} width={1080} height={1920} />
  <Composition id="Spinelong-en" component={SpinelongEn} durationInFrames={totalSpinelongEn()} fps={30} width={1080} height={1920} />
  <Composition id="Rehabv" component={Rehabv} durationInFrames={totalRehabv()} fps={30} width={1080} height={1920} />
  <Composition id="Rehabv-en" component={RehabvEn} durationInFrames={totalRehabvEn()} fps={30} width={1080} height={1920} />
  <Composition id="Rehabv-he" component={RehabvHe} durationInFrames={totalRehabvHe()} fps={30} width={1080} height={1920} />
  <Composition id="Rehabv-ar" component={RehabvAr} durationInFrames={totalRehabvAr()} fps={30} width={1080} height={1920} />
  <Composition id="Opday" component={Opday} durationInFrames={totalOpday()} fps={30} width={1080} height={1920} />
  <Composition id="Opday-he" component={OpdayHe} durationInFrames={totalOpdayHe()} fps={30} width={1080} height={1920} />
  <Composition id="Opday-en" component={OpdayEn} durationInFrames={totalOpdayEn()} fps={30} width={1080} height={1920} />
  <Composition id="Opday-ar" component={OpdayAr} durationInFrames={totalOpdayAr()} fps={30} width={1080} height={1920} />
  <Composition id="Admv" component={Admv} durationInFrames={totalAdmv()} fps={30} width={1080} height={1920} />
  <Composition id="Admv-he" component={AdmvHe} durationInFrames={totalAdmvHe()} fps={30} width={1080} height={1920} />
  <Composition id="Admv-ar" component={AdmvAr} durationInFrames={totalAdmvAr()} fps={30} width={1080} height={1920} />
  <Composition id="Admv-en" component={AdmvEn} durationInFrames={totalAdmvEn()} fps={30} width={1080} height={1920} />
  <Composition id="Cellv" component={Cellv} durationInFrames={totalCellv()} fps={30} width={1080} height={1920} />
  <Composition id="Cellv-he" component={CellvHe} durationInFrames={totalCellvHe()} fps={30} width={1080} height={1920} />
  <Composition id="Cellv-ar" component={CellvAr} durationInFrames={totalCellvAr()} fps={30} width={1080} height={1920} />
  <Composition id="Cellv-en" component={CellvEn} durationInFrames={totalCellvEn()} fps={30} width={1080} height={1920} />
  <Composition id="Pjv" component={Pjv} durationInFrames={totalPjv()} fps={30} width={1080} height={1920} />
  <Composition id="Pjv-he" component={PjvHe} durationInFrames={totalPjvHe()} fps={30} width={1080} height={1920} />
  <Composition id="Pjv-ar" component={PjvAr} durationInFrames={totalPjvAr()} fps={30} width={1080} height={1920} />
  <Composition id="Pjv-en" component={PjvEn} durationInFrames={totalPjvEn()} fps={30} width={1080} height={1920} />
  <Composition id="Drain" component={Drain} durationInFrames={totalDrain()} fps={30} width={1080} height={1920} />
  <Composition id="Drain-he" component={Drain_he} durationInFrames={totalDrain_he()} fps={30} width={1080} height={1920} />
  <Composition id="Drain-ar" component={Drain_ar} durationInFrames={totalDrain_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Drain-en" component={Drain_en} durationInFrames={totalDrain_en()} fps={30} width={1080} height={1920} />
  <Composition id="Acdf" component={Acdf} durationInFrames={totalAcdf()} fps={30} width={1080} height={1920} />
  <Composition id="Acdf-he" component={Acdf_he} durationInFrames={totalAcdf_he()} fps={30} width={1080} height={1920} />
  <Composition id="Acdf-ar" component={Acdf_ar} durationInFrames={totalAcdf_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Acdf-en" component={Acdf_en} durationInFrames={totalAcdf_en()} fps={30} width={1080} height={1920} />
  <Composition id="Amp" component={Amp} durationInFrames={totalAmp()} fps={30} width={1080} height={1920} />
  <Composition id="Amp-he" component={Amp_he} durationInFrames={totalAmp_he()} fps={30} width={1080} height={1920} />
  <Composition id="Amp-ar" component={Amp_ar} durationInFrames={totalAmp_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Amp-en" component={Amp_en} durationInFrames={totalAmp_en()} fps={30} width={1080} height={1920} />
  <Composition id="Shoulder" component={Shoulder} durationInFrames={totalShoulder()} fps={30} width={1080} height={1920} />
  <Composition id="Shoulder-he" component={Shoulder_he} durationInFrames={totalShoulder_he()} fps={30} width={1080} height={1920} />
  <Composition id="Shoulder-ar" component={Shoulder_ar} durationInFrames={totalShoulder_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Shoulder-en" component={Shoulder_en} durationInFrames={totalShoulder_en()} fps={30} width={1080} height={1920} />
  <Composition id="Wrist" component={Wrist} durationInFrames={totalWrist()} fps={30} width={1080} height={1920} />
  <Composition id="Wrist-he" component={Wrist_he} durationInFrames={totalWrist_he()} fps={30} width={1080} height={1920} />
  <Composition id="Wrist-ar" component={Wrist_ar} durationInFrames={totalWrist_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Wrist-en" component={Wrist_en} durationInFrames={totalWrist_en()} fps={30} width={1080} height={1920} />
  <Composition id="Delir" component={Delir} durationInFrames={totalDelir()} fps={30} width={1080} height={1920} />
  <Composition id="Delir-he" component={Delir_he} durationInFrames={totalDelir_he()} fps={30} width={1080} height={1920} />
  <Composition id="Delir-ar" component={Delir_ar} durationInFrames={totalDelir_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Delir-en" component={Delir_en} durationInFrames={totalDelir_en()} fps={30} width={1080} height={1920} />
  <Composition id="Logroll" component={Logroll} durationInFrames={totalLogroll()} fps={30} width={1080} height={1920} />
  <Composition id="Swell" component={Swell} durationInFrames={totalSwell()} fps={30} width={1080} height={1920} />
  <Composition id="Walker" component={Walker} durationInFrames={totalWalker()} fps={30} width={1080} height={1920} />
  <Composition id="Breath" component={Breath} durationInFrames={totalBreath()} fps={30} width={1080} height={1920} />
  <Composition id="Press" component={Press} durationInFrames={totalPress()} fps={30} width={1080} height={1920} />
  <Composition id="Pain" component={Pain} durationInFrames={totalPain()} fps={30} width={1080} height={1920} />
  <Composition id="Falls" component={Falls} durationInFrames={totalFalls()} fps={30} width={1080} height={1920} />
  <Composition id="Falls-he" component={Falls_he} durationInFrames={totalFalls_he()} fps={30} width={1080} height={1920} />
  <Composition id="Falls-ar" component={Falls_ar} durationInFrames={totalFalls_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Falls-en" component={Falls_en} durationInFrames={totalFalls_en()} fps={30} width={1080} height={1920} />
  <Composition id="Pain-he" component={Pain_he} durationInFrames={totalPain_he()} fps={30} width={1080} height={1920} />
  <Composition id="Pain-ar" component={Pain_ar} durationInFrames={totalPain_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Pain-en" component={Pain_en} durationInFrames={totalPain_en()} fps={30} width={1080} height={1920} />
  <Composition id="Press-he" component={Press_he} durationInFrames={totalPress_he()} fps={30} width={1080} height={1920} />
  <Composition id="Press-ar" component={Press_ar} durationInFrames={totalPress_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Press-en" component={Press_en} durationInFrames={totalPress_en()} fps={30} width={1080} height={1920} />
  <Composition id="Breath-he" component={Breath_he} durationInFrames={totalBreath_he()} fps={30} width={1080} height={1920} />
  <Composition id="Breath-ar" component={Breath_ar} durationInFrames={totalBreath_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Breath-en" component={Breath_en} durationInFrames={totalBreath_en()} fps={30} width={1080} height={1920} />
  <Composition id="Walker-he" component={Walker_he} durationInFrames={totalWalker_he()} fps={30} width={1080} height={1920} />
  <Composition id="Walker-ar" component={Walker_ar} durationInFrames={totalWalker_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Walker-en" component={Walker_en} durationInFrames={totalWalker_en()} fps={30} width={1080} height={1920} />
  <Composition id="Swell-he" component={Swell_he} durationInFrames={totalSwell_he()} fps={30} width={1080} height={1920} />
  <Composition id="Swell-ar" component={Swell_ar} durationInFrames={totalSwell_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Swell-en" component={Swell_en} durationInFrames={totalSwell_en()} fps={30} width={1080} height={1920} />
  <Composition id="Logroll-he" component={Logroll_he} durationInFrames={totalLogroll_he()} fps={30} width={1080} height={1920} />
  <Composition id="Logroll-ar" component={Logroll_ar} durationInFrames={totalLogroll_ar()} fps={30} width={1080} height={1920} />
  <Composition id="Logroll-en" component={Logroll_en} durationInFrames={totalLogroll_en()} fps={30} width={1080} height={1920} />
</>);
