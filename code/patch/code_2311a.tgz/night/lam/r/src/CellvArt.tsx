// «Целлюлит» — рисунки сцен (светлые, объёмные градиенты). Подписи слоёв — из props (язык).
import React from 'react';
import {useCurrentFrame, random} from 'remotion';
import {C, BODY, HEAD, ease} from './kit';

const fr = (d: number, p: number) => Math.round(d * p);
const Frame: React.FC<{top: number; h: number; o: number; children: React.ReactNode}> = ({top, h, o, children}) => (
  <div style={{position: 'absolute', left: 64, top, width: 952, height: h, borderRadius: 34, overflow: 'hidden', background: 'linear-gradient(180deg,#FFFFFF 0%,#EEF2F5 100%)',
    boxShadow: '0 18px 50px rgba(20,40,60,.14)', opacity: o, transform: `translateY(${(1 - o) * 30}px)`}}>{children}</div>
);

// Разрез кожи: эпидермис → дерма → подкожная клетчатка → мышца.
// mode: 'layers' (CL01, свечение глубоких слоёв), 'entry' (CL02, бактерии через трещину), 'abscess' (CL06, ограниченный очаг + дренирование врачом)
export const SkinLayers: React.FC<{top: number; d: number; mode: 'layers' | 'entry' | 'abscess'; labels: string[]; rtl?: boolean}> = ({top, d, mode, labels, rtl}) => {
  const f = useCurrentFrame();
  const o = ease(f, 2, 14);
  const H = 700, Wd = 952;
  const y0 = 120, yE = 150, yD = 290, yF = 520; // границы слоёв
  const sep = (i: number) => ease(f, fr(d, 0.05 + i * 0.07), fr(d, 0.12 + i * 0.07)); // «разложение» слоёв
  const off = (i: number) => (mode === 'layers' ? sep(i) * i * 16 : 0);
  const glow = mode === 'layers' ? ease(f, fr(d, 0.45), fr(d, 0.7)) : mode === 'abscess' ? 0.35 : ease(f, fr(d, 0.6), fr(d, 0.9)) * 0.6;
  const wave = (y: number, a: number, ph: number) => {
    let p = `M0 ${y}`;
    for (let x = 0; x <= Wd; x += 34) p += ` L${x} ${y + Math.sin(x / 70 + ph) * a}`;
    return p;
  };
  const band = (yt: number, yb: number, a1: number, a2: number, ph: number, dy: number) =>
    `${wave(yt + dy, a1, ph)} L${Wd} ${yb + dy} ${wave(yb + dy, a2, ph + 1).replace('M0', 'L0').split(' L').reverse().join(' L').replace(/^/, '')} Z`;
  const lob = Array.from({length: 26}, (_, i) => ({x: 20 + (i % 13) * 72 + (Math.floor(i / 13) % 2) * 36, y: yD + 60 + Math.floor(i / 13) * 110, r: 44 + random('l' + i) * 10}));
  const crackX = 470;
  const bac = Array.from({length: 14}, (_, i) => ({sx: 380 + random('bx' + i) * 200, sy: 40 + random('by' + i) * 50, ty: yE + 30 + random('bt' + i) * 260, tx: crackX - 120 + random('bq' + i) * 240, a: fr(d, 0.2 + i * 0.03)}));
  const lx = rtl ? Wd - 40 : 40;
  const anchor = rtl ? 'end' : 'start';
  const abs = mode === 'abscess' ? ease(f, fr(d, 0.12), fr(d, 0.4)) : 0;
  const arrow = mode === 'abscess' ? ease(f, fr(d, 0.5), fr(d, 0.7)) : 0;
  return <Frame top={top} h={H} o={o}>
    <svg width={Wd} height={H} style={{direction: 'ltr'}}>
      <defs>
        <linearGradient id="clEpi" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#F6D2B8" /><stop offset="1" stopColor="#E9B394" /></linearGradient>
        <linearGradient id="clDer" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#F4B9B0" /><stop offset="1" stopColor="#EBA197" /></linearGradient>
        <radialGradient id="clFat" cx="0.4" cy="0.35" r="0.7"><stop offset="0" stopColor="#FFF3C4" /><stop offset="1" stopColor="#F2D27A" /></radialGradient>
        <linearGradient id="clMus" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#C9524A" /><stop offset="1" stopColor="#9E3530" /></linearGradient>
        <radialGradient id="clGlow" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stopColor="#FF3B2F" stopOpacity="0.55" /><stop offset="1" stopColor="#FF3B2F" stopOpacity="0" /></radialGradient>
        <radialGradient id="clAbs" cx="0.45" cy="0.4" r="0.6"><stop offset="0" stopColor="#FFF6D8" /><stop offset="0.7" stopColor="#F3DC8A" /><stop offset="1" stopColor="#D9A43C" /></radialGradient>
        <filter id="clSh"><feDropShadow dx="0" dy="6" stdDeviation="6" floodOpacity="0.18" /></filter>
      </defs>
      {/* мышца */}
      <g transform={`translate(0 ${off(3)})`} filter="url(#clSh)">
        <rect x={0} y={yF} width={Wd} height={H - yF} fill="url(#clMus)" />
        {Array.from({length: 9}, (_, i) => <path key={i} d={wave(yF + 20 + i * 18, 4, i)} stroke="#E07A70" strokeWidth={3} fill="none" opacity={0.45} />)}
      </g>
      {/* подкожная клетчатка */}
      <g transform={`translate(0 ${off(2)})`} filter="url(#clSh)">
        <rect x={0} y={yD} width={Wd} height={yF - yD} fill="#F7E3A6" />
        {lob.map((l, i) => <circle key={i} cx={l.x} cy={l.y} r={l.r} fill="url(#clFat)" stroke="#E8C56A" strokeWidth={2} />)}
        <path d={`M120 ${yD} C 160 ${yD + 90} 100 ${yD + 160} 150 ${yF}`} stroke="#5B7FD6" strokeWidth={9} fill="none" opacity={0.7} />
        <path d={`M760 ${yD} C 720 ${yD + 100} 800 ${yD + 150} 770 ${yF}`} stroke="#C2453C" strokeWidth={8} fill="none" opacity={0.7} />
      </g>
      {/* дерма */}
      <g transform={`translate(0 ${off(1)})`} filter="url(#clSh)">
        <rect x={0} y={yE} width={Wd} height={yD - yE} fill="url(#clDer)" />
        {Array.from({length: 10}, (_, i) => <path key={i} d={`M${40 + i * 95} ${yE + 10} q 20 60 -6 120`} stroke="#D9857A" strokeWidth={3} fill="none" opacity={0.6} />)}
      </g>
      {/* эпидермис */}
      <g transform={`translate(0 ${off(0)})`} filter="url(#clSh)">
        <path d={`${wave(y0, 6, 0)} L${Wd} ${yE} L0 ${yE} Z`} fill="url(#clEpi)" />
        {mode === 'entry' && <path d={`M${crackX - 22} ${y0 - 6} L${crackX} ${yE + 6} L${crackX + 22} ${y0 - 6} Z`} fill="#FFFFFF" />}
      </g>
      {/* воспаление глубоких слоёв (мышца не затронута) */}
      <ellipse cx={mode === 'entry' ? crackX : 476} cy={(yE + yF) / 2 + off(1.5)} rx={460} ry={170} fill="url(#clGlow)" opacity={glow} />
      {/* бактерии через повреждение */}
      {mode === 'entry' && bac.map((b, i) => {
        const p = ease(f, b.a, b.a + fr(d, 0.25));
        const viaY = yE;
        const x = p < 0.5 ? b.sx + (crackX - b.sx) * (p * 2) : crackX + (b.tx - crackX) * ((p - 0.5) * 2);
        const y = p < 0.5 ? b.sy + (viaY - b.sy) * (p * 2) : viaY + (b.ty - viaY) * ((p - 0.5) * 2);
        return <g key={i} opacity={ease(f, b.a - 4, b.a + 4)}><ellipse cx={x} cy={y} rx={11} ry={6} fill="#7A4FD0" transform={`rotate(${i * 37} ${x} ${y})`} /><ellipse cx={x - 3} cy={y - 2} rx={4} ry={2} fill="#fff" opacity={0.5} /></g>;
      })}
      {/* абсцесс: ограниченный очаг в клетчатке */}
      {mode === 'abscess' && <g opacity={abs}>
        <ellipse cx={476} cy={yD + 110} rx={150 * abs} ry={92 * abs} fill="url(#clAbs)" stroke="#C88A2C" strokeWidth={6} />
        <ellipse cx={440} cy={yD + 80} rx={40 * abs} ry={18 * abs} fill="#fff" opacity={0.5} />
      </g>}
      {mode === 'abscess' && <g opacity={arrow}>
        <path d={`M476 ${yD - 60} L476 ${yD - 8}`} stroke={C.teal} strokeWidth={10} strokeLinecap="round" />
        <path d={`M452 ${yD - 34} L476 ${yD - 6} L500 ${yD - 34}`} stroke={C.teal} strokeWidth={10} fill="none" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx={476} cy={56} r={40} fill={C.tealL} stroke={C.teal} strokeWidth={5} />
        <path d="M458 56 h36 M476 38 v36" stroke={C.teal} strokeWidth={8} strokeLinecap="round" />
      </g>}
      {/* подписи слоёв */}
      {[[(y0 + yE) / 2 + off(0), 0], [(yE + yD) / 2 + off(1), 1], [(yD + yF) / 2 + off(2) + (mode === 'abscess' ? 110 : 0), 2], [(yF + H) / 2 + off(3), 3]].map(([y, i]) => labels[i] ? (
        <g key={i} opacity={ease(f, fr(d, 0.1 + i * 0.07), fr(d, 0.16 + i * 0.07))}>
          <text x={lx} y={y + 11} textAnchor={anchor} fontFamily={BODY} fontWeight={800} fontSize={32} fill={i === 3 ? '#fff' : C.ink} stroke={i === 3 ? 'none' : '#ffffff'} strokeWidth={8} paintOrder="stroke">{labels[i]}</text>
        </g>) : null)}
    </svg>
  </Frame>;
};

// Голень и стопа сбоку. mode: 'entry' (точки входа), 'red' (покраснение + значки), 'mark' (маркер по границе + нога на подушке), 'spread' (покраснение за линией)
export const LegRed: React.FC<{top: number; d: number; mode: 'entry' | 'red' | 'mark' | 'spread'; h?: number}> = ({top, d, mode, h = 560}) => {
  const f = useCurrentFrame();
  const o = ease(f, 2, 14);
  const red = mode === 'red' ? ease(f, fr(d, 0.05), fr(d, 0.45)) : mode === 'entry' ? 0 : 1;
  const mark = mode === 'mark' ? ease(f, fr(d, 0.08), fr(d, 0.4)) : mode === 'spread' ? 1 : 0;
  const lift = mode === 'mark' ? ease(f, fr(d, 0.62), fr(d, 0.82)) : 0;
  const spread = mode === 'spread' ? ease(f, fr(d, 0.1), fr(d, 0.4)) : 0;
  const swell = mode === 'red' ? ease(f, fr(d, 0.2), fr(d, 0.5)) : mode === 'entry' ? 0 : 0.6;
  const cx = 430, cy = 250 - lift * 0, rx = 170 + spread * 80, ry = 62 + spread * 16;
  // контур маркера — по наружной границе пятна (не через центр)
  const N = 48, pts: string[] = [];
  for (let i = 0; i <= Math.round(N * mark); i++) { const a = (i / N) * Math.PI * 2; pts.push(`${cx + Math.cos(a) * 172 * (1 + 0.04 * Math.sin(a * 5))},${250 + Math.sin(a) * 64 * (1 + 0.05 * Math.cos(a * 3))}`); }
  const entry = [[880, 300, 0.12], [905, 205, 0.32], [610, 236, 0.52], [330, 220, 0.72]] as const; // трещина пятки, между пальцами, ранка, разрез
  const icons = [[200, 90, 'therm'], [430, 70, 'drop'], [660, 90, 'pain'], [820, 140, 'hot']] as const;
  const ang = 0;
  return <Frame top={top} h={h} o={o}>
    <svg width={952} height={h} style={{direction: 'ltr'}}>
      <defs>
        <linearGradient id="lrSkin" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#F2C9A8" /><stop offset="0.55" stopColor="#E3AC86" /><stop offset="1" stopColor="#C98B66" /></linearGradient>
        <radialGradient id="lrRed" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stopColor="#E0453A" stopOpacity="0.62" /><stop offset="0.75" stopColor="#E0453A" stopOpacity="0.32" /><stop offset="1" stopColor="#E0453A" stopOpacity="0" /></radialGradient>
        <linearGradient id="lrPil" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#FFFFFF" /><stop offset="1" stopColor="#D8E2EA" /></linearGradient>
        <filter id="lrSh" x="-20%" y="-20%" width="140%" height="160%"><feDropShadow dx="0" dy="10" stdDeviation="10" floodOpacity="0.18" /></filter>
      </defs>
      {/* кровать / подушка */}
      <rect x={0} y={h - 120} width={952} height={120} fill="#E4EBF1" />
      <g opacity={lift} transform={`translate(0 ${(1 - lift) * 40})`}><rect x={540} y={286 - lift * 40} width={340} height={84} rx={42} fill="url(#lrPil)" filter="url(#lrSh)" /></g>
      <g transform={`rotate(${ang} 40 300) translate(0 ${-lift * 30})`}>
        <g filter="url(#lrSh)">
          <path d={`M20 ${190 - swell * 6} C 160 ${176 - swell * 10} 330 ${180 - swell * 14} 470 ${190 - swell * 12} C 600 ${196 - swell * 8} 720 196 800 206 C 830 150 880 150 900 186 C 930 190 950 214 944 246 L 940 310 C 900 330 840 326 800 300 C 720 306 600 312 470 ${316 + swell * 10} C 330 ${322 + swell * 12} 160 ${322 + swell * 8} 20 316 Z`} fill="url(#lrSkin)" />
        </g>
        {/* пальцы */}
        {[0, 1, 2].map((i) => <ellipse key={i} cx={936} cy={212 + i * 26} rx={14} ry={11} fill="#E8B693" />)}
        {/* послеоперационный шов */}
        <path d="M290 218 L370 214" stroke="#8C5A44" strokeWidth={4} strokeLinecap="round" />
        {[300, 318, 336, 354].map((x) => <line key={x} x1={x} y1={208} x2={x} y2={224} stroke="#8C5A44" strokeWidth={2.5} />)}
        {/* покраснение */}
        <ellipse cx={cx} cy={250} rx={rx * (0.6 + 0.4 * red)} ry={ry * (0.6 + 0.4 * red)} fill="url(#lrRed)" opacity={red} />
        {/* линия маркера */}
        {pts.length > 1 && <polyline points={pts.join(' ')} fill="none" stroke="#1B2333" strokeWidth={5} strokeDasharray="14 9" strokeLinecap="round" />}
        {mode === 'mark' && mark > 0 && mark < 1 && <g transform={`translate(${pts[pts.length - 1].split(',')[0]} ${pts[pts.length - 1].split(',')[1]}) rotate(-35)`}>
          <rect x={-10} y={-120} width={20} height={110} rx={8} fill="#2C6BD8" /><path d="M-10 -10 L0 8 L10 -10 Z" fill="#1B2333" />
        </g>}
        {/* точки входа */}
        {mode === 'entry' && entry.map(([x, y, a], i) => {
          const p = ease(f, fr(d, a), fr(d, a + 0.1));
          return <g key={i} opacity={p}>
            <circle cx={x} cy={y} r={16 + p * 22} fill="none" stroke={C.acc} strokeWidth={5} opacity={0.9} />
            {[0, 1, 2, 3].map((k) => <circle key={k} cx={x + Math.cos(k * 1.7) * 44 * (1 - p)} cy={y - 40 + Math.sin(k * 1.7) * 16 + p * 40} r={6} fill="#7A4FD0" opacity={1 - p * 0.6} />)}
          </g>;
        })}
      </g>
      {/* значки признаков */}
      {mode === 'red' && icons.map(([x, y, k], i) => {
        const p = ease(f, fr(d, 0.2 + i * 0.15), fr(d, 0.28 + i * 0.15));
        return <g key={i} opacity={p} transform={`translate(${x} ${y + (1 - p) * 20})`}>
          <circle r={38} fill="#fff" stroke={C.acc} strokeWidth={4} filter="url(#lrSh)" />
          {k === 'therm' && <><rect x={-6} y={-24} width={12} height={34} rx={6} fill="none" stroke={C.acc} strokeWidth={4} /><circle cx={0} cy={16} r={9} fill={C.acc} /></>}
          {k === 'drop' && <path d="M-22 6 q22 -40 44 0 q-22 22 -44 0" fill="none" stroke={C.acc} strokeWidth={5} />}
          {k === 'pain' && <path d="M-16 -18 L2 -2 L-8 4 L14 20" stroke={C.acc} strokeWidth={6} fill="none" strokeLinejoin="round" strokeLinecap="round" />}
          {k === 'hot' && [0, 1, 2].map((j) => <path key={j} d={`M${-14 + j * 14} 18 q -8 -12 0 -20 q 8 -10 0 -20`} stroke={C.acc} strokeWidth={4} fill="none" strokeLinecap="round" />)}
        </g>;
      })}
    </svg>
  </Frame>;
};

// Календарь лечения (CL08): дни 1–3 — наблюдение за улучшением; затем недели; курс — как назначил врач
export const CourseCal: React.FC<{top: number; d: number; lbl: [string, string, string]; rtl?: boolean}> = ({top, d, lbl, rtl}) => {
  const f = useCurrentFrame();
  const o = ease(f, 2, 14);
  return <Frame top={top} h={560} o={o}>
    <div style={{position: 'absolute', left: 40, right: 40, top: 40, display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 14, direction: rtl ? 'rtl' : 'ltr'}}>
      {Array.from({length: 14}, (_, i) => {
        const p = ease(f, fr(d, 0.04 + i * 0.015), fr(d, 0.08 + i * 0.015));
        const obs = i < 3;
        const hl = obs ? ease(f, fr(d, 0.12), fr(d, 0.25)) : 0;
        return <div key={i} style={{height: 96, borderRadius: 18, background: obs ? `rgba(23,163,152,${0.15 + hl * 0.6})` : '#fff', border: `3px solid ${obs ? C.teal : C.line}`, opacity: p,
          display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: HEAD, fontWeight: 800, fontSize: 36, color: obs && hl > 0.5 ? '#fff' : C.ink}}>{i + 1}</div>;
      })}
    </div>
    <div style={{position: 'absolute', left: 40, right: 40, top: 280, fontFamily: BODY, fontWeight: 800, fontSize: 30, color: C.teal, opacity: ease(f, fr(d, 0.2), fr(d, 0.3)), textAlign: rtl ? 'right' : 'left'}}>{lbl[0]}</div>
    <div style={{position: 'absolute', left: 40, right: 40, top: 340, height: 22, borderRadius: 11, background: C.bg2, direction: rtl ? 'rtl' : 'ltr'}}>
      <div style={{width: `${ease(f, fr(d, 0.4), fr(d, 0.65)) * 100}%`, height: '100%', borderRadius: 11, background: 'linear-gradient(90deg,#F1A097,#F6D9DA)'}} />
    </div>
    <div style={{position: 'absolute', left: 40, right: 40, top: 378, fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.mute, opacity: ease(f, fr(d, 0.45), fr(d, 0.55)), textAlign: rtl ? 'right' : 'left'}}>{lbl[1]}</div>
    <div style={{position: 'absolute', left: 40, right: 40, top: 450, display: 'flex', alignItems: 'center', gap: 20, opacity: ease(f, fr(d, 0.7), fr(d, 0.8)), direction: rtl ? 'rtl' : 'ltr'}}>
      <svg width={120} height={70}><rect x={4} y={8} width={112} height={54} rx={14} fill="#E9EEF3" stroke="#B8C4CF" strokeWidth={3} />{[0, 1, 2, 3].map((i) => <circle key={i} cx={22 + i * 26} cy={35} r={9} fill={i < Math.round(ease(f, fr(d, 0.75), fr(d, 0.95)) * 4) ? '#fff' : C.acc} stroke="#B8C4CF" strokeWidth={2} />)}</svg>
      <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 30, color: C.ink}}>{lbl[2]}</div>
    </div>
  </Frame>;
};
