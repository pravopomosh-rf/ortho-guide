// «Целлюлит» — ролик для пациентов (9:16), сверху ops/cellulitis.html. Тексты CL01–CL11, cap_* и vis_* ОДОБРЕНО ChatGPT 16.11 (tts-data cellv.json).
import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Subtitle, Note, C, BODY, HEAD, ease, Word} from './kit';
import {Icon} from './Figures';
import {NurseInspect} from './DressArt';
import {Phone101} from './UrgentArt';
import {SkinLayers, LegRed, CourseCal} from './CellvArt';
import tRu from './timing_cellv.json';
import tHe from './timing_cellv_he.json';
import tAr from './timing_cellv_ar.json';
import tEn from './timing_cellv_en.json';

type TT = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const FPS = 30, PAD = 0.5;
const fr = (d: number, p: number) => Math.round(d * p);
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};

type Dict = {brand: string; rtl?: boolean; layers: string[]; n: Record<string, string[]>; end: [string, string]};
const N: Record<string, Dict> = {
  ru: {
    brand: 'ОРТОПЕДИЯ · ПАЦИЕНТАМ', layers: ['эпидермис', 'дерма', 'подкожная клетчатка', 'мышца'],
    n: {
      CL01: ['бактериальная инфекция', 'чаще всего — на ноге', 'не косметический «целлюлит»'],
      CL02: ['ранка · трещина · укус', 'язва · операционный разрез', 'грибок между пальцами → трещины кожи'],
      CL03: ['покраснение может распространяться', 'отёк · болезненность', 'кожа горячая на ощупь', 'иногда: пузыри · температура · озноб · слабость'],
      CL04: ['отёки ног', 'нарушение лимфооттока', 'варикозная болезнь', 'диабет', 'сниженный иммунитет', 'избыточный вес', 'трещины кожи · грибок стопы', 'целлюлит уже был раньше'],
      CL05: ['анализы и ультразвук — по показаниям', 'антибиотики: таблетки или внутривенно', 'после операции: покраснение, боль, отёк или выделения у шва → сразу лечащему врачу'],
      CL06: ['гнойник под кожей', 'вскрыть и дренировать решает врач', 'одних антибиотиков иногда недостаточно'],
      CL07: ['границу обводят маркером', 'не стирайте линию', 'отдых: нога приподнята на подушке'],
      CL08: ['улучшение — через 2–3 дня', 'покраснение и отёк — ещё несколько недель', 'антибиотик — весь назначенный срок', 'быстрое ухудшение → не ждать'],
      CL09: ['быстро распространяется · сильная боль', 'кожа темнеет или немеет · тёмные пузыри', 'высокая температура · частое дыхание · спутанность', 'отёк лица, губ, языка · трудно дышать → экстренно', 'нет улучшения за 2–3 дня → повторный осмотр'],
      CL10: ['каждый день осматривайте ноги и стопы', 'увлажняйте сухую кожу', 'лечите грибок и трещины', 'ранки — в чистоте · меньше отёков', 'компрессионный трикотаж — только по рекомендации врача'],
      CL11: [],
    },
    end: ['Указания врача важнее', 'Лечащий врач · персонал отделения'],
  },
  en: {
    brand: 'ORTHOPAEDICS · FOR PATIENTS', layers: ['epidermis', 'dermis', 'subcutaneous tissue', 'muscle'],
    n: {
      CL01: ['bacterial infection', 'most often a leg', 'not cosmetic cellulite'],
      CL02: ['cut · crack · bite', 'ulcer · surgical incision', "athlete's foot → cracks in the skin"],
      CL03: ['redness that may spread', 'swelling · tenderness', 'skin hot to the touch', 'sometimes: blisters · fever · shivering · weakness'],
      CL04: ['leg swelling', 'poor lymph drainage', 'varicose veins', 'diabetes', 'weakened immunity', 'excess weight', "cracked skin · athlete's foot", 'cellulitis before'],
      CL05: ['blood tests and ultrasound only when indicated', 'antibiotics: by mouth or through a vein', 'after surgery: redness, pain, swelling or discharge at the wound → your treating doctor now'],
      CL06: ['abscess: a collection of pus', 'the doctor may open and drain it', 'antibiotics alone may not be enough'],
      CL07: ['the edge is marked with a pen', 'do not rub the line off', 'resting: leg raised on a pillow'],
      CL08: ['improvement within 2–3 days', 'redness and swelling: several more weeks', 'the full course of antibiotics', 'rapid worsening → do not wait'],
      CL09: ['spreads rapidly · unusually severe pain', 'dark or numb skin · dark blisters', 'high fever · rapid breathing · confusion', 'swelling of face, lips, tongue · difficulty breathing → emergency', 'no improvement in 2–3 days → reassessment'],
      CL10: ['check legs and feet daily', 'moisturise dry skin', "treat athlete's foot and cracks", 'keep wounds clean · manage swelling', 'compression stockings only if your doctor recommends'],
      CL11: [],
    },
    end: ["Your care team's instructions take priority", 'Treating doctor · ward staff'],
  },
  he: {
    brand: 'אורתופדיה · למטופלים', rtl: true, layers: ['אפידרמיס', 'דרמיס', 'רקמה תת עורית', 'שריר'],
    n: {
      CL01: ['זיהום חיידקי', 'לרוב ברגל', 'לא הצלוליט הקוסמטי'],
      CL02: ['פצע קטן · סדק · עקיצה או נשיכה', 'כיב · חתך ניתוחי', 'פטרת בין האצבעות ← סדקים בעור'],
      CL03: ['אדמומיות שעלולה להתפשט', 'נפיחות · כאב', 'עור חם למגע', 'לפעמים: שלפוחיות · חום גבוה · צמרמורות · חולשה'],
      CL04: ['נפיחות ברגליים', 'הפרעה בניקוז הלימפה', 'דליות', 'סוכרת', 'מערכת חיסון מוחלשת', 'עודף משקל', 'סדקים בעור · פטרת בכפות הרגליים', 'צלוליטיס בעבר'],
      CL05: ['בדיקות דם ואולטרסאונד לפי הצורך', 'אנטיביוטיקה בכדורים או דרך הווריד', 'אחרי ניתוח: אדמומיות, כאב, נפיחות או הפרשה סביב החתך ← מיד לרופא המטפל'],
      CL06: ['מורסה מתחת לעור', 'הרופא מחליט על פתיחה וניקוז', 'לפעמים אנטיביוטיקה בלבד אינה מספיקה'],
      CL07: ['מסמנים בטוש את גבול האדמומיות', 'אל תמחקו את הקו', 'במנוחה: הרגל מורמת על כרית'],
      CL08: ['שיפור תוך יומיים עד שלושה', 'אדמומיות ונפיחות: עוד כמה שבועות', 'אנטיביוטיקה לכל התקופה שהרופא קבע', 'החמרה מהירה ← אסור לחכות'],
      CL09: ['התפשטות מהירה · כאב חזק באופן חריג', 'עור מתכהה או מאבד תחושה · שלפוחיות עם נוזל כהה', 'חום גבוה · נשימה מהירה · בלבול', 'נפיחות בפנים, בשפתיים, בלשון · קושי בנשימה ← עזרה דחופה', 'אין שיפור תוך יומיים עד שלושה ← בדיקה חוזרת'],
      CL10: ['בדקו מדי יום רגליים וכפות רגליים', 'קרם לחות על עור יבש', 'טפלו בפטרת ובסדקים', 'ניקיון הפצעים · פחות נפיחות', 'גרבי לחץ רק בהמלצת הרופא'],
      CL11: [],
    },
    end: ['הנחיות הרופא המטפל קודמות', 'הרופא המטפל · הצוות במחלקה'],
  },
  ar: {
    brand: 'جراحة العظام · للمرضى', rtl: true, layers: ['البشرة', 'الأدمة', 'النسيج تحت الجلد', 'العضلة'],
    n: {
      CL01: ['عدوى بكتيرية', 'غالبًا في الساق', 'يختلف عن السيلوليت التجميلي'],
      CL02: ['جرح صغير · تشقق · لدغة أو عضة', 'قرحة · شق جراحي', 'الفطريات بين أصابع القدمين ← تشققات في الجلد'],
      CL03: ['احمرار قد ينتشر', 'تورم · ألم', 'سخونة الجلد عند لمسه', 'أحيانًا: فقاعات · حرارة · قشعريرة · ضعف'],
      CL04: ['تورم الساقين', 'اضطراب تصريف اللمف', 'دوالي', 'سكري', 'ضعف المناعة', 'زيادة الوزن', 'تشققات الجلد · فطريات القدم', 'إصابة سابقة'],
      CL05: ['فحوص الدم والموجات فوق الصوتية عند الحاجة', 'مضادات حيوية: أقراص أو عبر الوريد', 'بعد العملية: احمرار أو ألم أو تورم أو إفرازات حول الجرح ← الطبيب المعالج فورًا'],
      CL06: ['خراج تحت الجلد', 'الطبيب يقرر فتحه وتصريف القيح', 'أحيانًا لا تكفي المضادات الحيوية وحدها'],
      CL07: ['تحديد حدود الاحمرار بقلم', 'لا تمسحوا هذا الخط', 'أثناء الراحة: الساق مرفوعة على وسادة'],
      CL08: ['التحسن خلال يومين إلى ثلاثة أيام', 'الاحمرار والتورم: عدة أسابيع أخرى', 'المضاد الحيوي طوال المدة التي حددها الطبيب', 'تدهور سريع ← لا تنتظروا'],
      CL09: ['انتشار سريع · ألم شديد بشكل غير متناسب', 'جلد داكن أو فاقد للإحساس · فقاعات بسائل داكن', 'حرارة مرتفعة · تنفس سريع · تشوش', 'تورم الوجه أو الشفتين أو اللسان · صعوبة التنفس ← مساعدة طارئة', 'لا تحسن خلال يومين إلى ثلاثة ← إعادة الفحص'],
      CL10: ['افحصوا الساقين والقدمين كل يوم', 'رطبوا الجلد الجاف', 'عالجوا الفطريات والتشققات', 'نظافة الجروح · تخفيف التورم', 'الجوارب الضاغطة بتوصية الطبيب فقط'],
      CL11: [],
    },
    end: ['تعليمات الطبيب المعالج لها الأولوية', 'الطبيب المعالج · طاقم القسم'],
  },
};
const CAL: Record<string, [string, string, string]> = {
  ru: ['улучшение — через 2–3 дня', 'покраснение и отёк — ещё несколько недель', 'весь срок, назначенный врачом'],
  en: ['improvement within 2–3 days', 'redness and swelling: several more weeks', 'the full course your doctor prescribed'],
  he: ['שיפור תוך יומיים עד שלושה', 'אדמומיות ונפיחות: עוד כמה שבועות', 'לכל התקופה שהרופא קבע'],
  ar: ['التحسن خلال يومين إلى ثلاثة أيام', 'الاحمرار والتورم: عدة أسابيع أخرى', 'طوال المدة التي حددها الطبيب'],
};

const NV = '#E3E7EF';
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]; size?: number}> = ({y, items, size = 30}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10), transform: `translateY(${(1 - ease(f, a, a + 10)) * 14}px)`}}><Note size={size} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const CheckRow: React.FC<{y: number; at: number; icon: string; text: string; warn?: boolean}> = ({y, at, icon, text, warn}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at} style={warn ? {borderInlineStart: `10px solid ${C.blood}`} : undefined}>
    <div style={{display: 'flex', alignItems: 'center', gap: 24}}>
      <Icon k={icon} s={58} c={warn ? C.blood : C.acc} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 31, color: C.ink, lineHeight: 1.25}}>{text}</div>
      {!warn && <div style={{opacity: ease(f, at + 14, at + 22)}}><Icon k="check" s={52} /></div>}
    </div>
  </Card>;
};
const RISK_IC = ['leg', 'drop', 'leg', 'drop', 'heart', 'clock', 'wound', 'clock'];
const RiskGrid: React.FC<{d: number; items: string[]}> = ({d, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: 450, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18}}>
    {items.map((t, i) => {
      const a = fr(d, 0.05 + i * 0.09), p = ease(f, a, a + 10);
      const last = i === items.length - 1;
      return <div key={i} style={{gridColumn: last ? '1 / 3' : undefined, opacity: p, transform: `translateY(${(1 - p) * 20}px) scale(${0.96 + p * 0.04})`, background: last ? C.accL : '#fff', borderRadius: 26,
        boxShadow: '0 12px 30px rgba(20,40,60,.10)', padding: '22px 22px', display: 'flex', alignItems: 'center', gap: 16, minHeight: 112}}>
        <div style={{width: 64, height: 64, borderRadius: 18, background: last ? '#fff' : C.tealL, display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none'}}><Icon k={last ? 'clock' : RISK_IC[i] || 'leg'} s={48} c={last ? C.acc : C.teal} /></div>
        <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 30, color: C.ink, lineHeight: 1.2}}>{t}</div>
      </div>;
    })}
  </div>;
};
const WarnBox: React.FC<{d: number; items: string[]}> = ({d, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: 450, borderRadius: 30, border: `6px solid ${C.blood}`, background: '#fff', padding: '26px 28px', opacity: ease(f, 2, 12)}}>
    {items.slice(0, 4).map((t, i) => {
      const a = fr(d, 0.04 + i * 0.12), p = ease(f, a, a + 10);
      return <div key={i} style={{display: 'flex', gap: 16, alignItems: 'flex-start', marginBottom: 18, opacity: p, transform: `translateX(${(1 - p) * 20}px)`}}>
        <div style={{flex: 'none', width: 22, height: 22, borderRadius: 11, background: i === 3 ? C.blood : C.acc, marginTop: 10}} />
        <div style={{fontFamily: BODY, fontWeight: i === 3 ? 800 : 700, fontSize: 31, color: i === 3 ? C.blood : C.ink, lineHeight: 1.25}}>{t}</div>
      </div>;
    })}
  </div>;
};

const scene = (id: string, d: number, L: Dict, lang: string) => {
  const n = L.n[id];
  const t = (p: number) => fr(d, p);
  switch (id) {
    case 'CL01': return <>
      <SkinLayers top={440} d={d} mode="layers" labels={L.layers} rtl={L.rtl} />
      <Notes y={1170} items={[[n[0], t(0.2), C.blood, C.bloodL], [n[1], t(0.5), C.navy, NV], [n[2], t(0.75)]]} />
    </>;
    case 'CL02': return <>
      <LegRed top={440} d={d * 0.5 | 0} mode="entry" h={460} />
      <Sequence from={t(0.5)}><SkinLayers top={440} d={d - t(0.5)} mode="entry" labels={['', L.layers[1], L.layers[2], '']} rtl={L.rtl} /></Sequence>
      <Notes y={1170} items={[[n[0], t(0.08), C.navy, NV], [n[1], t(0.3), C.navy, NV], [n[2], t(0.6)]]} />
    </>;
    case 'CL03': return <>
      <LegRed top={440} d={d} mode="red" />
      <Notes y={1030} items={[[n[0], t(0.06)], [n[1], t(0.3), C.navy, NV], [n[2], t(0.5), C.navy, NV], [n[3], t(0.68), C.blood, C.bloodL]]} />
    </>;
    case 'CL04': return <RiskGrid d={d} items={n} />;
    case 'CL05': return <>
      <NurseInspect top={440} d={d} />
      <Notes y={900} items={[[n[0], t(0.2), C.navy, NV], [n[1], t(0.45), C.teal, C.tealL]]} />
      <Card x={64} y={1090} w={952} at={t(0.68)} style={{borderInlineStart: `10px solid ${C.blood}`}}>
        <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 31, color: C.ink, lineHeight: 1.3}}>{n[2]}</div>
      </Card>
    </>;
    case 'CL06': return <>
      <SkinLayers top={440} d={d} mode="abscess" labels={['', '', L.layers[2], '']} rtl={L.rtl} />
      <Notes y={1170} items={[[n[0], t(0.15)], [n[1], t(0.5), C.teal, C.tealL], [n[2], t(0.72), C.navy, NV]]} />
    </>;
    case 'CL07': return <>
      <LegRed top={440} d={d} mode="mark" />
      <Notes y={1030} items={[[n[0], t(0.1), C.navy, NV], [n[1], t(0.38)], [n[2], t(0.62), C.teal, C.tealL]]} />
    </>;
    case 'CL08': return <>
      <CourseCal top={440} d={d} lbl={CAL[lang]} rtl={L.rtl} />
      <Notes y={1040} items={[[n[3], t(0.55), C.blood, C.bloodL]]} />
    </>;
    case 'CL09': return <>
      <WarnBox d={Math.round(d * 0.8)} items={n} />
      <Card x={64} y={1060} w={952} at={t(0.6)}><div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.navy, lineHeight: 1.3}}>{n[4]}</div></Card>
      <Phone101 y={1220} at={t(0.84)} s={0.7} />
    </>;
    case 'CL10': return <>
      {n.map((x, i) => <CheckRow key={i} y={450 + i * 186} at={t(0.04 + i * 0.16)} icon={['leg', 'drop', 'wound', 'wound', 'pills'][i]} text={x} warn={i === 4} />)}
    </>;
    case 'CL11': return <>
      <Card x={64} y={640} w={952} at={t(0.1)} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center', padding: '60px 40px'}}>
        <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 50, color: C.ink, marginBottom: 20, lineHeight: 1.2}}>{L.end[0]}</div>
        <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 34, color: C.mute}}>{L.end[1]}</div>
      </Card>
    </>;
  }
  return null;
};

export const mkCellv = (lang: string, timing: unknown) => {
  const TT = timing as TT;
  const L = N[lang];
  const total = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
  const Comp: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
    let at = 0;
    return <AbsoluteFill style={{direction: L.rtl ? 'rtl' : 'ltr'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={L.brand} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            {scene(x.id, d, L, lang)}
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>;
  };
  return {Comp, total};
};
const ru = mkCellv('ru', tRu); export const Cellv = ru.Comp; export const totalCellv = ru.total;
const he = mkCellv('he', tHe); export const CellvHe = he.Comp; export const totalCellvHe = he.total;
const ar = mkCellv('ar', tAr); export const CellvAr = ar.Comp; export const totalCellvAr = ar.total;
const en = mkCellv('en', tEn); export const CellvEn = en.Comp; export const totalCellvEn = en.total;

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
