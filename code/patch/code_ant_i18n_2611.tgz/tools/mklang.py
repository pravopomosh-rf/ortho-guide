# Builds src/lang.ts (screen texts ru/he/ar/en with ChatGPT round-1 fixes) and wraps RU literals in Film.tsx with tx()
import re, ast, json, sys
base = '/home/claude/ant/'
src = open(base + 'tr_ant.py').read()
S = ast.literal_eval(re.search(r"^SCREEN = (\{.*?^\})", src, re.S | re.M).group(1))
S = {k.strip(): tuple(x.strip() for x in v) for k, v in S.items()}
# --- round 1 screen fixes (gpt/anterior_gpt_2611.txt п.1,2,4,7,8) ---
FIX_RU = {  # RU screen text changes: old -> new
  'Чаще всего — задний и боковой': 'Оба доступа широко применяются',
  'Мышцы не отсекают, а раздвигают и отводят': 'Мышцы обычно не отсекают, а раздвигают и отводят',
  'Ваши рекомендации из выписки и указания медицинской команды имеют приоритет': 'Индивидуальные указания лечащего врача имеют приоритет',
}
S['Оба доступа широко применяются'] = ('שתי הגישות נמצאות בשימוש נרחב', 'كلا المدخلين يُستخدم على نطاق واسع', 'Both approaches are widely used')
S['Мышцы обычно не отсекают, а раздвигают и отводят'] = ('בדרך כלל לא חותכים את השרירים, אלא מרחיקים ומסיטים אותם', 'عادةً لا تُقطع العضلات، بل تُباعَد وتُزاح', 'The muscles are usually not cut, but moved apart and held aside')
S['Индивидуальные указания лечащего врача имеют приоритет'] = ('להנחיות האישיות של הרופא המטפל יש עדיפות', 'للتعليمات الفردية الصادرة عن الطبيب المعالج الأولوية', "Your treating doctor's individual instructions take priority")
def setl(k, i, v):
    t = list(S[k]); t[i] = v; S[k] = tuple(t)
setl('Чашка — во впадину', 0, 'הכוסית בתוך שקע המפרק')
setl('Ножка — в бедренную кость', 0, 'גזע המשתל בתוך עצם הירך')
setl('Головка — на ножку', 0, 'ראש המשתל על הגזע')
setl('разрез кожи', 2, 'skin incision')
setl('Не отменяйте указания хирурга самостоятельно', 2, "Do not change your surgeon's instructions on your own")
for k, v in S.items():
    if 'الوظيفة' in v[1] and 'وظيفة المفصل' not in v[1]:
        setl(k, 1, v[1].replace('الوظيفة', 'وظيفة المفصل'))
k7 = 'Перед выпиской уточните: какие движения разрешены, какая нагрузка, какие упражнения'
setl(k7, 0, S[k7][0].replace('איזה עומס', 'כמה משקל מותר להעמיס על הרגל המנותחת'))
setl(k7, 1, S[k7][1].replace('وما الحِمل', 'وما مقدار الوزن المسموح بتحميله على الساق التي أُجريت لها العملية'))
# --- extra (credits, non-medical) ---
S['известен давно'] = ('מוכרת מזמן', 'معروف منذ زمن', 'long known')
S['«Маген Давид Адом»'] = S['«Маген Давид Адом»']
S['Mikael Häggström — общественное достояние (CC0) · Рентген эндопротеза — общественное достояние · оба — Викисклад'] = ('Mikael Häggström: נחלת הכלל (CC0) · צילום רנטגן של התותב: נחלת הכלל · שניהם מוויקישיתוף', 'Mikael Häggström: ملكية عامة (CC0) · صورة أشعة المفصل الاصطناعي: ملكية عامة · كلاهما من ويكيميديا كومنز', 'Mikael Häggström: public domain (CC0) · Prosthesis X-ray: public domain · both from Wikimedia Commons')
S['3D-кости, мышцы и кожа — атлас BodyParts3D, © 2008 Life Science Integrated Database Center, лицензия CC BY-SA 2.1 Япония'] = ('עצמות, שרירים ועור בתלת־ממד: האטלס BodyParts3D, © 2008 Life Science Integrated Database Center, רישיון CC BY-SA 2.1 יפן', 'العظام والعضلات والجلد ثلاثية الأبعاد: أطلس BodyParts3D، © 2008 Life Science Integrated Database Center، ترخيص CC BY-SA 2.1 اليابان', '3D bones, muscles and skin: BodyParts3D atlas, © 2008 Life Science Integrated Database Center, licence CC BY-SA 2.1 Japan')
S['Хрящ, протез, стрелки доступов, капсула и зоны — упрощённые схемы, сделаны для этого ролика'] = ('הסחוס, התותב, חצי הגישות, הקופסית והאזורים: תרשימים מפושטים שנעשו לסרטון הזה', 'الغضروف والمفصل الاصطناعي وأسهم المداخل والمحفظة والمناطق: مخططات مبسّطة صُنعت لهذا الفيديو', 'Cartilage, prosthesis, approach arrows, capsule and zones: simplified diagrams made for this video')
# --- wrap Film.tsx ---
f = open(base + 'src/Film.orig.tsx').read()
f = f.replace('«Маген<br />Давид Адом»', '«Маген Давид Адом»')
for o, n in FIX_RU.items():
    assert o in f, o
    f = f.replace(o, n)
CY = '[А-Яа-яЁё]'
miss = set()
def need(k):
    if k not in S: miss.add(k)
# attribute strings: text="..", n="..", t="..", title etc  -> {tx("..")}
f = re.sub(r'(\b\w+)="([^"\n]*' + CY + r'[^"\n]*)"', lambda m: (need(m.group(2).strip()), f'{m.group(1)}={{tx({json.dumps(m.group(2), ensure_ascii=False)})}}')[1], f)
# JS single-quoted literals except inside accent arrays
def jsq(m):
    s = m.group(1)
    need(s.strip()); return f'tx({json.dumps(s, ensure_ascii=False)})'
parts = re.split(r'(accent=\{\[[^\]]*\]\})', f)
for i in range(0, len(parts), 2):
    parts[i] = re.sub(r"'([^'\n]*" + CY + r"[^'\n]*)'", jsq, parts[i])
f = ''.join(parts)
# JSX text nodes
def jsx(m):
    s = m.group(1); k = re.sub(r'\s+', ' ', s).strip()
    need(k)
    lead = ' ' if re.match(r'[ \t]+\S', s) else ''
    trail = ' ' if re.search(r'\S[ \t]+$', s) else ''
    return '>' + lead + '{tx(' + json.dumps(k, ensure_ascii=False) + ')}' + trail + '<'
f = re.sub(r'>([^<>{}]*' + CY + r'[^<>{}]*)<', jsx, f)
f = f.replace("import {AbsoluteFill,", "import {tx, accFor, LANG, isRTL} from './lang';\nimport {AbsoluteFill,", 1)
open(base + 'src/Film.tsx', 'w').write(f)
left = [l for l in f.split('\n') if re.search(CY, l) and 'tx(' not in l and 'accent=' not in l and not l.strip().startswith('//')]
print('MISSING', sorted(miss)); print('LEFT', left[:20])
json.dump({k: list(v) for k, v in S.items()}, open(base + 'tools/screen.json', 'w'), ensure_ascii=False, indent=0)
