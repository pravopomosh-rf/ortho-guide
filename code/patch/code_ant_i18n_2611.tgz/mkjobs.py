import json,sys
T=json.load(open('/home/claude/ant/src/'+(sys.argv[2] if len(sys.argv)>2 else 'timing.json')+''))
mode=sys.argv[1]
clip={'s1':('c1','Clip',{"mode":"anatomy","start":0,"spin":0.5,"w":600,"h":640}),
 's2':('c2','Clip',{"mode":"oa","start":0,"spin":0.5,"w":600,"h":470}),
 's3':('c3','Clip',{"mode":"prosthesis","start":0,"spin":0.5,"w":620,"h":600}),
 's9':('c9','Clip',{"mode":"prosthesis","start":-400,"spin":1.2,"w":300,"h":300,"len":240}),
 'a1':('L_appr','Leg',{"mode":"approaches","w":560,"h":640}),'a2b':('L_post','Leg',{"mode":"posterior","w":560,"h":640}),
 'a2c':('L_lat','Leg',{"mode":"lateral","w":560,"h":640}),'a3b':('L_ant','Leg',{"mode":"anterior","w":720,"h":640}),
 'a5c':('L_chosen','Leg',{"mode":"chosen","w":560,"h":640}),'s6':('L_numb','Leg',{"mode":"numb","w":560,"h":640}),
 'w2':('L_wound','Leg',{"mode":"wound","w":640,"h":600}),'w3':('L_calf','Leg',{"mode":"calves","w":640,"h":600}),'w6':('L_pain','Leg',{"mode":"pain","w":560,"h":640})}
jobs={};g=0;pv=[]
for x in T:
    i=x['id']; n=round(x['dur']*30)
    ks=[int(n*0.75)]
    if i in('a1','a3b'): ks=[int(n*0.35),n-10]
    if i=='s2': ks=[int(n*0.3),int(n*0.85)]
    if i=='w7': ks=[n//2]
    for k in ks: pv.append((i,g+k))
    if i in clip:
        name,comp,pr=clip[i]; pr=dict(pr); off=0; cn=n
        if i=='s2':
            a=min(n-60,270); off=a; cn=n-a
        pr.setdefault('len',cn)
        fr=[k-off for k in ks if k-off>=0] if mode=='prev' else list(range(cn))
        j=jobs.setdefault(name,{"name":name,"comp":comp,"props":pr,"frames":[]}); j['frames']+=fr
    g+=n
json.dump(list(jobs.values()),open('/home/claude/ant/jobs/%s.json'%mode,'w'))
json.dump(pv,open('/home/claude/ant/jobs/pv.json','w'))
print(sum(len(j['frames']) for j in jobs.values()),'3D frames;',len(pv),'stills')
