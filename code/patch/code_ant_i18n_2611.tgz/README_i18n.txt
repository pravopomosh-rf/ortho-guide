ant i18n (26.11 ночь): Film/Root по языкам через inputProps {lang}. src/lang.ts — экранные тексты ru/he/ar/en
(tools/mkts.py из tools/screen.json; правки раунда 1 ChatGPT уже внесены: a2a «Оба доступа широко применяются»,
a3b «обычно», HE термины протеза, EN skin incision / Do not change..., AR وظيفة المفصل, s7 HE/AR вес, s9 плашка «Индивидуальные указания лечащего врача имеют приоритет»).
RTL: direction rtl на корне, метки 3D (Pin/PLabel) ltr; шрифты Noto Sans Hebrew/Arabic в public/fonts (из @fontsource).
Hip3D теперь грузит bp3d/*.bin (STL не нужны). timing_he/ar/en.json — ПОКА КОПИИ RU: заменить по длительностям аудио
(id сегментов как в timing.json; w45 = одна фраза). Путь: python3 mkjobs.py full timing_<l>.json → node render3d.mjs jobs/full.json
(public/clips общий — для каждого языка своя папка clips или очистить!) → npx remotion render src/index.ts Film out/f_<l>.mp4 --muted --props='{"lang":"<l>"}' --concurrency=2
→ ffmpeg + голос. Стоп-кадры: node stills.mjs jobs/pv.json pv/<l> <l>. Превью 4 языков проверено (контакт-листы).
