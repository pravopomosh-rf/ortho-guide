import re,glob
R='/home/claude/ortho-guide';V='1911a';n=0
for f in glob.glob(R+'/*.html')+glob.glob(R+'/ops/*.html')+glob.glob(R+'/qr/*.html'):
    s=open(f,encoding='utf8').read();o=s
    s=re.sub(r'<video class="vid v16" width="1280" height="720" style="aspect-ratio:1280/720"( id="v_ar")? controls preload="none" playsinline poster="\.\./video/c/preop_ar\.jpg" src="\.\./video/preop_ar\.mp4">',
      lambda m:f'<video class="vid v9" width="1080" height="1920" style="aspect-ratio:1080/1920"{m.group(1) or ""} controls preload="none" playsinline poster="../video/c/preopv_ar.jpg?v={V}" src="../video/preopv_ar.mp4?v={V}">',s)
    s=s.replace('video/t/preop_ar.jpg"',f'video/t/preopv_ar.jpg?v={V}"')
    if s!=o: open(f,'w',encoding='utf8').write(s);n+=1
print('files',n)
