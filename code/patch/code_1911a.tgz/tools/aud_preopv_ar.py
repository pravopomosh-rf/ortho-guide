# звук preopv_ar: 3 с тишины + сцены pad до round((dur+0.7)*30) кадров + OUT 210 кадров → /tmp/preopv_ar_audio.wav
import json,subprocess
d=json.load(open('i18n/ar.json'))['durs']
L=open('/tmp/alist.txt','w')
subprocess.run('ffmpeg -v error -y -f lavfi -i anullsrc=r=48000:cl=mono -t 3 /tmp/a_sil.wav',shell=True)
L.write("file '/tmp/a_sil.wav'\n")
for s in ['S%d'%i for i in range(1,13)]+['OUT']:
    fr=210 if s=='OUT' else round((d[s]+0.7)*30)
    o=f'/tmp/a_{s}.wav'
    subprocess.run(f'ffmpeg -v error -y -i public/preop_ar/{s}.wav -ar 48000 -ac 1 -af apad -t {fr/30:.4f} {o}',shell=True)
    L.write(f"file '{o}'\n")
L.close()
subprocess.run('ffmpeg -v error -y -f concat -safe 0 -i /tmp/alist.txt -c copy /tmp/preopv_ar_audio.wav',shell=True)
