cd /home/claude/preop
B=/opt/pw-browsers/chromium-1243/chrome-linux64/chrome
T=21232
for ((a=0;a<T;a+=600)); do b=$((a+599)); [ $b -ge $T ] && b=$((T-1)); o=parts/p_$(printf %05d $a).mp4
 [ -s $o ] && continue
 npx remotion render src/index3.ts PreopV-ar $o --frames=$a-$b --muted --crf=27 --pixel-format=yuv420p --concurrency=2 --browser-executable=$B --gl=swangle --log=error >>/tmp/rp.log 2>&1 || echo FAIL $a >>/tmp/rp.log
 echo done $a $(date +%T) >>/tmp/rp.log
done
echo ALLDONE >>/tmp/rp.log
