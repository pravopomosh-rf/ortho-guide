import './fonts';
import React from 'react';
import {registerRoot, Composition} from 'remotion';
import {PreopSceneV, PreopFilmV, preopTotalV} from './wide/PreopFilmV';
import {sceneFrames, scenesFor} from './wide/PreopFilm';
const R: React.FC = () => React.createElement(React.Fragment, null, ...(['he', 'ar', 'en'] as const).flatMap((lang) => scenesFor(lang as any).map((s) =>
  React.createElement(Composition, {key: lang + s.id, id: `SV-${lang}-${s.id}`, component: PreopSceneV as any, durationInFrames: sceneFrames(s), fps: 30, width: 1080, height: 1920, defaultProps: {id: s.id, lang}}))));
const R2: React.FC = () => React.createElement(React.Fragment, null, React.createElement(R),
  React.createElement(Composition, {id: 'PreopV-ar', component: PreopFilmV as any, durationInFrames: preopTotalV('ar'), fps: 30, width: 1080, height: 1920, defaultProps: {audio: true, lang: 'ar'}}),
  React.createElement(Composition, {id: 'PreopV-en', component: PreopFilmV as any, durationInFrames: preopTotalV('en'), fps: 30, width: 1080, height: 1920, defaultProps: {audio: true, lang: 'en'}}));
registerRoot(R2);
