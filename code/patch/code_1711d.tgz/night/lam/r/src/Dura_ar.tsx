// «Надрыв оболочки при операции на позвоночнике (дуротомия)» — ролик для пациентов (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {DuraSac, DuraTear, DuraLeak, TwoPaths, PosHeadache, WoundCheck, NoStrain, HomeToEr} from './DuraArt';
import {Clip3D} from './Clip3D';
import {Phone101} from './UrgentArt';
import {CallBell} from './WardArt';
import {Person, Icon} from './Figures';
import timing from './timing_dura_ar.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalDura_ar = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'جراحة العظام · للمرضى';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Дуротомия: сцены DU01–DU11 ----
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10)}}><Note size={28} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const N = C.navy, NL = '#E3E7EF';
const S01: React.FC<{d: number}> = ({d}) => <>
  <DuraSac top={470} d={d} />
  <Notes y={980} items={[['غشاء حول جذور الأعصاب', fr(d, 0.1), N, NL], ['في الداخل · سائل شفاف', fr(d, 0.5), C.teal, C.tealL]]} />
</>;
const S02: React.FC<{d: number}> = ({d}) => <>
  <DuraTear top={470} d={d} />
  <Notes y={880} items={[['مضاعفة معروفة', fr(d, 0.1), N, NL], ['أكثر في العمليات المتكرّرة وتضيّق القناة', fr(d, 0.35)], ['عادةً يُخاط أو يُغلق بلاصق فورًا', fr(d, 0.65), C.teal, C.tealL]]} />
</>;
const S03: React.FC<{d: number}> = ({d}) => <>
  <DuraLeak top={470} d={d} />
  <Notes y={900} items={[['السائل يتسرّب · الضغط ينخفض', fr(d, 0.1)], ['قد يظهر صداع من نوع خاص', fr(d, 0.4)], ['عادةً يلتئم دون عواقب', fr(d, 0.75), C.teal, C.tealL]]} />
</>;
const S04: React.FC<{d: number}> = ({d}) => <>
  <TwoPaths top={450} d={d} />
  <Notes y={1000} items={[['النهوض في الوقت المعتاد · مع الطاقم', fr(d, 0.2), C.teal, C.tealL], ['أو الاستلقاء بشكل مستوٍ · حسب تعليمات الجرّاح', fr(d, 0.35), N, NL], ['بعد إغلاق التمزّق · لم تظهر فائدة مقنعة للراحة الطويلة في السرير', fr(d, 0.55)], ['يقرّر الجرّاح', fr(d, 0.8), N, NL]]} />
</>;
const S05: React.FC<{d: number}> = ({d}) => <>
  <Clip3D src="c3/swell_pump.mp4" y={430} d={d} dur={9} />
  <Notes y={1195} items={[['حرّكوا القدمين · تنفّسوا بعمق', fr(d, 0.05), C.teal, C.tealL], ['الشرب · إذا سُمح', fr(d, 0.25), N, NL], ['لا تفوّتوا الوقاية من الجلطات', fr(d, 0.45), N, NL], ['النهوض فقط عند السماح ومع الطاقم', fr(d, 0.7)]]} />
</>;
const S06: React.FC<{d: number}> = ({d}) => <>
  <PosHeadache top={470} d={d} />
  <Notes y={920} items={[['عند الجلوس أو الوقوف · أشدّ', fr(d, 0.15)], ['عند الاستلقاء · أخفّ', fr(d, 0.5), C.teal, C.tealL]]} />
  <Tier y={1030} h={200} at={fr(d, 0.65)} title='أبلغوا الطاقم' color="#B45309" bg="#FFF7ED"
    items={[['head', 'صداع'], ['drop', 'غثيان'], ['head', 'ألم في الرقبة'], ['head', 'طنين في الأذنين']]} />
</>;
const S07: React.FC<{d: number}> = ({d}) => <>
  <WoundCheck top={470} d={d} />
  <Tier y={940} h={260} at={fr(d, 0.1)} title='أخبروا الطاقم فورًا' color="#B45309" bg="#FFF7ED"
    items={[['wound', 'الضمادة تتبلّل بسائل شفاف'], ['tube', 'سائل شفاف في التصريف'], ['wound', 'انتفاخ طري تحت الجرح']]} />
  <Notes y={1220} items={[['ليس دائمًا تسرّبًا · لكن يجب الفحص', fr(d, 0.8), N, NL]]} />
</>;
const S08: React.FC<{d: number}> = ({d}) => <>
  <NoStrain top={470} d={d} />
  <Notes y={800} items={[['تجنّب الشدّ عند التبرّز', fr(d, 0.1)], ['الإمساك · أخبروا الطاقم', fr(d, 0.35), C.teal, C.tealL], ['الأشياء الثقيلة · فقط بإذن الطبيب المعالج', fr(d, 0.7)]]} />
</>;
const S09: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={330} at={fr(d, 0.02)} title='أبلغوا فورًا' color={C.blood} bg={C.bloodL}
    items={[['head', 'صداع شديد جدًا'], ['therm', 'حمّى'], ['head', 'ألم وتيبّس في الرقبة'], ['faint', 'انزعاج من الضوء · تشوّش']]} />
  <Tier y={840} h={330} at={fr(d, 0.55)} title='فورًا أيضًا' color={C.blood} bg={C.bloodL}
    items={[['leg', 'ضعف أو خدر جديد في الساقين'], ['leg', 'خدر حول الأعضاء التناسلية أو فتحة الشرج أو بينهما'], ['bladder', 'صعوبة جديدة في التبوّل'], ['bladder', 'فقدان السيطرة على البول أو البراز']]} />
</>;
const S10: React.FC<{d: number}> = ({d}) => <>
  <HomeToEr top={470} d={d} />
  <Notes y={800} items={[['في البيت · فورًا إلى الطوارئ', fr(d, 0.05)], ['تشوّش، ضعف واضح، فقدان السيطرة على البول أو البراز · اتصلوا بـ 101', fr(d, 0.35)], ['لا تقودوا بأنفسكم', fr(d, 0.75), N, NL]]} />
  <Phone101 y={1000} at={fr(d, 0.45)} s={0.85} />
</>;
const S11: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>هذه توصيات عامة</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>التعليمات الفردية من طبيبكم والفريق الطبي لها الأولوية</div>
  </Card>
);
const SC: Record<string, React.FC<{d: number}>> = {DU01: S01, DU02: S02, DU03: S03, DU04: S04, DU05: S05, DU06: S06, DU07: S07, DU08: S08, DU09: S09, DU10: S10, DU11: S11};

export const Dura_ar: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
