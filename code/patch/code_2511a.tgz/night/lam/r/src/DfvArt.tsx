// Рисунки для ролика «Рана на стопе при диабете» (dfv). Только иллюстрации; надписи приходят из Dfv.tsx (одобренный текст).
import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C, ease, BODY} from './kit';

const fr = (d: number, p: number) => Math.round(d * p);
const SK = '#EBC6A8', SKS = '#C99B7A', BONE = '#F4ECDD', BONES = '#C9B99A';

const Frame: React.FC<{top: number; h: number; o: number; children: React.ReactNode}> = ({top, h, o, children}) =>
  <div style={{position: 'absolute', left: 64, top, width: 952, height: h, borderRadius: 34, overflow: 'hidden', opacity: o,
    background: 'linear-gradient(160deg,#FFFFFF 0%,#EEF4F8 100%)', boxShadow: '0 18px 44px rgba(20,40,60,.12)'}}>{children}</div>;

// Голень и стопа сбоку (полупрозрачная кожа, кости внутри)
const LegFoot: React.FC<{tint?: number; swell?: number}> = ({tint = 0, swell = 0}) => {
  const s = 1 + swell * 0.06;
  return <g transform={`translate(330 40) scale(${s}) translate(-330 -40)`}>
    <defs>
      <radialGradient id="dfSkin" cx="40%" cy="30%" r="80%"><stop offset="0" stopColor="#F6DCC6" /><stop offset="1" stopColor={SK} /></radialGradient>
      <radialGradient id="dfRed" cx="55%" cy="70%" r="60%"><stop offset="0" stopColor="#E2574C" stopOpacity={0.75} /><stop offset="1" stopColor="#E2574C" stopOpacity={0} /></radialGradient>
    </defs>
    <path d="M 250 20 L 370 20 L 372 300 Q 380 360 420 380 L 640 420 Q 700 432 700 470 Q 700 500 650 502 L 300 502 Q 240 500 236 440 L 244 300 Z"
      fill="url(#dfSkin)" stroke={SKS} strokeWidth={4} opacity={0.92} />
    {/* кости: большеберцовая, пяточная, плюсневые */}
    <g opacity={0.55}>
      <rect x={282} y={20} width={50} height={300} rx={22} fill={BONE} stroke={BONES} strokeWidth={3} />
      <ellipse cx={300} cy={440} rx={52} ry={40} fill={BONE} stroke={BONES} strokeWidth={3} />
      <ellipse cx={360} cy={370} rx={40} ry={30} fill={BONE} stroke={BONES} strokeWidth={3} />
      {[0, 1, 2].map((i) => <rect key={i} x={400 + i * 6} y={392 + i * 22} width={220} height={18} rx={9} fill={BONE} stroke={BONES} strokeWidth={3} transform={`rotate(${8 - i * 3} 400 400)`} />)}
    </g>
    <ellipse cx={520} cy={450} rx={210} ry={90} fill="url(#dfRed)" opacity={tint} />
  </g>;
};

// DF01: нервы стопы постепенно тускнеют (условно), затем ботинок с камешком
export const FootNerves: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const o = ease(f, 2, 14), dim = ease(f, fr(d, 0.25), fr(d, 0.5)), shoe = ease(f, fr(d, 0.6), fr(d, 0.7));
  const nerves = ['M 330 30 C 334 150 330 260 350 330 C 400 380 500 410 640 440', 'M 320 200 C 322 300 300 380 280 470', 'M 345 320 C 420 400 520 430 600 470', 'M 335 300 C 380 420 460 470 520 492', 'M 340 330 C 450 380 560 400 680 455'];
  return <Frame top={top} h={600} o={o}>
    <svg width={952} height={600} style={{direction: 'ltr'}}>
      <g opacity={1 - shoe * 0.85}><LegFoot />
        {nerves.map((p, i) => {
          const fade = i % 2 === 1 ? 1 - dim * 0.75 : 1 - dim * 0.15;
          return <path key={i} d={p} stroke="#F2C230" strokeWidth={6} fill="none" strokeLinecap="round" opacity={fade}
            strokeDasharray="900" strokeDashoffset={900 * (1 - ease(f, 4 + i * 4, 30 + i * 4))} style={{filter: 'drop-shadow(0 0 6px rgba(242,194,48,.6))'}} />;
        })}
      </g>
      <g opacity={shoe} transform={`translate(${476 - (1 - shoe) * 40} 330)`}>
        <path d="M -250 120 L -250 -60 Q -250 -110 -190 -110 L -80 -110 Q -40 -40 60 -20 L 210 10 Q 260 22 260 80 L 260 120 Z" fill="#5F7A94" stroke="#3F566C" strokeWidth={5} />
        <rect x={-262} y={112} width={534} height={30} rx={14} fill="#33475B" />
        <path d="M -240 -60 L -90 -100" stroke="#8FA6BC" strokeWidth={6} strokeLinecap="round" />
        {/* камешек внутри (видно через «окно» разреза) */}
        <ellipse cx={120} cy={70} rx={90} ry={34} fill="#fff" opacity={0.85} />
        <path d={`M 104 82 L 112 ${62 + Math.sin(f / 6) * 2} L 132 60 L 144 78 Z`} fill="#8D8378" stroke="#5E554C" strokeWidth={3} />
      </g>
    </svg>
  </Frame>;
};

// DF02: артерия с сужением (кровоток медленнее), затем разрез: инфекция идёт вглубь к кости
export const FlowDepth: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const o = ease(f, 2, 14), sec = ease(f, fr(d, 0.45), fr(d, 0.55)), sp = ease(f, fr(d, 0.55), fr(d, 0.9));
  const rbc = Array.from({length: 9}, (_, i) => i);
  return <Frame top={top} h={600} o={o}>
    <svg width={952} height={600} style={{direction: 'ltr'}}>
      <g opacity={1 - sec}>
        <path d="M 60 230 L 380 230 Q 440 262 500 262 Q 560 262 620 230 L 900 230 L 900 370 L 620 370 Q 560 338 500 338 Q 440 338 380 370 L 60 370 Z" fill="#F6C9C4" stroke="#C0453B" strokeWidth={5} />
        <path d="M 400 262 Q 500 300 600 262 L 600 338 Q 500 300 400 338 Z" fill="#F3E3A8" opacity={0.9} />
        {rbc.map((i) => {
          const x0 = (i * 100 + f * 3.2) % 860;
          const slow = x0 > 360 && x0 < 640 ? 0.6 : 1;
          const x = 60 + x0 * slow + (x0 > 640 ? -112 : 0);
          return <ellipse key={i} cx={x} cy={300 + (i % 3 - 1) * 26 * (x0 > 360 && x0 < 640 ? 0.3 : 1)} rx={22} ry={12} fill="#D2463C" />;
        })}
      </g>
      <g opacity={sec}>
        {[['#F6D2BA', 70], ['#FBE8B5', 120], ['#E79A8F', 150], [BONE, 180]].map(([c, h], i, a) => {
          const y = 60 + a.slice(0, i).reduce((s, x) => s + (x[1] as number), 0);
          return <rect key={i} x={40} y={y} width={872} height={h as number} fill={c as string} stroke={i === 3 ? BONES : 'none'} strokeWidth={3} />;
        })}
        <path d={`M 476 60 C ${420 - sp * 40} ${120 + sp * 120} ${440 - sp * 60} ${200 + sp * 250} 476 ${130 + sp * 380} C ${512 + sp * 60} ${200 + sp * 250} ${532 + sp * 40} ${120 + sp * 120} 476 60 Z`}
          fill="#8BAF3C" opacity={0.55} />
        {Array.from({length: 14}, (_, i) => <circle key={i} cx={476 + Math.sin(i * 2.1) * 40 * sp} cy={70 + (i / 14) * 440 * sp} r={7} fill="#5E7F1F" opacity={sp} />)}
      </g>
    </svg>
  </Frame>;
};

// Мини-пиктограммы обследования и разгрузки
const Pic: React.FC<{k: string}> = ({k}) => {
  const st = {stroke: C.navy, strokeWidth: 5, fill: 'none', strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const};
  const m: Record<string, React.ReactNode> = {
    mono: <><path d="M 30 80 L 30 20" {...st} /><path d="M 30 20 Q 50 30 52 50" stroke={C.acc} strokeWidth={4} fill="none" /><path d="M 52 50 Q 60 70 80 74 L 80 84 L 40 84" {...st} stroke={SKS} /></>,
    pulse: <><path d="M 10 55 L 30 55 L 38 35 L 48 75 L 56 45 L 62 55 L 90 55" {...st} stroke={C.blood} /></>,
    tube: <><rect x={38} y={12} width={24} height={72} rx={12} {...st} /><rect x={41} y={50} width={18} height={31} rx={8} fill={C.blood} /><rect x={34} y={8} width={32} height={10} rx={4} fill={C.teal} /></>,
    xray: <><rect x={12} y={12} width={76} height={76} rx={10} fill="#2C3E50" /><path d="M 30 70 L 40 40 L 56 34 L 74 44" stroke="#E8EEF3" strokeWidth={7} fill="none" strokeLinecap="round" /><circle cx={30} cy={72} r={7} fill="#E8EEF3" /></>,
    mri: <><circle cx={50} cy={46} r={34} {...st} strokeWidth={9} stroke="#8FA6BC" /><circle cx={50} cy={46} r={16} fill="#fff" stroke={C.navy} strokeWidth={4} /><rect x={10} y={78} width={80} height={10} rx={5} fill={C.navy} /></>,
    us: <><path d="M 36 14 L 64 14 L 70 56 Q 50 66 30 56 Z" fill="#DCE6EE" stroke={C.navy} strokeWidth={4} />{[0, 1, 2].map((i) => <path key={i} d={`M ${36 - i * 8} ${66 + i * 8} Q 50 ${74 + i * 10} ${64 + i * 8} ${66 + i * 8}`} stroke={C.teal} strokeWidth={4} fill="none" />)}</>,
    boot: <><path d="M 28 10 L 62 10 L 62 60 L 86 66 Q 92 70 90 82 L 20 82 Q 14 70 22 62 Z" fill="#DCE6EE" stroke={C.navy} strokeWidth={4} />{[24, 38, 52].map((y) => <rect key={y} x={22} y={y} width={44} height={6} rx={3} fill={C.teal} />)}</>,
    cast: <><path d="M 30 8 L 60 8 L 60 58 L 84 66 L 84 82 L 26 82 Z" fill="#F7F7F2" stroke="#B7B39F" strokeWidth={4} />{[20, 34, 48].map((y) => <path key={y} d={`M 30 ${y} L 60 ${y + 6}`} stroke="#D4CFBA" strokeWidth={3} />)}</>,
    shoe: <><path d="M 12 70 L 14 44 Q 30 40 44 50 L 78 58 Q 90 62 88 76 L 12 76 Z" fill="#5F7A94" stroke="#3F566C" strokeWidth={4} /><rect x={10} y={76} width={80} height={8} rx={4} fill="#33475B" /></>,
    walker: <><path d="M 24 20 L 76 20 M 26 20 L 18 86 M 74 20 L 82 86 M 22 52 L 78 52" {...st} strokeWidth={6} /><circle cx={18} cy={86} r={5} fill={C.navy} /><circle cx={82} cy={86} r={5} fill={C.navy} /></>,
    chair: <><circle cx={40} cy={64} r={22} {...st} /><path d="M 30 14 L 34 46 L 66 46 L 74 76 M 34 46 L 70 46" {...st} /><circle cx={74} cy={80} r={5} fill={C.navy} /></>,
    gluco: <><rect x={22} y={12} width={50} height={74} rx={10} fill="#DCE6EE" stroke={C.navy} strokeWidth={4} /><rect x={30} y={22} width={34} height={24} rx={4} fill="#fff" stroke={C.navy} strokeWidth={3} /><path d="M 46 86 L 46 96" stroke={C.navy} strokeWidth={5} /><circle cx={80} cy={30} r={7} fill={C.blood} /></>,
    vessel: <><path d="M 8 40 L 92 40 M 8 62 L 92 62" stroke="#C0453B" strokeWidth={6} /><path d="M 36 40 Q 50 52 64 40 M 36 62 Q 50 50 64 62" stroke="#C0453B" strokeWidth={6} fill="#F3E3A8" /></>,
    tissue: <><path d="M 14 60 Q 50 30 86 60 Q 50 84 14 60 Z" fill="#F0C3B5" stroke={SKS} strokeWidth={4} /><path d="M 40 58 Q 50 48 60 58" stroke="#6B5A3A" strokeWidth={6} fill="none" /></>,
  };
  return <svg width={110} height={110} viewBox="0 0 100 100" style={{direction: 'ltr', flex: 'none'}}>{m[k]}</svg>;
};

// Сетка карточек «картинка + подпись»
export const PicGrid: React.FC<{top: number; d: number; keys: string[]; labels: string[]; cols?: number; start?: number; step?: number}> = ({top, d, keys, labels, cols = 2, start = 0.08, step = 0.1}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top, display: 'grid', gridTemplateColumns: `repeat(${cols}, 1fr)`, gap: 18}}>
    {keys.map((k, i) => {
      const a = fr(d, start + i * step), p = ease(f, a, a + 10);
      return <div key={i} style={{opacity: p, transform: `translateY(${(1 - p) * 20}px) scale(${0.95 + p * 0.05})`, background: '#fff', borderRadius: 26,
        boxShadow: '0 12px 30px rgba(20,40,60,.10)', padding: '16px 18px', display: 'flex', alignItems: 'center', gap: 14, minHeight: 130}}>
        <div style={{width: 110, height: 110, borderRadius: 20, background: C.tealL, display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none'}}><Pic k={k} /></div>
        <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 30, color: C.ink, lineHeight: 1.2}}>{labels[i]}</div>
      </div>;
    })}
  </div>;
};

// DF04: две карточки — есть инфекция / нет инфекции
export const TwoWounds: React.FC<{top: number; d: number; L: string; Litems: [string, string]; R: string; Ritem: string}> = ({top, d, L, Litems, R, Ritem}) => {
  const f = useCurrentFrame();
  const a1 = ease(f, fr(d, 0.15), fr(d, 0.25)), a2 = ease(f, fr(d, 0.5), fr(d, 0.6));
  const card = (p: number, inf: boolean, title: string, rows: string[]) =>
    <div style={{flex: 1, opacity: p, transform: `translateY(${(1 - p) * 24}px)`, background: '#fff', borderRadius: 28, boxShadow: '0 12px 30px rgba(20,40,60,.10)', padding: '24px 22px', borderTop: `10px solid ${inf ? C.blood : C.teal}`}}>
      <svg width={200} height={130} viewBox="0 0 200 130" style={{direction: 'ltr', display: 'block', margin: '0 auto 10px'}}>
        <ellipse cx={100} cy={70} rx={90} ry={52} fill="#F1CDB5" />
        <ellipse cx={100} cy={70} rx={40} ry={20} fill={inf ? '#C8574C' : '#E59A8B'} />
        {inf && <ellipse cx={100} cy={70} rx={70} ry={40} fill="none" stroke="#E2574C" strokeWidth={8} opacity={0.4 + 0.3 * Math.sin(f / 7)} />}
        {!inf && <path d="M 64 70 Q 100 54 136 70" stroke="#F7E7DD" strokeWidth={6} fill="none" />}
      </svg>
      <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 31, color: inf ? C.blood : C.teal, lineHeight: 1.2, marginBottom: 12}}>{title}</div>
      {rows.map((r, i) => <div key={i} style={{fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.ink, lineHeight: 1.25, marginBottom: 10}}>• {r}</div>)}
    </div>;
  return <div style={{position: 'absolute', left: 64, right: 64, top, display: 'flex', gap: 20}}>
    {card(a1, true, L, Litems)}{card(a2, false, R, [Ritem])}
  </div>;
};

// DF08: нога лежит, опора под голенью, пятка свободна; рядом знак «не курить»
export const HeelFree: React.FC<{top: number; d: number; at: number}> = ({top, d, at}) => {
  const f = useCurrentFrame();
  const o = ease(f, at, at + 12), gap = 14 + Math.sin(f / 10) * 3;
  return <Frame top={top} h={330} o={o}>
    <svg width={952} height={330} style={{direction: 'ltr'}}>
      <rect x={30} y={250} width={892} height={50} rx={18} fill="#E3E7EF" />
      <path d="M 120 200 Q 320 150 520 158 L 600 214 Q 640 224 630 250 L 120 250 Z" fill="#9FC3D9" />
      <path d="M 80 120 L 600 140 Q 660 142 690 160 L 760 170 Q 800 190 780 206 L 690 206 Q 650 204 620 190 L 80 186 Z" fill={SK} stroke={SKS} strokeWidth={4} transform={`translate(0 ${-gap + 14})`} />
      <path d={`M 690 ${226 - gap + 14} L 690 248`} stroke={C.teal} strokeWidth={4} strokeDasharray="8 8" />
      <circle cx={700} cy={200 - gap + 14} r={30} fill="none" stroke={C.teal} strokeWidth={5} opacity={0.6 + 0.4 * Math.sin(f / 8)} />
    </svg>
  </Frame>;
};
export const NoSmoke: React.FC<{x: number; y: number; at: number}> = ({x, y, at}) => {
  const f = useCurrentFrame(); const o = ease(f, at, at + 10);
  return <svg width={150} height={150} viewBox="0 0 100 100" style={{position: 'absolute', left: x, top: y, opacity: o, direction: 'ltr'}}>
    <circle cx={50} cy={50} r={44} fill="#fff" stroke={C.blood} strokeWidth={8} />
    <rect x={18} y={46} width={52} height={12} rx={3} fill="#E8E2D6" /><rect x={70} y={46} width={12} height={12} fill="#E7A04B" />
    <line x1={20} y1={20} x2={80} y2={80} stroke={C.blood} strokeWidth={8} />
  </svg>;
};

// DF10: красная горячая опухшая стопа, кости и суставы — контекст
export const HotFoot: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const o = ease(f, 2, 14), r = ease(f, fr(d, 0.08), fr(d, 0.3)), heat = 0.5 + 0.5 * Math.sin(f / 9);
  return <Frame top={top} h={560} o={o}>
    <svg width={952} height={560} style={{direction: 'ltr'}}>
      <LegFoot tint={r * (0.6 + 0.3 * heat)} swell={r} />
      {[0, 1, 2].map((i) => <path key={i} d={`M ${560 + i * 50} ${300 - ((f * 1.5 + i * 30) % 90)} q 10 -14 0 -28 q -10 -14 0 -28`} stroke="#E2574C" strokeWidth={5} fill="none" strokeLinecap="round" opacity={r * 0.7} />)}
    </svg>
  </Frame>;
};
