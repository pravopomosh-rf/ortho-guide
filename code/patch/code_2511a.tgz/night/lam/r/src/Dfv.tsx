// «Рана на стопе при диабете» — ролик для пациентов (9:16), сверху ops/diabetic-foot.html. Тексты DF01–DF12, cap_* и vis_* ОДОБРЕНО ChatGPT (tts-data dfv.json); надписи — фрагменты одобренного текста.
import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Subtitle, Note, C, BODY, HEAD, ease, Word} from './kit';
import {Icon} from './Figures';
import {Phone101} from './UrgentArt';
import {BedReal} from './WardArt';
import {FootNerves, FlowDepth, PicGrid, TwoWounds, HeelFree, NoSmoke, HotFoot} from './DfvArt';
import tRu from './timing_dfv.json';
import tHe from './timing_dfv_he.json';
import tAr from './timing_dfv_ar.json';
import tEn from './timing_dfv_en.json';

type TT = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const FPS = 30, PAD = 0.5;
const fr = (d: number, p: number) => Math.round(d * p);
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};

type W4 = {L: string; Li: [string, string]; R: string; Ri: string; sev: string};
type Dict = {brand: string; rtl?: boolean; n: Record<string, string[]>; w: W4; end: [string, string]};
const N: Record<string, Dict> = {
  ru: {
    brand: 'ОРТОПЕДИЯ · ПАЦИЕНТАМ',
    n: {
      DF01: ['высокий сахар может повреждать нервы', 'стопа хуже чувствует боль, жар и давление', 'мозоль · ожог · камешек в ботинке'],
      DF02: ['кровоснабжение ног может нарушаться', 'раны заживают медленнее', 'инфекция — глубоко, иногда до кости'],
      DF03: ['чувствительность', 'кровоснабжение', 'анализы — по показаниям', 'рентген', 'МРТ — если диагноз неясен', 'ультразвук сосудов'],
      DF05: ['омертвевшие ткани удаляет обученный специалист', 'сосудистый специалист оценивает кровоток', 'контроль сахара в крови'],
      DF06: ['ортез', 'гипсовая повязка', 'обувь', 'средства передвижения', 'иногда наступать нельзя совсем', 'иногда — только в назначенном приспособлении'],
      DF07: ['ни шагу босиком', 'повязку не снимать, не менять, не мочить', 'намокла, загрязнилась, сместилась → медсестре'],
      DF08: ['калории и белок', 'обе пятки защищены от давления', 'курение ухудшает кровоснабжение'],
      DF09: ['температура · озноб · резкая слабость', 'необычная сонливость или спутанность', 'покраснение или отёк быстро распространяются', 'гной · выделения · запах · потемнение кожи', 'почернение пальцев · внезапно холодная стопа → экстренно'],
      DF10: ['покраснела · горячая · опухла', 'может быть стопа Шарко', 'срочный осмотр специалиста', 'до осмотра не нагружать стопу'],
      DF11: ['каждый день осматривайте обе стопы', 'вода тёплая, не горячая — проверьте локтем', 'не замачивайте · вытирайте между пальцами', 'не ходите босиком · проверяйте обувь рукой', 'рана + температура, кожа чернеет, стопа холодная → приёмное отделение'],
      DF12: [],
    },
    w: {L: 'есть признаки инфекции', Li: ['образец ткани из очищенной раны', 'антибиотики'], R: 'рана не инфицирована', Ri: 'антибиотики не ускоряют заживление', sev: 'тяжёлая инфекция → лечение сразу'},
    end: ['Указания врача важнее', 'Лечащий врач · персонал отделения'],
  },
  en: {
    brand: 'ORTHOPAEDICS · FOR PATIENTS',
    n: {
      DF01: ['high blood sugar can damage nerves', 'less sensitive to pain, heat and pressure', 'a callus · a burn · a stone in the shoe'],
      DF02: ['reduced blood flow to the legs', 'wounds may heal more slowly', 'infection can spread deep, sometimes to bone'],
      DF03: ['sensation', 'blood flow', 'tests when needed', 'X-ray first', 'MRI if still uncertain', 'vascular ultrasound'],
      DF05: ['a trained specialist removes dead tissue', 'a vascular specialist assesses blood flow', 'blood glucose is monitored'],
      DF06: ['special brace', 'cast', 'adapted footwear', 'mobility aids', 'sometimes no weight at all', 'sometimes only with a prescribed device'],
      DF07: ['not even a few barefoot steps', 'do not remove, change or wet the dressing', 'wet, dirty or displaced → tell the nurse'],
      DF08: ['enough calories and protein', 'both heels protected from pressure', 'smoking reduces blood flow'],
      DF09: ['fever · chills · sudden weakness', 'unusual drowsiness or confusion', 'rapidly spreading redness or swelling', 'pus · discharge · bad smell · darkening skin', 'blackening toes · a suddenly very cold foot → emergency'],
      DF10: ['red · hot · swollen', 'may be Charcot foot', 'urgent specialist assessment', 'no weight on that foot until examined'],
      DF11: ['check both feet every day', 'warm, not hot, water: test it with your elbow', 'do not soak · dry between the toes', 'never barefoot · check shoes by hand', 'wound + fever, black skin, cold foot → emergency department'],
      DF12: [],
    },
    w: {L: 'signs of infection', Li: ['tissue sample after cleaning', 'antibiotics'], R: 'uninfected wound', Ri: 'antibiotics do not speed up healing', sev: 'severe infection → treated immediately'},
    end: ["Your care team's instructions take priority", 'Treating doctor · ward staff'],
  },
  he: {
    brand: 'אורתופדיה · למטופלים', rtl: true,
    n: {
      DF01: ['רמת סוכר גבוהה עלולה לפגוע בעצבים', 'כף הרגל מרגישה פחות כאב, חום ולחץ', 'יבלת · כווייה · אבן קטנה בנעל'],
      DF02: ['זרימת הדם לרגליים עלולה להיפגע', 'פצעים מחלימים לאט יותר', 'זיהום לעומק, לפעמים עד העצם'],
      DF03: ['התחושה', 'זרימת הדם', 'בדיקות לפי הצורך', 'צילום רנטגן', 'תהודה מגנטית אם האבחנה אינה ברורה', 'אולטרסאונד של כלי הדם'],
      DF05: ['איש צוות שהוכשר לכך מסיר רקמות מתות', 'מומחה לכלי דם מעריך את זרימת הדם', 'מעקב אחר רמת הסוכר בדם'],
      DF06: ['מקבע מיוחד', 'גבס', 'נעל מותאמת', 'עזרי ניידות', 'לפעמים אסור לדרוך בכלל', 'לפעמים רק עם אמצעי מיוחד שנקבע'],
      DF07: ['אף לא כמה צעדים יחפים', 'לא להסיר, לא להחליף, לא להרטיב את החבישה', 'נרטבה, התלכלכה או זזה ← הודיעו לאחות'],
      DF08: ['מספיק קלוריות וחלבון', 'שני העקבים מוגנים מפני לחץ', 'עישון פוגע בזרימת הדם'],
      DF09: ['חום · צמרמורות · חולשה פתאומית', 'ישנוניות חריגה או בלבול', 'אדמומיות או נפיחות מתפשטות מהר', 'מוגלה · הפרשה · ריח רע · התכהות העור', 'השחרה של הבהונות · כף רגל קרה פתאום ← הערכה דחופה ביותר'],
      DF10: ['אדומה · חמה · נפוחה', 'ייתכן שמדובר בכף רגל שארקו', 'בדיקה דחופה אצל מומחה', 'עד לבדיקה אל תדרכו על כף הרגל'],
      DF11: ['בדקו מדי יום את שתי כפות הרגליים', 'מים פושרים ולא חמים, בדיקה בעזרת המרפק', 'לא להשרות · לייבש היטב בין הבהונות', 'לא ללכת יחפים · לבדוק ביד את פנים הנעליים', 'פצע וחום, עור משחיר, כף רגל קרה ← מיד לחדר המיון'],
      DF12: [],
    },
    w: {L: 'יש סימני זיהום', Li: ['דגימת רקמה מהפצע לאחר ניקויו', 'אנטיביוטיקה'], R: 'הפצע אינו מזוהם', Ri: 'אנטיביוטיקה אינה מזרזת את ההחלמה', sev: 'זיהום קשה ← מתחילים טיפול מיד'},
    end: ['הנחיות הרופא המטפל קודמות', 'הרופא המטפל · הצוות במחלקה'],
  },
  ar: {
    brand: 'جراحة العظام · للمرضى', rtl: true,
    n: {
      DF01: ['ارتفاع السكر قد يؤدي إلى تلف الأعصاب', 'تشعر القدم بالألم والحرارة والضغط بدرجة أقل', 'مسمار جلدي · حرق · حصاة داخل الحذاء'],
      DF02: ['قد تضعف الدورة الدموية في الساقين', 'تلتئم الجروح ببطء أكبر', 'عدوى في الأنسجة العميقة، وأحيانًا حتى العظم'],
      DF03: ['الإحساس', 'تدفق الدم', 'الفحوص عند الحاجة', 'صورة أشعة سينية', 'الرنين المغناطيسي إذا بقي التشخيص غير واضح', 'الموجات فوق الصوتية للأوعية'],
      DF05: ['مختص مدرّب يزيل الأنسجة الميتة', 'اختصاصي الأوعية يقيّم تدفق الدم', 'متابعة مستوى السكر في الدم'],
      DF06: ['جبيرة خاصة', 'جبس', 'حذاء مناسب', 'وسائل للمساعدة على التنقل', 'أحيانًا يُمنع تحميل أي وزن', 'أحيانًا فقط مع وسيلة خاصة يحددها الفريق الطبي'],
      DF07: ['ولا بضع خطوات حفاة', 'لا تنزعوا الضماد ولا تغيّروه ولا تبلّلوه', 'تبلّل أو اتّسخ أو تحرّك ← أبلغوا الممرضة'],
      DF08: ['ما يكفي من السعرات الحرارية والبروتين', 'حماية الكعبين من الضغط', 'التدخين يضعف الدورة الدموية'],
      DF09: ['حرارة · قشعريرة · ضعف مفاجئ', 'نعاس غير معتاد أو تشوش', 'انتشار سريع للاحمرار أو التورم', 'قيح · إفراز · رائحة كريهة · اسوداد الجلد', 'اسوداد أصابع القدم · برودة مفاجئة شديدة للقدم ← تقييم طبي طارئ'],
      DF10: ['حمراء · ساخنة · متورمة', 'قد تكون حالة قدم شاركو', 'فحص عاجل لدى مختص', 'حتى الفحص لا تحملوا وزنكم عليها'],
      DF11: ['افحصوا القدمين كل يوم', 'ماء دافئ غير ساخن، افحصوا حرارته بالمرفق', 'لا تنقعوا القدمين · جففوا جيدًا بين الأصابع', 'لا تمشوا حفاة · افحصوا داخل الحذاء بأيديكم', 'جرح وحرارة، جلد أسود، قدم باردة ← الطوارئ فورًا'],
      DF12: [],
    },
    w: {L: 'توجد علامات عدوى', Li: ['عينة نسيج من الجرح بعد تنظيفه', 'المضادات الحيوية'], R: 'جرح غير مصاب بعدوى', Ri: 'المضادات الحيوية لا تسرّع التئامه', sev: 'العدوى الشديدة ← العلاج فورًا'},
    end: ['تعليمات الطبيب المعالج لها الأولوية', 'الطبيب المعالج · طاقم القسم'],
  },
};

const NV = '#E3E7EF';
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]; size?: number}> = ({y, items, size = 30}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10), transform: `translateY(${(1 - ease(f, a, a + 10)) * 14}px)`}}><Note size={size} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const CheckRow: React.FC<{y: number; at: number; icon: string; text: string; warn?: boolean}> = ({y, at, icon, text, warn}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at} style={warn ? {borderInlineStart: `10px solid ${C.blood}`} : undefined}>
    <div style={{display: 'flex', alignItems: 'center', gap: 24}}>
      <Icon k={icon} s={58} c={warn ? C.blood : C.acc} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 31, color: C.ink, lineHeight: 1.25}}>{text}</div>
      {!warn && <div style={{opacity: ease(f, at + 14, at + 22)}}><Icon k="check" s={52} /></div>}
    </div>
  </Card>;
};
const RISK_IC = ['leg', 'drop', 'leg', 'drop', 'heart', 'clock', 'wound', 'clock'];
const RiskGrid: React.FC<{d: number; items: string[]}> = ({d, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: 450, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18}}>
    {items.map((t, i) => {
      const a = fr(d, 0.05 + i * 0.09), p = ease(f, a, a + 10);
      const last = i === items.length - 1;
      return <div key={i} style={{gridColumn: last ? '1 / 3' : undefined, opacity: p, transform: `translateY(${(1 - p) * 20}px) scale(${0.96 + p * 0.04})`, background: last ? C.accL : '#fff', borderRadius: 26,
        boxShadow: '0 12px 30px rgba(20,40,60,.10)', padding: '22px 22px', display: 'flex', alignItems: 'center', gap: 16, minHeight: 112}}>
        <div style={{width: 64, height: 64, borderRadius: 18, background: last ? '#fff' : C.tealL, display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none'}}><Icon k={last ? 'clock' : RISK_IC[i] || 'leg'} s={48} c={last ? C.acc : C.teal} /></div>
        <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 30, color: C.ink, lineHeight: 1.2}}>{t}</div>
      </div>;
    })}
  </div>;
};
const WarnBox: React.FC<{d: number; items: string[]}> = ({d, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: 450, borderRadius: 30, border: `6px solid ${C.blood}`, background: '#fff', padding: '26px 28px', opacity: ease(f, 2, 12)}}>
    {items.slice(0, 4).map((t, i) => {
      const a = fr(d, 0.04 + i * 0.12), p = ease(f, a, a + 10);
      return <div key={i} style={{display: 'flex', gap: 16, alignItems: 'flex-start', marginBottom: 18, opacity: p, transform: `translateX(${(1 - p) * 20}px)`}}>
        <div style={{flex: 'none', width: 22, height: 22, borderRadius: 11, background: i === 3 ? C.blood : C.acc, marginTop: 10}} />
        <div style={{fontFamily: BODY, fontWeight: i === 3 ? 800 : 700, fontSize: 31, color: i === 3 ? C.blood : C.ink, lineHeight: 1.25}}>{t}</div>
      </div>;
    })}
  </div>;
};

const SmokeNote: React.FC<{at: number; text: string}> = ({at, text}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', insetInlineStart: 240, insetInlineEnd: 64, top: 1080, opacity: ease(f, at, at + 10)}}><Note size={30} color={C.blood} bg={C.bloodL}>{text}</Note></div>;
};

const scene = (id: string, d: number, L: Dict) => {
  const n = L.n[id];
  const t = (p: number) => fr(d, p);
  switch (id) {
    case 'DF01': return <>
      <FootNerves top={440} d={d} />
      <Notes y={1080} items={[[n[0], t(0.2), C.navy, NV], [n[1], t(0.42)], [n[2], t(0.68), C.blood, C.bloodL]]} />
    </>;
    case 'DF02': return <>
      <FlowDepth top={440} d={d} />
      <Notes y={1080} items={[[n[0], t(0.06), C.blood, C.bloodL], [n[1], t(0.28), C.navy, NV], [n[2], t(0.56)]]} />
    </>;
    case 'DF03': return <PicGrid top={450} d={d} keys={['mono', 'pulse', 'tube', 'xray', 'mri', 'us']} labels={n} start={0.04} step={0.13} />;
    case 'DF04': return <>
      <TwoWounds top={450} d={d} L={L.w.L} Litems={L.w.Li} R={L.w.R} Ritem={L.w.Ri} />
      <Card x={64} y={1150} w={952} at={t(0.78)} style={{borderInlineStart: `10px solid ${C.blood}`}}>
        <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 31, color: C.ink, lineHeight: 1.3}}>{L.w.sev}</div>
      </Card>
    </>;
    case 'DF05': return <PicGrid top={460} d={d} cols={1} keys={['tissue', 'vessel', 'gluco']} labels={n} start={0.05} step={0.27} />;
    case 'DF06': return <>
      <PicGrid top={450} d={d} keys={['boot', 'cast', 'shoe', 'walker']} labels={n.slice(0, 4)} start={0.18} step={0.07} />
      <Notes y={790} items={[[n[4], t(0.5), C.blood, C.bloodL], [n[5], t(0.68), C.teal, C.tealL]]} />
    </>;
    case 'DF07': return <>
      <BedReal top={440} d={d} bell patient />
      <Notes y={1000} items={[[n[0], t(0.04), C.blood, C.bloodL], [n[1], t(0.3), C.navy, NV], [n[2], t(0.68), C.teal, C.tealL]]} />
    </>;
    case 'DF08': return <>
      <Notes y={460} items={[[n[0], t(0.04), C.teal, C.tealL]]} />
      <HeelFree top={580} d={d} at={t(0.3)} />
      <Notes y={940} items={[[n[1], t(0.34), C.navy, NV]]} />
      <NoSmoke x={64} y={1050} at={t(0.8)} />
      <SmokeNote at={t(0.82)} text={n[2]} />
    </>;
    case 'DF09': return <>
      <WarnBox d={Math.round(d * 0.75)} items={n} />
      <Card x={64} y={1070} w={952} at={t(0.6)} style={{borderInlineStart: `10px solid ${C.blood}`}}><div style={{fontFamily: BODY, fontWeight: 800, fontSize: 30, color: C.blood, lineHeight: 1.3}}>{n[4]}</div></Card>
      <Phone101 y={1240} at={t(0.86)} s={0.62} />
    </>;
    case 'DF10': return <>
      <HotFoot top={440} d={d} />
      <Notes y={1040} items={[[n[0], t(0.08), C.blood, C.bloodL], [n[1], t(0.3), C.navy, NV], [n[2], t(0.62)], [n[3], t(0.8), C.teal, C.tealL]]} />
    </>;
    case 'DF11': return <>
      {n.map((x, i) => <CheckRow key={i} y={450 + i * 186} at={t(0.02 + i * 0.12)} icon={['leg', 'drop', 'drop', 'leg', 'clock'][i]} text={x} warn={i === 4} />)}
    </>;
    case 'DF12': return <>
      <Card x={64} y={640} w={952} at={t(0.1)} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center', padding: '60px 40px'}}>
        <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 50, color: C.ink, marginBottom: 20, lineHeight: 1.2}}>{L.end[0]}</div>
        <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 34, color: C.mute}}>{L.end[1]}</div>
      </Card>
    </>;
  }
  return null;
};

export const mkDfv = (lang: string, timing: unknown) => {
  const TT = timing as TT;
  const L = N[lang];
  const total = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
  const Comp: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
    let at = 0;
    return <AbsoluteFill style={{direction: L.rtl ? 'rtl' : 'ltr'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={L.brand} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            {scene(x.id, d, L)}
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>;
  };
  return {Comp, total};
};
const ru = mkDfv('ru', tRu); export const Dfv = ru.Comp; export const totalDfv = ru.total;
const he = mkDfv('he', tHe); export const DfvHe = he.Comp; export const totalDfvHe = he.total;
const ar = mkDfv('ar', tAr); export const DfvAr = ar.Comp; export const totalDfvAr = ar.total;
const en = mkDfv('en', tEn); export const DfvEn = en.Comp; export const totalDfvEn = en.total;

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
