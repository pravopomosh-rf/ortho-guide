set -e
F="[0:v]trim=0:7.6,setpts=PTS-STARTPTS,fps=30,format=yuv420p[v0];[1:v]trim=2.5:8,setpts=PTS-STARTPTS,fps=30,format=yuv420p[v1];[2:v]trim=0:8,setpts=PTS-STARTPTS,fps=30,format=yuv420p[v2];[3:v]trim=0:8,setpts=PTS-STARTPTS,fps=30,format=yuv420p[v3];
[v0][v1]xfade=transition=fadewhite:duration=0.5:offset=7.1[x1];[x1][v2]xfade=transition=fadewhite:duration=0.5:offset=12.1[x2];[x2][v3]xfade=transition=fadewhite:duration=0.5:offset=19.6,fade=t=out:st=27.1:d=0.5:color=white[vv];
[0:a]atrim=0:7.6,asetpts=PTS-STARTPTS[a0];[1:a]atrim=2.5:8,asetpts=PTS-STARTPTS[a1];[2:a]atrim=0:8,asetpts=PTS-STARTPTS[a2];[3:a]atrim=0:8,asetpts=PTS-STARTPTS[a3];
[a0][a1]acrossfade=d=0.5[b1];[b1][a2]acrossfade=d=0.5[b2];[b2][a3]acrossfade=d=0.5,volume=0.8,afade=t=out:st=26.6:d=1[aa]"
ffmpeg -v error -y -i c1.mp4 -i c2.mp4 -i c3.mp4 -i c4.mp4 -filter_complex "$F" -map "[vv]" -map "[aa]" -c:v libx264 -preset medium -crf 18 -c:a aac -b:a 128k base.mp4
ffprobe -v error -show_entries format=duration -of csv=p=0 base.mp4
for L in ru he ar en; do
ffmpeg -v error -y -i base.mp4 -loop 1 -i title_$L.png -loop 1 -i disc_$L.png -filter_complex "[1:v]format=rgba,fade=t=in:st=20.4:d=0.9:alpha=1[t];[2:v]format=rgba,fade=t=in:st=23.5:d=0.7:alpha=1[d];[0:v][t]overlay=0:0:enable='gte(t,20.4)':shortest=1[o1];[o1][d]overlay=0:0:enable='gte(t,23.5)':shortest=1,format=yuv420p[v]" -map "[v]" -map 0:a -c:v libx264 -preset medium -crf 23 -movflags +faststart -c:a copy -t 27.6 hero_$L.mp4
done
cp base.mp4 hero_clean_src.mp4; ffmpeg -v error -y -i base.mp4 -an -c:v libx264 -crf 25 -movflags +faststart hero_clean.mp4
ls -la hero_*.mp4
