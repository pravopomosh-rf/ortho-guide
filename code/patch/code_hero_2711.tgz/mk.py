import json
T={'ru':('Современная ортопедия','путь от боли к движению','Восстановление индивидуально. Следуйте указаниям лечащего врача.'),
'he':('אורתופדיה מודרנית','הדרך מכאב לתנועה','ההחלמה אישית. פעלו לפי הנחיות הרופא המטפל.'),
'ar':('جراحة العظام الحديثة','الطريق من الألم إلى الحركة','يختلف التعافي من شخص لآخر. اتّبعوا تعليمات الطبيب المعالج.'),
'en':('Modern orthopedics','the path from pain to movement','Recovery varies from person to person. Follow your treating doctor’s instructions.')}
for l,(a,b,c) in T.items():
  rtl=l in('he','ar'); fam={'he':"'NH'",'ar':"'NA'"}.get(l,'Inter')
  html=f"""<html dir="{'rtl' if rtl else 'ltr'}"><head><meta charset=utf-8><style>
@font-face{{font-family:NH;font-weight:700;src:url(noto-sans-hebrew-hebrew-700-normal.woff2)}}@font-face{{font-family:NH;font-weight:800;src:url(noto-sans-hebrew-hebrew-800-normal.woff2)}}
@font-face{{font-family:NA;font-weight:700;src:url(noto-sans-arabic-arabic-700-normal.woff2)}}@font-face{{font-family:NA;font-weight:800;src:url(noto-sans-arabic-arabic-800-normal.woff2)}}
html,body{{margin:0;width:720px;height:1280px;background:transparent;font-family:{fam},Inter,sans-serif}}
.sc{{position:absolute;left:0;right:0;top:0;height:520px;background:linear-gradient(180deg,rgba(6,45,40,.55),rgba(6,45,40,0))}} .sb{{position:absolute;left:0;right:0;bottom:0;height:300px;background:linear-gradient(0deg,rgba(6,45,40,.6),rgba(6,45,40,0))}} .t{{position:absolute;left:48px;right:48px;top:150px;text-align:center;color:#fff;text-shadow:0 2px 18px rgba(0,40,35,.55),0 1px 3px rgba(0,0,0,.4)}}
.a{{font-weight:800;font-size:60px;line-height:1.1}} .b{{font-weight:700;font-size:38px;margin-top:14px;color:#e9fffb}}
.d{{position:absolute;left:40px;right:40px;bottom:70px;text-align:center;color:#fff;font-weight:700;font-size:24px;line-height:1.35;text-shadow:0 1px 8px rgba(0,0,0,.6)}}
</style></head><body><div class="sc"></div><div class="t"><div class="a">{a}</div><div class="b">{b}</div></div></body></html>"""
  open(f'title_{l}.html','w').write(html)
  open(f'disc_{l}.html','w').write(html.replace(f'<div class="t"><div class="a">{a}</div><div class="b">{b}</div></div>',f'<div class="sb"></div><div class="d">{c}</div>'))
