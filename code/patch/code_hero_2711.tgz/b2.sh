for L in ru he ar en; do
ffmpeg -v error -y -i base.mp4 -loop 1 -i title_$L.png -loop 1 -i disc_$L.png -filter_complex "[1:v]format=rgba,fade=t=in:st=20.4:d=0.9:alpha=1[t];[2:v]format=rgba,fade=t=in:st=23.5:d=0.7:alpha=1[d];[0:v][t]overlay=0:0:enable='gte(t,20.4)':shortest=1[o1];[o1][d]overlay=0:0:enable='gte(t,23.5)':shortest=1,format=yuv420p[v]" -map "[v]" -map 0:a -c:v libx264 -preset medium -crf 23 -movflags +faststart -c:a copy -t 27.6 hero_$L.mp4
done
cp base.mp4 hero_clean_src.mp4; ffmpeg -v error -y -i base.mp4 -an -c:v libx264 -crf 25 -movflags +faststart hero_clean.mp4
ls -la hero_*.mp4
