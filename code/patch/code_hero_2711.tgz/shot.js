const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:720,height:1280}});
for(const l of ['ru','he','ar','en'])for(const k of ['title','disc']){await p.goto('file://'+__dirname+`/${k}_${l}.html`);await p.waitForTimeout(400);await p.screenshot({path:`${k}_${l}.png`,omitBackground:true});}
await b.close()})();
