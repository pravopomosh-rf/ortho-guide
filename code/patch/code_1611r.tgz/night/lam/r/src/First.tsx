// «Первые часы после операции: как помочь близкому» — ролик для пациентов и родственников (9:16).
// Тексты F01–F09 ОДОБРЕНО ChatGPT (tts-data first.json). Надписи — дословные фрагменты одобренного текста.
import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Subtitle, Note, C, BODY, HEAD, ease, Word} from './kit';
import {Icon} from './Figures';
import {BedReal, CallBell} from './WardArt';
import tRu from './timing_first.json';
import tHe from './timing_first_he.json';
import tAr from './timing_first_ar.json';
import tEn from './timing_first_en.json';

type TT = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const FPS = 30, PAD = 0.5;
const fr = (d: number, p: number) => Math.round(d * p);
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};

type Dict = {brand: string; rtl?: boolean; n: Record<string, string[]>; sch: string[]; end: [string, string]};
const N: Record<string, Dict> = {
  ru: {
    brand: 'ОРТОПЕДИЯ · ПАЦИЕНТАМ',
    sch: ['сразу', '+1 ч', '+1 ч', '+2 ч', 'каждые 4 ч'],
    n: {
      F01: ['все хотят помочь', 'и это очень понятно'],
      F02: ['первые часы и первые сутки', 'чаще всего всё идёт спокойно', 'проход к пациенту — всегда свободен'],
      F03: ['давление · пульс · дыхание · кислород · температура · сознание', 'плановое наблюдение', 'эноксапарин: время определяет врач'],
      F04: ['свободный проход со всех сторон', 'стулья и сумки — не вплотную', 'медсестра · врач · тележка'],
      F05: ['не больше одного-двух близких', 'персонал подходит → освободите место', 'попросили выйти → выполните просьбу'],
      F06: ['тошнота и рвота после наркоза', 'еда и питьё — только с разрешения медсестры', 'когда и что можно, решает медицинская команда'],
      F07: ['борта — по решению персонала', 'кнопка вызова — под рукой', 'первый раз — с помощью персонала'],
      F08: ['трудно дышать · необычно сонлив · спутанность', 'боль резко усилилась · повязка пропитывается кровью', 'кнопка вызова · громко зовите персонал'],
    },
    end: ['Указания вашей команды важнее сайта', 'Медсестра · врач · медицинская команда'],
  },
  en: {
    brand: 'ORTHOPAEDICS · FOR PATIENTS',
    sch: ['on arrival', '+1 h', '+1 h', '+2 h', 'every 4 h'],
    n: {
      F01: ['everyone wants to help', 'and that is very understandable'],
      F02: ['the first hours and the first day', 'most of the time everything goes calmly', 'the way to the patient must always stay clear'],
      F03: ['blood pressure · pulse · breathing · oxygen · temperature · consciousness', 'planned monitoring', 'enoxaparin: the doctor decides the timing'],
      F04: ['a clear path on all sides', 'no chairs or bags right next to the bed', 'nurse · doctor · trolley'],
      F05: ['no more than one or two relatives', 'staff come → please make room', 'asked to leave → please do so'],
      F06: ['nausea and vomiting after anaesthesia', 'food or drink only with the nurse’s permission', 'the medical team decides when and what'],
      F07: ['rails: when the staff decide', 'call button within reach', 'the first time: with the staff’s help'],
      F08: ['hard to breathe · unusually drowsy · confused', 'pain much worse · dressing soaks with blood', 'call button · call the staff loudly'],
    },
    end: ["Your medical team's instructions come before this website", 'Nurse · doctor · medical team'],
  },
  he: {
    brand: 'אורתופדיה · למטופלים', rtl: true,
    sch: ['מיד', 'אחרי שעה', 'אחרי עוד שעה', 'אחרי שעתיים', 'כל ארבע שעות'],
    n: {
      F01: ['כולם רוצים לעזור', 'וזה מאוד מובן'],
      F02: ['השעות הראשונות והיממה הראשונה', 'ברוב המקרים הכול עובר בשקט', 'הדרך אל המטופל — פנויה תמיד'],
      F03: ['לחץ דם · דופק · נשימה · חמצן · חום · הכרה', 'מעקב מתוכנן', 'אנוקספרין: הרופא קובע את המועד'],
      F04: ['מעבר פנוי מכל הצדדים', 'כיסאות ותיקים — לא צמוד למיטה', 'אחות · רופא · עגלה'],
      F05: ['לא יותר מאחד או שניים', 'הצוות ניגש ← פנו מקום', 'ביקשו לצאת ← עשו זאת'],
      F06: ['בחילה והקאה אחרי הרדמה', 'אוכל ושתייה — רק באישור האחות', 'מתי ומה מותר, הצוות הרפואי מחליט'],
      F07: ['מעקות — לפי החלטת הצוות', 'כפתור הקריאה — בהישג יד', 'בפעם הראשונה — בעזרת הצוות'],
      F08: ['קשה לנשום · ישנוני באופן חריג · בלבול', 'הכאב התגבר מאוד · החבישה נספגת בדם', 'כפתור הקריאה · קראו לצוות בקול רם'],
    },
    end: ['הנחיות הצוות המטפל קודמות למידע באתר', 'אחות · רופא · צוות רפואי'],
  },
  ar: {
    brand: 'جراحة العظام · للمرضى', rtl: true,
    sch: ['فورًا', 'بعد ساعة', 'بعد ساعة أخرى', 'بعد ساعتين', 'كل أربع ساعات'],
    n: {
      F01: ['الجميع يريدون المساعدة', 'وهذا مفهوم جدًا'],
      F02: ['الساعات الأولى واليوم الأول', 'في معظم الحالات يمرّ كل شيء بهدوء', 'الطريق إلى المريض مفتوح دائمًا'],
      F03: ['الضغط · النبض · التنفّس · الأكسجين · الحرارة · الوعي', 'متابعة مخطّطة', 'الإينوكسابارين: يحدّد الطبيب الموعد'],
      F04: ['ممرّ مفتوح من كل الجهات', 'لا كراسي ولا حقائب ملاصقة للسرير', 'الممرضة · الطبيب · العربة'],
      F05: ['شخص أو شخصان من الأقارب فقط', 'يقترب الطاقم ← أفسحوا المكان', 'طُلب منكم الخروج ← نفّذوا الطلب'],
      F06: ['غثيان وقيء بعد التخدير', 'الطعام والشراب بإذن الممرضة فقط', 'متى وماذا يُسمح، يقرّر الفريق الطبي'],
      F07: ['الحواجز بقرار من الطاقم', 'زر الاستدعاء في متناول اليد', 'في المرة الأولى بمساعدة الطاقم'],
      F08: ['صعوبة التنفّس · نعاس غير معتاد · تشوّش', 'اشتدّ الألم كثيرًا · الضمادة تتشرّب بالدم', 'زر الاستدعاء · نادوا الطاقم بصوت عالٍ'],
    },
    end: ['تعليمات فريقكم الطبي لها الأولوية على الموقع', 'الممرضة · الطبيب · الفريق الطبي'],
  },
};

const NV = '#E3E7EF';
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10), transform: `translateY(${(1 - ease(f, a, a + 10)) * 14}px)`}}><Note size={30} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};

// фигура посетителя: голова + плечи (силуэт), мягкие цвета
const Visitor: React.FC<{x: number; y: number; s?: number; col: string; o?: number}> = ({x, y, s = 1, col, o = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
    <path d="M-46 92 Q-46 34 0 34 Q46 34 46 92 Z" fill={col} />
    <circle cx={0} cy={0} r={28} fill="#F1D3BC" />
    <path d="M-28 -4 Q-26 -32 0 -32 Q26 -32 28 -4 Q14 -18 0 -16 Q-14 -18 -28 -4 Z" fill="#5B4636" />
  </g>
);
const Chair: React.FC<{x: number; y: number; o?: number}> = ({x, y, o = 1}) => (
  <g transform={`translate(${x} ${y})`} opacity={o}>
    <rect x={-26} y={-40} width={52} height={10} rx={4} fill="#9AA3B2" />
    <rect x={-26} y={-40} width={8} height={70} rx={3} fill="#9AA3B2" />
    <rect x={-26} y={0} width={56} height={10} rx={4} fill="#B7BFCC" />
    <rect x={22} y={8} width={6} height={30} fill="#9AA3B2" /><rect x={-24} y={8} width={6} height={30} fill="#9AA3B2" />
  </g>
);
const VCOL = ['#7FA7D9', '#E5A07A', '#8CC7A9', '#C59AD6', '#E7C46B', '#93B4C4'];

const Crowd: React.FC<{top: number; d: number; keep?: number; crossAt?: number}> = ({top, d, keep = 6, crossAt}) => {
  const f = useCurrentFrame();
  const pos = [[130, 120], [250, 70], [370, 130], [710, 130], [830, 70], [950, 120]];
  return <div style={{position: 'absolute', left: 0, top, width: 1080, height: 300}}>
    <svg width={1080} height={300}>
      {pos.map(([x, y], i) => <g key={i} opacity={ease(f, fr(d, 0.04 + i * 0.04), fr(d, 0.1 + i * 0.04)) * (i < keep ? 1 : 0.18)}>
        <Visitor x={x} y={y} col={VCOL[i]} />
      </g>)}
      {crossAt !== undefined && <line x1={60} y1={40} x2={1020} y2={260} stroke={C.blood} strokeWidth={10} strokeLinecap="round" opacity={ease(f, crossAt, crossAt + 10) * 0.8} />}
    </svg>
  </div>;
};

// план палаты сверху: кровать, свободная зона вокруг, стулья отодвинуты
const FloorPlan: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const zone = ease(f, fr(d, 0.1), fr(d, 0.3));
  const mv = ease(f, fr(d, 0.35), fr(d, 0.55));
  const cart = ease(f, fr(d, 0.6), fr(d, 0.85));
  return <div style={{position: 'absolute', left: 0, top, width: 1080, height: 600}}>
    <svg width={1080} height={600}>
      <rect x={60} y={20} width={960} height={560} rx={28} fill="#fff" stroke={C.line} strokeWidth={3} />
      <rect x={300} y={140} width={480} height={300} rx={60} fill="none" stroke={C.teal} strokeWidth={6} strokeDasharray="22 14" opacity={zone} />
      <rect x={300} y={140} width={480} height={300} rx={60} fill={C.tealL} opacity={zone * 0.6} />
      <rect x={410} y={200} width={260} height={180} rx={18} fill="#E9EEF5" stroke="#AEB8C8" strokeWidth={4} />
      <rect x={430} y={214} width={70} height={152} rx={14} fill="#fff" stroke="#C9D1DE" strokeWidth={3} />
      <rect x={510} y={214} width={145} height={152} rx={14} fill="#CFE3F5" />
      {[[330, 180], [330, 400], [750, 180], [750, 400]].map(([x, y], i) => {
        const tx = x < 540 ? 140 : 900, ty = y < 300 ? 70 : 520;
        return <g key={i} transform={`translate(${x + (tx - x) * mv} ${y + (ty - y) * mv})`}>
          <rect x={-28} y={-28} width={56} height={56} rx={10} fill="#B7BFCC" /></g>;
      })}
      <g transform={`translate(${-80 + 380 * cart} 500)`}><rect x={-50} y={-34} width={100} height={60} rx={10} fill={C.acc} /><circle cx={-30} cy={30} r={9} fill="#555" /><circle cx={30} cy={30} r={9} fill="#555" /><path d="M-10 -4 h20 M0 -14 v20" stroke="#fff" strokeWidth={6} strokeLinecap="round" /></g>
    </svg>
  </div>;
};

// расписание проверок: шкала времени с точками
const Schedule: React.FC<{top: number; d: number; L: Dict}> = ({top, d, L}) => {
  const f = useCurrentFrame();
  const xs0 = [120, 300, 470, 680, 900]; const xs = L.rtl ? xs0.map((x) => 1080 - x) : xs0;
  return <div style={{position: 'absolute', left: 0, top, width: 1080, height: 330}}>
    <svg width={1080} height={330}>
      <line x1={100} y1={90} x2={980} y2={90} stroke={C.line} strokeWidth={8} strokeLinecap="round" />
      <line x1={L.rtl ? 980 : 100} y1={90} x2={L.rtl ? 980 - 880 * ease(f, fr(d, 0.25), fr(d, 0.5)) : 100 + 880 * ease(f, fr(d, 0.25), fr(d, 0.5))} y2={90} stroke={C.teal} strokeWidth={8} strokeLinecap="round" />
      {xs.map((x, i) => { const a = fr(d, 0.25 + i * 0.05); return <g key={i} opacity={ease(f, a, a + 8)}>
        <circle cx={x} cy={90} r={26} fill={C.teal} /><circle cx={x} cy={90} r={11} fill="#fff" />
        <text x={x} y={170} textAnchor="middle" fontFamily="Body" fontWeight={700} fontSize={L.rtl ? 25 : 30} fill={C.ink}>{L.sch[i]}</text>
      </g>; })}
    </svg>
    <div style={{position: 'absolute', left: 64, right: 64, top: 210, display: 'flex', justifyContent: 'space-between'}}>
      {['heart', 'lungs', 'therm', 'drop', 'head', 'wound'].map((k, i) => <div key={k} style={{opacity: ease(f, fr(d, 0.04 + i * 0.03), fr(d, 0.08 + i * 0.03)), background: '#fff', borderRadius: 22, padding: 12, boxShadow: '0 6px 18px rgba(0,0,0,.06)'}}><Icon k={k} s={92} /></div>)}
    </div>
  </div>;
};

// поднос: еда и вода зачёркнуты, затем галочка «по разрешению»
const TrayNo: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const x = ease(f, fr(d, 0.3), fr(d, 0.38)), ok = ease(f, fr(d, 0.62), fr(d, 0.7));
  return <div style={{position: 'absolute', left: 0, top, width: 1080, height: 420}}>
    <svg width={1080} height={420}>
      <ellipse cx={540} cy={300} rx={330} ry={60} fill="#D7DCE4" />
      <circle cx={430} cy={240} r={90} fill="#fff" stroke="#C9D1DE" strokeWidth={5} />
      <circle cx={430} cy={240} r={52} fill="#F2C48D" />
      <path d="M640 120 h80 l-12 180 h-56 Z" fill="#DDF0FA" stroke="#8FB9D6" strokeWidth={5} />
      <rect x={652} y={190} width={56} height={100} fill="#A9D6F0" opacity={0.7} />
      <g opacity={x * (1 - ok * 0.7)}><line x1={300} y1={110} x2={780} y2={340} stroke={C.blood} strokeWidth={14} strokeLinecap="round" /><line x1={780} y1={110} x2={300} y2={340} stroke={C.blood} strokeWidth={14} strokeLinecap="round" /></g>
      <g opacity={ok} transform="translate(860 90)"><circle r={60} fill={C.tealL} /><g transform="translate(-32 -32)"><path d="M12 33 L26 46 L52 18" stroke={C.green} strokeWidth={7} fill="none" strokeLinecap="round" strokeLinejoin="round" /></g></g>
    </svg>
  </div>;
};

const Row: React.FC<{y: number; at: number; icon: string; text: string; red?: boolean}> = ({y, at, icon, text, red}) => (
  <Card x={64} y={y} w={952} at={at} style={red ? {borderLeft: `10px solid ${C.blood}`} : undefined}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} c={red ? C.blood : C.acc} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
    </div>
  </Card>
);

const scene = (id: string, d: number, L: Dict) => {
  const n = L.n[id];
  const t = (p: number) => fr(d, p);
  switch (id) {
    case 'F01': return <>
      <BedReal top={560} d={d} bell={false} patient railsDown />
      <Crowd top={420} d={d} />
      <Notes y={1090} items={[[n[0], t(0.6), C.navy, NV], [n[1], t(0.78), C.teal, C.tealL]]} />
    </>;
    case 'F02': return <>
      <BedReal top={440} d={d} bell={false} patient railsDown />
      <Notes y={960} items={[[n[0], t(0.05), C.navy, NV], [n[1], t(0.35), C.teal, C.tealL], [n[2], t(0.6)]]} />
    </>;
    case 'F03': return <>
      <Schedule top={430} d={d} L={L} />
      <Notes y={800} items={[[n[0], t(0.04), C.navy, NV], [n[1], t(0.55), C.teal, C.tealL], [n[2], t(0.75)]]} />
    </>;
    case 'F04': return <>
      <FloorPlan top={420} d={d} />
      <Notes y={1060} items={[[n[0], t(0.1), C.teal, C.tealL], [n[1], t(0.4)], [n[2], t(0.65), C.navy, NV]]} />
    </>;
    case 'F05': return <>
      <Crowd top={440} d={d} keep={2} />
      <Notes y={800} items={[[n[0], t(0.05), C.teal, C.tealL], [n[1], t(0.35), C.navy, NV], [n[2], t(0.6)]]} />
    </>;
    case 'F06': return <>
      <TrayNo top={430} d={d} />
      <Notes y={890} items={[[n[0], t(0.05), C.navy, NV], [n[1], t(0.3)], [n[2], t(0.75), C.teal, C.tealL]]} />
    </>;
    case 'F07': return <>
      <BedReal top={440} d={d} patient />
      <Notes y={960} items={[[n[0], t(0.05), C.navy, NV], [n[1], t(0.45), C.teal, C.tealL], [n[2], t(0.75)]]} />
    </>;
    case 'F08': return <>
      <Row y={440} at={t(0.04)} icon="lungs" text={n[0]} red />
      <Row y={640} at={t(0.3)} icon="wound" text={n[1]} red />
      <CallBell x={540} y={880} s={0.55} at={t(0.62)} press={t(0.7)} cord={false} />
      <Notes y={1230} items={[[n[2], t(0.65), C.blood, C.bloodL]]} />
    </>;
    case 'F09': return <>
      <Card x={64} y={560} w={952} at={t(0.15)} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
        <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 46, color: C.ink, marginBottom: 14}}>{L.end[0]}</div>
        <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute}}>{L.end[1]}</div>
      </Card>
    </>;
  }
  return null;
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};

export const mkFirst = (lang: string, timing: unknown) => {
  const TT = timing as TT;
  const L = N[lang];
  const total = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
  const Comp: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
    let at = 0;
    return <AbsoluteFill style={{direction: L.rtl ? 'rtl' : 'ltr'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={L.brand} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            {scene(x.id, d, L)}
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>;
  };
  return {Comp, total};
};
const ru = mkFirst('ru', tRu);
export const First = ru.Comp;
export const totalFirst = ru.total;
const he = mkFirst('he', tHe); export const FirstHe = he.Comp; export const totalFirstHe = he.total;
const ar = mkFirst('ar', tAr); export const FirstAr = ar.Comp; export const totalFirstAr = ar.total;
const en = mkFirst('en', tEn); export const FirstEn = en.Comp; export const totalFirstEn = en.total;
