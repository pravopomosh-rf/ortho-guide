// «Мазок на CPE и VRE» — ролик для пациентов (9:16). Тексты CV01–CV10 ОДОБРЕНО ChatGPT 16.11 (tts-data cpe.json).
// Надписи — дословные фрагменты одобренного текста на каждом языке. Тайминги — timing_cpe[_lang].json.
import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Subtitle, Note, C, BODY, HEAD, ease, Word} from './kit';
import {Icon} from './Figures';
import {BedReal} from './WardArt';
import tRu from './timing_cpe.json';
import tHe from './timing_cpe_he.json';
import tAr from './timing_cpe_ar.json';
import tEn from './timing_cpe_en.json';

type TT = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const FPS = 30, PAD = 0.5;
const fr = (d: number, p: number) => Math.round(d * p);
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};

type Dict = {brand: string; rtl?: boolean; n: Record<string, string[]>};
const N: Record<string, Dict> = {
  ru: {
    brand: 'ОРТОПЕДИЯ · ПАЦИЕНТАМ',
    n: {
      CV01: ['мазок из прямой кишки на CPE и VRE', 'повторяют примерно через четырнадцать дней', 'плановая проверка'],
      CV02: ['устойчивых к определённым антибиотикам', 'могут не вызывать болезни', 'это называется носительством'],
      CV03: ['руки · медицинское оборудование · окружающие предметы', 'подобрать антибиотик труднее'],
      CV04: ['стерильный тампон', 'несколько секунд', 'кратковременный дискомфорт'],
      CV05: ['носительство без активной инфекции', 'обычно не требует лечения антибиотиками', 'решает лечащая команда'],
      CV06: ['отдельная палата или выделенная зона', 'специальное оборудование · халаты · перчатки', 'это не наказание'],
      CV07: ['по правилам инфекционного контроля', 'одного отрицательного мазка обычно недостаточно', 'не прекращайте без указания персонала'],
      CV08: ['после туалета — вода и мыло', 'вход и выход из палаты — антисептик', 'не садитесь на чужие кровати'],
      CV09: ['дома обычно достаточно обычной гигиены', 'сообщите о носительстве CPE или VRE'],
      CV10: ['медсестра · лечащий врач', 'Указания персонала важнее общих советов'],
    },
  },
  en: {
    brand: 'ORTHOPAEDICS · FOR PATIENTS',
    n: {
      CV01: ['rectal swab for CPE and VRE', 'repeated after about fourteen days', 'routine screening'],
      CV02: ['resistant to certain antibiotics', 'without causing illness', 'this is called carriage'],
      CV03: ['hands · medical equipment · surrounding objects', 'finding an effective antibiotic is harder'],
      CV04: ['sterile swab', 'a few seconds', 'brief, mild discomfort'],
      CV05: ['carriage without an active infection', 'usually does not require antibiotics', 'your medical team decides'],
      CV06: ['a separate room or designated area', 'dedicated equipment · gowns · gloves', 'not a punishment'],
      CV07: ['infection control procedures', 'one negative swab is usually not enough', 'do not stop precautions unless staff tell you to'],
      CV08: ['after the toilet: soap and water', 'entering and leaving the room: hand rub', "do not sit on other patients' beds"],
      CV09: ['at home, normal hygiene is usually enough', 'tell staff that you carry CPE or VRE'],
      CV10: ['nurse · doctor', 'Staff instructions come before general advice'],
    },
  },
  he: {
    brand: 'אורתופדיה · למטופלים', rtl: true,
    n: {
      CV01: ['משטח מהחלחולת לבדיקת נשאות', 'חוזרים על הבדיקה כעבור כארבעה עשר ימים', 'בדיקת סקר שגרתית'],
      CV02: ['עמידים לאנטיביוטיקות מסוימות', 'בלי לגרום למחלה', 'מצב זה נקרא נשאות'],
      CV03: ['ידיים · ציוד רפואי · חפצים בסביבה', 'קשה יותר להתאים אנטיביוטיקה'],
      CV04: ['מטוש סטרילי', 'כמה שניות', 'אי נוחות קלה וקצרה'],
      CV05: ['נשאות חיידקים ללא זיהום פעיל', 'בדרך כלל אינה דורשת טיפול אנטיביוטי', 'הצוות המטפל מחליט'],
      CV06: ['חדר נפרד או אזור ייעודי', 'ציוד נפרד · חלוקים · כפפות', 'זה אינו עונש'],
      CV07: ['לפי נהלי מניעת הזיהומים', 'משטח שלילי אחד אינו מספיק', 'אל תפסיקו ללא הנחיית הצוות'],
      CV08: ['אחרי השירותים — מים וסבון', 'בכניסה לחדר וביציאה ממנו — תכשיר חיטוי', 'אל תשבו על מיטות של מטופלים אחרים'],
      CV09: ['בבית בדרך כלל מספיקה היגיינה רגילה', 'ספרו שאתם נשאים'],
      CV10: ['האחות · הרופא המטפל', 'ההנחיות של הצוות חשובות יותר מעצות כלליות'],
    },
  },
  ar: {
    brand: 'جراحة العظام · للمرضى', rtl: true,
    n: {
      CV01: ['مسحة من المستقيم للكشف عن حمل البكتيريا', 'تُعاد المسحة بعد نحو أربعة عشر يومًا', 'فحص روتيني'],
      CV02: ['مقاومة لمضادات حيوية معيّنة', 'من دون أن تسبّب مرضًا', 'ويُسمّى ذلك حمل البكتيريا'],
      CV03: ['الأيدي · المعدات الطبية · الأشياء المحيطة', 'اختيار المضاد الحيوي المناسب أصعب'],
      CV04: ['ماسحة معقّمة', 'بضع ثوانٍ', 'انزعاج خفيف ومؤقت'],
      CV05: ['حمل البكتيريا من دون عدوى نشطة', 'لا يحتاج عادةً إلى مضادات حيوية', 'يقرّر الفريق المعالج'],
      CV06: ['غرفة منفصلة أو منطقة مخصّصة', 'معدات خاصة · أرواب · قفازات', 'ليست عقابًا'],
      CV07: ['وفق إجراءات مكافحة العدوى', 'عادةً لا تكفي مسحة سلبية واحدة', 'لا توقفوا الاحتياطات من دون تعليمات الطاقم'],
      CV08: ['بعد المرحاض — الماء والصابون', 'عند الدخول والخروج — المطهّر', 'لا تجلسوا على أسرّة المرضى الآخرين'],
      CV09: ['في البيت تكفي عادةً النظافة المعتادة', 'أخبروا الطاقم بأنكم تحملون البكتيريا'],
      CV10: ['الممرضة · الطبيب المعالج', 'تعليمات الطاقم أهم من النصائح العامة'],
    },
  },
};

const NV = '#E3E7EF';
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10), transform: `translateY(${(1 - ease(f, a, a + 10)) * 14}px)`}}><Note size={30} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};

// ——— 2D-сцены (светлые, мягкие тени) ———
const Stage: React.FC<{top: number; h?: number; children: React.ReactNode}> = ({top, h = 600, children}) => (
  <div style={{position: 'absolute', left: 64, top, width: 952, height: h, borderRadius: 36, background: '#fff', boxShadow: '0 18px 50px rgba(20,30,50,.10)', overflow: 'hidden'}}>
    <svg width={952} height={h} viewBox={`0 0 952 ${h}`}>{children}</svg>
  </div>
);
const Bug: React.FC<{x: number; y: number; r?: number; c?: string; o?: number}> = ({x, y, r = 12, c = '#E07A3F', o = 1}) => (
  <g opacity={o}><ellipse cx={x} cy={y} rx={r * 1.5} ry={r} fill={c} /><ellipse cx={x - r * 0.4} cy={y - r * 0.3} rx={r * 0.5} ry={r * 0.3} fill="#fff" opacity={0.45} /></g>
);
const Tube: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <rect x={-22} y={0} width={44} height={230} rx={22} fill="#EEF5FB" stroke="#9FB4C8" strokeWidth={4} />
    <rect x={-26} y={-30} width={52} height={40} rx={8} fill={C.teal} />
    <line x1={0} y1={10} x2={0} y2={180} stroke="#C9A77A" strokeWidth={6} strokeLinecap="round" />
    <ellipse cx={0} cy={190} rx={13} ry={20} fill="#F4F1EA" stroke="#D8D0C0" strokeWidth={3} />
    <rect x={-22} y={70} width={44} height={60} fill="#fff" stroke="#9FB4C8" strokeWidth={2} />
    <line x1={-14} y1={88} x2={14} y2={88} stroke="#9FB4C8" strokeWidth={3} /><line x1={-14} y1={104} x2={8} y2={104} stroke="#9FB4C8" strokeWidth={3} />
  </g>
);
const CalPage: React.FC<{x: number; y: number; txt: string; o: number; col: string}> = ({x, y, txt, o, col}) => (
  <g opacity={o} transform={`translate(${x},${y})`}>
    <rect x={0} y={0} width={210} height={200} rx={22} fill="#fff" stroke={C.line} strokeWidth={4} />
    <rect x={0} y={0} width={210} height={56} rx={22} fill={col} /><rect x={0} y={34} width={210} height={22} fill={col} />
    <circle cx={60} cy={8} r={8} fill={C.navy} /><circle cx={150} cy={8} r={8} fill={C.navy} />
    <text x={105} y={160} textAnchor="middle" fontFamily={HEAD} fontWeight={800} fontSize={84} fill={C.ink} direction="ltr">{txt}</text>
  </g>
);
const SwabCal: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const a = ease(f, fr(d, 0.25), fr(d, 0.32)), b = ease(f, fr(d, 0.45), fr(d, 0.55));
  return <Stage top={top}>
    <rect x={0} y={0} width={952} height={600} fill="#F4F8FC" />
    <g transform={`translate(0,${(1 - ease(f, 0, 14)) * 30})`} opacity={ease(f, 0, 14)}><Tube x={200} y={190} s={1.2} /></g>
    <CalPage x={380} y={200} txt="1" o={a} col={C.teal} />
    <path d={`M600 300 L${600 + 60 * b} 300`} stroke={C.mute} strokeWidth={6} strokeDasharray="10 10" />
    <CalPage x={680} y={200} txt="≈14" o={b} col={C.acc} />
  </Stage>;
};
const Gut: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const path = 'M260 140 C 160 140 150 260 250 270 C 380 280 560 250 680 270 C 800 290 800 400 690 410 C 560 420 380 380 260 410 C 160 440 180 520 300 520 L 520 520';
  const pts = [[300, 200], [420, 262], [560, 258], [700, 340], [560, 400], [400, 395], [300, 470], [450, 515]];
  const happy = ease(f, fr(d, 0.6), fr(d, 0.7));
  return <Stage top={top}>
    <rect x={0} y={0} width={952} height={600} fill="#FBF6F3" />
    <path d={path} stroke="#F2B9A8" strokeWidth={70} fill="none" strokeLinecap="round" opacity={ease(f, 0, 14)} />
    <path d={path} stroke="#F7D3C6" strokeWidth={46} fill="none" strokeLinecap="round" opacity={ease(f, 0, 14)} />
    {pts.map(([x, y], i) => <Bug key={i} x={x + Math.sin((f + i * 20) / 18) * 6} y={y} r={10} c={i % 2 ? '#E07A3F' : '#7A5CC8'} o={ease(f, fr(d, 0.1 + i * 0.03), fr(d, 0.15 + i * 0.03))} />)}
    <g opacity={happy} transform="translate(820,120)">
      <circle cx={0} cy={0} r={62} fill={C.tealL} stroke={C.teal} strokeWidth={6} />
      <circle cx={-20} cy={-12} r={7} fill={C.navy} /><circle cx={20} cy={-12} r={7} fill={C.navy} />
      <path d="M-26 16 Q0 40 26 16" stroke={C.navy} strokeWidth={7} fill="none" strokeLinecap="round" />
    </g>
  </Stage>;
};
const Spread: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const nodes = [[150, 300], [380, 200], [600, 330], [820, 210]];
  const clean = ease(f, fr(d, 0.82), fr(d, 0.92));
  const ic = (i: number, x: number, y: number) => {
    const o = ease(f, fr(d, 0.04 + i * 0.12), fr(d, 0.1 + i * 0.12));
    const g = [
      <g key="h"><path d={`M${x - 40} ${y + 50} L${x - 40} ${y - 20} Q${x - 40} ${y - 40} ${x - 26} ${y - 40} L${x - 26} ${y - 60} Q${x - 18} ${y - 74} ${x - 10} ${y - 60} L${x - 10} ${y - 66} Q${x - 2} ${y - 80} ${x + 6} ${y - 66} L${x + 6} ${y - 58} Q${x + 14} ${y - 70} ${x + 22} ${y - 56} L${x + 22} ${y - 10} L${x + 40} ${y - 30} Q${x + 54} ${y - 26} ${x + 44} ${y - 6} L${x + 20} ${y + 50} Z`} fill="#F1C7A8" stroke="#D49B76" strokeWidth={4} /></g>,
      <g key="r"><rect x={x - 70} y={y - 10} width={140} height={16} rx={8} fill="#B8C3D1" /><rect x={x - 66} y={y + 6} width={10} height={60} fill="#B8C3D1" /><rect x={x + 56} y={y + 6} width={10} height={60} fill="#B8C3D1" /><rect x={x - 80} y={y + 60} width={160} height={30} rx={8} fill="#DCE6F1" /></g>,
      <g key="t"><rect x={x - 60} y={y - 40} width={120} height={70} rx={10} fill="#DCE6F1" stroke="#9FB4C8" strokeWidth={4} /><rect x={x - 46} y={y - 26} width={60} height={34} rx={4} fill="#7FD1C7" /><circle cx={x - 40} cy={y + 50} r={12} fill={C.navy} /><circle cx={x + 40} cy={y + 50} r={12} fill={C.navy} /></g>,
      <g key="d"><rect x={x - 50} y={y - 90} width={100} height={190} rx={8} fill="#EDE3D3" stroke="#C9B79A" strokeWidth={4} /><rect x={x + 14} y={y} width={36} height={12} rx={6} fill="#8C96A3" /></g>,
    ][i];
    return <g key={i} opacity={o}>{g}<Bug x={x + 20} y={y - 20} r={10} o={o * (1 - clean)} /><Bug x={x - 18} y={y + 10} r={8} c="#7A5CC8" o={o * (1 - clean)} /></g>;
  };
  return <Stage top={top}>
    <rect x={0} y={0} width={952} height={600} fill="#F4F8FC" />
    {nodes.slice(1).map(([x, y], i) => { const [px, py] = nodes[i]; const p = ease(f, fr(d, 0.1 + i * 0.12), fr(d, 0.16 + i * 0.12)); return <path key={i} d={`M${px + 50} ${py - 60} Q${(px + x) / 2} ${Math.min(py, y) - 140} ${px + 50 + (x - px - 100) * p} ${py - 60 + (y - py) * p}`} stroke={C.acc} strokeWidth={5} strokeDasharray="12 10" fill="none" opacity={1 - clean} />; })}
    {nodes.map(([x, y], i) => ic(i, x, y + 120))}
    <g opacity={clean} transform="translate(476,520)"><circle r={50} fill={C.tealL} /><path d="M-22 0 L-6 16 L24 -16" stroke={C.green} strokeWidth={9} fill="none" strokeLinecap="round" /></g>
  </Stage>;
};
const Curtain: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const sec = Math.min(5, Math.floor(ease(f, fr(d, 0.5), fr(d, 0.85)) * 5));
  return <Stage top={top}>
    <rect x={0} y={0} width={952} height={600} fill="#F4F8FC" />
    <line x1={40} y1={50} x2={912} y2={50} stroke="#9FB4C8" strokeWidth={8} strokeLinecap="round" />
    {Array.from({length: 9}, (_, i) => <path key={i} d={`M${60 + i * 60} 56 q30 ${260} 0 ${500} h60 q-30 -240 0 -500 Z`} fill={i % 2 ? '#CFE7E4' : '#DDF0EE'} opacity={ease(f, i * 2, 14 + i * 2)} />)}
    <g opacity={ease(f, fr(d, 0.15), fr(d, 0.25))} transform="translate(740,170)">
      <rect x={-80} y={-20} width={160} height={260} rx={18} fill="#fff" stroke={C.line} strokeWidth={4} />
      <rect x={-60} y={0} width={120} height={36} rx={8} fill={C.tealL} />
      <line x1={0} y1={60} x2={0} y2={190} stroke="#C9A77A" strokeWidth={7} strokeLinecap="round" /><ellipse cx={0} cy={200} rx={12} ry={18} fill="#F4F1EA" stroke="#D8D0C0" strokeWidth={3} />
    </g>
    <g opacity={ease(f, fr(d, 0.45), fr(d, 0.55))} transform="translate(740,500)">
      <circle r={58} fill="#fff" stroke={C.navy} strokeWidth={6} /><rect x={-10} y={-74} width={20} height={14} rx={4} fill={C.navy} />
      <path d={`M0 0 L${Math.sin(sec / 60 * 2 * Math.PI * 6) * 40} ${-Math.cos(sec / 60 * 2 * Math.PI * 6) * 40}`} stroke={C.acc} strokeWidth={6} strokeLinecap="round" />
      <circle r={7} fill={C.acc} />
    </g>
  </Stage>;
};
const Tablet: React.FC<{top: number; d: number; sign: '+' | '−'; extra?: React.ReactNode}> = ({top, d, sign, extra}) => {
  const f = useCurrentFrame();
  const col = sign === '+' ? C.acc : C.teal;
  return <Stage top={top}>
    <rect x={0} y={0} width={952} height={600} fill="#F4F8FC" />
    <g opacity={ease(f, 0, 14)} transform={`translate(110,${70 + (1 - ease(f, 0, 14)) * 30})`}>
      <rect x={0} y={0} width={420} height={470} rx={34} fill={C.navy} /><rect x={22} y={24} width={376} height={420} rx={18} fill="#fff" />
      <rect x={52} y={60} width={200} height={18} rx={9} fill={C.line} /><rect x={52} y={96} width={140} height={18} rx={9} fill={C.line} />
      <circle cx={210} cy={270} r={95 * ease(f, fr(d, 0.08), fr(d, 0.2))} fill={sign === '+' ? C.accL : C.tealL} />
      <text x={210} y={312} textAnchor="middle" fontFamily={HEAD} fontWeight={800} fontSize={130} fill={col} opacity={ease(f, fr(d, 0.12), fr(d, 0.22))}>{sign}</text>
    </g>
    {extra}
  </Stage>;
};
const Shield: React.FC<{x: number; y: number; o: number}> = ({x, y, o}) => (
  <g opacity={o} transform={`translate(${x},${y})`}><path d="M0 -90 L80 -60 Q80 50 0 100 Q-80 50 -80 -60 Z" fill={C.tealL} stroke={C.teal} strokeWidth={7} /><path d="M-30 0 L-8 22 L34 -24" stroke={C.green} strokeWidth={10} fill="none" strokeLinecap="round" /></g>
);
const ShieldA: React.FC<{x: number; y: number; a: number}> = ({x, y, a}) => { const f = useCurrentFrame(); return <Shield x={x} y={y} o={ease(f, a, a + 12)} />; };
const Isolation: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  return <Stage top={top}>
    <rect x={0} y={0} width={952} height={600} fill="#F4F8FC" /><rect x={0} y={480} width={952} height={120} fill="#E6EDF4" />
    <g opacity={ease(f, 0, 14)}>
      <rect x={120} y={60} width={260} height={430} rx={10} fill="#EDE3D3" stroke="#C9B79A" strokeWidth={5} />
      <rect x={325} y={270} width={40} height={14} rx={7} fill="#8C96A3" />
      <g transform="translate(250,170)"><rect x={-70} y={-55} width={140} height={110} rx={14} fill="#fff" stroke={C.acc} strokeWidth={6} /><circle cx={0} cy={-14} r={18} fill={C.acc} /><path d="M-30 40 Q0 0 30 40" fill={C.acc} /></g>
    </g>
    <g opacity={ease(f, fr(d, 0.3), fr(d, 0.4))} transform="translate(560,250)">
      <rect x={0} y={0} width={300} height={200} rx={16} fill="#DCE6F1" stroke="#9FB4C8" strokeWidth={5} />
      <rect x={20} y={-70} width={110} height={70} rx={12} fill="#FFE8B8" stroke="#E0B45A" strokeWidth={4} />
      <g transform="translate(200,-40)"><rect x={-26} y={-50} width={52} height={90} rx={10} fill="#E9F7F5" stroke={C.teal} strokeWidth={4} /><rect x={-10} y={-70} width={20} height={22} fill={C.teal} /></g>
      <path d="M40 40 h80 v40 h-80 Z M160 40 q20 -20 40 0 l20 60 h-100 Z" fill="#B8D8F2" />
      <circle cx={40} cy={210} r={16} fill={C.navy} /><circle cx={260} cy={210} r={16} fill={C.navy} />
    </g>
  </Stage>;
};
const Hands: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const drops = Array.from({length: 6}, (_, i) => ((f * 3 + i * 23) % 90));
  return <Stage top={top}>
    <rect x={0} y={0} width={952} height={600} fill="#F4F8FC" />
    <g opacity={ease(f, 0, 14)}>
      <path d="M90 360 h300 l-30 120 h-240 Z" fill="#fff" stroke="#9FB4C8" strokeWidth={5} />
      <path d="M220 360 v-150 q0 -40 50 -40 h40" stroke="#8C96A3" strokeWidth={16} fill="none" strokeLinecap="round" />
      {drops.map((y, i) => <circle key={i} cx={305 + (i % 3) * 4} cy={200 + y * 1.6} r={5} fill="#7FC4EE" opacity={0.8} />)}
      <rect x={350} y={290} width={60} height={70} rx={14} fill="#FFD9E8" stroke="#E79AB8" strokeWidth={4} /><rect x={370} y={270} width={20} height={22} fill="#E79AB8" />
    </g>
    <g opacity={ease(f, fr(d, 0.4), fr(d, 0.5))} transform="translate(560,120)">
      <rect x={0} y={0} width={150} height={380} rx={10} fill="#EDE3D3" stroke="#C9B79A" strokeWidth={5} />
      <g transform="translate(200,110)"><rect x={-32} y={-20} width={64} height={110} rx={12} fill="#E9F7F5" stroke={C.teal} strokeWidth={5} /><rect x={-12} y={-44} width={24} height={26} fill={C.teal} /><path d="M12 -40 h22" stroke={C.teal} strokeWidth={8} strokeLinecap="round" /></g>
    </g>
    <g opacity={ease(f, fr(d, 0.75), fr(d, 0.85))} transform="translate(840,470)">
      <rect x={-70} y={-24} width={140} height={48} rx={10} fill="#DCE6F1" /><rect x={-70} y={-50} width={40} height={30} rx={8} fill="#fff" stroke="#9FB4C8" strokeWidth={3} />
      <circle r={78} fill="none" stroke={C.blood} strokeWidth={10} /><line x1={-55} y1={-55} x2={55} y2={55} stroke={C.blood} strokeWidth={10} />
    </g>
  </Stage>;
};
const HomeClinic: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const b = ease(f, fr(d, 0.5), fr(d, 0.6));
  return <Stage top={top}>
    <rect x={0} y={0} width={952} height={600} fill="#F7F4EE" />
    <g opacity={ease(f, 0, 14)} transform="translate(80,160)">
      <path d="M0 140 L170 20 L340 140 Z" fill="#E9A27B" /><rect x={30} y={140} width={280} height={240} fill="#FFF8EE" stroke="#E0C9A8" strokeWidth={5} />
      <rect x={140} y={250} width={64} height={130} rx={6} fill="#C99A6E" /><rect x={60} y={190} width={60} height={60} rx={6} fill="#BFE3F5" /><rect x={230} y={190} width={60} height={60} rx={6} fill="#BFE3F5" />
    </g>
    <g opacity={b} transform="translate(520,140)">
      <rect x={0} y={60} width={340} height={340} fill="#fff" stroke="#9FB4C8" strokeWidth={5} />
      <rect x={140} y={0} width={60} height={60} fill="#fff" stroke="#9FB4C8" strokeWidth={5} /><path d="M170 12 v36 M152 30 h36" stroke={C.blood} strokeWidth={10} />
      {[0, 1, 2].map((i) => <rect key={i} x={30 + i * 105} y={110} width={70} height={60} rx={6} fill="#BFE3F5" />)}
      <rect x={130} y={280} width={80} height={120} rx={6} fill="#9FB4C8" />
    </g>
    <g opacity={ease(f, fr(d, 0.62), fr(d, 0.72))} transform="translate(470,90)">
      <path d="M0 0 h220 a24 24 0 0 1 24 24 v60 a24 24 0 0 1 -24 24 h-150 l-30 30 v-30 h-40 a24 24 0 0 1 -24 -24 v-60 a24 24 0 0 1 24 -24 Z" fill={C.accL} stroke={C.acc} strokeWidth={4} />
      <text x={110} y={70} textAnchor="middle" fontFamily={HEAD} fontWeight={800} fontSize={38} fill={C.acc} direction="ltr">CPE · VRE</text>
    </g>
  </Stage>;
};

const scene = (id: string, d: number, L: Dict) => {
  const n = L.n[id];
  const t = (p: number) => fr(d, p);
  switch (id) {
    case 'CV01': return <><SwabCal top={440} d={d} /><Notes y={1080} items={[[n[0], t(0.08), C.navy, NV], [n[1], t(0.5)], [n[2], t(0.78), C.teal, C.tealL]]} /></>;
    case 'CV02': return <><Gut top={440} d={d} /><Notes y={1080} items={[[n[0], t(0.15), C.navy, NV], [n[1], t(0.45), C.teal, C.tealL], [n[2], t(0.62)]]} /></>;
    case 'CV03': return <><Spread top={440} d={d} /><Notes y={1080} items={[[n[0], t(0.1), C.navy, NV], [n[1], t(0.55)]]} /></>;
    case 'CV04': return <><Curtain top={440} d={d} /><Notes y={1080} items={[[n[0], t(0.2), C.navy, NV], [n[1], t(0.5), C.teal, C.tealL], [n[2], t(0.75)]]} /></>;
    case 'CV05': return <><Tablet top={440} d={d} sign="+" extra={<ShieldA x={720} y={300} a={t(0.6)} />} /><Notes y={1080} items={[[n[0], t(0.1), C.navy, NV], [n[1], t(0.4), C.teal, C.tealL], [n[2], t(0.65)]]} /></>;
    case 'CV06': return <><Isolation top={440} d={d} /><Notes y={1080} items={[[n[0], t(0.2), C.navy, NV], [n[1], t(0.42)], [n[2], t(0.7), C.teal, C.tealL]]} /></>;
    case 'CV07': return <><Tablet top={440} d={d} sign="−" extra={<Shield x={720} y={300} o={1} />} /><Notes y={1080} items={[[n[0], t(0.08), C.navy, NV], [n[1], t(0.4)], [n[2], t(0.68), C.blood, C.bloodL]]} /></>;
    case 'CV08': return <><Hands top={440} d={d} /><Notes y={1080} items={[[n[0], t(0.15), C.teal, C.tealL], [n[1], t(0.42), C.navy, NV], [n[2], t(0.72)]]} /></>;
    case 'CV09': return <><HomeClinic top={440} d={d} /><Notes y={1080} items={[[n[0], t(0.1), C.teal, C.tealL], [n[1], t(0.6)]]} /></>;
    case 'CV10': return <>
      <BedReal top={440} d={d} bell={false} patient />
      <Card x={64} y={1060} w={952} at={t(0.4)} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
        <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 42, color: C.ink, marginBottom: 14}}>{n[1]}</div>
        <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute}}>{n[0]}</div>
      </Card>
    </>;
  }
  return null;
};

export const mkCpe = (lang: string, timing: unknown) => {
  const TT = timing as TT;
  const L = N[lang];
  const total = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
  const Comp: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
    let at = 0;
    return <AbsoluteFill style={{direction: L.rtl ? 'rtl' : 'ltr'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={L.brand} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            {scene(x.id, d, L)}
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>;
  };
  return {Comp, total};
};
const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
const ru = mkCpe('ru', tRu); export const Cpe = ru.Comp; export const totalCpe = ru.total;
const he = mkCpe('he', tHe); export const CpeHe = he.Comp; export const totalCpeHe = he.total;
const ar = mkCpe('ar', tAr); export const CpeAr = ar.Comp; export const totalCpeAr = ar.total;
const en = mkCpe('en', tEn); export const CpeEn = en.Comp; export const totalCpeEn = en.total;
