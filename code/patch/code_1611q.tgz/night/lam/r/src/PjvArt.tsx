// «Первые дни после замены сустава» — рисунки сцен (светлые, объёмные градиенты). Без текста — подписи в сцене.
import React from 'react';
import {useCurrentFrame, random} from 'remotion';
import {C, BODY, MONO, ease} from './kit';

const fr = (d: number, p: number) => Math.round(d * p);
const SKIN = ['#F2C9A8', '#E3AC86', '#C98B66'];

const Frame: React.FC<{top: number; h: number; o: number; dark?: boolean; children: React.ReactNode}> = ({top, h, o, dark, children}) => (
  <div style={{position: 'absolute', left: 64, top, width: 952, height: h, borderRadius: 34, overflow: 'hidden', background: dark ? '#0E1116' : 'linear-gradient(180deg,#FFFFFF 0%,#EEF2F5 100%)',
    boxShadow: '0 18px 50px rgba(20,40,60,.14)', opacity: o, transform: `translateY(${(1 - o) * 30}px)`}}>{children}</div>
);
const SkinDefs: React.FC<{id: string}> = ({id}) => (
  <defs>
    <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor={SKIN[0]} /><stop offset="0.55" stopColor={SKIN[1]} /><stop offset="1" stopColor={SKIN[2]} />
    </linearGradient>
    <filter id={id + 's'} x="-20%" y="-20%" width="140%" height="160%"><feDropShadow dx="0" dy="10" stdDeviation="10" floodOpacity="0.18" /></filter>
  </defs>
);
// нога сбоку (бедро слева → голень → стопа справа), колено в x≈470
const LegSide: React.FC<{id: string; y?: number}> = ({id, y = 0}) => (
  <g transform={`translate(0 ${y})`} filter={`url(#${id}s)`}>
    <path d="M40 150 C 160 120 330 128 430 150 C 470 158 500 160 540 158 C 650 150 760 150 820 160 L 846 150 C 880 120 912 118 918 150 L 920 240 C 900 262 860 262 836 246 L 820 240 C 760 246 650 240 540 238 C 500 238 470 244 430 252 C 330 270 160 276 40 262 Z" fill={`url(#${id})`} />
    <ellipse cx={470} cy={200} rx={56} ry={50} fill="#fff" opacity={0.12} />
  </g>
);

// PJ03 — блокада нерва под контролем ультразвука
export const NerveBlock: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const o = ease(f, 2, 14);
  const probe = ease(f, fr(d, 0.08), fr(d, 0.22));
  const nd = ease(f, fr(d, 0.3), fr(d, 0.55));
  const pool = ease(f, fr(d, 0.55), fr(d, 0.8));
  // ультразвук: зернистость
  const dots = Array.from({length: 520}, (_, i) => ({x: random('x' + i) * 400, y: random('y' + i) * 250, r: 1 + random('r' + i) * 2.4, a: 0.15 + random('a' + i) * 0.55}));
  return <Frame top={top} h={760} o={o}>
    <svg width={952} height={760}>
      <SkinDefs id="nbSkin" />
      {/* монитор УЗИ */}
      <g transform="translate(476 40)">
        <rect x={-250} y={0} width={500} height={320} rx={24} fill="#1C2129" />
        <rect x={-230} y={22} width={460} height={276} rx={12} fill="#05070A" />
        <clipPath id="usClip"><path d="M0 0 L 400 0 L 400 250 L 0 250 Z" /></clipPath>
        <g clipPath="url(#usClip)" transform="translate(-200 40)">
          <rect x={0} y={0} width={400} height={250} fill="#23272D" />
          {dots.map((p, i) => <circle key={i} cx={p.x} cy={p.y} r={p.r} fill="#D8DDE2" opacity={p.a * (p.y > 30 ? 1 : 0.5)} />)}
          <rect x={0} y={0} width={400} height={26} fill="#D8DDE2" opacity={0.35} />
          {/* сосуд и нерв (тёмный круг + «соты») */}
          <circle cx={170} cy={140} r={26} fill="#05070A" />
          <g opacity={0.95}><ellipse cx={232} cy={150} rx={30} ry={22} fill="#05070A" stroke="#E8ECF0" strokeWidth={4} />
            {[[-12, -6], [8, -8], [-4, 8], [14, 6]].map(([x, y], i) => <circle key={i} cx={232 + x} cy={150 + y} r={6} fill="#3A4048" />)}</g>
          {/* игла — яркая линия */}
          <line x1={-10} y1={10} x2={-10 + 220 * nd} y2={10 + 128 * nd} stroke="#FFFFFF" strokeWidth={4} opacity={nd > 0 ? 0.95 : 0} />
          {/* анестетик — тёмное облако вокруг нерва */}
          <ellipse cx={232} cy={150} rx={30 + 34 * pool} ry={22 + 22 * pool} fill="none" stroke="#05070A" strokeWidth={16 * pool} opacity={0.85} />
        </g>
      </g>
      {/* нога + датчик + шприц */}
      <g transform="translate(0 400)">
        <LegSide id="nbSkin" />
        <g transform={`translate(${300} ${128 - 60 * (1 - probe)})`} opacity={probe}>
          <rect x={-46} y={-110} width={92} height={96} rx={20} fill="#E8EDF2" stroke="#B9C3CC" strokeWidth={4} />
          <rect x={-56} y={-20} width={112} height={26} rx={8} fill="#5C6B78" />
          <path d="M0 -110 C 0 -170 60 -200 120 -220" stroke="#5C6B78" strokeWidth={10} fill="none" />
        </g>
        <g opacity={ease(f, fr(d, 0.24), fr(d, 0.3))} transform={`translate(${150 + 50 * nd} ${70 + 40 * nd}) rotate(30)`}>
          <rect x={-170} y={-16} width={140} height={32} rx={8} fill="#F4F7FA" stroke="#9AA6B2" strokeWidth={4} />
          <rect x={-200} y={-6} width={34} height={12} rx={4} fill="#9AA6B2" />
          <rect x={-60} y={-12} width={30} height={24} fill={C.teal} opacity={0.5 + 0.5 * (1 - pool)} />
          <line x1={-30} y1={0} x2={60} y2={0} stroke="#8A96A2" strokeWidth={4} />
        </g>
      </g>
    </svg>
  </Frame>;
};

// PJ05 — закрытый поднос, вода, часы «1–2 ч»
export const TrayWait: React.FC<{top: number; d: number; txt?: string}> = ({top, d, txt = '1–2 ч'}) => {
  const f = useCurrentFrame();
  const o = ease(f, 2, 14);
  const hand = ease(f, fr(d, 0.3), fr(d, 0.85));
  return <Frame top={top} h={520} o={o}>
    <svg width={952} height={520}>
      <defs>
        <linearGradient id="cloche" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#FFFFFF" /><stop offset="1" stopColor="#B8C2CC" /></linearGradient>
        <linearGradient id="glass" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#D6EEF6" stopOpacity="0.9" /><stop offset="1" stopColor="#9FD3E6" stopOpacity="0.7" /></linearGradient>
        <filter id="tsh"><feDropShadow dx="0" dy="10" stdDeviation="10" floodOpacity="0.16" /></filter>
      </defs>
      <rect x={60} y={360} width={560} height={40} rx={14} fill="#C9B79C" filter="url(#tsh)" />
      <path d="M140 360 C 140 230 520 230 520 360 Z" fill="url(#cloche)" filter="url(#tsh)" />
      <circle cx={330} cy={250} r={16} fill="#9AA6B2" />
      <g transform="translate(560 220)" filter="url(#tsh)">
        <path d="M0 0 L 80 0 L 70 140 L 10 140 Z" fill="url(#glass)" stroke="#8FB9C9" strokeWidth={4} />
        <rect x={6} y={50} width={68} height={6} fill="#fff" opacity={0.7} />
      </g>
      {/* часы */}
      <g transform="translate(790 230)">
        <circle r={110} fill="#fff" stroke={C.teal} strokeWidth={10} filter="url(#tsh)" />
        <path d={`M0 0 L0 -96 A96 96 0 ${hand > 0.5 ? 1 : 0} 1 ${96 * Math.sin(hand * Math.PI * 2 * 0.999)} ${-96 * Math.cos(hand * Math.PI * 2 * 0.999)} Z`} fill={C.tealL} />
        <line x1={0} y1={0} x2={70 * Math.sin(hand * Math.PI * 2)} y2={-70 * Math.cos(hand * Math.PI * 2)} stroke={C.ink} strokeWidth={8} strokeLinecap="round" />
        <circle r={10} fill={C.ink} />
        <text y={160} textAnchor="middle" fontFamily={/[\u0590-\u06FF]/.test(txt) ? 'Inter, sans-serif' : 'Mono, monospace'} fontWeight={700} fontSize={txt.length > 6 ? 36 : 44} fill={C.teal} style={{direction: /[\u0590-\u06FF]/.test(txt) ? 'rtl' : 'ltr'}}>{txt}</text>
      </g>
    </svg>
  </Frame>;
};

// PJ07 — холод через ткань, 15–20 минут
export const IceKnee: React.FC<{top: number; d: number; unit?: string}> = ({top, d, unit = 'мин'}) => {
  const f = useCurrentFrame();
  const o = ease(f, 2, 14);
  const cloth = ease(f, fr(d, 0.15), fr(d, 0.3));
  const ice = ease(f, fr(d, 0.3), fr(d, 0.45));
  const t = ease(f, fr(d, 0.5), fr(d, 0.85));
  const snow = Array.from({length: 7}, (_, i) => i);
  return <Frame top={top} h={600} o={o}>
    <svg width={952} height={600}>
      <SkinDefs id="ikSkin" />
      <defs><linearGradient id="ikIce" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#E6F6FF" /><stop offset="1" stopColor="#7CC4E8" /></linearGradient></defs>
      <g transform="translate(0 210)">
        <LegSide id="ikSkin" />
        {/* повязка на колене */}
        <rect x={430} y={150} width={90} height={92} rx={14} fill="#FFFFFF" stroke="#D6DCE2" strokeWidth={4} />
        {/* ткань рядом с повязкой (над бедром) */}
        <path d={`M250 ${138 - 40 * (1 - cloth)} C 300 128 370 128 420 138 L 420 168 C 370 160 300 160 250 170 Z`} fill="#F3EEE6" stroke="#D9CDBB" strokeWidth={3} opacity={cloth} />
        {/* пакет со льдом */}
        <g transform={`translate(330 ${100 - 120 * (1 - ice)})`} opacity={ice}>
          <rect x={-80} y={-40} width={160} height={70} rx={26} fill="url(#ikIce)" stroke="#5BA8D0" strokeWidth={4} />
          {snow.map((i) => <path key={i} d={`M${-56 + i * 18} -12 l0 16 M${-64 + i * 18} -4 l16 0`} stroke="#fff" strokeWidth={3} opacity={0.9} />)}
        </g>
        {/* капля на повязке перечёркнута */}
        <g transform="translate(560 120)" opacity={ease(f, fr(d, 0.75), fr(d, 0.85))}>
          <path d="M0 -26 C -12 -8 -16 0 -16 8 a16 16 0 0 0 32 0 C 16 0 12 -8 0 -26 Z" fill="#5BA8D0" />
          <line x1={-24} y1={20} x2={24} y2={-28} stroke={C.acc} strokeWidth={7} strokeLinecap="round" />
        </g>
      </g>
      {/* таймер */}
      <g transform="translate(790 120)">
        <circle r={84} fill="#fff" stroke="#5BA8D0" strokeWidth={9} />
        <path d={`M0 0 L0 -72 A72 72 0 ${t > 0.5 ? 1 : 0} 1 ${72 * Math.sin(t * Math.PI * 2 * 0.999)} ${-72 * Math.cos(t * Math.PI * 2 * 0.999)} Z`} fill="#D7EEFA" />
        <circle r={8} fill={C.ink} />
        <text y={128} textAnchor="middle" fontFamily={/[\u0590-\u06FF]/.test(unit) ? 'Inter, sans-serif' : 'Mono, monospace'} fontWeight={700} fontSize={40} fill="#2E7FAE" style={{direction: /[\u0590-\u06FF]/.test(unit) ? 'rtl' : 'ltr', unicodeBidi: 'plaintext'}}>{'\u206615–20\u2069 ' + unit}</text>
      </g>
    </svg>
  </Frame>;
};

// PJ09 — рентген: эндопротез колена (прямая и боковая проекции)
export const KneeXray: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const o = ease(f, 2, 14);
  const scan = ease(f, fr(d, 0.1), fr(d, 0.45));
  const comp = ease(f, fr(d, 0.45), fr(d, 0.65));
  const View: React.FC<{x: number; lat?: boolean}> = ({x, lat}) => (
    <g transform={`translate(${x} 0)`}>
      <defs>
        <radialGradient id={'bone' + (lat ? 'l' : 'a')} cx="0.5" cy="0.5" r="0.6"><stop offset="0" stopColor="#B9C0C8" /><stop offset="1" stopColor="#6E7782" /></radialGradient>
      </defs>
      {/* бедренная кость */}
      <path d={lat ? 'M-46 20 L 30 20 L 40 250 C 60 300 30 336 -10 336 C -60 336 -80 300 -60 250 Z' : 'M-50 20 L 50 20 L 56 240 C 110 270 116 330 70 342 L -70 342 C -116 330 -110 270 -56 240 Z'} fill={`url(#bone${lat ? 'l' : 'a'})`} opacity={0.85} />
      {/* большеберцовая кость */}
      <path d={lat ? 'M-60 396 L 50 396 C 46 430 34 450 30 470 L 26 660 L -40 660 L -44 470 C -52 450 -60 430 -60 396 Z' : 'M-96 396 L 96 396 C 92 430 66 450 52 470 L 46 660 L -46 660 L -52 470 C -66 450 -92 430 -96 396 Z'} fill={`url(#bone${lat ? 'l' : 'a'})`} opacity={0.85} />
      {!lat && <path d="M66 420 C 90 440 92 470 80 500 L 76 660 L 62 660 L 64 500 Z" fill="#7C8590" opacity={0.7} />}
      {/* компоненты эндопротеза — металл ярко-белый, вкладыш не виден (щель) */}
      <g opacity={comp}>
        <path d={lat ? 'M-62 250 C -84 300 -60 352 -10 352 C 40 352 64 312 46 252 L 34 260 C 46 306 28 334 -10 334 C -50 334 -66 300 -48 258 Z' : 'M-104 300 C -112 330 -96 352 -70 356 L 70 356 C 96 352 112 330 104 300 L 86 300 C 90 322 80 336 64 338 L -64 338 C -80 336 -90 322 -86 300 Z'} fill="#FFFFFF" />
        <rect x={lat ? -60 : -100} y={392} width={lat ? 112 : 200} height={14} rx={4} fill="#FFFFFF" />
        <path d={lat ? 'M-8 406 L 8 406 L 4 500 L -4 500 Z' : 'M-14 406 L 14 406 L 8 510 L -8 510 Z'} fill="#FFFFFF" />
      </g>
    </g>
  );
  return <Frame top={top} h={760} o={o} dark>
    <svg width={952} height={760}>
      <g transform="translate(0 50)">
        <View x={300} />
        <View x={660} lat />
      </g>
      <rect x={0} y={760 * scan - 6} width={952} height={12} fill={C.teal} opacity={scan > 0 && scan < 1 ? 0.55 : 0} />
      <text x={300} y={740} textAnchor="middle" fontFamily="Mono, monospace" fontWeight={700} fontSize={24} fill="#8A96A2">AP</text>
      <text x={660} y={740} textAnchor="middle" fontFamily="Mono, monospace" fontWeight={700} fontSize={24} fill="#8A96A2">LAT</text>
    </svg>
  </Frame>;
};
