// «Первые дни после замены сустава» (колено/бедро) — ролик для пациентов (9:16). Тексты PJ01–PJ11 ОДОБРЕНО ChatGPT (tts-data pjv.json).
// Один файл на все языки: подписи в словаре N[lang], тайминги — timing_pjv[_lang].json.
import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Subtitle, Note, C, BODY, HEAD, ease, Word} from './kit';
import {Icon} from './Figures';
import {BedReal} from './WardArt';
import {FaceScale} from './PainArt';
import {Clip3D} from './Clip3D';
import {NerveBlock, TrayWait, IceKnee, KneeXray} from './PjvArt';
import tRu from './timing_pjv.json';
import tHe from './timing_pjv_he.json';
import tAr from './timing_pjv_ar.json';
import tEn from './timing_pjv_en.json';

type TT = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const FPS = 30, PAD = 0.5;
const fr = (d: number, p: number) => Math.round(d * p);
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};

type Dict = {brand: string; rtl?: boolean; h: string; min: string; n: Record<string, string[]>; end: [string, string]};
const N: Record<string, Dict> = {
  ru: {
    brand: 'ОРТОПЕДИЯ · ПАЦИЕНТАМ', h: '1–2 ч', min: 'мин',
    n: {
      PJ01: ['боль · отёк · синяки', 'слабость · онемение кожи у шва', 'температура или нарастающая боль → медсестре', 'внезапная одышка или боль в груди → срочно зовите персонал'],
      PJ02: ['регулярно или по необходимости', 'не ждите сильной боли — особенно перед физиотерапией', 'схему самостоятельно не меняйте'],
      PJ03: ['местный анестетик рядом с нервом', 'часто под контролем ультразвука', 'нужна не каждому пациенту'],
      PJ04: ['онемение или слабость — иногда до 48 часов', 'не вставайте без персонала', 'усиливается или длится дольше ожидаемого → сразу сообщите'],
      PJ05: ['тошнота → скажите медсестре', 'первые 1–2 часа после возвращения обычно не едят', 'пить и есть — после разрешения медсестры'],
      PJ06: ['раздражение от трубки или маски', 'боль в горле · осиплость · ком — обычно проходят', 'трудно дышать или глотать → немедленно персоналу'],
      PJ07: ['только по инструкции персонала', 'обязательно через ткань · с перерывами', 'повязку не мочить'],
      PJ08: ['колено: прямое, опора под голенью и пяткой', 'не держать долго подушку под согнутым коленом', 'бедро: положение и ограничения — как показали'],
      PJ09: ['положение компонентов искусственного сустава', 'обычно — на следующий день', 'снимок оценивает травматолог-ортопед'],
      PJ10: ['3–4 физиотерапевта в отделении', 'на следующий день: сесть → встать → первые шаги', 'первый раз — только с персоналом', 'нагрузку определяет травматолог-ортопед'],
      PJ11: ['упражнения — в разрешённых пределах', 'сильная боль → остановитесь', 'вопросы — медсестре, физиотерапевту, врачу'],
    },
    end: ['Указания вашей команды важнее сайта', 'Медсестра · физиотерапевт · врач'],
  },
  en: {
    brand: 'ORTHOPAEDICS · FOR PATIENTS', h: '1–2 h', min: 'min',
    n: {
      PJ01: ['pain · swelling · bruising', 'weakness · numb skin near the incision', 'raised temperature or increasing pain → tell your nurse', 'sudden breathlessness or chest pain → call staff immediately'],
      PJ02: ['given regularly or when needed', 'do not wait for severe pain, especially before physiotherapy', 'never change medicines yourself'],
      PJ03: ['local anaesthetic near a nerve', 'often guided by ultrasound', 'not every patient needs a nerve block'],
      PJ04: ['numb or weak, sometimes for up to 48 hours', 'do not get up without staff assistance', 'worsening or prolonged numbness → report immediately'],
      PJ05: ['nausea → tell your nurse', 'usually no eating for the first 1–2 hours after returning', 'eat or drink only when your nurse allows it'],
      PJ06: ['breathing tube or special airway mask', 'sore throat · hoarseness · a lump — usually improve', 'breathing or swallowing difficulty → report immediately'],
      PJ07: ['only as staff instruct', 'with breaks and a cloth between pack and skin', 'keep the dressing dry'],
      PJ08: ['knee: straight, support under the calf and heel', 'not a pillow under a bent knee for long periods', 'hip: follow the position and precautions shown by staff'],
      PJ09: ['position of the artificial joint components', 'usually the following day', 'your orthopaedic surgeon reviews the image'],
      PJ10: ['three to four physiotherapists', 'the day after surgery: sit up → stand → first steps', 'do not get up alone for the first time', 'your orthopaedic surgeon sets weight-bearing limits'],
      PJ11: ['exercise within your prescribed limits', 'stop if pain is severe', 'ask your nurse, physiotherapist or doctor'],
    },
    end: ["Your medical team's instructions come before this website", 'Nurse · physiotherapist · doctor'],
  },
  he: {
    brand: 'אורתופדיה · למטופלים', rtl: true, h: 'שעה–שעתיים', min: 'דקות',
    n: {
      PJ01: ['כאב · נפיחות · שטפי דם', 'חולשה · חוסר תחושה בעור ליד הצלקת', 'עלייה בחום הגוף או כאב שמחמיר ← דווחו לאחות', 'קוצר נשימה פתאומי או כאב בחזה ← הזעיקו מיד את הצוות'],
      PJ02: ['בקביעות או לפי הצורך', 'אל תחכו לכאב חזק, במיוחד לפני פיזיותרפיה', 'אל תשנו את הטיפול בעצמכם'],
      PJ03: ['חומר הרדמה מקומי ליד עצב', 'לעיתים קרובות בהנחיית אולטרסאונד', 'לא כל המטופלים זקוקים לחסימה כזאת'],
      PJ04: ['רדומה או חלשה, לעיתים עד ארבעים ושמונה שעות', 'אל תקומו ללא עזרת הצוות', 'מחמיר או נמשך מעבר לצפוי ← דווחו מיד'],
      PJ05: ['בחילות ← דווחו לאחות', 'בדרך כלל נמנעים מאכילה בשעה עד שעתיים הראשונות', 'שתייה ואכילה רק לאחר אישור האחות'],
      PJ06: ['צינור הנשמה או מסכה מיוחדת', 'כאב גרון · צרידות · תחושת גוש — בדרך כלל חולפים', 'קושי בנשימה או בבליעה ← דווחו מיד לצוות'],
      PJ07: ['רק לפי הנחיות הצוות', 'עם הפסקות ותמיד עם בד בין השקית לעור', 'אל תרטיבו את החבישה'],
      PJ08: ['ברך: ישרה, תמיכה מתחת לשוק ולעקב', 'בלי כרית מתחת לברך כפופה לאורך זמן', 'ירך: המנח שהצוות הראה לכם והמגבלות'],
      PJ09: ['מיקום רכיבי המפרק המלאכותי', 'בדרך כלל ביום שלאחר הניתוח', 'האורתופד המנתח מעריך את הצילום'],
      PJ10: ['שלושה עד ארבעה פיזיותרפיסטים', 'ביום שלאחר הניתוח: לשבת ← לקום ← צעדים ראשונים', 'בפעם הראשונה קומו רק בעזרת הצוות', 'האורתופד המנתח קובע את מידת הדריכה'],
      PJ11: ['תרגילים במסגרת המגבלות שנקבעו לכם', 'הפסיקו במקרה של כאב חזק', 'שאלו את האחות, הפיזיותרפיסט והרופא'],
    },
    end: ['הנחיות הצוות המטפל קודמות למידע באתר', 'אחות · פיזיותרפיסט · רופא'],
  },
  ar: {
    brand: 'جراحة العظام · للمرضى', rtl: true, h: 'ساعة–ساعتان', min: 'دقيقة',
    n: {
      PJ01: ['ألم · تورّم · كدمات', 'ضعف · خدر في الجلد قرب الجرح', 'ارتفاع الحرارة أو ازدياد الألم ← أخبروا الممرضة', 'ضيق مفاجئ في التنفس أو ألم في الصدر ← استدعوا الطاقم فورًا'],
      PJ02: ['بعضها بانتظام وبعضها عند الحاجة', 'لا تنتظروا حتى يشتد الألم، خاصة قبل العلاج الطبيعي', 'لا تغيّروا العلاج بأنفسكم'],
      PJ03: ['مخدّر موضعي بالقرب من عصب', 'غالبًا بتوجيه الموجات فوق الصوتية', 'ليس كل المرضى بحاجة إلى هذا الإجراء'],
      PJ04: ['خدر أو ضعف مؤقت، أحيانًا حتى ثمانٍ وأربعين ساعة', 'لا تنهضوا دون مساعدة الطاقم', 'إذا ازداد الخدر أو استمر ← أبلغوا الطاقم فورًا'],
      PJ05: ['الغثيان ← أخبروا الممرضة', 'عادةً لا طعام خلال الساعة أو الساعتين الأوليين', 'الشرب والأكل بعد موافقة الممرضة فقط'],
      PJ06: ['أنبوبة تنفس أو قناع خاص', 'ألم في الحلق · بحة · إحساس بكتلة — عادةً تتحسن', 'صعوبة في التنفس أو البلع ← أبلغوا الطاقم فورًا'],
      PJ07: ['فقط وفق تعليمات الطاقم', 'مع فترات راحة وقماش بين الكمادة والجلد', 'لا تبلّلوا الضماد'],
      PJ08: ['الركبة: مستقيمة مع دعم تحت الساق والكعب', 'لا وسادة تحت الركبة المثنية طويلًا', 'الورك: الوضعية الموضّحة لكم والقيود الموصوفة'],
      PJ09: ['موضع أجزاء المفصل الصناعي', 'عادةً في اليوم التالي للعملية', 'جرّاح العظام يقيّم الصورة'],
      PJ10: ['ثلاثة إلى أربعة أخصائيين للعلاج الطبيعي', 'في اليوم التالي: الجلوس ← النهوض ← الخطوات الأولى', 'لا تنهضوا للمرة الأولى إلا بمساعدة الطاقم', 'جرّاح العظام يحدّد الوزن المسموح على الساق'],
      PJ11: ['مارسوا التمارين ضمن الحدود المسموح بها', 'توقفوا عند الألم الشديد', 'اسألوا الممرضة وأخصائي العلاج الطبيعي والطبيب'],
    },
    end: ['تعليمات فريقكم الطبي لها الأولوية على الموقع', 'الممرضة · أخصائي العلاج الطبيعي · الطبيب'],
  },
};

const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10), transform: `translateY(${(1 - ease(f, a, a + 10)) * 14}px)`}}><Note size={30} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const NV = ['#E3E7EF'] as const;
const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22)}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tiles: React.FC<{d: number; rtl?: boolean}> = ({d, rtl}) => {
  const f = useCurrentFrame();
  const col = (i: number) => `hsl(${120 - i * 12}, 62%, ${i < 5 ? 42 : 48}%)`;
  return <div style={{position: 'absolute', left: 64, top: 560, display: 'flex', gap: 8, flexDirection: rtl ? 'row-reverse' : 'row'}}>
    {Array.from({length: 11}, (_, i) => <div key={i} style={{width: 80, height: 110, borderRadius: 16, background: col(i), opacity: ease(f, fr(d, 0.02 + i * 0.02), fr(d, 0.06 + i * 0.02)), display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: HEAD, fontWeight: 800, fontSize: 38, color: '#fff'}}>{i}</div>)}
  </div>;
};

const scene = (id: string, d: number, L: Dict) => {
  const n = L.n[id];
  const t = (p: number) => fr(d, p);
  switch (id) {
    case 'PJ01': return <>
      <BedReal top={440} d={d} bell={false} patient />
      <Notes y={930} items={[[n[0], t(0.08), C.navy, NV[0]], [n[1], t(0.28), C.navy, NV[0]], [n[2], t(0.5)], [n[3], t(0.72), C.blood, C.bloodL]]} />
    </>;
    case 'PJ02': return <>
      <Tiles d={d} rtl={L.rtl} />
      <FaceScale d={d} ptrY={500} faceY={760} rtl={L.rtl} />
      <Notes y={1110} items={[[n[0], t(0.15), C.navy, NV[0]], [n[1], t(0.38)], [n[2], t(0.75), C.navy, NV[0]]]} />
    </>;
    case 'PJ03': return <>
      <NerveBlock top={440} d={d} />
      <Notes y={1230} items={[[n[0], t(0.3), C.navy, NV[0]], [n[1], t(0.5), C.teal, C.tealL], [n[2], t(0.75)]]} />
    </>;
    case 'PJ04': return <>
      <Clip3D src="c3/falls_sitfeet.mp4" y={440} h={660} d={d} dur={7} />
      <Notes y={1140} items={[[n[0], t(0.1), C.navy, NV[0]], [n[1], t(0.45)], [n[2], t(0.65), C.blood, C.bloodL]]} />
    </>;
    case 'PJ05': return <>
      <TrayWait top={450} d={d} txt={L.h} />
      <Notes y={1010} items={[[n[0], t(0.08), C.navy, NV[0]], [n[1], t(0.35), C.teal, C.tealL], [n[2], t(0.7)]]} />
    </>;
    case 'PJ06': return <>
      <Clip3D src="c3/anest_air.mp4" y={440} d={d} dur={12} from={28} label={(s) => s < 29 ? null : n[0]} />
      <Notes y={1220} items={[[n[1], t(0.45), C.navy, NV[0]], [n[2], t(0.75), C.blood, C.bloodL]]} />
    </>;
    case 'PJ07': return <>
      <IceKnee top={450} d={d} unit={L.min} />
      <Notes y={1090} items={[[n[0], t(0.3), C.navy, NV[0]], [n[1], t(0.5), C.teal, C.tealL], [n[2], t(0.75)]]} />
    </>;
    case 'PJ08': return <>
      <Clip3D src="c3/swell_elevate.mp4" y={440} h={640} d={d} dur={8} />
      <Notes y={1120} items={[[n[0], t(0.25), C.teal, C.tealL], [n[1], t(0.45)], [n[2], t(0.7), C.navy, NV[0]]]} />
    </>;
    case 'PJ09': return <>
      <KneeXray top={440} d={d} />
      <Notes y={1230} items={[[n[0], t(0.2), C.navy, NV[0]], [n[1], t(0.5), C.teal, C.tealL], [n[2], t(0.7)]]} />
    </>;
    case 'PJ10': return <>
      <Clip3D src="c3/walker_walk.mp4" y={440} h={640} d={d} dur={13.8} />
      <Notes y={1120} items={[[n[0], t(0.05), C.navy, NV[0]], [n[1], t(0.25), C.teal, C.tealL], [n[2], t(0.55)], [n[3], t(0.75), C.navy, NV[0]]]} />
    </>;
    case 'PJ11': return <>
      <CheckRow y={470} at={t(0.08)} icon="leg" text={n[0]} />
      <CheckRow y={660} at={t(0.3)} icon="head" text={n[1]} />
      <CheckRow y={850} at={t(0.5)} icon="check" text={n[2]} />
      <Card x={64} y={1080} w={952} at={t(0.72)} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
        <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 42, color: C.ink, marginBottom: 14}}>{L.end[0]}</div>
        <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute}}>{L.end[1]}</div>
      </Card>
    </>;
  }
  return null;
};

export const mkPjv = (lang: string, timing: unknown) => {
  const TT = timing as TT;
  const L = N[lang];
  const total = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
  const Comp: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
    let at = 0;
    return <AbsoluteFill style={{direction: L.rtl ? 'rtl' : 'ltr'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={L.brand} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            {scene(x.id, d, L)}
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>;
  };
  return {Comp, total};
};
const ru = mkPjv('ru', tRu);
export const Pjv = ru.Comp;
export const totalPjv = ru.total;
const he = mkPjv('he', tHe); export const PjvHe = he.Comp; export const totalPjvHe = he.total;
const ar = mkPjv('ar', tAr); export const PjvAr = ar.Comp; export const totalPjvAr = ar.total;
const en = mkPjv('en', tEn); export const PjvEn = en.Comp; export const totalPjvEn = en.total;

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
