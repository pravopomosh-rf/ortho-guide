// «День операции» — ролик для пациентов (9:16). Тексты OD01–OD10 ОДОБРЕНО ChatGPT (tts-data opday.json).
// Надписи — дословные фрагменты одобренного текста; момент появления = позиция фрагмента в тексте озвучки.
import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Subtitle, Note, C, BODY, HEAD, ease, Word} from './kit';
import {Icon} from './Figures';
import {Stage, Bust, Bubble, Pill, Fade, NV, SKIN, HAIR, GREY} from './Admv';
import tRu from './timing_opday.json';
import tHe from './timing_opday_he.json';
import tEn from './timing_opday_en.json';
import tAr from './timing_opday_ar.json';

type TX = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string};
const FPS = 30, PAD = 0.5;
const fr = (d: number, p: number) => Math.round(d * p);
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
type Dict = {brand: string; rtl?: boolean; n: Record<string, string[]>};
export const N: Record<string, Dict> = {
  ru: {brand: 'ОРТОПЕДИЯ · ПАЦИЕНТАМ', n: {
    OD01: ['День операции', 'от утра в палате', 'до возвращения в отделение'],
    OD02: ['указания о голодании, питье и приёме лекарств', 'с небольшим глотком воды', 'скажет врач или анестезиолог'],
    OD03: ['Примите душ', 'наденьте больничную рубашку', 'снимите украшения и часы', 'Идентификационный браслет не снимайте'],
    OD04: ['Контактные линзы', 'съёмные зубные протезы', 'слуховые аппараты', 'по указанию персонала'],
    OD05: ['в операционный блок на кровати или каталке', 'передаст необходимую информацию'],
    OD06: ['имя', 'вид операции', 'сторону или место вмешательства', 'сведения об аллергиях', 'обычная часть проверки безопасности'],
    OD07: ['где им разрешено ожидать', 'зона ожидания для родственников', 'по номеру пациента', 'Уточните, какая система используется здесь'],
    OD08: ['в палате пробуждения', 'под наблюдением медицинского персонала'],
    OD09: ['Когда ваше состояние позволит', 'дополнительное наблюдение или лечение', 'зависит от операции, анестезии и вашего состояния'],
    OD10: ['Это общая информация', 'Индивидуальные указания лечащего врача и медицинского персонала, который отвечает за ваше лечение, имеют приоритет'],
  }},
  en: {brand: 'ORTHOPAEDICS · FOR PATIENTS', n: {
    OD01: ['On the day of your operation', 'from the morning on the ward', 'until your return after surgery'],
    OD02: ['fasting, drinking and taking medicines', 'with a small sip of water', 'Your doctor or anaesthetist will tell you'],
    OD03: ['Shower at the time instructed', 'put on a hospital gown', 'remove your jewellery and watch', 'Keep your identification wristband on'],
    OD04: ['contact lenses', 'removable dentures', 'hearing aids', 'according to staff instructions'],
    OD05: ['on a bed or trolley', 'hand over the necessary information'],
    OD06: ['your name', 'the planned procedure', 'the correct side or site', 'any allergies', 'a normal part of the safety checks'],
    OD07: ['where they may wait', "a relatives' waiting area", 'using a patient number', 'Ask staff what arrangements are available here'],
    OD08: ['in the recovery room', 'under the supervision of medical staff'],
    OD09: ['When your condition allows', 'additional monitoring or treatment', 'depends on the operation, anaesthesia and your condition'],
    OD10: ['This is general information', 'Individual instructions from your treating doctor and the medical team responsible for your care take priority'],
  }},
  he: {brand: 'אורתופדיה · למטופלים', rtl: true, n: {
    OD01: ['יום הניתוח', 'משעות הבוקר במחלקה', 'ועד החזרה אליה לאחר הניתוח'],
    OD02: ['לגבי צום, שתייה ונטילת תרופות', 'עם לגימה קטנה של מים', 'הרופא המטפל או הרופא המרדים ינחו אתכם'],
    OD03: ['התרחצו בזמן שנקבע לכם', 'לבשו חלוק אשפוז', 'הסירו תכשיטים ושעון', 'אל תסירו את צמיד הזיהוי'],
    OD04: ['עדשות מגע', 'שיניים תותבות נשלפות', 'מכשירי שמיעה', 'לפי הנחיות הצוות'],
    OD05: ['במיטה או באלונקה', 'את המידע הרפואי הדרוש'],
    OD06: ['לשמכם', 'לסוג הניתוח', 'לצד או למקום שבו יבוצע הניתוח', 'למידע על אלרגיות', 'חלק רגיל מבדיקות הבטיחות'],
    OD07: ['היכן מותר להם להמתין', 'אזור המתנה למשפחות', 'לפי מספר המטופל', 'שאלו את הצוות איזו מערכת קיימת במקום'],
    OD08: ['בחדר ההתאוששות', 'תחת השגחה של הצוות הרפואי'],
    OD09: ['כאשר מצבכם יאפשר זאת', 'השגחה נוספת או טיפול ביחידה אחרת', 'תלוי בסוג הניתוח, בהרדמה ובמצבכם'],
    OD10: ['זהו מידע כללי', 'ההנחיות האישיות של הרופא המטפל ושל הצוות הרפואי האחראי לטיפול בכם קודמות למידע הכללי'],
  }},
  ar: {brand: 'جراحة العظام · للمرضى', rtl: true, n: {
    OD01: ['يوم العملية', 'من الصباح في القسم', 'وحتى عودتكم إليه بعد العملية'],
    OD02: ['بشأن الصيام والشرب وتناول الأدوية', 'مع رشفة صغيرة من الماء', 'سيخبركم الطبيب المعالج أو طبيب التخدير'],
    OD03: ['استحمّوا في الوقت المحدّد', 'ارتدوا ثوب المستشفى', 'وانزعوا المجوهرات والساعة', 'لا تنزعوا سوار التعريف'],
    OD04: ['العدسات اللاصقة', 'أطقم الأسنان المتحركة', 'أجهزة السمع', 'وفق تعليمات الطاقم'],
    OD05: ['على السرير أو على نقالة', 'المعلومات الطبية اللازمة'],
    OD06: ['اسمكم', 'نوع العملية', 'الجهة أو موضع الجراحة', 'أي حساسية', 'جزء طبيعي من إجراءات السلامة'],
    OD07: ['المكان المسموح لهم بالانتظار فيه', 'منطقة انتظار', 'باستخدام رقم المريض', 'اسألوا الطاقم عن النظام المتّبع هنا'],
    OD08: ['في غرفة الإفاقة', 'تحت مراقبة الطاقم الطبي'],
    OD09: ['عندما تسمح حالتكم', 'مراقبة إضافية أو علاج في وحدة أخرى', 'تعتمد مدة البقاء على نوع العملية والتخدير وحالتكم الصحية'],
    OD10: ['هذه معلومات عامة', 'تعليمات طبيبكم المعالج والطاقم الطبي المسؤول عن رعايتكم لها الأولوية على المعلومات العامة'],
  }},
};

// момент фрагмента s в озвучке (кадр от начала сцены)
const atOf = (x: TX, s: string, min = 6) => {
  const i = x.text.indexOf(s);
  const af = Math.round(x.dur * FPS);
  return Math.max(min, Math.round(4 + (i < 0 ? 0 : i / x.text.length) * (af - 10)));
};
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10), transform: `translateY(${(1 - ease(f, a, a + 10)) * 14}px)`}}><Note size={34} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};

// ——— общие предметы ———
const BLANK = '#CFE3EE';
// Кровать сбоку: колёса, матрас, подушка; patient: 'sit' | 'lie' | undefined
const Bed: React.FC<{x: number; y: number; s?: number; who?: 'sit' | 'lie'; col?: string}> = ({x, y, s = 1, who, col = '#8DA9C4'}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-10} y={-70} width={16} height={150} rx={8} fill="#9FB4C8" />
    <rect x={354} y={-30} width={16} height={110} rx={8} fill="#9FB4C8" />
    <rect x={0} y={40} width={360} height={22} rx={8} fill="#B7C6D6" />
    <rect x={0} y={0} width={360} height={46} rx={18} fill="#fff" stroke="#C9D6E3" strokeWidth={4} />
    {[30, 330].map((cx) => <g key={cx}><rect x={cx - 4} y={60} width={8} height={30} fill="#9FB4C8" /><circle cx={cx} cy={98} r={13} fill="#5D6F86" /><circle cx={cx} cy={98} r={5} fill="#C9D6E3" /></g>)}
    <rect x={14} y={-22} width={90} height={30} rx={14} fill="#F7FAFC" stroke="#D3DEE9" strokeWidth={3} />
    {who === 'lie' && <g>
      <ellipse cx={62} cy={-34} rx={34} ry={30} fill={SKIN} />
      <path d="M30 -40 Q34 -70 64 -66 Q94 -64 96 -40 Q80 -54 62 -52 Q44 -54 30 -40 Z" fill={HAIR} />
      <circle cx={52} cy={-36} r={3.5} fill="#3A3F4A" /><circle cx={74} cy={-36} r={3.5} fill="#3A3F4A" />
      <path d="M90 -20 Q200 -48 350 -14 L350 6 L90 6 Z" fill={BLANK} stroke="#A9C6DA" strokeWidth={3} />
    </g>}
    {who === 'sit' && <g>
      <path d="M100 -10 Q110 -120 170 -126 Q230 -120 240 -10 Z" fill={col} />
      <path d="M150 -10 Q250 -30 340 -8 L340 6 L150 6 Z" fill={BLANK} stroke="#A9C6DA" strokeWidth={3} />
      <rect x={158} y={-158} width={24} height={28} rx={8} fill={SKIN} />
      <ellipse cx={170} cy={-190} rx={36} ry={42} fill={SKIN} />
      <path d="M132 -194 Q130 -238 170 -238 Q210 -238 208 -194 Q196 -218 170 -216 Q144 -218 132 -194 Z" fill={GREY} />
      <circle cx={157} cy={-188} r={4} fill="#3A3F4A" /><circle cx={183} cy={-188} r={4} fill="#3A3F4A" />
      <path d="M160 -170 Q170 -163 180 -170" stroke="#B9806A" strokeWidth={4} fill="none" strokeLinecap="round" />
    </g>}
  </g>
);
const Tablet: React.FC<{x: number; y: number; r?: number}> = ({x, y, r = 0}) => (
  <g transform={`translate(${x} ${y}) rotate(${r})`}><rect x={-60} y={-80} width={120} height={160} rx={14} fill={C.navy} /><rect x={-50} y={-68} width={100} height={136} rx={6} fill="#EAF4FB" />
    {[0, 1, 2, 3].map((i) => <g key={i}><circle cx={-32} cy={-44 + i * 30} r={7} fill={C.teal} /><rect x={-18} y={-50 + i * 30} width={i % 2 ? 46 : 60} height={10} rx={5} fill="#BCC8D6" /></g>)}</g>
);
const Monitor: React.FC<{x: number; y: number; f: number}> = ({x, y, f}) => {
  const beat = (i: number) => { const p = (i * 2 + f * 4) % 120; return p < 50 ? 0 : p < 56 ? -26 : p < 62 ? 22 : p < 66 ? -6 : 0; };
  return <g transform={`translate(${x} ${y})`}>
    <rect x={-6} y={-6} width={292} height={212} rx={22} fill="#C9D6E3" /><rect x={0} y={0} width={280} height={200} rx={18} fill="#1E2A3A" />
    <path d={Array.from({length: 33}, (_, i) => `${i ? 'L' : 'M'}${16 + i * 7.6} ${60 + beat(i)}`).join(' ')} stroke={C.green} strokeWidth={4} fill="none" />
    <text x={20} y={140} fontFamily={HEAD} fontWeight={700} fontSize={22} fill="#9FB4C8" direction="ltr">HR</text>
    <text x={130} y={140} textAnchor="end" fontFamily={HEAD} fontWeight={800} fontSize={38} fill={C.green} direction="ltr">74</text>
    <text x={150} y={140} fontFamily={HEAD} fontWeight={700} fontSize={22} fill="#9FB4C8" direction="ltr">SpO₂</text>
    <text x={268} y={180} textAnchor="end" fontFamily={HEAD} fontWeight={800} fontSize={38} fill="#7FB8E0" direction="ltr">97%</text>
    <rect x={232} y={86} width={30} height={12} rx={6} fill="#FFB020" opacity={(Math.floor(f / 14) % 2) ? 0.9 : 0.3} />
  </g>;
};
const Win: React.FC<{x: number; y: number; w: number; h: number; sun: number}> = ({x, y, w, h, sun}) => (
  <g transform={`translate(${x} ${y})`}>
    <defs><linearGradient id="dawn" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#9EC9F0" /><stop offset="0.7" stopColor="#FCD9B0" /><stop offset="1" stopColor="#FBC28C" /></linearGradient></defs>
    <rect x={0} y={0} width={w} height={h} rx={14} fill="url(#dawn)" />
    <circle cx={w * 0.62} cy={h - 20 - sun * (h * 0.45)} r={34} fill="#FFE08A" />
    <path d={`M0 ${h - 40} Q${w * 0.3} ${h - 70} ${w * 0.55} ${h - 46} T${w} ${h - 56} V${h} H0 Z`} fill="#B9D7B4" />
    <rect x={0} y={0} width={w} height={h} rx={14} fill="none" stroke="#fff" strokeWidth={12} /><line x1={w / 2} y1={0} x2={w / 2} y2={h} stroke="#fff" strokeWidth={8} />
  </g>
);
const Door: React.FC<{x: number; y: number; open?: number}> = ({x, y, open = 0}) => (
  <g transform={`translate(${x} ${y})`}>
    <rect x={-8} y={-8} width={236} height={386} rx={10} fill="#C9D6E3" />
    <rect x={0} y={0} width={110 - open * 70} height={370} fill="#E8EEF5" stroke="#B7C6D6" strokeWidth={3} /><rect x={110 + open * 70} y={0} width={110 - open * 70} height={370} fill="#E8EEF5" stroke="#B7C6D6" strokeWidth={3} />
    <circle cx={55 - open * 35} cy={120} r={24} fill="#BFE3F5" opacity={1 - open} /><circle cx={165 + open * 35} cy={120} r={24} fill="#BFE3F5" opacity={1 - open} />
    <rect x={40} y={-56} width={140} height={34} rx={10} fill={C.teal} /><circle cx={110} cy={-39} r={8} fill="#fff" />
  </g>
);

// ——— сцены ———
const Morning: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  return <Stage top={top} bg="#FBF5EE">
    <rect x={0} y={470} width={952} height={130} fill="#EFE4D6" />
    <Win x={560} y={60} w={320} h={300} sun={ease(f, 0, d)} />
    <g opacity={ease(f, 0, 14)}><Bed x={90} y={380} who="sit" col="#8DA9C4" /></g>
    <g opacity={ease(f, fr(d, 0.35), fr(d, 0.5))} transform="translate(500 420)"><rect x={0} y={0} width={110} height={90} rx={10} fill="#fff" stroke="#D3C3AE" strokeWidth={4} /><rect x={12} y={-30} width={36} height={30} rx={6} fill="#CFE9F7" stroke="#7FB8E0" strokeWidth={3} /></g>
    <g opacity={ease(f, fr(d, 0.6), fr(d, 0.75))} transform="translate(800 470)"><circle r={46} fill="#fff" stroke={C.teal} strokeWidth={5} /><path d="M0 -30 V0 L20 14" stroke={C.navy} strokeWidth={6} fill="none" strokeLinecap="round" /></g>
  </Stage>;
};
const Fasting: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const o = (p: number) => ease(f, fr(d, p), fr(d, p + 0.08));
  return <Stage top={top} bg="#F4F8FC">
    <rect x={0} y={480} width={952} height={120} fill="#E4EAF1" />
    <g opacity={ease(f, 0, 12)}><Bust x={200} y={330} col={C.teal} cap s={1.15} />
      <g transform="translate(300 330) rotate(-8)"><rect x={0} y={0} width={150} height={200} rx={10} fill="#fff" stroke={C.line} strokeWidth={4} />
        {[0, 1, 2, 3, 4].map((i) => <rect key={i} x={20} y={30 + i * 32} width={i % 2 ? 80 : 110} height={11} rx={5} fill={C.line} />)}<rect x={20} y={30} width={14} height={11} rx={4} fill={C.acc} /></g></g>
    <g opacity={o(0.1)} transform="translate(740 170)"><circle r={88} fill="#fff" stroke={C.blood} strokeWidth={10} />
      <circle cx={0} cy={10} r={36} fill="#F28C8C" /><path d="M0 -26 q6 -20 22 -24" stroke="#6CA86C" strokeWidth={7} fill="none" strokeLinecap="round" />
      <path d="M-50 -20 v50 M-62 -20 v18 q0 14 12 14 q12 0 12 -14 v-18 M50 -20 q16 10 0 40 v20" stroke="#8C96A3" strokeWidth={6} fill="none" strokeLinecap="round" />
      <line x1={-62} y1={-62} x2={62} y2={62} stroke={C.blood} strokeWidth={10} /></g>
    <g opacity={o(0.4)} transform="translate(560 300)"><rect x={0} y={80} width={300} height={100} rx={12} fill="#EFE4D6" stroke="#D3C3AE" strokeWidth={4} />
      <path d="M40 0 h56 l-8 80 h-40 Z" fill="#E6F4FB" stroke="#7FB8E0" strokeWidth={4} /><path d="M46 52 h44 l-3 28 h-38 Z" fill="#9CD3F0" />
      <rect x={140} y={20} width={130} height={60} rx={8} fill="#fff" stroke="#C9CED6" strokeWidth={4} /><rect x={140} y={20} width={130} height={18} rx={8} fill={C.teal} /><Pill x={205} y={60} /></g>
    <g opacity={o(0.75)} transform="translate(470 120)"><Bubble x={0} y={0} o={1} w={170}><circle cx={-34} cy={-4} r={22} fill={C.tealL} stroke={C.teal} strokeWidth={5} /><path d="M-44 -4 h20" stroke={C.teal} strokeWidth={5} /><path d="M6 -16 h46 M6 4 h36 M6 22 h44" stroke={C.mute} strokeWidth={6} strokeLinecap="round" /></Bubble></g>
  </Stage>;
};
const Prep: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const o = (p: number) => ease(f, fr(d, p), fr(d, p + 0.07));
  const drops = Array.from({length: 6}, (_, i) => ((f * 3 + i * 21) % 70));
  const drop = ease(f, fr(d, 0.55), fr(d, 0.68));
  return <Stage top={top} bg="#F2F7FA">
    <rect x={0} y={480} width={952} height={120} fill="#DCE8EF" />
    <g opacity={o(0) * (1 - 0.5 * o(0.3))}><path d="M80 60 v50 q0 18 26 18 h44" stroke="#8C96A3" strokeWidth={12} fill="none" strokeLinecap="round" /><ellipse cx={156} cy={136} rx={38} ry={13} fill="#8C96A3" />
      {drops.map((y, i) => <circle key={i} cx={132 + (i % 4) * 16} cy={156 + y * 3.4} r={5} fill="#7FC4EE" />)}
      <g transform="translate(210 330)"><rect x={0} y={0} width={46} height={110} rx={12} fill="#E9F7F5" stroke={C.teal} strokeWidth={5} /><rect x={14} y={-22} width={18} height={24} fill={C.teal} /></g></g>
    <g opacity={o(0.3)} transform="translate(330 110)"><path d="M40 0 L100 0 L120 30 L160 40 L150 120 L130 110 L130 320 L10 320 L10 110 L-10 120 L-20 40 L20 30 Z" fill="#CFE3EE" stroke="#8FB3CB" strokeWidth={4} />
      {[0, 1, 2, 3, 4, 5].map((i) => <circle key={i} cx={30 + (i % 3) * 40} cy={150 + Math.floor(i / 3) * 80} r={6} fill="#8FB3CB" />)}</g>
    <g opacity={o(0.5)} transform="translate(560 330)"><rect x={0} y={60} width={170} height={100} rx={14} fill="#fff" stroke={C.line} strokeWidth={4} /><rect x={0} y={60} width={170} height={26} rx={12} fill={C.tealL} />
      <g transform={`translate(${60} ${-40 + drop * 120})`} opacity={1 - drop * 0.3}><circle r={20} fill="none" stroke="#E2B84A" strokeWidth={7} /><circle cx={0} cy={-22} r={6} fill="#9FD8F2" /></g>
      <g transform={`translate(${120} ${-60 + drop * 140})`} opacity={1 - drop * 0.3}><rect x={-8} y={-40} width={16} height={80} rx={6} fill="#5D6F86" /><circle r={22} fill="#fff" stroke="#5D6F86" strokeWidth={6} /><path d="M0 -12 V0 L8 6" stroke={C.navy} strokeWidth={3} fill="none" /></g></g>
    <g opacity={o(0.75)} transform="translate(760 140)">
      <path d="M-20 200 C 20 190 60 190 120 196 L160 180 L170 240 L120 250 C 60 254 20 254 -20 250 Z" fill={SKIN} stroke="#D9B193" strokeWidth={4} />
      <rect x={60} y={176} width={56} height={90} rx={14} fill="#fff" stroke="#C9D6E3" strokeWidth={5} />
      {Array.from({length: 6}, (_, i) => <rect key={i} x={70 + i * 6} y={196} width={i % 3 ? 2 : 4} height={30} fill={C.navy} />)}
      <circle cx={88} cy={90} r={52} fill={C.tealL} stroke={C.teal} strokeWidth={6} /><path d="M64 90 L82 108 L114 74" stroke={C.green} strokeWidth={10} fill="none" strokeLinecap="round" /></g>
  </Stage>;
};
const Devices: React.FC<{top: number; d: number; x: TX; n: string[]}> = ({top, d, x, n}) => {
  const f = useCurrentFrame();
  const a = (s: string) => atOf(x, s);
  const card = (cx: number, at: number, kid: React.ReactNode) => <g opacity={ease(f, at, at + 10)} transform={`translate(${cx} ${300 + (1 - ease(f, at, at + 10)) * 30})`}>
    <rect x={-120} y={-130} width={240} height={260} rx={28} fill="#fff" stroke={C.line} strokeWidth={4} />{kid}</g>;
  return <Stage top={top} bg="#F6F3FA">
    {card(176, a(n[0]), <g><rect x={-80} y={-30} width={160} height={60} rx={30} fill={C.tealL} stroke={C.teal} strokeWidth={5} /><circle cx={-40} cy={0} r={22} fill="#fff" stroke={C.teal} strokeWidth={5} /><circle cx={40} cy={0} r={22} fill="#fff" stroke={C.teal} strokeWidth={5} /><circle cx={-40} cy={0} r={12} fill="#BFE3F5" /></g>)}
    {card(476, a(n[1]), <g><rect x={-80} y={-50} width={160} height={110} rx={20} fill="#EAF4FB" stroke="#7FB8E0" strokeWidth={5} /><path d="M-50 -10 q0 -24 25 -24 h50 q25 0 25 24 q0 14 -10 14 h-80 q-10 0 -10 -14 Z" fill="#F4B8B8" />{[-36, -12, 12, 36].map((tx) => <rect key={tx} x={tx - 10} y={-2} width={20} height={26} rx={7} fill="#fff" stroke="#D8D0C0" strokeWidth={2} />)}</g>)}
    {card(776, a(n[2]), <g><path d="M-10 -70 q60 -10 60 50 q0 40 -30 60 q-10 8 -10 30" stroke="#C9A77A" strokeWidth={28} fill="none" strokeLinecap="round" /><circle cx={-20} cy={70} r={20} fill="#E8D7C0" /><path d="M-10 -70 q60 -10 60 50" stroke="#E8D7C0" strokeWidth={10} fill="none" strokeLinecap="round" /></g>)}
    <g opacity={ease(f, a(n[3]), a(n[3]) + 12)}><Bust x={476} y={540} col={C.teal} cap s={0.75} /></g>
  </Stage>;
};
const ToTheatre: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const mv = ease(f, 0, fr(d, 0.45));
  const hand = ease(f, fr(d, 0.62), fr(d, 0.8));
  return <Stage top={top} bg="#F3F6FA">
    <rect x={0} y={470} width={952} height={130} fill="#E4EAF1" />
    {[0, 1, 2].map((i) => <rect key={i} x={100 + i * 280} y={20} width={150} height={14} rx={7} fill="#fff" />)}
    <Door x={700} y={100} open={0} />
    <g transform={`translate(${-260 + mv * 300} 0)`}><Bed x={120} y={360} who="lie" s={0.95} /><Bust x={520} y={290} col={C.teal} s={0.85} /></g>
    <g opacity={ease(f, fr(d, 0.4), fr(d, 0.5))}><Bust x={860} y={300} col="#5E8FC2" cap s={0.85} flip /></g>
    <g opacity={ease(f, fr(d, 0.6), fr(d, 0.66))}><Tablet x={600 + hand * 130} y={420} r={-10 + hand * 20} /></g>
  </Stage>;
};
const SI = [
  <g key="a"><circle cx={32} cy={20} r={12} fill={C.acc} /><path d="M10 58 Q12 36 32 36 Q52 36 54 58 Z" fill={C.acc} /></g>,
  <g key="b"><rect x={12} y={8} width={40} height={50} rx={6} fill="none" stroke={C.acc} strokeWidth={5} /><path d="M20 22 h24 M20 33 h24 M20 44 h14" stroke={C.acc} strokeWidth={5} strokeLinecap="round" /></g>,
  <g key="c"><path d="M28 32 H6 M14 22 L4 32 L14 42 M36 32 H58 M50 22 L60 32 L50 42" stroke={C.acc} strokeWidth={6} fill="none" strokeLinecap="round" strokeLinejoin="round" /></g>,
  <g key="d"><circle cx={32} cy={32} r={24} fill="none" stroke={C.blood} strokeWidth={5} /><rect x={29} y={16} width={6} height={22} rx={3} fill={C.blood} /><circle cx={32} cy={46} r={4} fill={C.blood} /></g>,
];
const Safety: React.FC<{x: TX; n: string[]}> = ({x, n}) => {
  const f = useCurrentFrame();
  return <>{n.slice(0, 4).map((t, i) => {
    const at = atOf(x, t), ok = ease(f, at + 18, at + 28);
    return <Card key={i} x={64} y={460 + i * 160} w={952} at={at}>
      <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
        <svg width={60} height={60} viewBox="0 0 64 64">{SI[i]}</svg>
        <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 38, color: C.ink}}>{t}</div>
        <div style={{width: 64, height: 64, borderRadius: 32, border: `5px solid ${ok > 0.5 ? C.green : C.line}`, background: ok > 0.5 ? '#E3F6EC' : '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${0.8 + 0.2 * ok})`}}>
          <svg width={44} height={44} viewBox="0 0 64 64" opacity={ok}><path d="M12 33 L26 46 L52 18" stroke={C.green} strokeWidth={8} fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>
        </div>
      </div>
    </Card>;
  })}
  <Notes y={1130} items={[[n[4], atOf(x, n[4]), C.teal, C.tealL]]} /></>;
};
const Waiting: React.FC<{top: number; d: number; x: TX; n: string[]}> = ({top, d, x, n}) => {
  const f = useCurrentFrame();
  const scr = atOf(x, n[1]);
  const rows: [string, number, string][] = [['2741', 0.85, C.teal], ['3186', 0.45, '#F2A65A'], ['4520', 0.2, '#7FB8E0']];
  return <Stage top={top} bg="#F6F3EE">
    <rect x={0} y={470} width={952} height={130} fill="#E9E0D2" />
    <g opacity={ease(f, 0, 12)}>
      <Bust x={160} y={330} col="#E3B48F" s={0.95} /><Bust x={300} y={320} col="#8DA9C4" hair={GREY} s={1} />
      <rect x={60} y={420} width={360} height={90} rx={30} fill="#7C9CB8" /><rect x={40} y={380} width={50} height={130} rx={22} fill="#6A8AA6" /><rect x={390} y={380} width={50} height={130} rx={22} fill="#6A8AA6" />
    </g>
    <g opacity={ease(f, scr, scr + 14)} transform="translate(500 70)">
      <rect x={-8} y={-8} width={396} height={316} rx={22} fill="#C9D6E3" /><rect x={0} y={0} width={380} height={300} rx={16} fill={C.navy} />
      {rows.map(([num, p, c], i) => <g key={num} transform={`translate(24 ${40 + i * 86})`} opacity={ease(f, scr + 8 + i * 8, scr + 18 + i * 8)}>
        <text x={0} y={30} fontFamily={HEAD} fontWeight={800} fontSize={32} fill="#fff" direction="ltr">#{num}</text>
        <rect x={150} y={8} width={180} height={26} rx={13} fill="#2E3B52" /><rect x={150} y={8} width={180 * p * ease(f, scr + 14, scr + 40)} height={26} rx={13} fill={c} />
        <circle cx={320} cy={21} r={9} fill={c} opacity={(Math.floor((f + i * 7) / 15) % 2) ? 1 : 0.4} />
      </g>)}
    </g>
    <g opacity={ease(f, atOf(x, n[3]), atOf(x, n[3]) + 12)}><Bust x={700} y={480} col={C.teal} cap s={0.6} /><Bubble x={820} y={410} o={1} w={110}><text x={0} y={22} textAnchor="middle" fontFamily={HEAD} fontWeight={800} fontSize={58} fill={C.acc} direction="ltr">i</text></Bubble></g>
  </Stage>;
};
const Recovery: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  return <Stage top={top} bg="#EEF5F7">
    <rect x={0} y={470} width={952} height={130} fill="#DCE8EF" />
    <g opacity={ease(f, 0, 14)}><Bed x={80} y={370} who="lie" s={1.15} /></g>
    <g opacity={ease(f, 8, 22)}><rect x={640} y={330} width={14} height={160} fill="#9FB4C8" /><Monitor x={540} y={110} f={f} /></g>
    <g opacity={ease(f, fr(d, 0.4), fr(d, 0.55))}><Bust x={860} y={330} col={C.teal} cap s={0.95} flip /></g>
  </Stage>;
};
const Back: React.FC<{top: number; d: number; x: TX; n: string[]}> = ({top, d, x, n}) => {
  const f = useCurrentFrame();
  const mv = ease(f, 6, fr(d, 0.4));
  const alt = ease(f, atOf(x, n[1]), atOf(x, n[1]) + 14);
  return <Stage top={top} bg="#FBF5EE">
    <rect x={0} y={470} width={952} height={130} fill="#EFE4D6" />
    <rect x={0} y={0} width={300} height={470} fill="#EEF5F7" /><rect x={292} y={0} width={16} height={470} fill="#C9D6E3" />
    <Win x={640} y={50} w={260} h={220} sun={1} />
    <g transform={`translate(${-60 + mv * 380} 0)`}><Bed x={60} y={380} who="lie" s={0.95} /></g>
    <g opacity={ease(f, fr(d, 0.3), fr(d, 0.42))}><Bust x={860} y={330} col={C.teal} cap s={0.9} flip /></g>
    <g opacity={alt} transform="translate(160 150)"><circle r={70} fill="#fff" stroke="#7FB8E0" strokeWidth={6} /><path d="M-36 0 h72 M0 -36 v72" stroke="#7FB8E0" strokeWidth={14} strokeLinecap="round" /></g>
  </Stage>;
};
const Final: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  return <Stage top={top} h={560} bg="#F4F8FC">
    <rect x={0} y={440} width={952} height={120} fill="#E4EAF1" />
    <g opacity={ease(f, 0, 14)}><Bed x={300} y={370} who="sit" s={0.95} col="#B49AD6" /></g>
    <g opacity={ease(f, 8, 22)}><Bust x={150} y={300} col="#fff" steth s={1.05} /></g>
    <g opacity={ease(f, 16, 30)}><Bust x={820} y={300} col={C.teal} cap s={1.05} flip /></g>
    <Bubble x={250} y={100} o={ease(f, fr(d, 0.2), fr(d, 0.3))} w={150}><path d="M-40 -10 h80 M-40 14 h56" stroke={C.mute} strokeWidth={8} strokeLinecap="round" /></Bubble>
    <Bubble x={700} y={110} o={ease(f, fr(d, 0.45), fr(d, 0.55))} w={130}><path d="M-26 2 L-8 20 L28 -18" stroke={C.green} strokeWidth={10} fill="none" strokeLinecap="round" /></Bubble>
  </Stage>;
};

const scene = (x: TX, d: number, L: Dict) => {
  const n = L.n[x.id];
  const a = (s: string) => atOf(x, s);
  const T: [string, string][] = [[C.navy, NV], [C.teal, C.tealL], [C.acc, C.accL], [C.blood, C.bloodL]];
  const notes = (y: number, idx: number[], cols?: number[]) => <Notes y={y} items={idx.map((k, j) => [n[k], a(n[k]), ...T[(cols || [0, 1, 2, 3])[j]]] as [string, number, string, string])} />;
  switch (x.id) {
    case 'OD01': return <><Morning top={440} d={d} />{notes(1080, [0, 1, 2], [0, 1, 2])}</>;
    case 'OD02': return <><Fasting top={440} d={d} />{notes(1080, [0, 1, 2], [0, 1, 2])}</>;
    case 'OD03': return <><Prep top={440} d={d} />{notes(1080, [0, 1, 2, 3], [1, 0, 2, 3])}</>;
    case 'OD04': return <><Devices top={440} d={d} x={x} n={n} />{notes(1080, [0, 1, 2, 3], [0, 0, 0, 1])}</>;
    case 'OD05': return <><ToTheatre top={440} d={d} />{notes(1080, [0, 1], [0, 1])}</>;
    case 'OD06': return <Safety x={x} n={n} />;
    case 'OD07': return <><Waiting top={440} d={d} x={x} n={n} />{notes(1080, [0, 1, 2, 3], [0, 1, 2, 1])}</>;
    case 'OD08': return <><Recovery top={440} d={d} />{notes(1080, [0, 1], [0, 1])}</>;
    case 'OD09': return <><Back top={440} d={d} x={x} n={n} />{notes(1080, [0, 1, 2], [1, 0, 2])}</>;
    case 'OD10': return <><Final top={440} d={d} />{notes(1020, [0], [0])}
      <Card x={64} y={1110} w={952} at={a(n[1])} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
        <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, lineHeight: 1.25, color: C.ink}}>{n[1]}</div>
      </Card></>;
  }
  return null;
};

export const mkOpday = (lang: string, timing: unknown) => {
  const TT = timing as TX[];
  const L = N[lang];
  const total = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
  const Comp: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
    let at = 0;
    return <AbsoluteFill style={{direction: L.rtl ? 'rtl' : 'ltr'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={L.brand} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} size={x.head.length >= 28 ? 50 : undefined} />
            {scene(x, d, L)}
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>;
  };
  return {Comp, total};
};
const ru = mkOpday('ru', tRu); export const Opday = ru.Comp; export const totalOpday = ru.total;
const he = mkOpday('he', tHe); export const OpdayHe = he.Comp; export const totalOpdayHe = he.total;
const en = mkOpday('en', tEn); export const OpdayEn = en.Comp; export const totalOpdayEn = en.total;
const ar = mkOpday('ar', tAr); export const OpdayAr = ar.Comp; export const totalOpdayAr = ar.total;
export {Bed, Win, Monitor, Notes, atOf, Door, Tablet};
export type {TX};
