// «Реабилитация (шикум)» — ролик для пациентов (9:16). Тексты RH01–RH11 ОДОБРЕНО ChatGPT (tts-data rehabv.json).
// Надписи — дословные фрагменты одобренного текста; появление по позиции фрагмента в озвучке.
import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Subtitle, C, BODY, HEAD, ease, Word} from './kit';
import {Icon, Person} from './Figures';
import {Stage, Bust, Bubble, Fade, NV, SKIN, GREY} from './Admv';
import {Bed, Win, Notes, atOf, TX} from './Opday';
import tRu from './timing_rehabv.json';
import tEn from './timing_rehabv_en.json';
import tHe from './timing_rehabv_he.json';
import tAr from './timing_rehabv_ar.json';

const FPS = 30, PAD = 0.5;
const fr = (d: number, p: number) => Math.round(d * p);
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
type Dict = {brand: string; rtl?: boolean; n: Record<string, string[]>};
export const N: Record<string, Dict> = {
  ru: {brand: 'ОРТОПЕДИЯ · ПАЦИЕНТАМ', n: {
    RH01: ['на иврите шикум', 'движения, силу, самостоятельность', 'вернуться к повседневной жизни'],
    RH02: ['трудно ходить, вставать с кровати', 'одеваться, принимать душ', 'Мышцы могут ослабнуть'],
    RH03: ['физиотерапевт', 'эрготерапевт', 'медсестра', 'врач-реабилитолог', 'другие специалисты'],
    RH04: ['в реабилитационном отделении', 'в дневном центре', 'у физиотерапевта больничной кассы', 'дома', 'Не всем нужен реабилитационный стационар'],
    RH05: ['Медицинская команда оценивает', 'Социальный работник, координатор выписки или медсестра связи', 'Больничная касса рассматривает направление'],
    RH06: ['уберите скользящие коврики и провода', 'хорошее освещение, особенно ночью', 'безопасный путь к туалету, ванной и кровати'],
    RH07: ['ходунки', 'костыли', 'поручни', 'стул для душа', 'Без необходимости приспособления не покупайте'],
    RH08: ['Программа зависит от операции', 'Соблюдайте ограничения движений и нагрузки', 'увеличивайте активность постепенно'],
    RH09: ['Хорошие признаки', 'Нарастающую боль', 'температуру', 'выделения из раны', 'боль и отёк икры', 'срочно обратитесь за медицинской помощью'],
    RH10: ['по номеру 101', 'внезапная одышка', 'сильная боль в груди', 'потеря сознания'],
    RH11: ['куда вы направлены', 'кто организует лечение', 'какие движения вам разрешены', 'Индивидуальные указания лечащего врача имеют приоритет'],
  }},
  en: {brand: 'ORTHOPAEDICS · FOR PATIENTS', n: {
    RH01: ['Rehabilitation after orthopaedic surgery', 'regain movement, strength and independence', 'return to everyday activities'],
    RH02: ['difficult to walk, get out of bed', 'get dressed, shower or use the toilet', 'Your muscles may become weaker'],
    RH03: ['physiotherapist', 'occupational therapist', 'nurse', 'rehabilitation doctor', 'other specialists'],
    RH04: ['a rehabilitation ward', 'a day rehabilitation centre', "your health fund's physiotherapy services", 'at home', 'Not everyone needs inpatient rehabilitation'],
    RH05: ['The medical team assesses', 'A social worker, discharge coordinator or liaison nurse', 'Your health fund reviews the referral'],
    RH06: ['Remove loose rugs and trailing cables', 'good lighting, especially at night', 'a safe route between your bed, toilet and bathroom'],
    RH07: ['a walking frame', 'crutches', 'grab rails', 'a shower chair', 'Do not buy equipment unnecessarily'],
    RH08: ['depends on the operation', 'Follow any movement or weight-bearing restrictions', 'increase your activity gradually'],
    RH09: ['Good signs of progress', 'worsening pain', 'fever', 'wound discharge', 'calf pain and swelling', 'Seek urgent medical assessment'],
    RH10: ['on 101', 'sudden shortness of breath', 'severe chest pain', 'loss of consciousness'],
    RH11: ['where you have been referred', 'who will arrange your ongoing care', 'which movements you are allowed to perform', "Your treating doctor's individual instructions take priority over general advice"],
  }},
  he: {brand: 'אורתופדיה · למטופלים', rtl: true, n: {
    RH01: ['שיקום לאחר ניתוח אורתופדי', 'לשפר את התנועה, לחזק את השרירים', 'ולפעילות היומיומית'],
    RH02: ['קשה ללכת, לקום מהמיטה', 'להתלבש, להתקלח או להשתמש בשירותים', 'השרירים עלולים להיחלש'],
    RH03: ['פיזיותרפיסט', 'מרפא בעיסוק', 'אח או אחות', 'רופא מומחה בשיקום', 'ואנשי מקצוע נוספים'],
    RH04: ['במחלקת שיקום', 'במסגרת שיקום יום', 'בטיפולי פיזיותרפיה דרך קופת החולים', 'או בבית', 'לא כל מטופל זקוק לאשפוז שיקומי'],
    RH05: ['הצוות הרפואי מעריך', 'עובד סוציאלי, מתאם שחרור או אחות קשר', 'קופת החולים בוחנת את ההפניה'],
    RH06: ['הסירו שטיחים מחליקים וכבלים מהרצפה', 'דאגו לתאורה טובה, במיוחד בלילה', 'מעבר בטוח בין המיטה, השירותים וחדר הרחצה'],
    RH07: ['להליכון', 'לקביים', 'למאחזי יד', 'לכיסא רחצה', 'אל תרכשו אביזרים ללא צורך'],
    RH08: ['תוכנית השיקום תלויה בסוג הניתוח', 'הקפידו על הגבלות התנועה והדריכה', 'והגבירו את הפעילות בהדרגה'],
    RH09: ['סימנים טובים להתקדמות', 'כאב שמחמיר', 'חום', 'הפרשה מהפצע', 'כאב ונפיחות בשוק', 'פנו בדחיפות לבדיקה רפואית'],
    RH10: ['הזעיקו מיד אמבולנס', 'קוצר נשימה פתאומי', 'כאב חזק בחזה', 'אובדן הכרה'],
    RH11: ['לאיזו מסגרת אתם מופנים', 'מי מתאם את המשך הטיפול', 'ואילו תנועות מותרות לכם', 'ההנחיות האישיות של הרופא המטפל קודמות למידע הכללי'],
  }},
  ar: {brand: 'جراحة العظام · للمرضى', rtl: true, n: {
    RH01: ['إعادة التأهيل بعد جراحة العظام', 'استعادة الحركة والقوة والاستقلالية', 'والعودة إلى أنشطتكم اليومية'],
    RH02: ['صعوبة في المشي أو النهوض من السرير', 'ارتداء الملابس أو الاستحمام أو استخدام المرحاض', 'قد تضعف العضلات'],
    RH03: ['أخصائي العلاج الطبيعي', 'وأخصائي العلاج الوظيفي', 'والممرض أو الممرضة', 'وطبيب متخصص في التأهيل', 'وغيرهم من المختصين'],
    RH04: ['في قسم تأهيل داخلي', 'أو مركز تأهيل نهاري', 'جلسات العلاج الطبيعي التابعة لصندوق المرضى', 'أو في المنزل', 'ليس جميع المرضى بحاجة إلى الإقامة في مركز تأهيل'],
    RH05: ['يقيّم الفريق الطبي', 'للأخصائي الاجتماعي أو منسق الخروج أو ممرضة التنسيق', 'ويدرس صندوق المرضى الإحالة'],
    RH06: ['أزيلوا السجاد القابل للانزلاق والأسلاك من الأرض', 'ووفّروا إضاءة جيدة، خصوصًا ليلًا', 'لمسار آمن بين السرير والمرحاض والحمّام'],
    RH07: ['مشّاية', 'عكازات', 'مقابض دعم', 'كرسي للاستحمام', 'لا تشتروا هذه الوسائل دون توصية'],
    RH08: ['تعتمد خطة التأهيل على نوع العملية', 'التزموا بقيود الحركة وتحميل الوزن', 'وزيدوا نشاطكم تدريجيًا'],
    RH09: ['من علامات التحسن', 'ألم يزداد', 'حمى', 'إفرازات من الجرح', 'ألم وتورم في ربلة الساق', 'فاطلبوا تقييمًا طبيًا عاجلًا'],
    RH10: ['فاتصلوا بالإسعاف فورًا', 'ضيق مفاجئ في التنفس', 'ألم شديد في الصدر', 'فقدان للوعي'],
    RH11: ['الجهة التي أُحلتم إليها', 'ومن سينسّق استمرار علاجكم', 'وما الحركات المسموح لكم بها', 'تعليمات طبيبكم المعالج الخاصة بحالتكم لها الأولوية على المعلومات العامة'],
  }},
};

const WalkerF: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} stroke="#8C96A3" strokeWidth={9} fill="none" strokeLinecap="round">
    <path d="M0 0 L-10 170 M60 0 L70 170 M0 0 H60 M-6 100 H66" /><circle cx={-10} cy={176} r={9} fill="#5D6F86" stroke="none" /><circle cx={70} cy={176} r={9} fill="#5D6F86" stroke="none" />
  </g>
);
const Crutch: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g transform={`translate(${x} ${y})`} stroke="#8C96A3" strokeWidth={8} fill="none" strokeLinecap="round"><path d="M-14 0 h28 M-10 0 L-4 90 M10 0 L4 90 M-4 90 L0 200 M4 90 L0 200 M-10 60 h20" /><rect x={-16} y={-10} width={32} height={14} rx={7} fill="#5D6F86" stroke="none" /></g>
);
const Rail: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g transform={`translate(${x} ${y})`}><rect x={-80} y={-40} width={160} height={120} rx={8} fill="#E9F1F7" /><path d="M-60 20 H60" stroke="#8C96A3" strokeWidth={14} strokeLinecap="round" /><rect x={-66} y={6} width={14} height={30} rx={4} fill="#5D6F86" /><rect x={52} y={6} width={14} height={30} rx={4} fill="#5D6F86" /></g>
);
const Chair: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g transform={`translate(${x} ${y})`} stroke="#8C96A3" strokeWidth={8} strokeLinecap="round"><rect x={-60} y={-20} width={120} height={26} rx={10} fill="#fff" /><path d="M-50 6 L-62 90 M50 6 L62 90 M-30 6 L-36 90 M30 6 L36 90" /><path d="M-60 -20 V-90 H60 V-20" fill="none" /></g>
);
const House: React.FC = () => (<g><path d="M-80 0 L0 -70 L80 0 V80 H-80 Z" fill="#F2D9B8" stroke="#C9A77A" strokeWidth={5} /><rect x={-20} y={20} width={40} height={60} fill="#C98F6A" /><rect x={30} y={10} width={30} height={30} fill="#BFE3F5" /></g>);
const IconCard: React.FC<{cx: number; cy: number; at: number; w?: number; h?: number; children: React.ReactNode}> = ({cx, cy, at, w = 200, h = 230, children}) => {
  const f = useCurrentFrame(); const o = ease(f, at, at + 10);
  return <g opacity={o} transform={`translate(${cx} ${cy + (1 - o) * 30})`}><rect x={-w / 2} y={-h / 2} width={w} height={h} rx={26} fill="#fff" stroke={C.line} strokeWidth={4} />{children}</g>;
};

const Hall: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const ph = f / 9, mv = ease(f, 0, d);
  return <Stage top={top} bg="#F2F7F4">
    <rect x={0} y={470} width={952} height={130} fill="#DDEBE3" />
    {[0, 1, 2].map((i) => <rect key={i} x={560 + i * 120} y={90} width={90} height={200} rx={10} fill="#E6F1EA" stroke="#C7DDD0" strokeWidth={3} />)}
    <rect x={40} y={380} width={300} height={16} rx={8} fill="#9FB4C8" /><rect x={40} y={396} width={12} height={84} fill="#9FB4C8" /><rect x={328} y={396} width={12} height={84} fill="#9FB4C8" />
    <g transform={`translate(${200 + mv * 220} 330)`}><Person phase={ph} scale={0.95} /><WalkerF x={50} y={-70} s={1.05} /></g>
    <g opacity={ease(f, fr(d, 0.25), fr(d, 0.4))}><Bust x={720 + mv * 120} y={330} col="#3E8E7E" s={0.95} flip /></g>
  </Stage>;
};
const Hard: React.FC<{top: number; d: number; x: TX; n: string[]}> = ({top, x, n}) => {
  const f = useCurrentFrame();
  const a0 = atOf(x, n[0]), a1 = atOf(x, n[1]), a2 = atOf(x, n[2]);
  return <Stage top={top} bg="#F4F8FC">
    <g opacity={ease(f, a0, a0 + 12)}><Bed x={40} y={420} who="sit" s={0.7} /></g>
    <g opacity={ease(f, a1, a1 + 12)} transform="translate(430 120)"><path d="M40 0 L100 0 L120 30 L160 40 L150 120 L130 110 L130 300 L10 300 L10 110 L-10 120 L-20 40 L20 30 Z" fill="#E3B48F" stroke="#C9935F" strokeWidth={4} /><path d="M70 30 V300" stroke="#C9935F" strokeWidth={4} strokeDasharray="10 10" /></g>
    <g opacity={ease(f, a1 + 10, a1 + 22)} transform="translate(700 100)"><path d="M0 0 v50 q0 18 26 18 h44" stroke="#8C96A3" strokeWidth={12} fill="none" strokeLinecap="round" /><ellipse cx={76} cy={76} rx={36} ry={12} fill="#8C96A3" />{[0, 1, 2, 3].map((i) => <line key={i} x1={56 + i * 12} y1={96} x2={52 + i * 12} y2={140 + ((f * 3 + i * 9) % 40)} stroke="#7FC4EE" strokeWidth={5} strokeLinecap="round" />)}<Chair x={80} y={330} /></g>
    <g opacity={ease(f, a2, a2 + 12)} transform="translate(476 470)"><rect x={-300} y={-30} width={600} height={60} rx={30} fill="#fff" stroke={C.line} strokeWidth={4} /><rect x={-290} y={-20} width={580 * (1 - 0.45 * ease(f, a2 + 6, a2 + 40))} height={40} rx={20} fill={C.acc} opacity={0.75} /></g>
  </Stage>;
};
const Team: React.FC<{top: number; x: TX; n: string[]}> = ({top, x, n}) => {
  const cols = ['#3E8E7E', '#7A6BC2', C.teal, '#fff', '#5E8FC2'];
  const f = useCurrentFrame();
  return <Stage top={top} bg="#F2F7F4">
    <rect x={0} y={470} width={952} height={130} fill="#DDEBE3" />
    {n.map((t, i) => { const at = atOf(x, t); return <g key={i} opacity={ease(f, at, at + 12)} transform={`translate(0 ${(1 - ease(f, at, at + 12)) * 30})`}><Bust x={110 + i * 183} y={340} col={cols[i]} cap={i === 2} steth={i === 3} s={0.9} hair={i % 2 ? GREY : undefined} /></g>; })}
  </Stage>;
};
const Places: React.FC<{top: number; x: TX; n: string[]}> = ({top, x, n}) => (
  <Stage top={top} bg="#F6F3FA">
    <IconCard cx={130} cy={300} at={atOf(x, n[0])}><g transform="translate(-95 40) scale(0.52)"><Bed x={0} y={0} who="lie" /></g></IconCard>
    <IconCard cx={360} cy={300} at={atOf(x, n[1])}><g transform="translate(-40 0) scale(0.5)"><Bust x={0} y={0} col="#E3B48F" /><Bust x={150} y={0} col="#8DA9C4" hair={GREY} /></g><circle cx={60} cy={70} r={20} fill="#F2A65A" /></IconCard>
    <IconCard cx={590} cy={300} at={atOf(x, n[2])}><rect x={-80} y={50} width={160} height={20} rx={10} fill={C.tealL} /><circle cx={0} cy={0} r={50} fill="#7FB8E0" opacity={0.8} /><path d="M-40 -10 q40 -30 80 0" stroke="#fff" strokeWidth={6} fill="none" /></IconCard>
    <IconCard cx={820} cy={300} at={atOf(x, n[3])}><House /></IconCard>
  </Stage>
);
const Decide: React.FC<{top: number; d: number; x: TX; n: string[]}> = ({top, x, n}) => {
  const f = useCurrentFrame();
  const a1 = atOf(x, n[1]), a2 = atOf(x, n[2]);
  return <Stage top={top} bg="#F7F4EE">
    <rect x={0} y={430} width={952} height={170} fill="#E8DCC8" />
    <g opacity={ease(f, 0, 12)}><Bust x={160} y={300} col="#fff" steth /></g>
    <g opacity={ease(f, a1, a1 + 12)}><Bust x={370} y={310} col="#7A6BC2" /></g>
    <g opacity={ease(f, 8, 20)}><Bust x={620} y={320} col="#8DA9C4" hair={GREY} flip /><Bust x={790} y={330} col="#E3B48F" s={0.9} flip /></g>
    <rect x={120} y={430} width={720} height={30} rx={12} fill="#C9B79A" />
    <g opacity={ease(f, a1 + 10, a1 + 24)} transform="translate(330 380) rotate(-6)"><rect x={0} y={0} width={150} height={60} rx={6} fill="#fff" stroke={C.line} strokeWidth={3} /><rect x={14} y={14} width={90} height={9} rx={4} fill={C.line} /><rect x={14} y={34} width={60} height={9} rx={4} fill={C.teal} /></g>
    <g opacity={ease(f, a2, a2 + 14)} transform="translate(560 120)"><rect x={-70} y={-60} width={140} height={120} rx={20} fill={C.tealL} stroke={C.teal} strokeWidth={5} /><path d="M-30 0 L-8 22 L34 -22" stroke={C.green} strokeWidth={9} fill="none" strokeLinecap="round" /></g>
  </Stage>;
};
const Home: React.FC<{top: number; x: TX; n: string[]}> = ({top, x, n}) => {
  const f = useCurrentFrame();
  const a0 = atOf(x, n[0]), a1 = atOf(x, n[1]), a2 = atOf(x, n[2]);
  const rug = ease(f, a0 + 6, a0 + 30), light = ease(f, a1, a1 + 14), path = ease(f, a2, a2 + 40);
  return <Stage top={top} bg={light > 0.5 ? '#FBF5EA' : '#E9E6EE'}>
    <rect x={0} y={460} width={952} height={140} fill="#E5D9C6" />
    <g transform="translate(60 360)"><Bed x={0} y={0} s={0.7} /></g>
    <rect x={790} y={180} width={130} height={280} rx={8} fill="#F4F1EA" stroke="#C9B79A" strokeWidth={4} /><circle cx={810} cy={330} r={7} fill="#8C96A3" />
    <g opacity={1 - rug}><ellipse cx={520 + rug * 300} cy={510} rx={120} ry={26} fill="#C96F6F" /><path d={`M ${330} 540 Q 450 520 520 560 T 700 540`} stroke="#3A3F4A" strokeWidth={6} fill="none" /></g>
    <g transform="translate(360 300)"><rect x={-10} y={0} width={20} height={160} fill="#8C96A3" /><path d="M-50 0 h100 l-20 -60 h-60 Z" fill={light > 0.5 ? '#FFE08A' : '#D8D3C8'} />
      <circle cx={0} cy={-20} r={120} fill="#FFE08A" opacity={0.25 * light} /></g>
    <path d="M300 500 Q 550 470 800 470" stroke={C.green} strokeWidth={10} fill="none" strokeDasharray="20 16" strokeLinecap="round" pathLength={1} style={{strokeDasharray: `${path} 1`}} />
  </Stage>;
};
const Gear: React.FC<{top: number; x: TX; n: string[]}> = ({top, x, n}) => (
  <Stage top={top} bg="#F4F8FC">
    <IconCard cx={130} cy={300} at={atOf(x, n[0])}><WalkerF x={-35} y={-80} s={0.85} /></IconCard>
    <IconCard cx={360} cy={300} at={atOf(x, n[1])}><Crutch x={-30} y={-95} /><Crutch x={30} y={-95} /></IconCard>
    <IconCard cx={590} cy={300} at={atOf(x, n[2])}><Rail x={0} y={-10} /></IconCard>
    <IconCard cx={820} cy={300} at={atOf(x, n[3])}><Chair x={0} y={20} /></IconCard>
  </Stage>
);
const Program: React.FC<{top: number; d: number; x: TX; n: string[]}> = ({top, d, x, n}) => {
  const f = useCurrentFrame();
  const a2 = atOf(x, n[2]);
  const bone = (k: number) => [
    <g key="h"><path d="M-10 -80 L10 40" stroke="#E8DCC8" strokeWidth={26} strokeLinecap="round" /><circle cx={-12} cy={-80} r={24} fill="#E8DCC8" /><path d="M-60 -110 q40 10 60 40" stroke="#D8CBB4" strokeWidth={18} fill="none" /><circle cx={-12} cy={-80} r={40} fill={C.acc} opacity={0.25} /></g>,
    <g key="k"><path d="M0 -90 V-10 M0 10 V90" stroke="#E8DCC8" strokeWidth={26} strokeLinecap="round" /><ellipse cx={0} cy={0} rx={22} ry={12} fill="#D8CBB4" /><circle cx={0} cy={0} r={40} fill={C.acc} opacity={0.25} /></g>,
    <g key="s"><circle cx={-20} cy={-50} r={26} fill="#E8DCC8" /><path d="M-20 -50 L0 60" stroke="#E8DCC8" strokeWidth={24} strokeLinecap="round" /><path d="M-60 0 Q0 90 60 -10" stroke="#7FB8E0" strokeWidth={20} fill="none" strokeLinecap="round" /><circle cx={-20} cy={-50} r={40} fill={C.acc} opacity={0.25} /></g>,
    <g key="p">{[0, 1, 2, 3, 4].map((i) => <rect key={i} x={-24} y={-90 + i * 38} width={48} height={28} rx={8} fill="#E8DCC8" />)}<rect x={-24} y={-14} width={48} height={28} rx={8} fill={C.acc} opacity={0.5} /></g>,
  ][k];
  return <Stage top={top} bg="#F6F3FA">
    {[0, 1, 2, 3].map((k) => <IconCard key={k} cx={130 + k * 230} cy={250} at={6 + k * 10}>{bone(k)}</IconCard>)}
    <g transform="translate(80 450)" opacity={ease(f, a2, a2 + 10)}>
      {[0, 1, 2, 3, 4].map((i) => <rect key={i} x={i * 160} y={60 - i * 22} width={130} height={40 + i * 22} rx={12} fill={C.teal} opacity={ease(f, a2 + i * 8, a2 + 8 + i * 8)} />)}
    </g>
  </Stage>;
};
const Signs: React.FC<{top: number; d: number; x: TX; n: string[]}> = ({top, x, n}) => {
  const f = useCurrentFrame();
  const ic: [string, string][] = [[n[1], 'faint'], [n[2], 'therm'], [n[3], 'wound'], [n[4], 'calf']];
  return <Stage top={top} bg="#F4F8FC">
    <rect x={0} y={0} width={420} height={600} fill="#ECF7F1" />
    <g transform={`translate(${120 + ease(f, 0, 90) * 90} 330)`}><Person phase={f / 9} scale={0.8} /></g>
    <g transform="translate(330 90)" opacity={ease(f, 6, 18)}><circle r={46} fill="#fff" stroke={C.green} strokeWidth={6} /><path d="M-20 0 L-6 14 L22 -16" stroke={C.green} strokeWidth={8} fill="none" strokeLinecap="round" /></g>
    {ic.map(([t, k], i) => { const at = atOf(x, t); return <g key={k} opacity={ease(f, at, at + 10)} transform={`translate(${540 + (i % 2) * 200} ${150 + Math.floor(i / 2) * 230})`}>
      <circle r={80} fill={C.bloodL} stroke={C.blood} strokeWidth={6} /><g transform="translate(-48 -48) scale(1.5)"><Icon k={k} s={64} c={C.blood} /></g></g>; })}
  </Stage>;
};
const Ambulance: React.FC<{top: number; x: TX; n: string[]}> = ({top, x, n}) => {
  const f = useCurrentFrame();
  const a0 = atOf(x, n[0]);
  return <Stage top={top} bg="#FBF1F1">
    <g transform="translate(200 50)" opacity={ease(f, 0, 12)}><rect x={0} y={0} width={240} height={480} rx={36} fill={C.navy} /><rect x={14} y={40} width={212} height={400} rx={14} fill="#fff" />
      <text x={120} y={160} textAnchor="middle" fontFamily={HEAD} fontWeight={800} fontSize={90} fill={C.blood} direction="ltr" opacity={ease(f, a0, a0 + 10)}>101</text>
      <circle cx={120} cy={330} r={56} fill={C.green} opacity={ease(f, a0 + 6, a0 + 16)} /><path d="M98 312 q10 40 44 40 l8 -14 l-18 -12 l-8 8 q-12 -6 -16 -20 l8 -8 l-12 -18 Z" fill="#fff" opacity={ease(f, a0 + 6, a0 + 16)} /></g>
    {[['lungs', 1], ['heart', 2], ['faint', 3]].map(([k, j], i) => { const at = atOf(x, n[j as number]); return <g key={k as string} opacity={ease(f, at, at + 10)} transform={`translate(640 ${110 + i * 170})`}><circle r={70} fill="#fff" stroke={C.blood} strokeWidth={6} /><g transform="translate(-48 -48) scale(1.5)"><Icon k={k as string} s={64} c={C.blood} /></g></g>; })}
  </Stage>;
};
const Discharge: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  return <Stage top={top} h={560} bg="#F4F8FC">
    <rect x={0} y={440} width={952} height={120} fill="#E4EAF1" />
    <g opacity={ease(f, 0, 12)}><Bust x={200} y={300} col="#8DA9C4" hair={GREY} /><Bust x={360} y={320} col="#E3B48F" s={0.9} /></g>
    <g opacity={ease(f, 6, 18)}><Bust x={780} y={300} col={C.teal} cap flip /></g>
    <g transform={`translate(${640 - ease(f, fr(d, 0.15), fr(d, 0.35)) * 160} 340) rotate(-8)`}><rect x={0} y={0} width={130} height={170} rx={8} fill="#fff" stroke={C.line} strokeWidth={4} />{[0, 1, 2, 3].map((i) => <rect key={i} x={16} y={24 + i * 32} width={i % 2 ? 60 : 90} height={10} rx={5} fill={C.line} />)}<rect x={16} y={24} width={30} height={10} rx={5} fill={C.teal} /></g>
  </Stage>;
};

const scene = (x: TX, d: number, L: Dict) => {
  const n = L.n[x.id];
  const a = (s: string) => atOf(x, s);
  const T: [string, string][] = [[C.navy, NV], [C.teal, C.tealL], [C.acc, C.accL], [C.blood, C.bloodL]];
  const notes = (y: number, idx: number[], cols: number[]) => <Notes y={y} items={idx.map((k, j) => [n[k], a(n[k]), ...T[cols[j]]] as [string, number, string, string])} />;
  switch (x.id) {
    case 'RH01': return <><Hall top={440} d={d} />{notes(1080, [0, 1, 2], [0, 1, 2])}</>;
    case 'RH02': return <><Hard top={440} d={d} x={x} n={n} />{notes(1080, [0, 1, 2], [0, 0, 2])}</>;
    case 'RH03': return <><Team top={440} x={x} n={n} />{notes(1080, [0, 1, 2, 3, 4], [1, 1, 1, 1, 0])}</>;
    case 'RH04': return <><Places top={440} x={x} n={n} />{notes(1080, [4, 0, 1, 2, 3], [2, 1, 1, 1, 1])}</>;
    case 'RH05': return <><Decide top={440} d={d} x={x} n={n} />{notes(1080, [0, 1, 2], [0, 1, 2])}</>;
    case 'RH06': return <><Home top={440} x={x} n={n} />{notes(1080, [0, 1, 2], [2, 0, 1])}</>;
    case 'RH07': return <><Gear top={440} x={x} n={n} />{notes(1080, [0, 1, 2, 3, 4], [1, 1, 1, 1, 2])}</>;
    case 'RH08': return <><Program top={440} d={d} x={x} n={n} />{notes(1080, [0, 1, 2], [0, 2, 1])}</>;
    case 'RH09': return <><Signs top={440} d={d} x={x} n={n} />{notes(1080, [0, 1, 2, 3, 4, 5], [1, 3, 3, 3, 3, 3])}</>;
    case 'RH10': return <><Ambulance top={440} x={x} n={n} />{notes(1080, [0, 1, 2, 3], [3, 3, 3, 3])}</>;
    case 'RH11': return <><Discharge top={440} d={d} />{notes(1020, [0, 1, 2], [0, 0, 0])}
      <Card x={64} y={1190} w={952} at={a(n[3])} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
        <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, lineHeight: 1.25, color: C.ink}}>{n[3]}</div>
      </Card></>;
  }
  return null;
};

export const mkRehabv = (lang: string, timing: unknown) => {
  const TT = timing as TX[];
  const L = N[lang];
  const total = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
  const Comp: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
    let at = 0;
    return <AbsoluteFill style={{direction: L.rtl ? 'rtl' : 'ltr'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={L.brand} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} size={x.head.length >= 28 ? 50 : undefined} />
            {scene(x, d, L)}
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>;
  };
  return {Comp, total};
};
const ru = mkRehabv('ru', tRu); export const Rehabv = ru.Comp; export const totalRehabv = ru.total;
const en = mkRehabv('en', tEn); export const RehabvEn = en.Comp; export const totalRehabvEn = en.total;
const he = mkRehabv('he', tHe); export const RehabvHe = he.Comp; export const totalRehabvHe = he.total;
const ar = mkRehabv('ar', tAr); export const RehabvAr = ar.Comp; export const totalRehabvAr = ar.total;
