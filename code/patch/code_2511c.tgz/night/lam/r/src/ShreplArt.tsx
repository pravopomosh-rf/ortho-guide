// Рисунки для ролика «Эндопротезирование плечевого сустава» (shrepl). Только схемы; все надписи приходят из Shrepl.tsx (одобренный текст).
import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C, ease, BODY} from './kit';

const fr = (d: number, p: number) => Math.round(d * p);
const BONE = '#F4ECDD', BONES = '#C9B99A', CART = '#BFE3EC', CARTS = '#7FC0CF';
const MET = 'url(#srMetal)', METS = '#5E6977', POLY = '#F7FAFF', POLYS = '#8FA6C4';
const SKIN = '#E9C9AE', SKINS = '#C99B7A', SHIRT = '#7FA7C9', SHIRTS = '#4F7FA6';
const MUS = '#D9686A', TEND = '#EFE3C8', TENDS = '#C9B48A';

export const Frame: React.FC<{top: number; h: number; o?: number; children: React.ReactNode}> = ({top, h, o = 1, children}) =>
  <div style={{position: 'absolute', left: 64, top, width: 952, height: h, borderRadius: 34, overflow: 'hidden', opacity: o,
    background: 'linear-gradient(160deg,#FFFFFF 0%,#EEF4F8 100%)', boxShadow: '0 18px 44px rgba(20,40,60,.12)'}}>{children}</div>;

const Defs: React.FC = () => <defs>
  <linearGradient id="srMetal" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#F2F5F8" /><stop offset="0.45" stopColor="#B9C3CF" /><stop offset="1" stopColor="#7D8896" /></linearGradient>
  <radialGradient id="srBone" cx="40%" cy="35%" r="75%"><stop offset="0" stopColor="#FFF9EE" /><stop offset="1" stopColor={BONE} /></radialGradient>
</defs>;

export type JMode = 'natural' | 'worn' | 'tear' | 'fracture' | 'anat' | 'rev' | 'op';
// Правое плечо спереди (схема): ключица, лопатка с суставной впадиной, плечевая кость; дельтовидная мышца полупрозрачно.
// lift — отведение руки (град.), dis — вывих 0..1, op — 0..1 переход «изношенный сустав → протез», delt — яркость дельтовидной мышцы
export const Joint: React.FC<{mode: JMode; lift?: number; dis?: number; op?: number; delt?: number; w?: number; h?: number}> = ({mode, lift = 0, dis = 0, op = 0, delt = 0.25, w = 952, h = 560}) => {
  const rev = mode === 'rev';
  const showAnat = mode === 'anat' || (mode === 'op' && op > 0);
  const worn = mode === 'worn' || (mode === 'op');
  const wornO = mode === 'op' ? 1 - Math.min(1, op * 1.6) : 1;
  const hx = rev ? 452 : 462, hy = rev ? 262 : 240;
  return <svg width={w} height={h} viewBox="0 0 952 560" style={{display: 'block', direction: 'ltr'}}>
    <Defs />
    {/* лопатка */}
    <path d="M 170 150 L 392 168 L 398 318 L 300 500 L 196 318 Z" fill="url(#srBone)" stroke={BONES} strokeWidth={4} />
    <path d="M 220 210 L 380 200" stroke={BONES} strokeWidth={3} opacity={0.6} />
    {/* ключица и акромион */}
    <path d="M 110 96 C 220 70 330 84 430 112" stroke={BONES} strokeWidth={34} strokeLinecap="round" fill="none" />
    <path d="M 110 96 C 220 70 330 84 430 112" stroke={BONE} strokeWidth={26} strokeLinecap="round" fill="none" />
    <path d="M 340 130 Q 420 104 500 140" stroke={BONES} strokeWidth={30} strokeLinecap="round" fill="none" />
    <path d="M 340 130 Q 420 104 500 140" stroke={BONE} strokeWidth={22} strokeLinecap="round" fill="none" />
    {/* суставная впадина (хрящ) */}
    {!rev && <ellipse cx={398} cy={240} rx={13} ry={62} fill={mode === 'worn' || (mode === 'op' && op < 0.5) ? '#E5D6BC' : CART} stroke={mode === 'worn' ? BONES : CARTS} strokeWidth={3} />}
    {/* анатомический: полиэтиленовая впадина на лопатке */}
    {!rev && <g opacity={mode === 'anat' ? 1 : mode === 'op' ? ease(op * 100, 55, 85) : 0}>
      <path d="M 392 176 Q 430 240 392 304 L 404 304 Q 444 240 404 176 Z" fill={POLY} stroke={POLYS} strokeWidth={4} />
    </g>}
    {/* реверсивный: металлический шар на лопатке */}
    {rev && <g>
      <rect x={386} y={214} width={22} height={52} rx={6} fill={MET} stroke={METS} strokeWidth={3} />
      <path d={`M 404 192 A 50 50 0 0 1 404 292 Z`} fill={MET} stroke={METS} strokeWidth={4} />
    </g>}
    {/* плечевая кость (вращается вокруг головки) */}
    <g transform={`translate(${dis * 60} ${dis * 120}) rotate(${-lift + dis * 12} ${hx} ${hy})`}>
      <path d={rev ? 'M 450 300 Q 480 318 512 300 L 548 548 L 494 552 Z' : 'M 440 285 Q 470 310 505 290 L 540 548 L 488 552 Z'} fill="url(#srBone)" stroke={BONES} strokeWidth={4} opacity={showAnat || rev ? 0.75 : 1} />
      {/* натуральная или изношенная головка */}
      {!rev && <g opacity={mode === 'anat' ? 0 : mode === 'op' ? wornO : 1}>
        <circle cx={462} cy={240} r={62} fill="url(#srBone)" stroke={BONES} strokeWidth={4} />
        {!worn && mode !== 'fracture' && <path d="M 414 196 A 62 62 0 0 0 414 284" stroke={CARTS} strokeWidth={10} fill="none" strokeLinecap="round" />}
        {worn && <g opacity={wornO}>
          <path d="M 406 214 l -14 -8 M 408 268 l -14 8 M 440 182 l -6 -14" stroke={BONES} strokeWidth={7} strokeLinecap="round" />
          <circle cx={430} cy={226} r={9} fill="#B99A7A" opacity={0.6} /><circle cx={440} cy={262} r={7} fill="#B99A7A" opacity={0.6} /><circle cx={424} cy={248} r={5} fill="#B99A7A" opacity={0.6} />
        </g>}
        {mode === 'fracture' && <path d="M 430 300 L 452 262 L 440 236 L 470 206 L 486 180" stroke={C.acc} strokeWidth={6} fill="none" strokeLinecap="round" strokeLinejoin="round" />}
      </g>}
      {/* анатомический протез: металлическая головка + ножка */}
      {!rev && <g opacity={mode === 'anat' ? 1 : mode === 'op' ? ease(op * 100, 40, 75) : 0}>
        <path d="M 470 282 L 496 282 L 520 506 L 502 510 Z" fill={MET} stroke={METS} strokeWidth={3} />
        <path d="M 430 196 A 62 62 0 1 1 430 284 L 446 274 L 446 206 Z" fill={MET} stroke={METS} strokeWidth={4} />
      </g>}
      {/* реверсивный протез: чашка на плечевой кости + ножка */}
      {rev && <g>
        <path d="M 474 300 L 500 300 L 526 512 L 506 516 Z" fill={MET} stroke={METS} strokeWidth={3} />
        <path d="M 430 196 A 54 54 0 0 1 452 316 L 478 300 A 74 74 0 0 0 446 182 Z" fill={POLY} stroke={POLYS} strokeWidth={4} />
        <path d="M 446 182 A 74 74 0 0 1 478 300 L 492 312 A 90 90 0 0 0 452 168 Z" fill={MET} stroke={METS} strokeWidth={4} />
      </g>}
    </g>
    {/* сухожилие вращательной манжеты (поверх головки) */}
    {!rev && mode !== 'anat' && mode !== 'op' && <g transform={`rotate(${-lift} 462 240)`} opacity={dis > 0 ? 1 - dis : 1}>
      {mode === 'tear' ? <>
        <path d="M 300 172 Q 380 160 430 172" stroke={TENDS} strokeWidth={22} strokeLinecap="round" fill="none" />
        <path d="M 300 172 Q 380 160 430 172" stroke={TEND} strokeWidth={16} strokeLinecap="round" fill="none" />
        <path d="M 488 184 Q 510 196 518 214" stroke={TENDS} strokeWidth={22} strokeLinecap="round" fill="none" />
        <path d="M 488 184 Q 510 196 518 214" stroke={TEND} strokeWidth={16} strokeLinecap="round" fill="none" />
        <path d="M 440 168 l 10 8 l -6 6 l 12 8" stroke={C.acc} strokeWidth={5} fill="none" strokeLinecap="round" />
      </> : <>
        <path d="M 300 172 Q 420 150 518 214" stroke={TENDS} strokeWidth={22} strokeLinecap="round" fill="none" opacity={0.9} />
        <path d="M 300 172 Q 420 150 518 214" stroke={TEND} strokeWidth={16} strokeLinecap="round" fill="none" opacity={0.9} />
      </>}
    </g>}
    {/* дельтовидная мышца */}
    <g transform={`rotate(${-lift} ${hx} ${hy})`} opacity={delt}>
      <path d="M 352 112 Q 560 96 556 300 L 532 440 Q 520 330 494 260 Q 470 180 352 112 Z" fill={MUS} stroke="#A9393C" strokeWidth={3} />
      {[0, 1, 2, 3].map((i) => <path key={i} d={`M ${380 + i * 34} ${118 + i * 4} Q ${520 + i * 6} ${200 + i * 10} ${528 - i * 2} ${400 - i * 30}`} stroke="#B9484B" strokeWidth={2} fill="none" opacity={0.7} />)}
    </g>
  </svg>;
};

// Метка-подпись поверх рисунка (HTML, чтобы RTL-текст шёл правильно)
export const Tag: React.FC<{x: number; y: number; at: number; t: string; col?: string; bg?: string; size?: number}> = ({x, y, at, t, col = C.navy, bg = 'rgba(255,255,255,.92)', size = 26}) => {
  const f = useCurrentFrame(); const o = ease(f, at, at + 10);
  return <div style={{position: 'absolute', left: x, top: y, opacity: o, transform: `translateY(${(1 - o) * 10}px)`, fontFamily: BODY, fontWeight: 800, fontSize: size, color: col,
    background: bg, borderRadius: 14, padding: '6px 14px', boxShadow: '0 6px 16px rgba(20,40,60,.10)', whiteSpace: 'nowrap'}}>{t}</div>;
};

// SP01: сустав-«шар во впадине», рука поднимается
export const BallSocket: React.FC<{top: number; d: number; ball: string; socket: string}> = ({top, d, ball, socket}) => {
  const f = useCurrentFrame();
  const lift = 28 * (0.5 - 0.5 * Math.cos(Math.max(0, f - fr(d, 0.25)) / 22)) * ease(f, fr(d, 0.25), fr(d, 0.3));
  return <div style={{position: 'absolute', left: 64, top, width: 952, height: 560}}>
    <Frame top={0} h={560}><Joint mode="natural" lift={lift} delt={0.18} /></Frame>
    <Tag x={560} y={150} at={fr(d, 0.06)} t={ball} col={C.teal} />
    <Tag x={40} y={300} at={fr(d, 0.12)} t={socket} col={C.teal} />
  </div>;
};

// SP02: три причины — мини-суставы
export const Causes: React.FC<{top: number; d: number; items: string[]}> = ({top, d, items}) => {
  const f = useCurrentFrame();
  const modes: JMode[] = ['worn', 'tear', 'fracture'];
  return <div style={{position: 'absolute', left: 64, right: 64, top, display: 'flex', flexDirection: 'column', gap: 18}}>
    {items.map((t, i) => {
      const a = fr(d, 0.04 + i * 0.13), p = ease(f, a, a + 10);
      return <div key={i} style={{opacity: p, transform: `translateY(${(1 - p) * 20}px)`, background: '#fff', borderRadius: 26, boxShadow: '0 12px 30px rgba(20,40,60,.10)',
        display: 'flex', alignItems: 'center', gap: 20, padding: '10px 24px 10px 10px', minHeight: 150}}>
        <div style={{position: 'relative', width: 230, height: 136, borderRadius: 18, overflow: 'hidden', background: '#F2F6F9', flex: 'none', direction: 'ltr'}}>
          <div style={{position: 'absolute', left: -162, top: -62}}><Joint mode={modes[i]} w={571} h={336} delt={0} /></div>
        </div>
        <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 30, color: C.ink, lineHeight: 1.22}}>{t}</div>
      </div>;
    })}
  </div>;
};

// SP03/SP04: анатомический и реверсивный протез рядом; hl — какой выделен
export const TwoProst: React.FC<{top: number; d: number; hl: 'anat' | 'rev'; tA: string; tR: string; bone: string; blade: string; deltLbl?: string}> = ({top, d, hl, tA, tR, bone, blade, deltLbl}) => {
  const f = useCurrentFrame();
  const lift = hl === 'rev' ? 24 * ease(f, fr(d, 0.55), fr(d, 0.75)) : 0;
  const delt = hl === 'rev' ? 0.25 + 0.6 * ease(f, fr(d, 0.5), fr(d, 0.6)) : 0.12;
  const panel = (k: 'anat' | 'rev', x: number, title: string) => {
    const on = k === hl;
    return <div style={{position: 'absolute', left: x, top: 0, width: 466, height: 640, borderRadius: 30, overflow: 'hidden', background: '#fff',
      boxShadow: on ? `0 0 0 6px ${C.teal}, 0 18px 40px rgba(20,40,60,.14)` : '0 12px 30px rgba(20,40,60,.08)', opacity: on ? 1 : 0.55}}>
      <div style={{position: 'absolute', left: 0, right: 0, top: 18, textAlign: 'center', fontFamily: BODY, fontWeight: 800, fontSize: 32, color: on ? C.teal : C.mute}}>{title}</div>
      <div style={{position: 'absolute', left: -210, top: 40, transform: 'scale(0.92)', transformOrigin: '50% 0'}}>
        <Joint mode={k} lift={k === 'rev' ? lift : 0} delt={k === 'rev' ? delt : 0.1} w={952} h={560} />
      </div>
    </div>;
  };
  return <div style={{position: 'absolute', left: 64, top, width: 952, height: 640}}>
    {panel('anat', 0, tA)}{panel('rev', 486, tR)}
    <Tag x={hl === 'anat' ? 20 : 506} y={560} at={fr(d, 0.3)} t={blade} size={24} />
    <Tag x={hl === 'anat' ? 230 : 716} y={500} at={fr(d, 0.4)} t={bone} size={24} />
    {deltLbl && <Tag x={700} y={86} at={fr(d, 0.52)} t={deltLbl} col={C.blood} size={24} />}
  </div>;
};

// SP05: изношенные поверхности удаляются → компоненты протеза
export const OpSwap: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const op = ease(f, fr(d, 0.55), fr(d, 0.9));
  const cut = ease(f, fr(d, 0.45), fr(d, 0.55)) * (1 - ease(f, fr(d, 0.6), fr(d, 0.7)));
  return <Frame top={top} h={470}>
    <div style={{position: 'absolute', left: 0, top: -40}}><Joint mode="op" op={op} delt={0.08} /></div>
    <svg width={952} height={470} style={{position: 'absolute', left: 0, top: 0}}>
      <path d="M 520 40 L 520 420" stroke={C.acc} strokeWidth={6} strokeDasharray="16 12" opacity={cut} />
    </svg>
  </Frame>;
};

// Фигура с рукой в поддерживающем бандаже (+ повязка, холод, движения пальцев)
export const SlingFig: React.FC<{top: number; d: number; ice?: number; fingers?: boolean; dress?: number; lock?: number}> = ({top, d, ice = 0, fingers, dress = 0, lock = 0}) => {
  const f = useCurrentFrame();
  const k = fingers ? (1 - Math.cos(f / 8)) / 2 : 0;
  return <Frame top={top} h={520}>
    <svg width={952} height={520} style={{position: 'absolute', left: 0, top: 0, direction: 'ltr'}}>
      <g transform="translate(-64 0)">
        <circle cx={540} cy={92} r={60} fill={SKIN} stroke={SKINS} strokeWidth={4} />
        <path d="M 512 146 L 568 146 L 570 176 L 510 176 Z" fill={SKIN} stroke={SKINS} strokeWidth={3} />
        <path d="M 410 176 L 670 176 L 696 520 L 384 520 Z" fill={SHIRT} stroke={SHIRTS} strokeWidth={4} />
        {/* больное плечо (слева на рисунке = правое плечо пациента) */}
        <path d="M 420 180 Q 380 200 386 330 L 404 360 L 560 330" stroke={SKIN} strokeWidth={50} fill="none" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M 420 180 Q 380 200 386 330 L 404 360 L 560 330" stroke={SKINS} strokeWidth={54} fill="none" strokeLinecap="round" strokeLinejoin="round" opacity={0.25} />
        {/* кисть и пальцы */}
        <g transform="translate(572 322)">
          <ellipse cx={0} cy={0} rx={30} ry={24} fill={SKIN} stroke={SKINS} strokeWidth={3} />
          {[0, 1, 2, 3].map((i) => <rect key={i} x={20} y={-20 + i * 11} width={34 - k * 16} height={10} rx={5} fill={SKIN} stroke={SKINS} strokeWidth={2} />)}
        </g>
        {/* бандаж */}
        <path d="M 380 312 L 590 290 L 604 372 L 396 396 Z" fill={C.teal} opacity={0.88} />
        <path d="M 600 300 L 640 178" stroke={C.teal} strokeWidth={14} strokeLinecap="round" />
        <path d="M 392 320 L 440 178" stroke={C.teal} strokeWidth={14} strokeLinecap="round" opacity={0.7} />
        {/* повязка на плече */}
        <rect x={386} y={176} width={74} height={92} rx={14} fill="#fff" stroke="#C9D2DC" strokeWidth={4} opacity={dress} />
        {/* холод: пакет поверх ткани */}
        <g opacity={ice} transform={`translate(0 ${Math.sin(f / 10) * 2})`}>
          <rect x={360} y={168} width={120} height={110} rx={20} fill="#EAF6FF" stroke="#8CC7EE" strokeWidth={5} />
          <rect x={370} y={178} width={100} height={90} rx={16} fill="#BFE3FA" opacity={0.85} />
          {[[420, 222]].map(([x, y], i) => <g key={i} stroke="#4E9BD1" strokeWidth={5} strokeLinecap="round">
            <line x1={x - 22} y1={y} x2={x + 22} y2={y} /><line x1={x} y1={y - 22} x2={x} y2={y + 22} /><line x1={x - 16} y1={y - 16} x2={x + 16} y2={y + 16} /><line x1={x - 16} y1={y + 16} x2={x + 16} y2={y - 16} /></g>)}
        </g>
        {/* движения пальцев/кисти/локтя */}
        {fingers && <g stroke={C.green} strokeWidth={6} fill="none" strokeLinecap="round" opacity={0.9}>
          <path d={`M 640 280 A 60 60 0 0 1 650 370`} strokeDasharray="12 10" />
          <circle cx={404} cy={360} r={30 + k * 6} opacity={0.6} />
        </g>}
        {/* замок на плече — без самостоятельного подъёма руки */}
        <g opacity={lock} transform="translate(330 120)">
          <rect x={0} y={26} width={64} height={52} rx={10} fill={C.blood} />
          <path d="M 12 28 V 16 a 20 20 0 0 1 40 0 V 28" stroke={C.blood} strokeWidth={8} fill="none" />
        </g>
      </g>
    </svg>
  </Frame>;
};

// SP09: карточки «нельзя» с пиктограммами
const Pic: React.FC<{k: string}> = ({k}) => <svg width={96} height={96} viewBox="0 0 96 96" style={{direction: 'ltr'}}>
  {k === 'lean' && <g><rect x={10} y={66} width={76} height={10} rx={4} fill="#9AA6B4" /><rect x={40} y={10} width={18} height={56} rx={9} fill={SKIN} stroke={SKINS} strokeWidth={2} /><path d="M 49 30 v 24 M 41 46 l 8 8 l 8 -8" stroke={C.acc} strokeWidth={4} fill="none" strokeLinecap="round" /></g>}
  {k === 'push' && <g><rect x={14} y={50} width={60} height={14} rx={5} fill="#9AA6B4" /><rect x={14} y={24} width={12} height={40} rx={5} fill="#9AA6B4" /><rect x={20} y={64} width={6} height={20} fill="#9AA6B4" /><rect x={64} y={64} width={6} height={20} fill="#9AA6B4" /><path d="M 70 46 V 14 M 60 24 l 10 -10 l 10 10" stroke={C.acc} strokeWidth={5} fill="none" strokeLinecap="round" /></g>}
  {k === 'bag' && <g><path d="M 34 34 Q 48 12 62 34" stroke="#8B5E3C" strokeWidth={6} fill="none" /><rect x={20} y={34} width={56} height={48} rx={10} fill="#C98B55" stroke="#8B5E3C" strokeWidth={3} /></g>}
  {k === 'pos' && <g><circle cx={48} cy={48} r={16} fill={BONE} stroke={BONES} strokeWidth={3} /><path d="M 22 30 A 32 32 0 0 1 78 34" stroke={C.acc} strokeWidth={5} fill="none" strokeLinecap="round" /><path d="M 72 22 l 6 12 l -12 2" stroke={C.acc} strokeWidth={5} fill="none" strokeLinecap="round" /></g>}
  {k === 'bed' && <g><rect x={8} y={62} width={80} height={10} rx={4} fill="#9AA6B4" /><path d="M 14 62 L 30 30 L 40 34 L 30 62 Z" fill={C.tealL} stroke={C.teal} strokeWidth={3} /><rect x={36} y={52} width={50} height={10} rx={4} fill={C.tealL} stroke={C.teal} strokeWidth={3} /><circle cx={30} cy={24} r={8} fill={SKIN} /></g>}
  {k === 'shirt' && <g><path d="M 30 16 L 18 24 L 10 40 L 22 46 L 26 38 L 26 84 L 70 84 L 70 38 L 74 46 L 86 40 L 78 24 L 66 16 Q 48 28 30 16 Z" fill={SHIRT} stroke={SHIRTS} strokeWidth={3} /><line x1={48} y1={26} x2={48} y2={84} stroke={SHIRTS} strokeWidth={3} />{[40, 54, 68].map((y) => <circle key={y} cx={52} cy={y} r={3} fill="#fff" />)}</g>}
  {k === 'shower' && <g><path d="M 20 20 h 36 a 12 12 0 0 1 12 12" stroke={C.teal} strokeWidth={6} fill="none" strokeLinecap="round" /><rect x={56} y={30} width={24} height={8} rx={3} fill={C.teal} />{[0, 1, 2].map((i) => <line key={i} x1={60 + i * 8} y1={46} x2={58 + i * 8} y2={62} stroke="#4E9BD1" strokeWidth={4} strokeLinecap="round" />)}<rect x={14} y={70} width={40} height={14} rx={6} fill="#fff" stroke="#C9D2DC" strokeWidth={3} /></g>}
  {k === 'er' && <g><rect x={14} y={30} width={68} height={52} rx={6} fill="#fff" stroke={C.blood} strokeWidth={4} /><path d="M 48 40 v 32 M 32 56 h 32" stroke={C.blood} strokeWidth={8} strokeLinecap="round" /><path d="M 10 32 L 48 10 L 86 32" stroke={C.blood} strokeWidth={5} fill="none" strokeLinecap="round" /></g>}
  {k === 'hand' && <g><path d="M 30 80 V 40 a 6 6 0 0 1 12 0 V 30 a 6 6 0 0 1 12 0 V 34 a 6 6 0 0 1 12 0 V 44 a 6 6 0 0 1 12 0 V 64 Q 78 82 60 84 Z" fill={SKIN} stroke={SKINS} strokeWidth={3} /></g>}
</svg>;

export const Rows: React.FC<{top: number; d: number; items: [string, string][]; no?: boolean; start?: number; step?: number; size?: number; gap?: number}> = ({top, d, items, no, start = 0.04, step = 0.15, size = 30, gap = 16}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top, display: 'flex', flexDirection: 'column', gap}}>
    {items.map(([k, t], i) => {
      const a = fr(d, start + i * step), p = ease(f, a, a + 10), x = ease(f, a + 8, a + 16);
      return <div key={i} style={{opacity: p, transform: `translateY(${(1 - p) * 18}px)`, background: '#fff', borderRadius: 26, boxShadow: '0 12px 30px rgba(20,40,60,.10)',
        display: 'flex', alignItems: 'center', gap: 20, padding: '12px 24px 12px 14px', minHeight: 120, borderInlineStart: no ? `10px solid ${C.blood}` : `10px solid ${C.teal}`}}>
        <div style={{position: 'relative', width: 104, height: 104, borderRadius: 20, background: no ? C.bloodL : C.tealL, display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none'}}>
          <Pic k={k} />
          {no && <svg width={104} height={104} style={{position: 'absolute', left: 0, top: 0, opacity: x}}><circle cx={52} cy={52} r={44} fill="none" stroke={C.blood} strokeWidth={7} /><line x1={22} y1={82} x2={82} y2={22} stroke={C.blood} strokeWidth={7} strokeLinecap="round" /></svg>}
        </div>
        <div style={{fontFamily: BODY, fontWeight: 800, fontSize: size, color: C.ink, lineHeight: 1.22}}>{t}</div>
      </div>;
    })}
  </div>;
};

// SP12: вывих — головка выходит из впадины
export const Dislocate: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const k = ease(f, fr(d, 0.25), fr(d, 0.4));
  const shake = k > 0.95 ? Math.sin(f / 2) * 1.5 : 0;
  return <Frame top={top} h={460}>
    <div style={{position: 'absolute', left: shake, top: -60}}><Joint mode="anat" dis={k} delt={0.1} /></div>
    <svg width={952} height={460} style={{position: 'absolute', left: 0, top: 0}}>
      <circle cx={470} cy={230} r={110} fill="none" stroke={C.blood} strokeWidth={6} strokeDasharray="14 10" opacity={k} />
    </svg>
  </Frame>;
};
