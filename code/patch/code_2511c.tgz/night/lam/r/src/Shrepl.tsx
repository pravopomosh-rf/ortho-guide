// «Эндопротезирование плечевого сустава» — ролик для пациентов (9:16), сверху ops/shoulder-replacement.html. Тексты SP01–SP12 ОДОБРЕНО ChatGPT (tts-data shrepl.json);
// все надписи — фрагменты одобренного текста / заголовков одобренной страницы (tools/shrepl_page.json).
import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Subtitle, Note, C, BODY, HEAD, ease, Word} from './kit';
import {Phone101} from './UrgentArt';
import {BallSocket, Causes, TwoProst, OpSwap, SlingFig, Rows, Dislocate} from './ShreplArt';
import tRu from './timing_shrepl.json';
import tHe from './timing_shrepl_he.json';
import tAr from './timing_shrepl_ar.json';
import tEn from './timing_shrepl_en.json';

type TT = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const FPS = 30, PAD = 0.5;
const fr = (d: number, p: number) => Math.round(d * p);
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};

type Dict = {brand: string; rtl?: boolean; n: Record<string, string[]>; end: string};
const N: Record<string, Dict> = {
  ru: {
    brand: 'ОРТОПЕДИЯ · ПАЦИЕНТАМ',
    n: {
      SP01: ['шар', 'суставная впадина', 'поднимаем руку', 'одеваемся', 'берём предметы', 'даже простые движения могут вызывать боль'],
      SP02: ['тяжёлый артроз', 'разрушение сустава после большого разрыва сухожилий', 'сложный перелом', 'если другие методы не помогают', 'травматолог-ортопед может предложить эндопротезирование'],
      SP03: ['Анатомический', 'Реверсивный', 'плечевая кость', 'лопатка', 'сухожилия вращательной манжеты сохранены и хорошо работают'],
      SP04: ['Анатомический', 'Реверсивный', 'плечевая кость', 'лопатка', 'дельтовидная мышца', 'даже когда сухожилия вращательной манжеты сильно повреждены'],
      SP05: ['анестезиолог объяснит обезболивание', 'общий наркоз, иногда вместе с блокадой нервов плеча', 'удаляет повреждённые суставные поверхности', 'устанавливает компоненты протеза'],
      SP06: ['палата пробуждения', 'повязка', 'поддерживающий бандаж', 'боль · чувствительность · движения пальцев'],
      SP07: ['боль и отёк ожидаемы', 'обезболивание', 'холод — только так, как объяснит персонал', 'защищая кожу от переохлаждения'],
      SP08: ['индивидуальный план', 'пальцы · кисть · локоть', 'самостоятельно поднимать оперированную руку нельзя', 'новые упражнения без разрешения нельзя'],
      SP09: ['нельзя опираться на оперированную руку', 'нельзя отталкиваться ею от кровати или кресла', 'нельзя поднимать тяжести', 'некоторые положения плеча временно запрещены', 'Точные ограничения и сроки определяет лечащий врач'],
      SP10: ['спать на спине или с приподнятой верхней частью тела', 'свободная одежда, лучше с застёжкой спереди', 'душ, снятие бандажа и уход за раной — только по инструкциям'],
      SP11: ['температура', 'выделения из раны', 'нарастающая боль', 'новое онемение или побледнение пальцев', 'срочная медицинская оценка', 'внезапная одышка или боль в груди → 101'],
      SP12: ['возможное, но нечастое осложнение', 'плечо внезапно изменило форму · резкая боль · рука перестала нормально двигаться', 'не пытайтесь вправить сустав самостоятельно', 'срочно — в приёмное отделение'],
    },
    end: 'Указания врача важнее',
  },
  en: {
    brand: 'ORTHOPAEDICS · FOR PATIENTS',
    n: {
      SP01: ['ball', 'socket', 'lift your arm', 'get dressed', 'hold things', 'even simple movements can become painful'],
      SP02: ['severe arthritis', 'joint damage after a large rotator cuff tear', 'a complex fracture', 'if other treatments do not help', 'your orthopaedic surgeon may recommend shoulder replacement'],
      SP03: ['Anatomical', 'Reverse', 'upper arm bone', 'shoulder blade', 'the rotator cuff tendons are intact and working well'],
      SP04: ['Anatomical', 'Reverse', 'upper arm bone', 'shoulder blade', 'deltoid muscle', 'even when the rotator cuff tendons are badly damaged'],
      SP05: ['the anaesthetist will explain your anaesthesia and pain relief', 'general anaesthesia, sometimes with a nerve block around the shoulder', 'removes the damaged joint surfaces', 'places the implant components'],
      SP06: ['recovery room', 'dressing', 'sling', 'pain · sensation · finger movements'],
      SP07: ['some pain and swelling are expected', 'pain relief', 'cold packs only as instructed by the team', 'protect your skin from cold injury'],
      SP08: ['individual recovery plan', 'fingers · wrist · elbow', 'do not lift your operated arm by yourself', 'no new exercises without permission'],
      SP09: ['do not put weight through your operated arm', 'do not push yourself up from a bed or chair with it', 'do not lift heavy objects', 'some shoulder positions may be temporarily restricted', 'Your doctor will explain exactly what you can do and for how long'],
      SP10: ['sleep on your back or with your upper body raised', 'loose clothes, preferably with fastenings at the front', 'showering, removing the sling, wound care: follow your instructions'],
      SP11: ['fever', 'discharge from the wound', 'increasing pain', 'new numbness or pale fingers', 'urgent medical assessment', 'sudden shortness of breath or chest pain → call 101'],
      SP12: ['possible but uncommon', 'shoulder suddenly changes shape · severe pain · you cannot move your arm normally', 'do not try to put the joint back yourself', 'go to the emergency department urgently'],
    },
    end: "Your care team's instructions take priority",
  },
  he: {
    brand: 'אורתופדיה · למטופלים', rtl: true,
    n: {
      SP01: ['כדור', 'שקע', 'להרים את היד', 'להתלבש', 'להחזיק חפצים', 'אפילו תנועות פשוטות עלולות לגרום לכאב'],
      SP02: ['שחיקת סחוס קשה', 'פגיעה במפרק בעקבות קרע גדול בגידי השרוול המסובב', 'שבר מורכב', 'אם טיפולים אחרים אינם עוזרים', 'מנתח אורתופד עשוי להמליץ על החלפת מפרק הכתף'],
      SP03: ['החלפת כתף אנטומית', 'החלפת כתף הפוכה', 'עצם הזרוע', 'השכמה', 'גידי השרוול המסובב שמורים ומתפקדים היטב'],
      SP04: ['החלפת כתף אנטומית', 'החלפת כתף הפוכה', 'עצם הזרוע', 'השכמה', 'שריר הדלתא', 'גם כאשר גידי השרוול המסובב פגועים בצורה קשה'],
      SP05: ['הרופא המרדים יסביר על ההרדמה ועל הטיפול בכאב', 'הרדמה כללית, ולעיתים גם חסימה עצבית באזור הכתף', 'מסיר את משטחי המפרק הפגועים', 'מתקין את חלקי המשתל'],
      SP06: ['חדר ההתאוששות', 'חבישה', 'מתלה תומך', 'כאב · תחושה · תנועת האצבעות'],
      SP07: ['צפויים כאב ונפיחות', 'טיפול לשיכוך כאבים', 'קירור רק לפי הנחיות הצוות', 'הגנו על העור מפני פגיעת קור'],
      SP08: ['תוכנית אישית', 'האצבעות · כף היד · המרפק', 'אל תרימו את היד המנותחת בעצמכם', 'אל תתחילו תרגילים חדשים ללא אישור'],
      SP09: ['אסור להישען על היד המנותחת', 'אסור לדחוף בעזרתה את הגוף מהמיטה או מהכיסא', 'אסור להרים חפצים כבדים', 'גם תנוחות מסוימות של הכתף עשויות להיות אסורות באופן זמני', 'הרופא המטפל יקבע את ההגבלות ואת משך הזמן שלהן'],
      SP10: ['לישון על הגב או כשהחלק העליון של הגוף מוגבה', 'בגדים רחבים, רצוי עם פתיחה מלפנים', 'מקלחת, הסרת המתלה וטיפול בפצע רק לפי ההנחיות'],
      SP11: ['חום גוף גבוה', 'הפרשה מהפצע', 'כאב שמתגבר', 'חוסר תחושה חדש או חיוורון באצבעות', 'הערכה רפואית דחופה', 'קוצר נשימה פתאומי או כאב בחזה ← 101'],
      SP12: ['סיבוך אפשרי, אך אינו שכיח', 'צורת הכתף השתנתה פתאום · כאב חד · אינכם יכולים להזיז את היד כרגיל', 'אל תנסו להחזיר את המפרק למקומו בעצמכם', 'פנו בדחיפות לחדר המיון'],
    },
    end: 'הנחיות הרופא המטפל קודמות',
  },
  ar: {
    brand: 'جراحة العظام · للمرضى', rtl: true,
    n: {
      SP01: ['كرة', 'تجويف', 'رفع الذراع', 'ارتداء الملابس', 'الإمساك بالأشياء', 'قد تصبح حتى الحركات البسيطة مؤلمة'],
      SP02: ['تآكل شديد في المفصل', 'تلف في المفصل بعد تمزق كبير في أوتار الكفة المدورة', 'كسر معقد', 'إذا لم تساعد العلاجات الأخرى', 'قد يقترح جرّاح العظام استبدال مفصل الكتف'],
      SP03: ['المفصل التشريحي', 'المفصل العكسي', 'عظم العضد', 'لوح الكتف', 'أوتار الكفة المدورة سليمة وتعمل بشكل جيد'],
      SP04: ['المفصل التشريحي', 'المفصل العكسي', 'عظم العضد', 'لوح الكتف', 'العضلة الدالية', 'حتى عندما تكون أوتار الكفة المدورة متضررة بشدة'],
      SP05: ['سيشرح لكم طبيب التخدير طريقة التخدير وتسكين الألم', 'التخدير العام، وأحيانًا مع تخدير الأعصاب في منطقة الكتف', 'يزيل الأسطح المفصلية المتضررة', 'يثبّت أجزاء المفصل الاصطناعي'],
      SP06: ['غرفة الإفاقة', 'ضمادة', 'حمّالة داعمة', 'الألم · الإحساس · حركة الأصابع'],
      SP07: ['من المتوقع حدوث بعض الألم والتورم', 'علاج لتخفيف الألم', 'الكمادات الباردة فقط وفق تعليمات الطاقم', 'احموا الجلد من أذى البرودة'],
      SP08: ['برنامج يناسب حالتكم', 'الأصابع · اليد · المرفق', 'لا ترفعوا الذراع التي أُجريت لها العملية بأنفسكم', 'لا تبدأوا تمارين جديدة دون موافقة'],
      SP09: ['لا تتكئوا على الذراع التي أُجريت لها العملية', 'لا تدفعوا جسمكم بها للنهوض من السرير أو الكرسي', 'لا ترفعوا أشياء ثقيلة', 'قد تُمنع أيضًا بعض وضعيات الكتف مؤقتًا', 'يحدد الطبيب المعالج القيود ومدتها'],
      SP10: ['النوم على الظهر أو مع رفع الجزء العلوي من الجسم', 'ملابس واسعة، ويفضّل أن تُفتح من الأمام', 'الاستحمام ونزع الحمّالة والعناية بالجرح فقط وفق التعليمات'],
      SP11: ['ارتفاع الحرارة', 'خروج إفرازات من الجرح', 'ازدياد الألم', 'خدر جديد أو شحوب في الأصابع', 'تقييم طبي عاجل', 'ضيق مفاجئ في التنفس أو ألم في الصدر ← 101'],
      SP12: ['من المضاعفات الممكنة، لكنه غير شائع', 'تغيّر شكل الكتف فجأة · ألم حاد · لم تعودوا قادرين على تحريك الذراع بشكل طبيعي', 'لا تحاولوا إعادة المفصل إلى مكانه بأنفسكم', 'توجّهوا فورًا إلى قسم الطوارئ'],
    },
    end: 'تعليمات الطبيب المعالج لها الأولوية',
  },
};

const NV = '#E3E7EF';
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]; size?: number}> = ({y, items, size = 30}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10), transform: `translateY(${(1 - ease(f, a, a + 10)) * 14}px)`}}><Note size={size} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const WarnCard: React.FC<{y: number; at: number; text: string; red?: boolean; size?: number}> = ({y, at, text, red, size = 31}) =>
  <Card x={64} y={y} w={952} at={at} style={{borderInlineStart: `10px solid ${red ? C.blood : C.teal}`}}>
    <div style={{fontFamily: BODY, fontWeight: 800, fontSize: size, color: red ? C.blood : C.ink, lineHeight: 1.3}}>{text}</div>
  </Card>;
const WarnBox: React.FC<{d: number; items: string[]; top: number}> = ({d, items, top}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top, borderRadius: 30, border: `6px solid ${C.blood}`, background: '#fff', padding: '26px 28px 8px', opacity: ease(f, 2, 12)}}>
    {items.map((t, i) => {
      const a = fr(d, 0.04 + i * 0.1), p = ease(f, a, a + 10);
      return <div key={i} style={{display: 'flex', gap: 16, alignItems: 'flex-start', marginBottom: 18, opacity: p, transform: `translateX(${(1 - p) * 20}px)`}}>
        <div style={{flex: 'none', width: 22, height: 22, borderRadius: 11, background: C.acc, marginTop: 10}} />
        <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 31, color: C.ink, lineHeight: 1.25}}>{t}</div>
      </div>;
    })}
  </div>;
};

const scene = (id: string, d: number, L: Dict, rtl: boolean) => {
  const n = L.n[id];
  const t = (p: number) => fr(d, p);
  switch (id) {
    case 'SP01': return <>
      <BallSocket top={440} d={d} ball={n[0]} socket={n[1]} />
      <Notes y={1030} items={[[n[2], t(0.3), C.teal, C.tealL], [n[3], t(0.38), C.teal, C.tealL], [n[4], t(0.46), C.teal, C.tealL]]} />
      <WarnCard y={1150} at={t(0.72)} text={n[5]} red />
    </>;
    case 'SP02': return <>
      <Causes top={440} d={d} items={n.slice(0, 3)} />
      <Notes y={980} items={[[n[3], t(0.58), C.navy, NV]]} />
      <WarnCard y={1070} at={t(0.72)} text={n[4]} />
    </>;
    case 'SP03': return <>
      <TwoProst top={440} d={d} hl="anat" tA={n[0]} tR={n[1]} bone={n[2]} blade={n[3]} />
      <WarnCard y={1110} at={t(0.68)} text={n[4]} />
    </>;
    case 'SP04': return <>
      <TwoProst top={440} d={d} hl="rev" tA={n[0]} tR={n[1]} bone={n[2]} blade={n[3]} deltLbl={n[4]} />
      <WarnCard y={1110} at={t(0.7)} text={n[5]} />
    </>;
    case 'SP05': return <>
      <OpSwap top={440} d={d} />
      <Notes y={930} size={28} items={[[n[0], t(0.04), C.navy, NV], [n[1], t(0.2), C.navy, NV], [n[2], t(0.5)], [n[3], t(0.72), C.teal, C.tealL]]} />
    </>;
    case 'SP06': return <>
      <SlingFig top={440} d={d} dress={1} />
      <Notes y={990} items={[[n[0], t(0.06), C.navy, NV], [n[1], t(0.36)], [n[2], t(0.5), C.teal, C.tealL], [n[3], t(0.72), C.navy, NV]]} />
    </>;
    case 'SP07': return <>
      <Ice d={d} />
      <Notes y={990} items={[[n[0], t(0.04)], [n[1], t(0.3), C.teal, C.tealL], [n[2], t(0.55), C.navy, NV], [n[3], t(0.76), C.blood, C.bloodL]]} />
    </>;
    case 'SP08': return <>
      <Lock8 d={d} />
      <Notes y={990} items={[[n[0], t(0.04), C.navy, NV], [n[1], t(0.24), C.teal, C.tealL], [n[2], t(0.6), C.blood, C.bloodL], [n[3], t(0.78), C.blood, C.bloodL]]} />
    </>;
    case 'SP09': return <>
      <Rows top={440} d={d} no items={[['lean', n[0]], ['push', n[1]], ['bag', n[2]], ['pos', n[3]]]} start={0.03} step={0.16} size={29} gap={14} />
      <WarnCard y={1080 + (rtl ? 0 : 0)} at={t(0.8)} text={n[4]} size={30} />
    </>;
    case 'SP10': return <>
      <Rows top={460} d={d} items={[['bed', n[0]], ['shirt', n[1]], ['shower', n[2]]]} start={0.04} step={0.3} />
    </>;
    case 'SP11': return <>
      <WarnBox top={440} d={Math.round(d * 0.7)} items={n.slice(0, 4)} />
      <Notes y={840} items={[[n[4], t(0.42), C.blood, C.bloodL]]} />
      <WarnCard y={930} at={t(0.62)} text={n[5]} red />
      <Phone101 y={1080} at={t(0.7)} s={0.6} />
    </>;
    case 'SP12': return <>
      <Dislocate top={440} d={d} />
      <Notes y={920} size={28} items={[[n[0], t(0.04), C.navy, NV], [n[1], t(0.3)], [n[2], t(0.62), C.blood, C.bloodL], [n[3], t(0.78), C.blood, C.bloodL]]} />
      <End at={t(0.9)} text={L.end} />
    </>;
  }
  return null;
};
const Ice: React.FC<{d: number}> = ({d}) => { const f = useCurrentFrame(); return <SlingFig top={440} d={d} dress={1} ice={ease(f, fr(d, 0.3), fr(d, 0.38))} />; };
const Lock8: React.FC<{d: number}> = ({d}) => { const f = useCurrentFrame(); return <SlingFig top={440} d={d} dress={1} fingers lock={ease(f, fr(d, 0.58), fr(d, 0.64))} />; };
const End: React.FC<{at: number; text: string}> = ({at, text}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: 1330, textAlign: 'center', opacity: ease(f, at, at + 10), fontFamily: HEAD, fontWeight: 800, fontSize: 34, color: C.teal}}>{text}</div>;
};

export const mkShrepl = (lang: string, timing: unknown) => {
  const TT = timing as TT;
  const L = N[lang];
  const total = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
  const Comp: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
    let at = 0;
    return <AbsoluteFill style={{direction: L.rtl ? 'rtl' : 'ltr'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={L.brand} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} size={x.head.length > 34 ? 50 : x.head.length > 24 ? 58 : 66} />
            {scene(x.id, d, L, !!L.rtl)}
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>;
  };
  return {Comp, total};
};
const ru = mkShrepl('ru', tRu); export const Shrepl = ru.Comp; export const totalShrepl = ru.total;
const he = mkShrepl('he', tHe); export const ShreplHe = he.Comp; export const totalShreplHe = he.total;
const ar = mkShrepl('ar', tAr); export const ShreplAr = ar.Comp; export const totalShreplAr = ar.total;
const en = mkShrepl('en', tEn); export const ShreplEn = en.Comp; export const totalShreplEn = en.total;

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
