// «Операция на шее спереди (ACDF)» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import {WalkDaily} from './LimbArt';
import timing from './timing_acdf_ar.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalAcdf_ar = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'جراحة العظام · للمرضى';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- ACDF: сцены N01–N12 ----
const BONE = '#EFE6D8', BONES = '#C9B79C', CORD = '#F4E3A6', CORDS = '#C9A23A';
// шейный позвонок/диск сверху: спереди вверху, сзади внизу; в канале спинной мозг; корешки по бокам
const CervTop: React.FC<{h: number; rem?: number; top?: number}> = ({h, rem = 0, top = 470}) => {
  const hv = h * (1 - rem);
  return <svg width={1080} height={760} viewBox="0 0 1080 760" style={{position: 'absolute', left: 0, top}}>
    <path d="M 300 290 C 300 150 440 110 540 125 C 640 110 780 150 780 290 C 780 360 730 395 670 400 C 620 405 590 390 540 390 C 490 390 460 405 410 400 C 350 395 300 360 300 290 Z" fill="#DCEAF0" stroke="#9CC9D3" strokeWidth={5} />
    <ellipse cx={540} cy={255} rx={130} ry={78} fill="#BFD9E6" />
    {hv > 0 && <path d="M 480 384 C 476 420 458 440 438 444 C 418 446 404 432 408 410 C 414 394 440 386 480 384 Z" transform={`translate(450 388) scale(${0.3 + 0.7 * hv} ${hv}) translate(-450 -388)`} fill="#BFD9E6" stroke={C.acc} strokeWidth={4} />}
    <path d="M 360 420 C 340 510 390 600 470 640 L 540 690 L 610 640 C 690 600 740 510 720 420 L 680 425 C 690 510 650 570 540 590 C 430 570 390 510 400 425 Z" fill={BONE} stroke={BONES} strokeWidth={4} />
    <ellipse cx={540} cy={500} rx={115} ry={72} fill="#E3F1F7" stroke="#8CC3D6" strokeWidth={4} />
    <ellipse cx={540} cy={502} rx={78} ry={46} fill={CORD} stroke={CORDS} strokeWidth={3} />
    <circle cx={418} cy={462 + 10 * hv} r={16} fill="#F2D27A" stroke={hv > 0.5 ? C.acc : '#C99A1E'} strokeWidth={4} />
    <circle cx={662} cy={462} r={16} fill="#F2D27A" stroke="#C99A1E" strokeWidth={4} />
    <text textAnchor="end" x={300} y={90} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.teal}>↑ الأمام (الحلق)</text>
    <text textAnchor="end" x={700} y={740} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.mute}>النخاع الشوكي</text>
  </svg>;
};
// два шейных позвонка сбоку: спереди слева; disc: 1 = диск на месте, 0 = удалён; cage, plate 0..1
const CervSide: React.FC<{disc: number; cage?: number; plate?: number}> = ({disc, cage = 0, plate = 0}) => {
  const Vt = (y: number) => <g>
    <rect x={300} y={y} width={240} height={150} rx={26} fill={BONE} stroke={BONES} strokeWidth={4} />
    <path d={`M 540 ${y + 30} L 640 ${y + 25} L 640 ${y + 95} L 540 ${y + 100} Z`} fill={BONE} stroke={BONES} strokeWidth={4} />
    <path d={`M 700 ${y + 10} L 820 ${y + 50} L 820 ${y + 110} L 700 ${y + 120} Z`} fill={BONE} stroke={BONES} strokeWidth={4} />
  </g>;
  return <svg width={1080} height={700} style={{position: 'absolute', left: 0, top: 470}}>
    {Vt(110)}{Vt(370)}
    <rect x={648} y={60} width={44} height={560} rx={22} fill={CORD} stroke={CORDS} strokeWidth={3} />
    <g opacity={disc}><rect x={310} y={268} width={225} height={94} rx={20} fill="#BFD9E6" stroke="#9CC9D3" strokeWidth={3} />
      <path d="M 530 300 C 575 300 600 315 640 318 L 640 345 C 600 348 570 352 530 345 Z" fill="#BFD9E6" stroke={C.acc} strokeWidth={4} opacity={0.9} /></g>
    <g opacity={cage}><rect x={340} y={272} width={170} height={86} rx={12} fill="#D9DEE6" stroke="#6B7686" strokeWidth={4} />
      {Array.from({length: 8}, (_, i) => <circle key={i} cx={365 + (i % 4) * 40} cy={297 + Math.floor(i / 4) * 34} r={9} fill="#F2D27A" stroke="#C99A1E" strokeWidth={2} />)}</g>
    <g opacity={plate} transform={`translate(${(1 - plate) * -40} 0)`}>
      <rect x={272} y={180} width={26} height={270} rx={12} fill="#8E99A8" stroke="#5B6575" strokeWidth={3} />
      {[215, 415].map((y) => <g key={y}><line x1={285} y1={y} x2={430} y2={y + 6} stroke={C.navy} strokeWidth={13} strokeLinecap="round" /><circle cx={285} cy={y} r={17} fill={C.navy} /></g>)}
    </g>
    <text textAnchor="end" x={300} y={40} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.mute}>منظر جانبي · الرقبة</text>
    <text textAnchor="end" x={300} y={90} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.teal}>الأمام</text>
    <text textAnchor="end" x={740} y={90} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.teal}>الخلف</text>
  </svg>;
};
const Hint: React.FC<{t: string; y?: number}> = ({t, y = 1200}) => <div style={{position: 'absolute', left: 64, top: y, fontFamily: BODY, fontWeight: 600, fontSize: 22, color: C.mute}}>{t}</div>;
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10)}}><Note size={28} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};

const S01: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const p = ease(f, fr(d, 0.25), fr(d, 0.6));
  return <>
    <Card x={64} y={470} w={420} label="المريضة" at={4}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>مريضة</div>
      
    </Card>
    <Card x={540} y={470} w={476} label="ألم يمتد إلى الذراع" at={14}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 36, color: C.ink}}>عدة أشهر</div>
    </Card>
    <svg width={1080} height={700} style={{position: 'absolute', left: 0, top: 700}}>
      <circle cx={420} cy={90} r={62} fill="#E4E7EC" stroke="#C9CED6" strokeWidth={4} />
      <path d="M 392 145 L 448 145 L 452 200 L 388 200 Z" fill="#E4E7EC" stroke="#C9CED6" strokeWidth={4} />
      <path d="M 300 200 L 540 200 C 580 205 600 230 610 270 L 700 470 L 760 600 L 720 620 L 640 480 L 560 320 L 540 560 L 300 560 Z" fill="#E4E7EC" stroke="#C9CED6" strokeWidth={4} />
      <path d={`M 440 150 C 470 200 540 215 580 260 C 620 330 660 410 700 480 C 720 520 735 560 ${745} ${560 + 50 * p}`} stroke={C.acc} strokeWidth={10} fill="none" strokeLinecap="round" strokeDasharray="800" strokeDashoffset={800 * (1 - p)} opacity={0.85} />
      <circle cx={440} cy={150} r={24} fill={C.acc} opacity={0.35 * p} />
    </svg>
    <Notes y={1390} items={[['ألم في الذراع', fr(d, 0.5)], ['خدر في الأصابع', fr(d, 0.58)], ['لم يزُل دون جراحة', fr(d, 0.66)]]} />
  </>;
};

const S02: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const h = ease(f, fr(d, 0.1), fr(d, 0.4));
  return <>
    <CervTop h={h} />
    <Hint t="رسم توضيحي، ليس بالمقياس · فقرة رقبية، منظر علوي" y={1250} />
    <Notes y={1300} items={[['انزلاق غضروفي أو نتوءات عظمية', fr(d, 0.15)], ['تضغط على جذر عصبي', fr(d, 0.45)], ['أحيانًا · على النخاع الشوكي', fr(d, 0.7), C.navy, '#E3E7EF']]} />
  </>;
};

const S03: React.FC<{d: number}> = ({d}) => {
  const items = ['ألم وخدر في الذراع', 'العلاج دون جراحة لم يُفِد', 'ضعف متزايد، اضطراب المشي · تقييم عاجل'];
  return <>
    {items.map((t, i) => <Slot key={i} x={64} y={480 + i * 190} w={952} h={160} at={fr(d, 0.08 + i * 0.2)}>
      <Icon k={i === 2 ? 'leg' : 'check'} s={64} c={i === 2 ? '#B45309' : C.mute} /><div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>{t}</div></Slot>)}
    <Card x={64} y={1080} w={952} at={fr(d, 0.8)} style={{background: C.navy}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: '#fff'}}>القرار يتخذه الجرّاح</div>
    </Card>
  </>;
};

const S04: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const cut = ease(f, fr(d, 0.15), fr(d, 0.35)), ret = ease(f, fr(d, 0.5), fr(d, 0.75));
  return <>
    <svg width={1080} height={420} style={{position: 'absolute', left: 0, top: 470}}>
      {/* вид спереди: голова, шея, плечи */}
      <ellipse cx={300} cy={110} rx={86} ry={100} fill="#E4E7EC" stroke="#C9CED6" strokeWidth={4} />
      <path d="M 245 190 L 355 190 L 365 300 L 235 300 Z" fill="#E4E7EC" stroke="#C9CED6" strokeWidth={4} />
      <path d="M 120 400 C 140 320 200 300 235 296 L 365 296 C 400 300 460 320 480 400 Z" fill="#E4E7EC" stroke="#C9CED6" strokeWidth={4} />
      <line x1={300} y1={196} x2={300} y2={292} stroke="#C9CED6" strokeWidth={2} strokeDasharray="6 6" />
      <path d={`M 302 255 Q ${302 + 25 * cut} ${259} ${302 + 50 * cut} 255`} stroke={C.acc} strokeWidth={7} fill="none" strokeLinecap="round" />
      <text textAnchor="end" x={150} y={390} fontFamily="'Body'" fontWeight={700} fontSize={22} fill={C.mute}>شق في ثنية الرقبة</text>
    </svg>
    <svg width={520} height={420} viewBox="0 0 520 420" style={{position: 'absolute', left: 520, top: 470}}>
      {/* поперечный срез шеи: спереди вверху */}
      <ellipse cx={260} cy={210} rx={230} ry={190} fill="#F3F4F7" stroke="#C9CED6" strokeWidth={4} />
      <g transform={`translate(${-70 * ret} 0)`}>
        <circle cx={260} cy={110} r={46} fill="#fff" stroke="#8CC3D6" strokeWidth={6} />
        <ellipse cx={260} cy={185} rx={34} ry={20} fill="#F6D9DA" stroke="#D99" strokeWidth={4} />
      </g>
      <rect x={200} y={225} width={120} height={70} rx={20} fill={BONE} stroke={BONES} strokeWidth={4} />
      <ellipse cx={260} cy={325} rx={38} ry={24} fill={CORD} stroke={CORDS} strokeWidth={3} />
      <path d={`M ${330} 40 L ${330 - 20 * ret} ${200}`} stroke={C.teal} strokeWidth={6} opacity={ret} strokeLinecap="round" />
      <text textAnchor="end" x={20} y={30} fontFamily="'Body'" fontWeight={700} fontSize={20} fill={C.mute}>مقطع الرقبة · الأمام في الأعلى</text>
    </svg>
    <div style={{position: 'absolute', left: 64, top: 930, display: 'flex', flexDirection: 'column', gap: 14}}>
      {[['القصبة الهوائية', '#8CC3D6'], ['المريء', '#D99'], ['فقرة', BONES], ['النخاع الشوكي', CORDS]].map(([t, c], i) => <div key={t} style={{display: 'flex', alignItems: 'center', gap: 14, opacity: ease(f, fr(d, 0.4) + i * 6, fr(d, 0.4) + 10 + i * 6)}}>
        <div style={{width: 26, height: 26, borderRadius: 13, background: c}} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>{t}</span></div>)}
    </div>
    <Notes y={1250} items={[['تخدير عام', fr(d, 0.05), C.navy, '#E3E7EF'], ['تُبعد القصبة الهوائية والمريء بلطف إلى الجانب', fr(d, 0.6), C.teal, C.tealL]]} />
  </>;
};

const S05: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const r = ease(f, fr(d, 0.25), fr(d, 0.6));
  return <>
    <CervSide disc={1 - r} />
    <Hint t="رسم توضيحي، ليس بمقياس حقيقي" y={1180} />
    <Notes y={1230} items={[['أُزيل القرص · النتوءات العظمية عند الحاجة', fr(d, 0.55)], ['العصب والنخاع الشوكي محرَّران', fr(d, 0.75), C.teal, C.tealL]]} />
  </>;
};

const S06: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const cg = ease(f, fr(d, 0.05), fr(d, 0.25)), pl = ease(f, fr(d, 0.35), fr(d, 0.55));
  return <>
    <CervSide disc={0} cage={cg} plate={pl} />
    <Hint t="رسم توضيحي، ليس بمقياس حقيقي" y={1180} />
    <Notes y={1230} items={[['طُعم عظمي أو حشوة', fr(d, 0.1), '#9A7410', '#FBF0D0'], ['صفيحة وبراغٍ', fr(d, 0.4), C.navy, '#E3E7EF'], ['الالتحام · أشهر عديدة', fr(d, 0.75)]]} />
  </>;
};

const S07: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.02)} icon="shower" text="الصيام والاستحمام والأدوية: حسب نشرة التحضير للعملية" />
  <CheckRow y={720} at={fr(d, 0.3)} icon="pills" text="مميّعات الدم: فقط بتعليمات الطبيب" />
  <Card x={64} y={960} w={952} at={fr(d, 0.62)} label="التدخين">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>ناقشوا مع الطبيب التوقف عن التدخين</div>
  </Card>
</>;

const S08: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.02)} icon="leg" text="في اليوم الأول · النهوض والمشي بإذن الفريق" />
  <CheckRow y={700} at={fr(d, 0.2)} icon="drop" text="الأكل والشرب · عند السماح وأمان البلع" />
  <Card x={64} y={920} w={952} at={fr(d, 0.45)} label="أنبوب تصريف · طوق">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>أحيانًا · يقرر الجرّاح</div>
  </Card>
  <Card x={64} y={1140} w={952} at={fr(d, 0.7)} label="إلى البيت">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 36, color: C.ink}}>لدى كثيرين · بعد يوم أو يومين</div>
  </Card>
</>;

const S09: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={470} w={952} at={fr(d, 0.02)} label="شائع ويزول عادةً">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>صعوبة بلع الطعام الصلب · بحة الصوت</div>
  </Card>
  <CheckRow y={700} at={fr(d, 0.4)} icon="check" text="جلوسًا باستقامة · ببطء · بكميات صغيرة" />
  <CheckRow y={900} at={fr(d, 0.52)} icon="check" text="البدء بطعام طري" />
  <Card x={64} y={1110} w={952} at={fr(d, 0.75)} style={{border: `4px solid #B45309`, background: '#FFF7ED'}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>سعال أو شَرَق أثناء الأكل أو الشرب · توقّفوا عن الأكل والشرب، أخبروا الطاقم فورًا · في البيت إلى الطبيب في اليوم نفسه</div>
  </Card>
</>;

const S10: React.FC<{d: number}> = ({d}) => <>
  <WalkDaily top={1130} d={d} />
  <CheckRow y={480} at={fr(d, 0.02)} icon="leg" text="المشي كل يوم · زيادة النشاط تدريجيًا" />
  <Card x={64} y={720} w={952} at={fr(d, 0.3)} label="الأثقال · القيادة · الرياضة">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>فقط عندما يسمح الجرّاح</div>
  </Card>
  <CheckRow y={960} at={fr(d, 0.6)} icon="wound" text="ضمادة جافة · تمارين أخصائي العلاج الطبيعي" />
</>;

const S11: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={330} at={fr(d, 0.02)} title="101 فورًا" color={C.blood} bg="#FDECEC"
    items={[['lungs', 'صعوبة في التنفس'], ['wound', 'تورّم الرقبة يزداد بسرعة'], ['drop', 'لا تستطيعون بلع حتى اللعاب'], ['head', 'في المستشفى · أخبروا الطاقم فورًا']]} />
  <Tier y={830} h={330} at={fr(d, 0.35)} title="بشكل عاجل إلى الطوارئ" color="#B45309" bg="#FFF7ED"
    items={[['drop', 'البلع أصعب بوضوح'], ['leg', 'ضعف أو خدر جديد في الذراعين أو الساقين'], ['leg', 'تدهور المشي']]} />
  <Tier y={1190} h={220} at={fr(d, 0.75)} title="إلى الطبيب في اليوم نفسه" color={C.navy} bg="#fff"
    items={[['therm', 'حمّى'], ['wound', 'احمرار أو إفرازات من الجرح']]} />
</>;

const S12: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>هذه توصيات عامة</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>تعليمات طبيبكم والفريق الطبي الخاصة بكم لها الأولوية</div>
  </Card>
);

const SC: Record<string, React.FC<{d: number}>> = {N01: S01, N02: S02, N03: S03, N04: S04, N05: S05, N06: S06, N07: S07, N08: S08, N09: S09, N10: S10, N11: S11, N12: S12};

export const Acdf_ar: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill style={{direction: 'rtl'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
