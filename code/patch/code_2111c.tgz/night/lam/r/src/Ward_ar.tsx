// «После операции в отделении и подготовка к выписке» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import {BedReal, CallBell} from './WardArt';
import {Clip3D} from './Clip3D';
import timing from './timing_ward_ar.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalWard_ar = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'جراحة العظام · للمرضى';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- В отделении: сцены R01–R14 ----
const RED = C.blood, ORG = '#B45309', BLU = C.navy;
const Band: React.FC<{y: number; at: number; color: string; bg: string; title: string; sub: string}> = ({y, at, color, bg, title, sub}) => {
  const f = useCurrentFrame(); const p = ease(f, at, at + 14);
  return <div style={{position: 'absolute', left: 64, top: y, width: 952, height: 200, borderRadius: 28, background: bg, border: `4px solid ${color}`, overflow: 'hidden', opacity: p, transform: `translateX(${(1 - p) * -40}px)`}}>
    <div style={{position: 'absolute', left: 0, top: 0, bottom: 0, width: `${100 * p}%`, background: color, opacity: 0.08}} />
    <div style={{position: 'absolute', insetInlineStart: 34, top: 34, fontFamily: HEAD, fontWeight: 800, fontSize: 48, color}}>{title}</div>
    <div style={{position: 'absolute', insetInlineStart: 34, top: 112, fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>{sub}</div>
  </div>;
};
const List: React.FC<{y: number; d: number; items: [string, string][]; color: string; start?: number; step?: number}> = ({y, d, items, color, start = 0.05, step = 0.14}) => {
  const f = useCurrentFrame();
  return <>{items.map(([k, t], i) => <div key={i} style={{position: 'absolute', left: 64, width: 952, top: y + i * 118, display: 'flex', alignItems: 'center', gap: 22, background: '#fff', borderRadius: 22, padding: '18px 24px', boxSizing: 'border-box', borderLeft: `10px solid ${color}`, opacity: ease(f, fr(d, start + i * step), fr(d, start + i * step) + 10)}}>
    <Icon k={k} s={54} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink, lineHeight: 1.2}}>{t}</span></div>)}</>;
};
const Stamp: React.FC<{y: number; at: number; color: string; bg: string; text: string}> = ({y, at, color, bg, text}) =>
  <Card x={64} y={y} w={952} at={at} style={{background: bg, border: `4px solid ${color}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 46, color}}>{text}</div>
  </Card>;

const Bed: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame(); const r = ease(f, fr(d, 0.2), fr(d, 0.35)); const b = ease(f, fr(d, 0.55), fr(d, 0.65));
  return <svg width={1080} height={460} style={{position: 'absolute', left: 0, top}}>
    <rect x={150} y={250} width={780} height={60} rx={16} fill="#D9E2EC" />
    <rect x={170} y={210} width={740} height={50} rx={22} fill="#fff" stroke="#CBD2DC" strokeWidth={4} />
    <rect x={190} y={170} width={150} height={50} rx={22} fill="#F1F4F8" stroke="#CBD2DC" strokeWidth={3} />
    <line x1={170} y1={310} x2={170} y2={420} stroke="#9AA6B5" strokeWidth={12} /><line x1={910} y1={310} x2={910} y2={420} stroke="#9AA6B5" strokeWidth={12} />
    <line x1={150} y1={120} x2={150} y2={310} stroke="#9AA6B5" strokeWidth={14} strokeLinecap="round" />
    <g transform={`translate(0 ${60 * (1 - r)})`} opacity={0.4 + 0.6 * r}>
      <rect x={260} y={130} width={560} height={70} rx={14} fill="none" stroke={C.teal} strokeWidth={10} />
      {[340, 420, 500, 580, 660, 740].map((x) => <line key={x} x1={x} y1={130} x2={x} y2={200} stroke={C.teal} strokeWidth={6} />)}
    </g>
    <g opacity={b} transform={`translate(860 40) scale(${0.8 + 0.2 * b})`}>
      <circle cx={60} cy={60} r={56} fill={C.acc} /><circle cx={60} cy={60} r={30} fill="#fff" />
    </g>
  </svg>;
};
const S01: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const it: [string, string][] = [['heart', 'ضغط الدم · النبض'], ['lungs', 'التنفّس · نسبة الأكسجين'], ['therm', 'حمّى'], ['wound', 'الضماد'], ['leg', 'الإحساس والحركة']];
  return <List y={480} d={d} color={C.teal} items={it} step={0.14} />;
};
const S02: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <BedReal top={450} d={d} bell={false} />
    <CallBell x={472} y={1120} s={0.52} at={fr(d, 0.6)} press={fr(d, 0.68)} />
    <div style={{position: 'absolute', left: 64, top: 960, display: 'flex', gap: 12, flexWrap: 'wrap', width: 952}}>
      <div style={{opacity: ease(f, fr(d, 0.25), fr(d, 0.33))}}><Note color={C.teal} bg={C.tealL} size={28}>الحواجز مرفوعة: خطر سقوط أقل، لكن دون ضمان</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.45), fr(d, 0.53))}}><Note size={28}>لا تنهض وحدك · لا تتسلّق · لا تُنزلها</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.62), fr(d, 0.7))}}><Note color={C.navy} bg="#E3E7EF" size={28}>مساعدة أو حمّام: زر النداء</Note></div>
    </div>
  </>;
};
const S03: React.FC<{d: number}> = ({d}) => <>
  <List y={470} d={d} color={ORG} items={[['leg', 'اشتد الألم كثيرًا · خدر أو ضعف'], ['head', 'غثيان شديد · دوخة'], ['lungs', 'صعوبة في التنفّس · نزيف'], ['bladder', 'لا تستطيع التبوّل']]} step={0.11} />
  <Card x={64} y={980} w={952} at={fr(d, 0.62)} label="للأقارب" style={{borderLeft: `10px solid ${RED}`}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>ارتباك مفاجئ، نعاس غير معتاد، لا يتعرّف على أهله ← فورًا للطاقم</div>
  </Card>
</>;
const S04: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={470} at={fr(d, 0.02)} icon="pills" text="عدة مسكّنات: باراسيتامول، وعند الحاجة أفيونيات" />
  <Card x={64} y={700} w={952} at={fr(d, 0.35)} style={{background: C.tealL}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.teal}}>الهدف: الحركة والراحة والتمارين</div>
  </Card>
  <CheckRow y={900} at={fr(d, 0.65)} icon="pills" text="لا تتحمّل ألمًا شديدًا · أدويتك الخاصة فقط بالتنسيق" />
</>;
const S05: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={470} w={952} at={4} label="الأفيونيات">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>نعاس · غثيان · إمساك · أحيانًا تباطؤ خطير في التنفّس</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 28, color: C.mute, marginTop: 8}}>فقط حسب الوصفة</div>
  </Card>
  <Stamp y={760} at={fr(d, 0.55)} color={RED} bg="#FDECEC" text="صعوبة الإيقاظ · تنفّس بطيء" />
  <div style={{position: 'absolute', left: 64, top: 980, opacity: ease(useCurrentFrame(), fr(d, 0.7), fr(d, 0.78))}}><Note color={RED} bg="#FDECEC" size={30}>استدعِ الطاقم فورًا</Note></div>
</>;
const S06: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={470} w={952} at={4} label="استبدال المفصل">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>عادةً يوم العملية أو خلال أول 24 ساعة</div>
  </Card>
  <Card x={64} y={680} w={952} at={fr(d, 0.3)} label="كسر الورك">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>عادةً في اليوم التالي</div>
  </Card>
  <Stamp y={900} at={fr(d, 0.62)} color={C.navy} bg="#fff" text="المرة الأولى: فقط مع الطاقم" />
  <CallBell x={425} y={1130} s={0.5} at={fr(d, 0.7)} press={fr(d, 0.78)} />
</>;
const S07: React.FC<{d: number}> = ({d}) => <>
  <List y={470} d={d} color={C.teal} items={[['leg', 'حذاء مغلق غير زلق'], ['head', 'النظارات'], ['leg', 'المشّاية قريبة'], ['clock', 'ضوء في الليل'], ['heart', 'زر النداء والهاتف في متناول اليد']]} step={0.13} />
  <CallBell x={420} y={1090} s={0.46} at={fr(d, 0.82)} press={fr(d, 0.88)} />
</>;
const S08: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={470} at={fr(d, 0.02)} icon="pills" text="حقن أو أقراص · جوارب أو أكمام ضاغطة: يقرّر الفريق" />
  <CheckRow y={610} at={fr(d, 0.3)} icon="leg" text="القدمان: نحوك وبعيدًا عنك إذا سُمح · لا يغني عن الأدوية" />
  <Tier y={1240} h={220} at={fr(d, 0.62)} title="استدعِ الطاقم فورًا" color={RED} bg="#FDECEC"
    items={[['calf', 'ألم جديد أو تورّم في ربلة الساق'], ['lungs', 'ضيق نفس مفاجئ'], ['heart', 'ألم في الصدر']]} />
  <Clip3D src="c3/swell_pump.mp4" y={750} h={470} pos="50% 25%" d={d} dur={9} at={fr(d, 0.3)} />
</>;
const S09: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={470} at={fr(d, 0.02)} icon="lungs" text="التنفّس بعمق والسعال عدة مرات في الساعة" />
  <CheckRow y={610} at={fr(d, 0.25)} icon="drop" text="اشرب ما يكفي إذا لم يكن هناك تقييد" />
  <Card x={64} y={750} w={952} at={fr(d, 0.5)} label="الإمساك">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>لا تبرّز لعدة أيام ← للممرضة</div>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: RED, marginTop: 8}}>ألم شديد في البطن، انتفاخ، تقيّؤ ← فورًا</div>
  </Card>
  <Clip3D src="c3/breath_breathe.mp4" y={1010} h={430} pos="50% 8%" d={d} dur={18.6} at={fr(d, 0.04)} />
</>;
const S10: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={470} at={fr(d, 0.02)} icon="wound" text="الطاقم يغيّر الضماد · لا تلمس الجرح" />
  <CheckRow y={690} at={fr(d, 0.2)} icon="tube" text="لا تشدّ أنبوب التصريف أو القسطرة" />
  <List y={910} d={d} color={ORG} items={[['wound', 'الضماد مبتلّ كثيرًا · احمرار وتورّم وألم تزداد'], ['head', 'العمود الفقري: إفرازات شفافة من الجرح · صداع شديد جديد']]} start={0.45} step={0.18} />
</>;
const S11: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={470} w={952} at={4} label="من قسمنا عادةً: مستشفى تأهيلي">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>استبدال الورك أو الركبة · كسر الورك · البتر</div>
  </Card>
  <Card x={64} y={720} w={952} at={fr(d, 0.5)} label="التأهيل في البيت؟">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>أخبر مسبقًا · يعتمد على الحالة وظروف البيت وصندوق المرضى</div>
  </Card>
</>;
const S12: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const it = ['الأدوية: ماذا وإلى متى · أي أدوية دائمة تستأنف', 'من يعطي الحقن في البيت', 'الجرح، الغرز، متى تستحم', 'التحميل، التمارين، القيود، أدوات المساعدة', 'المساعدة في البيت', 'المتابعة · من تراجع', 'أعراض تستدعي مساعدة طارئة'];
  return <Card x={64} y={470} w={952} at={4} label="كتابةً قبل الخروج">
    {it.map((t, i) => <div key={t} style={{display: 'flex', alignItems: 'center', gap: 16, marginTop: 14, opacity: ease(f, fr(d, 0.1 + i * 0.11), fr(d, 0.16 + i * 0.11))}}>
      <Icon k="check" s={46} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>{t}</span></div>)}
  </Card>;
};
const S13: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={470} at={fr(d, 0.02)} icon="leg" text="إزالة السجاد والأسلاك · ضوء ليلًا" />
  <CheckRow y={690} at={fr(d, 0.2)} icon="shower" text="مقابض · مقعد مرحاض مرتفع · كرسي بمساند" />
  <CheckRow y={910} at={fr(d, 0.45)} icon="leg" text="زِد المشي تدريجيًا" />
  <Card x={64} y={1130} w={952} at={fr(d, 0.7)} label="القيادة" style={{border: `4px solid ${ORG}`}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>فقط بعد موافقة الطبيب · ليس مع الأفيونيات</div>
  </Card>
</>;
const S14: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>هذه توصيات عامة</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>تعليمات طبيبكم والفريق الطبي الخاصة بكم لها الأولوية</div>
  </Card>
);

const SC: Record<string, React.FC<{d: number}>> = {R01: S01, R02: S02, R03: S03, R04: S04, R05: S05, R06: S06, R07: S07, R08: S08, R09: S09, R10: S10, R11: S11, R12: S12, R13: S13, R14: S14};

export const Ward_ar: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill style={{direction: 'rtl'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
