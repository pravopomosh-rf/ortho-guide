// «Эноксапарин дома» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import {DressAnim, WristElev, FingerFlex, SharpsBin} from './LimbArt';
import timing from './timing_enox_ar.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalEnox_ar = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'جراحة العظام · للمرضى';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Эноксапарин: сцены E01–E11 ----
// преднаполненный шприц, вертикально иглой вниз: x — центр, y — верх штока
const Syringe: React.FC<{x: number; y: number; plunger?: number; cap?: number; shield?: number; s?: number; air?: number}> = ({x, y, plunger = 0, cap = 1, shield = 0, s = 1, air = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-40} y={0 + 200 * plunger} width={80} height={14} rx={6} fill="#6B7686" />
    <rect x={-7} y={14 + 200 * plunger} width={14} height={110 - 0} fill="#9AA5AE" />
    <rect x={-34} y={120} width={68} height={300} rx={14} fill="rgba(220,235,245,.8)" stroke="#9AA5AE" strokeWidth={4} />
    <rect x={-50} y={118} width={100} height={14} rx={6} fill="#9AA5AE" />
    <rect x={-30} y={124 + 200 * plunger} width={60} height={22} rx={4} fill="#4A5568" />
    {air > 0 && plunger < 0.05 && <circle cx={0} cy={160} r={12} fill="#fff" stroke="#9AA5AE" strokeWidth={2} opacity={air} />}
    <rect x={-30} y={146 + 200 * plunger} width={60} height={Math.max(0, 270 - 200 * plunger)} rx={4} fill="#EAF6FB" />
    <rect x={-6} y={420} width={12} height={20} fill="#9AA5AE" />
    <line x1={0} y1={440} x2={0} y2={530} stroke="#B9C2CB" strokeWidth={4} />
    {cap > 0 && <rect x={-14} y={430 + 40 * (1 - cap)} width={28} height={110} rx={10} fill="#5B8DEF" opacity={cap} />}
    {shield > 0 && <rect x={-20} y={420} width={40} height={115 * shield} rx={10} fill="rgba(91,141,239,.55)" stroke="#5B8DEF" strokeWidth={3} />}
  </g>
);

const S01: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <svg width={1080} height={560} style={{position: 'absolute', left: 0, top: 470}}>
      <path d="M 380 20 L 520 20 L 540 300 L 560 520 L 420 530 L 400 300 Z" fill="#E4E7EC" stroke="#C9CED6" strokeWidth={4} />
      <path d="M 455 40 C 470 180 480 320 490 500" stroke="#9EB3D6" strokeWidth={16} fill="none" strokeLinecap="round" />
      <ellipse cx={482} cy={330} rx={16} ry={34} fill={C.blood} opacity={ease(f, fr(d, 0.1), fr(d, 0.25))} />
      <text textAnchor="end" x={600} y={320} fontFamily="'Body'" fontWeight={700} fontSize={30} fill={C.blood} opacity={ease(f, fr(d, 0.15), fr(d, 0.25))}>جلطة في وريد الساق</text>
    </svg>
    <Card x={64} y={1060} w={952} at={fr(d, 0.4)} label="إينوكسابارين">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>مثل كليكسان أو كروسيا · حتى بعد الخروج</div>
    </Card>
    <div style={{position: 'absolute', left: 64, top: 1280, opacity: ease(f, fr(d, 0.72), fr(d, 0.82))}}><Note color={C.navy} bg="#E3E7EF" size={28}>لعدد الأيام في رسالة الخروج · دون تفويت</Note></div>
  </>;
};

const S02: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.02)} icon="check" text="الحقن بنفسك فقط بعد تعليم من ممرضة أو طبيب" />
  <CheckRow y={700} at={fr(d, 0.3)} icon="pills" text="نشرة حقنتك أنت · لا تغيّر الدواء أو الجرعة" />
  <Card x={64} y={920} w={952} at={fr(d, 0.6)} label="يجب أن يعرف الطبيب">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>مرض الكلى · تفاعل شديد مع الهيبارين سابقًا</div>
  </Card>
  <Card x={64} y={1130} w={952} at={fr(d, 0.78)} style={{border: `4px solid ${C.acc}`}} label="النزيف">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>الأسبرين والإيبوبروفين والديكلوفيناك: أخبر الطبيب · مسكّنات جديدة فقط بموافقة الطبيب</div>
  </Card>
</>;

const S03: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const items = ['اسم الدواء', 'الجرعة', 'تاريخ الصلاحية', 'الحقنة سليمة', 'المحلول صافٍ'];
  return <>
    <svg width={400} height={620} style={{position: 'absolute', left: 60, top: 480}}><Syringe x={200} y={20} s={1.05} /></svg>
    {items.map((t, i) => <div key={t} style={{position: 'absolute', left: 470, top: 520 + i * 110, display: 'flex', alignItems: 'center', gap: 16, opacity: ease(f, fr(d, 0.05 + i * 0.1), fr(d, 0.12 + i * 0.1))}}><Icon k="check" s={56} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink}}>{t}</span></div>)}
    <div style={{position: 'absolute', left: 64, top: 1180, opacity: ease(f, fr(d, 0.6), fr(d, 0.7))}}><Note size={28}>تالفة، منتهية، عكرة: لا تُستخدم</Note></div>
    <div style={{position: 'absolute', left: 64, top: 1260, opacity: ease(f, fr(d, 0.85), fr(d, 0.95))}}><Note color={C.teal} bg={C.tealL} size={28}>غسل اليدين بالصابون وتجفيفهما</Note></div>
  </>;
};

const S04: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const side = Math.floor(f / 45) % 2;
  return <>
    <svg width={1080} height={700} style={{position: 'absolute', left: 0, top: 470}}>
      <path d="M 240 40 C 230 250 250 520 300 680 L 780 680 C 830 520 850 250 840 40 Z" fill="#F3E2D6" stroke="#D9B79F" strokeWidth={4} />
      <circle cx={540} cy={330} r={14} fill="#D4A59A" />
      <circle cx={540} cy={330} r={95} fill="none" stroke={C.acc} strokeWidth={4} strokeDasharray="12 10" opacity={ease(f, fr(d, 0.15), fr(d, 0.25))} />
      <text x={540} y={460} textAnchor="middle" fontFamily="'Body'" fontWeight={700} fontSize={26} fill={C.acc} opacity={ease(f, fr(d, 0.15), fr(d, 0.25))}>5 سم على الأقل</text>
      <ellipse cx={360} cy={420} rx={90} ry={70} fill={C.teal} opacity={0.15 + (side === 0 ? 0.25 : 0) * ease(f, fr(d, 0.6), fr(d, 0.7))} stroke={C.teal} strokeWidth={4} />
      <ellipse cx={720} cy={420} rx={90} ry={70} fill={C.teal} opacity={0.15 + (side === 1 ? 0.25 : 0) * ease(f, fr(d, 0.6), fr(d, 0.7))} stroke={C.teal} strokeWidth={4} />
      <text x={360} y={530} textAnchor="middle" fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.teal}>يمين</text>
      <text x={720} y={530} textAnchor="middle" fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.teal}>يسار</text>
    </svg>
    <div style={{position: 'absolute', left: 64, top: 1200, display: 'flex', gap: 12, flexWrap: 'wrap', opacity: ease(f, fr(d, 0.4), fr(d, 0.5))}}>
      <Note size={28}>ليس في الندبات أو الكدمات أو الأماكن المؤلمة أو المحمرّة أو المتورّمة</Note>
    </div>
    <div style={{position: 'absolute', left: 64, top: 1290, opacity: ease(f, fr(d, 0.6), fr(d, 0.7))}}><Note color={C.teal} bg={C.tealL} size={28}>التبديل: يمين ← يسار ← يمين</Note></div>
    <div style={{position: 'absolute', left: 64, top: 1380, opacity: ease(f, fr(d, 0.8), fr(d, 0.9))}}><Note color={C.navy} bg="#E3E7EF" size={28}>منديل كحولي أو ماء وصابون · دون فرك</Note></div>
  </>;
};

const S05: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const cap = 1 - ease(f, fr(d, 0.1), fr(d, 0.3));
  return <>
    <svg width={500} height={700} style={{position: 'absolute', left: 290, top: 470}}><Syringe x={250} y={20} cap={cap} s={1.15} /></svg>
    <div style={{position: 'absolute', left: 64, top: 1240, display: 'flex', gap: 12, flexWrap: 'wrap'}}>
      <div style={{opacity: ease(f, fr(d, 0.25), fr(d, 0.35))}}><Note size={28}>لا تلمس الإبرة شيئًا</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.5), fr(d, 0.6))}}><Note color={C.navy} bg="#E3E7EF" size={28}>لا تُخرج فقاعة الهواء</Note></div>
    </div>
  </>;
};

// вид сбоку: кожа, подкожный жир, мышца; складка пальцами; игла 90°
const Fold: React.FC<{needle: number; plunger?: number; out?: number}> = ({needle, plunger = 0, out = 0}) => (
  <svg width={1080} height={720} viewBox="0 0 1080 720" style={{position: 'absolute', left: 0, top: 470}}>
    <rect x={80} y={560} width={920} height={150} fill="#E7B4A8" />
    <path d="M 80 470 L 380 470 C 420 470 440 300 540 300 C 640 300 660 470 700 470 L 1000 470 L 1000 560 L 80 560 Z" fill="#F7E3B5" />
    <path d="M 80 450 L 380 450 C 420 450 440 280 540 280 C 640 280 660 450 700 450 L 1000 450 L 1000 470 L 700 470 C 660 470 640 300 540 300 C 440 300 420 470 380 470 L 80 470 Z" fill="#F3D2C1" />
    <text textAnchor="end" x={100} y={520} fontFamily="'Body'" fontWeight={700} fontSize={24} fill="#9A7410">الدهون تحت الجلد</text>
    <text textAnchor="end" x={100} y={640} fontFamily="'Body'" fontWeight={700} fontSize={24} fill="#8B4A3E">العضلة</text>
    {/* пальцы */}
    <ellipse cx={400} cy={360} rx={40} ry={70} fill="#E9C2A6" stroke="#C99C7E" strokeWidth={3} transform="rotate(-25 400 360)" />
    <ellipse cx={680} cy={360} rx={40} ry={70} fill="#E9C2A6" stroke="#C99C7E" strokeWidth={3} transform="rotate(25 680 360)" />
    <g transform={`translate(0 ${121 + 180 * needle - 320 * out})`}><Syringe x={540} y={-250} s={0.62} cap={0} plunger={plunger} air={0} /></g>
    <text textAnchor="end" x={760} y={240} fontFamily="'Body'" fontWeight={800} fontSize={40} fill={C.teal} opacity={needle}>90°</text>
  </svg>
);
const S06: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Fold needle={ease(f, fr(d, 0.55), fr(d, 0.8))} />
    <div style={{position: 'absolute', left: 64, top: 1240, display: 'flex', gap: 12, flexWrap: 'wrap'}}>
      <div style={{opacity: ease(f, fr(d, 0.15), fr(d, 0.25))}}><Note color={C.navy} bg="#E3E7EF" size={28}>الثنية: الإبهام والسبابة</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.8), fr(d, 0.9))}}><Note color={C.teal} bg={C.tealL} size={28}>الإبرة بكامل طولها، بزاوية قائمة</Note></div>
    </div>
  </>;
};

const S07: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <Fold needle={1} plunger={ease(f, fr(d, 0.05), fr(d, 0.6))} out={ease(f, fr(d, 0.68), fr(d, 0.85))} />
    <div style={{position: 'absolute', left: 64, top: 1240, display: 'flex', gap: 12, flexWrap: 'wrap'}}>
      <div style={{opacity: ease(f, fr(d, 0.05), fr(d, 0.15))}}><Note size={28}>ببطء حتى النهاية</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.7), fr(d, 0.8))}}><Note color={C.navy} bg="#E3E7EF" size={28}>الإصبع على المكبس · اسحب مستقيمًا · الإبرة بعيدًا عنك</Note></div>
    </div>
  </>;
};

const S08: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const sh = ease(f, fr(d, 0.2), fr(d, 0.35));
  return <>
    <svg width={500} height={720} style={{position: 'absolute', left: 290, top: 470}}><Syringe x={250} y={20} cap={0} plunger={1} air={0} shield={sh} s={1.15} /></svg>
    <div style={{position: 'absolute', left: 760, top: 1000, fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.teal, opacity: ease(f, fr(d, 0.33), fr(d, 0.4)) * (1 - ease(f, fr(d, 0.6), fr(d, 0.7)))}}>طق!</div>
    <div style={{position: 'absolute', left: 64, top: 1260, display: 'flex', gap: 12, flexWrap: 'wrap'}}>
      <div style={{opacity: ease(f, fr(d, 0.05), fr(d, 0.15))}}><Note color={C.navy} bg="#E3E7EF" size={28}>كروسيا: اضغط بقوة بعد السحب</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.75), fr(d, 0.85))}}><Note size={28}>لا تفرك مكان الحقن</Note></div>
    </div>
  </>;
};

const S09: React.FC<{d: number}> = ({d}) => <>
  <SharpsBin top={470} d={d} />
  <div style={{position: 'absolute', left: 0, top: 470, width: 1080, height: 1920}}><S09c d={d} /></div>
</>;
const S09c: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.02)} icon="wound" text="فورًا في حاوية الأدوات الحادة · دون إعادة الغطاء" />
  <CheckRow y={700} at={fr(d, 0.4)} icon="therm" text="يُحفظ تحت 25 °م · لا يُجمَّد · بعيدًا عن الأطفال" />
  <CheckRow y={920} at={fr(d, 0.75)} icon="clock" text="سجّل كل حقنة في التقويم" />
</>;

const S10: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={480} w={952} at={fr(d, 0.02)} label="نسيت حقنة كروسيا">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>احقنها حالما تتذكر · لا جرعة مضاعفة في اليوم نفسه</div>
  </Card>
  <Card x={64} y={740} w={952} at={fr(d, 0.4)} label="التالية قريبة أو لست متأكدًا">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>استشر الطبيب أو الصيدلي</div>
  </Card>
  <Card x={64} y={980} w={952} at={fr(d, 0.7)} style={{border: `4px solid #B45309`, background: '#FFF7ED'}} label="خطأ في الجرعة">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>اتصل فورًا بالطبيب أو الممرضة أو الصيدلي</div>
  </Card>
</>;

const S11: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={460} at={fr(d, 0.3)} title="101 فورًا" color={C.blood} bg="#FDECEC"
    items={[['drop', 'تقيّؤ الدم · نزيف شديد'], ['head', 'صداع شديد مفاجئ'], ['faint', 'فقدان الوعي · ضعف في جانب واحد'], ['lungs', 'تورّم الشفتين أو الحلق · ضيق نفس'], ['heart', 'ألم في الصدر']]} />
  <Tier y={955} h={230} at={fr(d, 0.18)} title="فورًا إلى الطوارئ" color="#B45309" bg="#FFF7ED"
    items={[['drop', 'براز أسود كالقطران'], ['head', 'سقوط مع ارتطام الرأس']]} />
  <Tier y={1210} h={290} at={fr(d, 0.02)} title="إلى الطبيب في اليوم نفسه" color={C.navy} bg="#fff"
    items={[['bladder', 'دم في البول'], ['drop', 'نزيف من الأنف · كدمات كبيرة'], ['calf', 'ألم أو تورّم في ربلة الساق']]} />
</>;

const S12: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>هذه توصيات عامة</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>تعليمات طبيبكم والفريق الطبي الخاصة بكم لها الأولوية</div>
  </Card>
);

const SC: Record<string, React.FC<{d: number}>> = {E01: S01, E02: S02, E03: S03, E04: S04, E05: S05, E06: S06, E07: S07, E08: S08, E09: S09, E10: S10, E11: S11, E12: S12};

export const Enox_ar: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill style={{direction: 'rtl'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
