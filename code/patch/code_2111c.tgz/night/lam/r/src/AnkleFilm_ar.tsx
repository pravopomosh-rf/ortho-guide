// «Перелом лодыжки» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import {Clip3D} from './Clip3D';
import {A3, ALbl, WomanTwist} from './A3';
import timing from './timing_ankle_ar.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalAnkleFilm_ar = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'جراحة العظام · للمرضى';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
// ---- Перелом лодыжки: сцены F01–F11 ----
const BONE = '#EFE6D8', BONES = '#C9B79C';
// голеностоп спереди (правая нога): большеберцовая медиально (слева на схеме), малоберцовая латерально (справа), таранная снизу
const Ankle: React.FC<{lat?: number; med?: number; shift?: number; synd?: number; fix?: number; hl?: number; top?: number; label?: boolean; glow?: number}> = ({lat = 0, med = 0, shift = 0, synd = 0, fix = 0, hl = 0, top = 470, label = true, glow = 0}) => {
  const sx = shift * 40;
  return <svg width={1080} height={800} viewBox="140 0 800 593" style={{position: 'absolute', left: 0, top}}>
    {/* большеберцовая */}
    <path d="M 400 0 L 540 0 C 545 150 560 250 590 300 L 595 372 L 430 372 L 428 440 C 420 458 392 460 382 445 L 372 380 C 368 300 390 200 400 0 Z" fill={BONE} stroke={hl ? C.acc : BONES} strokeWidth={4} />
    {/* малоберцовая */}
    <path d="M 615 0 L 645 0 C 648 150 650 260 655 320 C 672 345 680 420 668 470 C 655 492 628 488 618 462 C 608 420 604 360 608 320 C 610 250 612 150 615 0 Z" fill={BONE} stroke={hl ? C.acc : BONES} strokeWidth={4} />
    {/* синдесмоз */}
    <g opacity={0.4 + 0.6 * synd}>{[300, 320, 340].map((y) => <line key={y} x1={586} y1={y} x2={612} y2={y + 4} stroke={synd > 0.5 ? C.acc : '#C98C6E'} strokeWidth={5} />)}</g>
    {/* таранная */}
    <g transform={`translate(${sx},0)`}><path d="M 432 378 C 470 368 560 368 598 378 C 606 410 602 450 585 480 L 450 480 C 432 455 428 410 432 378 Z" fill="#E8DCC6" stroke={BONES} strokeWidth={4} /></g>
    {/* линии перелома */}
    {lat > 0 && <path d="M 604 400 L 664 360" stroke={C.acc} strokeWidth={6 * lat} strokeLinecap="round" />}
    {med > 0 && <path d="M 368 368 L 432 380" stroke={C.acc} strokeWidth={6 * med} strokeLinecap="round" />}
    {/* фиксация */}
    {fix > 0 && <g opacity={fix}>
      <rect x={664} y={240} width={24} height={200} rx={10} fill="#9AA5AE" stroke="#6B7686" strokeWidth={3} />
      {[260, 300, 340, 380, 420].map((y) => <line key={y} x1={676} y1={y} x2={618} y2={y} stroke={C.navy} strokeWidth={6} strokeLinecap="round" />)}
      {[0, 1].map((i) => <line key={i} x1={396 + i * 16} y1={440 - i * 6} x2={420 + i * 16} y2={330} stroke={C.navy} strokeWidth={7} strokeLinecap="round" />)}
      <line x1={690} y1={318} x2={500} y2={318} stroke={C.teal} strokeWidth={7} strokeLinecap="round" />
    </g>}
    {glow > 0 && <circle cx={520} cy={400} r={140} fill={C.acc} opacity={0.18 * glow} />}
    {label && <text textAnchor="end" x={150} y={575} fontFamily="'Body'" fontWeight={700} fontSize={22} fill={C.mute}>رسم توضيحي، ليس بمقياس حقيقي · الكاحل الأيمن من الأمام</text>}
  </svg>;
};

const S01: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const pulse = ease(f, fr(d, 0.3), fr(d, 0.4)) * (0.6 + 0.4 * Math.sin(f / 5));
  return <>
    <Card x={64} y={470} w={420} label="المريضة" at={4}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>مريضة</div>
      
    </Card>
    <Card x={540} y={470} w={476} label="الإصابة" at={14}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>تعثّرت والتوت قدمها</div>
    </Card>
    <WomanTwist y={650} h={740} d={d} />
    <div style={{position: 'absolute', left: 64, top: 1420, display: 'flex', gap: 12, flexWrap: 'wrap'}}>
      {['ألم', 'تورّم', 'كدمة', 'لا تستطيع الدوس'].map((t, i) => <div key={t} style={{opacity: ease(f, fr(d, 0.45) + i * 8, fr(d, 0.45) + 10 + i * 8)}}><Note size={28}>{t}</Note></div>)}
    </div>
  </>;
};

const Lbl: React.FC<{x: number; y: number; o: number; c?: string; children: React.ReactNode}> = ({x, y, o, c = C.navy, children}) =>
  <div style={{position: 'absolute', left: x, top: y, opacity: o, fontFamily: BODY, fontWeight: 700, fontSize: 26, color: c, background: '#fff', borderRadius: 14, padding: '6px 14px', boxShadow: '0 6px 18px rgba(20,24,32,.08)'}}>{children}</div>;
const S02: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <A3 n="anat" y={470} d={d} />
    <ALbl n="anat" y={470} d={d} k="tibia" side="r" o={ease(f, fr(d, 0.1), fr(d, 0.2)) * (1 - ease(f, fr(d, 0.74), fr(d, 0.78)))}>الظنبوب</ALbl>
    <ALbl n="anat" y={470} d={d} k="fibula" side="l" o={ease(f, fr(d, 0.1), fr(d, 0.2)) * (1 - ease(f, fr(d, 0.74), fr(d, 0.78)))}>الشظية</ALbl>
    <ALbl n="anat" y={470} d={d} k="talus" side="r" dy={60} o={ease(f, fr(d, 0.2), fr(d, 0.3)) * (1 - ease(f, fr(d, 0.74), fr(d, 0.78)))} c="#6B5A3A">عظم الكاحل</ALbl>
    <ALbl n="anat" y={470} d={d} k="med" side="r" o={ease(f, fr(d, 0.6), fr(d, 0.66)) * (1 - ease(f, fr(d, 0.74), fr(d, 0.78)))} c={C.acc}>الكعب الإنسي</ALbl>
    <ALbl n="anat" y={470} d={d} k="post" side="l" o={ease(f, fr(d, 0.8), fr(d, 0.86))} c={C.acc}>الكعب الخلفي</ALbl>
    <ALbl n="anat" y={470} d={d} k="lat" side="l" o={ease(f, fr(d, 0.42), fr(d, 0.5)) * (1 - ease(f, fr(d, 0.74), fr(d, 0.78)))} c={C.acc}>الكعب الوحشي</ALbl>
    <div style={{position: 'absolute', left: 64, top: 1300, opacity: ease(f, fr(d, 0.7), fr(d, 0.8))}}><Note color={C.navy} bg="#E3E7EF" size={28}>الكعب الخلفي: الحافة الخلفية للظنبوب</Note></div>
  </>;
};

const S03: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const a = ease(f, fr(d, 0.05), fr(d, 0.2)), b = ease(f, fr(d, 0.35), fr(d, 0.5)), s = ease(f, fr(d, 0.7), fr(d, 0.8));
  return <>
    <A3 n="frac" y={470} d={d} />
    <div style={{position: 'absolute', left: 64, top: 1300, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
      <div style={{opacity: a * (1 - b)}}><Note color={C.teal} bg={C.tealL} size={28}>الوحشي فقط: غالبًا مستقر</Note></div>
      <div style={{opacity: b}}><Note size={28}>كعبان أو ثلاثة: غالبًا غير مستقر، خلع</Note></div>
      <div style={{opacity: s}}><Note color={C.navy} bg="#E3E7EF" size={28}>الارتفاق: أربطة بين العظمين</Note></div>
    </div>
  </>;
};

const S04: React.FC<{d: number}> = ({d}) => <>
  <Card x={64} y={480} w={952} at={fr(d, 0.05)} label="الجرّاح يقرّر">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>الفحص + الصور</div>
  </Card>
  <Card x={64} y={680} w={460} at={fr(d, 0.2)} style={{borderTop: `8px solid ${C.acc}`}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>انزياح أو عدم استقرار</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 26, color: C.mute, marginTop: 8}}>عادةً عملية</div>
  </Card>
  <Card x={556} y={680} w={460} at={fr(d, 0.38)} style={{borderTop: `8px solid ${C.teal}`}}>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>مستقر، بدون انزياح</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 26, color: C.mute, marginTop: 8}}>غالبًا جبس أو حذاء خاص</div>
  </Card>
  <Card x={64} y={960} w={952} at={fr(d, 0.62)} style={{background: '#FDECEC', border: `4px solid ${C.blood}`}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 32, color: C.blood}}>جرح فوق الكسر</div>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink, marginTop: 8}}>قد يكون كسرًا مفتوحًا، اطلب المساعدة فورًا</div>
  </Card>
</>;

const S05: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const up = ease(f, 6, fr(d, 0.25));
  return <>
    <Clip3D src="c3/swell_elevate_hf.mp4" y={430} h={450} d={d} dur={8} label={(t) => t > 3.4 ? '― مستوى القلب ―' : null} />
    <Card x={64} y={900} w={952} at={fr(d, 0.3)} label="التورّم">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>عند التورّم الشديد تُؤجَّل العملية أحيانًا · عند الخلع أو التشوّه: إعادة وتثبيت مؤقت عاجلان</div>
    </Card>
    <Card x={64} y={1150} w={952} at={fr(d, 0.62)} style={{border: `4px solid #B45309`, background: '#FFF7ED'}} label="أخبر فورًا">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.ink}}>ألم تحت الجبيرة ↑ · خدر · وخز · قدم باردة أو شاحبة</div>
    </Card>
  </>;
};

const S06: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const fx = ease(f, fr(d, 0.15), fr(d, 0.45)), sy = ease(f, fr(d, 0.5), fr(d, 0.65));
  return <>
    <A3 n="fix" y={470} d={d} />
    <div style={{position: 'absolute', left: 64, top: 1300, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
      <div style={{opacity: fx}}><Note color={C.navy} bg="#E3E7EF" size={28}>صفيحة وبراغٍ</Note></div>
      <div style={{opacity: sy}}><Note color={C.teal} bg={C.tealL} size={28}>الارتفاق: برغي أو خيط مع أزرار</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.75), fr(d, 0.85))}}><Note size={28}>ثم جبيرة أو جبس أو دعامة</Note></div>
    </div>
  </>;
};

const S07: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <CheckRow y={480} at={fr(d, 0.02)} icon="leg" text="الساق مرفوعة · حرّك أصابع القدم" />
    <Card x={64} y={700} w={460} at={fr(d, 0.25)} style={{borderTop: `8px solid ${C.teal}`}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>لبعضهم: تحميل وزن مبكر</div>
    </Card>
    <Card x={556} y={700} w={460} at={fr(d, 0.35)} style={{borderTop: `8px solid ${C.acc}`}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>لآخرين: لا دوس مؤقتًا</div>
    </Card>
    <Card x={64} y={920} w={952} at={fr(d, 0.55)} style={{background: C.navy}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: '#fff'}}>فقط حسب تعليمات الجرّاح المكتوبة</div>
    </Card>
    <div style={{position: 'absolute', left: 64, top: 1130, opacity: ease(f, fr(d, 0.45), fr(d, 0.55))}}><Note color={C.teal} bg={C.tealL} size={30}>عكازات أو مشّاية، يعلّمك أخصائي العلاج الطبيعي</Note></div>
    <Card x={64} y={1230} w={952} at={fr(d, 0.72)} label="الوقاية من الجلطات">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.ink}}>لا يحتاجها الجميع · إذا وُصفت فحسب الخطة ولا توقفها بنفسك</div>
    </Card>
  </>;
};

const S08: React.FC<{d: number}> = ({d}) => {
  const items: [string, string][] = [['drop', 'ألم لا يزول بالمسكّنات'], ['leg', 'خدر، وخز، قدم شاحبة أو باردة'], ['wound', 'الضمادة تتبلّل'], ['calf', 'ألم أو تورّم في ربلة الساق'], ['lungs', 'ضيق نفس مفاجئ أو ألم في الصدر']];
  return <>{items.map(([k, t], i) => <Slot key={i} x={64} y={480 + i * 190} w={952} h={160} at={fr(d, 0.06 + i * 0.16)}>
    <Icon k={k} s={64} /><div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink, lineHeight: 1.2}}>{t}</div></Slot>)}</>;
};

const S09: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.02)} icon="drop" text="الجبس جاف · لا تُدخل فيه شيئًا" />
  <Card x={64} y={700} w={952} at={fr(d, 0.25)} style={{border: `4px solid #B45309`, background: '#FFF7ED'}} label="دون تأخير إلى القسم أو الطوارئ">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>تبلّل الجبس أو انكسر أو يحتكّ بشدة · رائحة أو إفرازات</div>
  </Card>
  <Card x={64} y={1000} w={952} at={fr(d, 0.7)} label="التدخين">
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>يزيد خطر المضاعفات، ناقش التوقف على الأقل خلال العلاج</div>
  </Card>
</>;

const S10: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const rows: [string, string][] = [['6 أسابيع على الأقل', 'الالتئام الأولي'], ['10–12 أسبوعًا', 'الالتئام الكامل'], ['3–4 أشهر', 'النشاط المعتاد لدى معظم الناس']];
  return <>
    {rows.map(([h, t], i) => <Card key={i} x={64} y={480 + i * 200} w={952} at={fr(d, 0.05 + i * 0.2)}>
      <div style={{display: 'flex', alignItems: 'center', gap: 30}}><div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 52, color: C.acc, minWidth: 300}}>{h}</div>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>{t}</div></div></Card>)}
    <div style={{position: 'absolute', left: 64, top: 1110, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
      <div style={{opacity: ease(f, fr(d, 0.6), fr(d, 0.7))}}><Note size={28}>التورّم والتيبّس: عدة أشهر</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.85), fr(d, 0.95))}}><Note color={C.navy} bg="#E3E7EF" size={28}>القيادة فقط بموافقة الطبيب، عندما تكون آمنة</Note></div>
    </div>
  </>;
};

const S11: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={520} at={fr(d, 0.02)} title="101 مساعدة طارئة" color={C.blood} bg="#FDECEC"
    items={[['lungs', 'ضيق نفس مفاجئ'], ['heart', 'ألم في الصدر'], ['leg', 'قدم باردة أو شاحبة أو زرقاء'], ['leg', 'خدر واضح'], ['drop', 'ألم يشتد بحدّة'], ['wound', 'الجبس يضغط بشدة']]} />
  <div style={{position: 'absolute', left: 64, top: 1010, opacity: ease(useCurrentFrame(), fr(d, 0.45), fr(d, 0.55))}}><Note size={28}>لا تقُد بنفسك</Note></div>
  <Tier y={1090} h={300} at={fr(d, 0.7)} title="إلى الطبيب في اليوم نفسه" color={C.navy} bg="#fff"
    items={[['therm', 'حرارة 38 درجة أو أكثر'], ['wound', 'احمرار أو إفرازات من الجرح'], ['calf', 'ألم جديد أو تورّم في ربلة الساق']]} />
</>;

const S12: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>هذه توصيات عامة</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>تعليمات طبيبكم والفريق الطبي الخاصة بكم لها الأولوية</div>
  </Card>
);

const SC: Record<string, React.FC<{d: number}>> = {F01: S01, F02: S02, F03: S03, F04: S04, F05: S05, F06: S06, F07: S07, F08: S08, F09: S09, F10: S10, F11: S11, F12: S12};

export const AnkleFilm_ar: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
  let at = 0;
  return (
    <AbsoluteFill style={{direction: 'rtl'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
