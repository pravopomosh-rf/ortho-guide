// «Ламинэктомия» — ролик для пациентов в формате «клинический случай» (9:16).
import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Counter, Bar, Subtitle, Slot, Note, C, BODY, HEAD, MONO, ease, Word, clamp01} from './kit';
import {Vertebra} from './Vertebra';
import {Person, Icon} from './Figures';
import timing from './timing_lam_he.json';

type T = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const TT = timing as T;
const FPS = 30, PAD = 0.5;
export const totalLam_he = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
const BRAND = 'אורתופדיה · למטופלים';

// words timed proportionally to characters across the audio
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};
const fr = (d: number, p: number) => Math.round(d * p);

const S01: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const walkEnd = fr(d, 0.62), bend = ease(f, walkEnd + 30, walkEnd + 75);
  const glow = Math.min(ease(f, fr(d, 0.15), fr(d, 0.55)), 1 - 0.7 * bend);
  return <>
    <Card x={64} y={470} w={420} label="מטופל" at={4}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 40, color: C.ink}}>מטופל</div>
      
    </Card>
    <Card x={540} y={470} w={476} label="הולך" at={14}>
      <div><Counter from={0} to={180} a={10} b={walkEnd} size={78} suffix=" מ׳" /></div>
      <div style={{marginTop: 10}}><Bar p={ease(f, 10, walkEnd) * 0.9} color={C.acc} /></div>
      <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 24, color: C.mute, marginTop: 8}}>ונעצר</div>
    </Card>
    <Img src={staticFile(`lamwalk/${String(Math.min(f, d - 1)).padStart(4, '0')}.png`)} style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 1920, transform: 'scale(0.86)', transformOrigin: '540px 1475px'}} />
    <svg width={1080} height={900} style={{position: 'absolute', left: 0, top: 760}}>
      {glow > 0.2 && <g opacity={glow}><foreignObject x={760} y={400} width={290} height={260}><div style={{display: 'flex', gap: 12, flexDirection: 'column', alignItems: 'flex-start'}}>
        <Note size={32}>חוסר תחושה</Note><Note size={32}>כבדות</Note><Note size={32}>כאב</Note></div></foreignObject></g>}
      {bend > 0.3 && <foreignObject x={40} y={70} width={470} height={90}><div style={{opacity: bend, whiteSpace: "nowrap"}}><Note size={32} color={C.teal} bg={C.tealL}>התכופפות קדימה ← הקלה</Note></div></foreignObject>}
    </svg>
  </>;
};

const S02: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  return <>
    <div style={{position: 'absolute', left: 110, top: 560}}><Vertebra sten={ease(f, 10, fr(d, 0.7))} cut={0} size={860} labels={{canal: 'תעלה', lig: 'רצועה', ost: 'זיזים גרמיים'}} /></div>
    <div style={{position: 'absolute', left: 64, top: 1430, fontFamily: BODY, fontWeight: 600, fontSize: 22, color: C.mute}}>תרשים, לא בקנה מידה · מבט מלמעלה, הגב למטה</div>
  </>;
};

const MiniCanal: React.FC<{sten: number; title: string; c: string}> = ({sten, title, c}) => (
  <div style={{textAlign: 'center', width: 400}}>
    <div style={{height: 300, overflow: 'hidden'}}><Vertebra sten={sten} cut={0} size={380} /></div>
    <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 28, color: c}}>{title}</div>
  </div>
);
const S03: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const steps = ['טיפול ללא ניתוח', 'לא עזר', 'ייעוץ מנתח'];
  return <>
    <Card x={64} y={470} w={952} label="תהודה מגנטית (MRI)" at={2}>
      <div style={{display: 'flex', justifyContent: 'space-around'}}><MiniCanal sten={0} title="תקין" c={C.teal} /><MiniCanal sten={1} title="היצרות" c={C.acc} /></div>
    </Card>
    <div style={{position: 'absolute', left: 64, right: 64, top: 920, display: 'flex', gap: 16, justifyContent: 'center'}}>
      {['תסמינים', 'בדיקה', 'צילומים'].map((t, i) => <div key={t} style={{opacity: ease(f, fr(d, 0.25) + i * 6, fr(d, 0.25) + i * 6 + 10)}}><Note color={C.ink} bg="#fff" size={30}>{t}</Note></div>)}
    </div>
    {steps.map((t, i) => {
      const a = fr(d, 0.55) + i * 14, o = ease(f, a, a + 10);
      return <div key={t} style={{position: 'absolute', left: 120, right: 120, top: 1030 + i * 120, opacity: o, transform: `translateX(${(1 - o) * 40}px)`}}>
        <div style={{display: 'flex', alignItems: 'center', gap: 22, background: i === 2 ? C.navy : '#fff', borderRadius: 24, padding: '22px 30px', boxShadow: '0 10px 26px rgba(20,24,32,.07)'}}>
          <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 34, color: i === 2 ? '#fff' : C.acc}}>{i + 1}</div>
          <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: i === 2 ? '#fff' : C.ink}}>{t}</div>
        </div>
      </div>;
    })}
  </>;
};

const S04: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const hlA = fr(d, 0.08), cutA = fr(d, 0.45);
  const hl = f > hlA && f < cutA + 10 ? 0.5 + 0.5 * Math.sin((f - hlA) / 6) : 0;
  return <>
    <div style={{position: 'absolute', left: 110, top: 560}}><Vertebra sten={1} cut={ease(f, cutA, cutA + 40)} hl={hl} glow={ease(f, cutA + 30, cutA + 55)} size={860} labels={{canal: 'יותר מקום', lam: 'למינה'}} /></div>
    <div style={{position: 'absolute', left: 64, top: 1430, fontFamily: BODY, fontWeight: 600, fontSize: 22, color: C.mute}}>תרשים, לא בקנה מידה · מפרקי החוליה נשמרים</div>
  </>;
};

const S05: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const scr = ease(f, fr(d, 0.35), fr(d, 0.5)), graft = ease(f, fr(d, 0.55), fr(d, 0.7));
  const bone = '#EFE6D8', boneS = '#C9B79C';
  // lateral view: front (bodies) left, back (posterior elements) right
  const Vt = (y: number) => <g>
    <rect x={250} y={y} width={260} height={160} rx={30} fill={bone} stroke={boneS} strokeWidth={4} />
    {/* pedicle */}
    <path d={`M 505 ${y + 40} L 600 ${y + 30} L 600 ${y + 90} L 505 ${y + 95} Z`} fill={bone} stroke={boneS} strokeWidth={4} />
    {/* lamina + spinous process */}
    <path d={`M 600 ${y + 20} L 650 ${y + 10} L 790 ${y + 60} L 800 ${y + 100} L 650 ${y + 110} L 600 ${y + 100} Z`} fill={bone} stroke={boneS} strokeWidth={4} />
  </g>;
  const screw = (y: number) => <g>
    <line x1={640} y1={y + 62} x2={330} y2={y + 82} stroke={C.navy} strokeWidth={14} strokeLinecap="round" strokeDasharray="20 9" />
    <circle cx={650} cy={y + 62} r={20} fill={C.navy} />
  </g>;
  return <>
    <svg width={1080} height={640} style={{position: 'absolute', left: 0, top: 480}}>
      {Vt(100)}{Vt(380)}
      <rect x={265} y={272} width={230} height={96} rx={22} fill="#D7E9EE" stroke="#9CC9D3" strokeWidth={3} />
      {graft > 0 && <g opacity={graft}>{Array.from({length: 15}, (_, i) => <circle key={i} cx={290 + (i % 5) * 45} cy={292 + Math.floor(i / 5) * 26} r={10} fill="#F2D27A" stroke="#C99A1E" strokeWidth={2} />)}</g>}
      <g opacity={scr}>{screw(100)}{screw(380)}<line x1={672} y1={150} x2={672} y2={455} stroke="#6B7686" strokeWidth={16} strokeLinecap="round" /></g>
      <text textAnchor="end" x={250} y={80} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.teal}>קדימה</text><text textAnchor="end" x={460} y={80} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.mute}>מבט מהצד</text><text textAnchor="end" x={720} y={80} fontFamily="'Body'" fontWeight={700} fontSize={24} fill={C.teal}>אחורה</text>
    </svg>
    <div style={{position: 'absolute', left: 64, top: 1150, display: 'flex', gap: 16, flexWrap: 'wrap'}}>
      <div style={{opacity: scr}}><Note color={C.navy} bg="#E3E7EF" size={28}>ברגים בפדיקלים + מוט מאחור</Note></div>
      <div style={{opacity: graft}}><Note color="#9A7410" bg="#FBF0D0" size={28}>חומר עצם לאיחוי</Note></div>
      <div style={{opacity: ease(f, fr(d, 0.15), fr(d, 0.25))}}><Note size={28}>רק אם צריך</Note></div>
    </div>
    <Card x={64} y={1250} w={952} at={fr(d, 0.78)} style={{background: C.navy}}>
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: '#fff'}}>אם זה נחוץ לכם, יחליט המנתח לאחר הבירור</div>
    </Card>
  </>;
};

const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22), transform: `scale(${0.6 + 0.4 * ease(f, at + 14, at + 22)})`}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const S06: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={500} at={fr(d, 0.02)} icon="shower" text="מקלחת בערב ובבוקר לפי הוראות המחלקה" />
  <CheckRow y={700} at={fr(d, 0.25)} icon="razor" text="לא לגלח את הגב בעצמכם" />
  <CheckRow y={900} at={fr(d, 0.38)} icon="therm" text="לספר על פצעים, חום, שיעול, צריבה, שיניים ואלרגיה לחומרי חיטוי" />
</>;

const SC01: React.FC<{d: number}> = ({d}) => <>
  <CheckRow y={480} at={fr(d, 0.02)} icon="shower" text="מקלחת בערב ובבוקר בכלורהקסידין 4%" />
  <CheckRow y={660} at={fr(d, 0.3)} icon="clock" text="כשהעור יבש לגמרי — שש מטליות סייג׳ 2%" />
  <CheckRow y={840} at={fr(d, 0.6)} icon="check" text="הצוות יעזור בניגוב הגב" />
  <CheckRow y={1020} at={fr(d, 0.78)} icon="drop" text="לא לשטוף את החומר" />
  <div style={{position: 'absolute', right: 64, top: 1220, opacity: ease(useCurrentFrame(), fr(d, 0.1), fr(d, 0.1) + 12)}}><Note size={30}>אם אין לכם אלרגיה לכלורהקסידין</Note></div>
</>;

const S07: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const calA = fr(d, 0.3);
  return <>
    <CheckRow y={480} at={2} icon="pills" text="רשימת כל התרופות" />
    <Card x={64} y={660} w={952} at={fr(d, 0.1)} label="מדללי דם">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink}}>רק לפי הוראת הרופא. אל תפסיקו אספירין בעצמכם</div>
    </Card>
    <Card x={64} y={880} w={952} at={calA} label="גליפלוזינים">
      <div style={{display: 'flex', gap: 30, alignItems: 'center'}}>
        <div style={{textAlign: 'center'}}><div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 72, color: C.acc, direction: 'ltr'}}>≥{Math.round(interpolate(f, [calA, calA + 30], [0, 3], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}))}</div><div style={{fontFamily: MONO, fontWeight: 700, fontSize: 20, color: C.mute}}>ימים</div></div>
        <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 28, color: C.ink, lineHeight: 1.3}}>אמפגליפלוזין, דפגליפלוזין<div style={{color: C.mute, fontWeight: 600}}>ארטוגליפלוזין, לפחות 4 ימים</div></div>
      </div>
      <div style={{marginTop: 14}}><Note>רק לפי תוכנית הרופא · סיכון לחמצת קטוטית</Note></div>
    </Card>
    <Card x={64} y={1200} w={952} at={fr(d, 0.85)} label="אינסולין ותרופות אחרות לסוכרת">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink}}>תוכנית אישית מהרופא</div>
    </Card>
  </>;
};

const S08: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const marks = [{h: '8 שע׳ לפני', t: 'ארוחה כבדה או שומנית', c: C.acc}, {h: '6 שע׳ לפני', t: 'ארוחה קלה', c: '#E58A2B'}, {h: '2 שע׳ לפני', t: 'מים ונוזלים צלולים', c: C.teal}, {h: '0', t: 'הרדמה', c: C.navy}];
  const p = ease(f, 6, fr(d, 0.85));
  return <>
    <div style={{position: 'absolute', left: 150, top: 520, width: 8, height: 900, background: C.line, borderRadius: 8}} />
    <div style={{position: 'absolute', left: 150, top: 520, width: 8, height: 900 * p, background: C.ink, borderRadius: 8}} />
    {marks.map((m, i) => {
      const a = 6 + i * fr(d, 0.22), o = ease(f, a, a + 12);
      return <div key={i} style={{position: 'absolute', left: 120, top: 500 + i * 290, display: 'flex', alignItems: 'center', gap: 34, opacity: o, transform: `translateX(${(1 - o) * 30}px)`}}>
        <div style={{width: 68, height: 68, borderRadius: 68, background: m.c, boxShadow: `0 0 0 10px ${C.bg1}`}} />
        <div style={{background: '#fff', borderRadius: 26, padding: '22px 30px', boxShadow: '0 12px 30px rgba(20,24,32,.07)', width: 680}}>
          <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 56, color: m.c}}>{m.h}</div>
          <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink}}>{m.t}</div>
        </div>
      </div>;
    })}
  </>;
};

const S09: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const dr = fr(d, 0.42);
  const fill = ease(f, dr + 10, dr + 80);
  return <>
    <Card x={64} y={480} w={952} at={2} label="קימה">
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink}}>בדרך כלל מוקדם, בליווי צוות המחלקה</div>
    </Card>
    <Card x={64} y={700} w={952} h={620} at={dr} label="נקז · לא תמיד">
      <svg width={880} height={460}>
        <rect x={40} y={40} width={260} height={150} rx={30} fill="#F3E2D6" stroke="#D9B79F" strokeWidth={3} />
        <line x1={110} y1={115} x2={230} y2={115} stroke="#C98C6E" strokeWidth={6} strokeDasharray="6 8" />
        <path d={`M 200 120 C 360 120 360 300 520 300`} stroke="#B9C6CF" strokeWidth={16} fill="none" strokeLinecap="round" />
        <path d={`M 200 120 C 360 120 360 300 520 300`} stroke={C.blood} strokeWidth={8} fill="none" strokeLinecap="round" strokeDasharray="20 18" strokeDashoffset={-f * 1.5} opacity={0.6} />
        <rect x={520} y={220} width={170} height={210} rx={30} fill="#fff" stroke="#9AA5AE" strokeWidth={5} />
        <rect x={528} y={428 - 190 * fill * 0.35} width={154} height={190 * fill * 0.35} rx={22} fill={C.blood} opacity={0.75} />
        <text x={605} y={210} textAnchor="middle" fontFamily="'Body'" fontWeight={700} fontSize={26} fill={C.mute}>מיכל סגור</text>
      </svg>
      <div style={{display: 'flex', gap: 12, flexWrap: 'wrap', marginTop: 6}}>
        {['לא למשוך', 'לא לקפל', 'לא לנתק'].map((t, i) => <div key={t} style={{opacity: ease(f, dr + 40 + i * 10, dr + 50 + i * 10)}}><Note size={28}>{t}</Note></div>)}
      </div>
    </Card>
    <div style={{position: 'absolute', left: 64, top: 1350, opacity: ease(f, fr(d, 0.82), fr(d, 0.9))}}><Note color={C.navy} bg="#E3E7EF" size={28}>מתי להוציא, מחליט המנתח</Note></div>
  </>;
};

const S10: React.FC<{d: number}> = ({d}) => {
  const items: [string, string][] = [['tube', 'הצינורית יצאה או התנתקה'], ['drop', 'מתמלא מהר בדם אדום בהיר'], ['clock', 'הניקוז נפסק פתאום'], ['wound', 'דולף סביב הצינורית'], ['head', 'נוזל שקוף + כאב ראש בישיבה או בעמידה']];
  return <>{items.map(([k, t], i) => <Slot key={i} x={64} y={480 + i * 190} w={952} h={160} at={fr(d, 0.08 + i * 0.17)}>
    <Icon k={k} s={70} /><div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, color: C.ink, lineHeight: 1.2}}>{t}</div></Slot>)}</>;
};

const Tier: React.FC<{y: number; at: number; title: string; color: string; bg: string; items: [string, string][]; h: number}> = ({y, at, title, color, bg, items, h}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} h={h} at={at} style={{border: `4px solid ${color}`, background: bg}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 36, color, marginBottom: 14}}>{title}</div>
    <div style={{display: 'flex', flexWrap: 'wrap', gap: '10px 18px'}}>
      {items.map(([k, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 10, opacity: ease(f, at + 8 + i * 6, at + 16 + i * 6)}}>
        <Icon k={k} s={42} c={color} /><span style={{fontFamily: BODY, fontWeight: 700, fontSize: 26, color: C.ink}}>{t}</span></div>)}
    </div>
  </Card>;
};
const S11: React.FC<{d: number}> = ({d}) => <>
  <Tier y={470} h={430} at={fr(d, 0.02)} title="מיד לחדר המיון" color="#B45309" bg="#FFF7ED"
    items={[['leg', 'חולשה או חוסר תחושה ברגל אחת או בשתיהן'], ['bladder', 'חוסר תחושה בין איברי המין לפי הטבעת, קושי במתן שתן'], ['bladder', 'אובדן שליטה על השלפוחית או המעיים'], ['head', 'נוזל שקוף מהפצע + כאב ראש']]} />
  <Tier y={930} h={250} at={fr(d, 0.6)} title="לרופא ללא דיחוי" color={C.navy} bg="#fff"
    items={[['therm', 'חום'], ['wound', 'אודם או הפרשה מהפצע'], ['calf', 'כאב או נפיחות בשוק אחת']]} />
  <Tier y={1210} h={230} at={fr(d, 0.82)} title="101 מיד" color={C.blood} bg="#FDECEC"
    items={[['lungs', 'קוצר נשימה פתאומי'], ['heart', 'כאב בחזה'], ['faint', 'עילפון']]} />
</>;

const S12: React.FC<{d: number}> = () => (
  <Card x={64} y={760} w={952} at={4} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
    <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 44, color: C.ink, marginBottom: 18}}>אלה המלצות כלליות</div>
    <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute, lineHeight: 1.35}}>ההוראות האישיות של הרופא ושל הצוות הרפואי קודמות</div>
  </Card>
);

const SC: Record<string, React.FC<{d: number}>> = {L01: S01, L02: S02, L03: S03, L04: S04, L05: S05, L06: S06, C01: SC01, L07: S07, L08: S08, L09: S09, L10: S10, L11: S11, L12: S12};

export const Lam_he: React.FC<{withAudio?: boolean; head?: boolean}> = ({withAudio = true, head = false}: {withAudio?: boolean; head?: boolean}) => {
  let at = 0;
  return (
    <AbsoluteFill style={{direction: 'rtl'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        const Comp = SC[x.id];
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={BRAND} n={i + 1} total={TT.length} label={x.label} />
            {!head && <><Headline text={x.head} acc={x.acc} at={0} />
            <Comp d={d} />
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} /></>}
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>
  );
};

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
