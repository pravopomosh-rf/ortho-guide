import json,subprocess,sys,os
L=sys.argv[1]; S='/home/claude/night/lam/r'; W='/home/claude/w'
old=json.load(open(f'{W}/old.json'))[L]
sfx='' if L=='ru' else '_'+L
fr=[round((x['dur']+0.5)*30) for x in json.load(open(f'{S}/src/timing_lam{sfx}.json'))]
nc=[0]; [nc.append(nc[-1]+x) for x in fr]
oc=[0]; [oc.append(oc[-1]+x) for x in old]
O=f'/home/claude/ortho-guide/video/laminectomy_{L}.mp4'
A=f'{S}/out/lamA_{L}.mp4'; B=f'{S}/out/lamB_{L}.mp4'; H=f'{S}/out/lamH_{L}.mp4'
w=720 if L=='ru' else 1080; h=w*16//9; s=w/1080
rtl=L in('he','ar'); bx=int((58 if rtl else 872)*s)//2*2; by=int(132*s)//2*2; bw=int(150*s)//2*2; bh=int(56*s)//2*2
enc=['-c:v','libx264','-preset','medium','-crf','17','-pix_fmt','yuv420p','-r','30','-video_track_timescale','90000','-an']
def run(a): subprocess.run(['ffmpeg','-v','error','-y']+a,check=True)
def oldseg(name,o0,o1,n0):
    # old frames [o0,o1) placed at new frame n0, with header patch from H
    n1=n0+(o1-o0)
    fc=(f"[0:v]trim=start_frame={o0}:end_frame={o1},setpts=PTS-STARTPTS,format=rgb24[o];"
        f"[1:v]trim=start_frame={n0}:end_frame={n1},setpts=PTS-STARTPTS,format=rgb24[hp];"
        f"[o][hp]overlay={bx}:{by}:shortest=1,format=yuv420p[v]")
    run(['-i',O,'-i',H,'-filter_complex',fc,'-map','[v]']+enc+[f'{W}/{L}_{name}.mp4'])
def newseg(name,src,f0,f1):
    run(['-i',src,'-vf',f"trim=start_frame={f0}:end_frame={f1},setpts=PTS-STARTPTS,scale={w}:{h},format=yuv420p"]+enc+[f'{W}/{L}_{name}.mp4'])
segs=[]
assert old[1:6]==fr[1:6] and old[6:]==fr[7:], (old,fr)
if L=='en':
    assert old[0]==fr[0]
    oldseg('s1',0,nc[6]-4,0); segs.append('s1')
else:
    o0=old[0]; f0=fr[0]; y0=int(726*s)//2*2; bh2=int((1488-726)*s)//2*2
    k=(f0-2)/(o0-2)
    fc=(f"[1:v]trim=start_frame=0:end_frame={o0-2},setpts=(PTS-STARTPTS)*{k:.6f},fps=30,trim=end_frame={f0-2},crop={w}:{bh2}:0:{y0},format=rgb24[b1];"
        f"[1:v]trim=start_frame={o0-2}:end_frame={o0+10},setpts=PTS-STARTPTS,crop={w}:{bh2}:0:{y0},format=rgb24[b2];[b1][b2]concat=n=2:v=1:a=0[band];"
        f"[0:v]trim=start_frame=0:end_frame={f0+10},setpts=PTS-STARTPTS,scale={w}:{h},format=rgb24[a];[a][band]overlay=0:{y0}:shortest=1,format=yuv420p[v]")
    run(['-i',A,'-i',O,'-filter_complex',fc,'-map','[v]']+enc+[f'{W}/{L}_s1.mp4']); segs.append('s1')
    oldseg('s2',o0+10,oc[6]-4,f0+10); segs.append('s2')
newseg('s3',B,0,(nc[7]+10)-(nc[6]-4)); segs.append('s3')
oldseg('s4',oc[6]+10,oc[-1],nc[7]+10); segs.append('s4')
open(f'{W}/{L}_list.txt','w').write(''.join(f"file '{W}/{L}_{x}.mp4'\n" for x in segs))
run(['-f','concat','-safe','0','-i',f'{W}/{L}_list.txt','-c','copy',f'{W}/{L}_v.mp4'])
# audio
T=lambda n:n/30
parts=[]
if L=='en': parts.append(('old',0,oc[6]))
else:
    parts.append(('new',f'{S}/public/aud/lam_{L}_L01.wav',fr[0])); parts.append(('old',oc[1],oc[6]))
parts.append(('new',f'{S}/public/aud/lam_{L}_C01.wav',fr[6])); parts.append(('old',oc[6],oc[-1]))
ins=[];fcs=[]
for i,p in enumerate(parts):
    if p[0]=='old':
        ins+=['-i',O]; fcs.append(f"[{i}:a]atrim=start={T(p[1])}:end={T(p[2])},asetpts=PTS-STARTPTS,aresample=48000,aformat=channel_layouts=stereo[a{i}]")
    else:
        ins+=['-i',p[1]]; fcs.append(f"[{i}:a]aresample=48000,aformat=channel_layouts=stereo,adelay=133|133,apad,atrim=end={T(p[2])}[a{i}]")
fc=';'.join(fcs)+';'+''.join(f'[a{i}]' for i in range(len(parts)))+f'concat=n={len(parts)}:v=0:a=1[a]'
run(ins+['-filter_complex',fc,'-map','[a]','-c:a','pcm_s16le',f'{W}/{L}_a.wav'])
out=f'{S}/out/lam_{L}.mp4'
run(['-i',f'{W}/{L}_v.mp4','-i',f'{W}/{L}_a.wav','-map','0:v','-map','1:a','-c:v','copy','-c:a','aac','-b:a','160k','-shortest','-movflags','+faststart',out])
for x in [f'{W}/{L}_v.mp4',f'{W}/{L}_a.wav',out]:
    print(x,subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',x]).decode().strip())
print('expected',nc[-1]/30)
