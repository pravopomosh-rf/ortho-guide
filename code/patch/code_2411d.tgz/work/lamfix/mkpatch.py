import json,subprocess,sys,numpy as np
from PIL import Image
L=sys.argv[1]; S='/home/claude/night/lam/r'; W='/home/claude/w'
sfx='' if L=='ru' else '_'+L
fr=[round((x['dur']+0.5)*30) for x in json.load(open(f'{S}/src/timing_lam{sfx}.json'))]
w=720 if L=='ru' else 1080; h=w*16//9; s=w/1080
rtl=L in('he','ar'); bx=int((58 if rtl else 872)*s)//2*2; by=int(132*s)//2*2; bw=int(150*s)//2*2; bh=int(56*s)//2*2
def crop(im): 
    im=im.convert('RGB').resize((w,h),Image.LANCZOS) if im.size[0]!=w else im.convert('RGB')
    return np.asarray(im.crop((bx,by,bx+bw,by+bh))).astype(float)
imgs=[crop(Image.open(f'{W}/st/{L}_{i+1:02d}.png')) for i in range(len(fr))]
f0=subprocess.check_output(['ffmpeg','-v','error','-i',f'{S}/out/lamA_{L}.mp4','-frames:v','1','-f','image2pipe','-vcodec','png','-'])
import io; bg=crop(Image.open(io.BytesIO(f0)))
def bez(t,p1=(0.22,1),p2=(0.36,1)):
    lo,hi=0.0,1.0
    for _ in range(40):
        m=(lo+hi)/2; x=3*(1-m)**2*m*p1[0]+3*(1-m)*m**2*p2[0]+m**3
        if x<t: lo=m
        else: hi=m
    m=(lo+hi)/2; return 3*(1-m)**2*m*p1[1]+3*(1-m)*m**2*p2[1]+m**3
def ease(f,a,b): t=min(1,max(0,(f-a)/(b-a))); return bez(t) if 0<t<1 else t
st=[0]; [st.append(st[-1]+x) for x in fr]; N=st[-1]
p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{bw}x{bh}','-r','30','-i','-','-c:v','libx264','-crf','8','-pix_fmt','yuv444p',f'{S}/out/lamH_{L}.mp4'],stdin=subprocess.PIPE)
for n in range(N):
    acc=bg.copy()
    for k in range(len(fr)):
        l=n-st[k]; d=fr[k]
        if l<0 or l>=d+10: continue
        v=min(ease(l,0,10), 1 if k==len(fr)-1 else 1-ease(l,d-2,d+10))
        if v>0: acc+=v*(imgs[k]-bg)
    p.stdin.write(np.clip(acc,0,255).astype(np.uint8).tobytes())
p.stdin.close(); p.wait(); print('patch',L,N,bw,bh)
