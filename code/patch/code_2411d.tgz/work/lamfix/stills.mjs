import {bundle} from '@remotion/bundler'; import {renderStill, selectComposition} from '@remotion/renderer'; import fs from 'fs';
const R='/home/claude/night/lam/r'; const CH='/opt/pw-browsers/chromium-1243/chrome-linux64/chrome';
const serveUrl=await bundle({entryPoint:R+'/src/index.ts'});
for (const L of process.argv.slice(2)){
  const sfx=L==='ru'?'':'_'+L, id='LamH'+(L==='ru'?'':'-'+L);
  const tm=JSON.parse(fs.readFileSync(`${R}/src/timing_lam${sfx}.json`));
  const comp=await selectComposition({serveUrl,id,inputProps:{head:true,withAudio:false},browserExecutable:CH});
  let at=0;
  for (let i=0;i<tm.length;i++){const d=Math.round((tm[i].dur+0.5)*30); const f=at+Math.floor(d/2); at+=d;
    await renderStill({composition:comp,serveUrl,frame:f,output:`/home/claude/w/st/${L}_${String(i+1).padStart(2,'0')}.png`,inputProps:{head:true,withAudio:false},browserExecutable:CH});}
  console.log('done',L);
}
