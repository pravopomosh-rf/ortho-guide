import json,subprocess,io,sys
from PIL import Image
L=sys.argv[1]; sfx='' if L=='ru' else '_'+L
fr=[round((x['dur']+0.5)*30) for x in json.load(open(f'/home/claude/night/lam/r/src/timing_lam{sfx}.json'))]
c=[0];[c.append(c[-1]+x) for x in fr]
pts=[60,200,fr[0]-20,fr[0]+9,fr[0]+11, c[6]-5,c[6]-3,c[6]+40,c[7]-30, c[7]+9,c[7]+11, c[8]+30]
ims=[]
for p in pts:
    b=subprocess.check_output(['ffmpeg','-v','error','-i',f'/home/claude/out/laminectomy_{L}.mp4','-vf',f'select=eq(n\\,{p}),scale=240:-1','-frames:v','1','-f','image2pipe','-vcodec','png','-'])
    ims.append(Image.open(io.BytesIO(b)))
W=Image.new('RGB',(240*6,ims[0].height*2),'white')
for i,im in enumerate(ims): W.paste(im,((i%6)*240,(i//6)*im.height))
W.save(f'/home/claude/out/seams_{L}.png')
