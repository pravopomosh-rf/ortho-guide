import json,re,subprocess,numpy as np
S='/home/claude/night/lam/r/src'; T='/home/claude/ttsrepo'; R='/home/claude/night/lam/r'
tx=json.load(open(f'{T}/lam.json'))
old={}
for L in ['ru','he','ar','en']:
    a=np.load(f'/home/claude/w/{L}.npy'); d=np.abs(np.diff(a,axis=0)).mean(1)
    idx=np.where(d>0.3)[0]; grp=[]
    for i in idx:
        if grp and i-grp[-1][-1]<=4: grp[-1].append(i)
        else: grp.append([i])
    st=[g[0]+2 for g in grp if len(g)>=3 and g[0]>5]; b=[0]+st+[len(a)]
    old[L]=[int(b[i+1]-b[i]) for i in range(len(b)-1)]
json.dump(old,open('/home/claude/w/old.json','w'))
for L in ['ru','he','ar','en']:
    sfx='' if L=='ru' else '_'+L
    tm=json.load(open(f'{S}/timing_lam{sfx}.json'))
    assert len(tm)==12 and len(old[L])==12
    for x,fr in zip(tm,old[L]): x['dur']=round(fr/30-0.5,4); x['audio']=None
    # new L01 (ru/he/ar) and C01
    for cid in (['L01'] if L!='en' else [])+['C01']:
        src=f'{T}/aud/lam/{L}/{cid}.opus'; out=f'lam_{L}_{cid}.wav'
        subprocess.run(['ffmpeg','-v','error','-y','-i',src,'-ar','48000','-ac','2',f'{R}/public/aud/{out}'],check=True)
        dd=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',f'{R}/public/aud/{out}']))
        if cid=='L01': tm[0]['dur']=round(dd,2); tm[0]['audio']=out
    if f'{L}_L01' in tx: tm[0]['text']=tx[f'{L}_L01'].strip()
    kc=[x for x in json.load(open(f'{S}/timing_kyph{sfx}.json')) if x['id']=='C01'][0]
    c=dict(kc); c['label']=tm[5]['label']; c['audio']=f'lam_{L}_C01.wav'
    dd=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',f'{R}/public/aud/lam_{L}_C01.wav'])); c['dur']=round(dd,2)
    tm.insert(6,c)
    json.dump(tm,open(f'{S}/timing_lam{sfx}.json','w'),ensure_ascii=False)
    print(L,[round((x['dur']+0.5)*30) for x in tm], c['label'])
    # tsx
    f=f'{S}/Lam{sfx}.tsx'; s=open(f).read(); k=open(f'{S}/Kyph{sfx}.tsx').read()
    sc=k[k.index('const SC01'):k.index('const S07')]
    if 'const SC01' not in s:
        s=s.replace('const S07',sc+'const S07',1)
        s=s.replace('L06: S06, L07','L06: S06, C01: SC01, L07')
        # head-only mode
        s=s.replace('({withAudio = true}) => {','({withAudio = true, head = false}: {withAudio?: boolean; head?: boolean}) => {',1)
        s=s.replace('React.FC<{withAudio?: boolean}>','React.FC<{withAudio?: boolean; head?: boolean}>',1)
        s=s.replace('<Headline text={x.head} acc={x.acc} at={0} />\n            <Comp d={d} />\n            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />',
          '{!head && <><Headline text={x.head} acc={x.acc} at={0} />\n            <Comp d={d} />\n            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} /></>}')
        assert '{!head &&' in s and 'C01: SC01' in s
        open(f,'w').write(s)
