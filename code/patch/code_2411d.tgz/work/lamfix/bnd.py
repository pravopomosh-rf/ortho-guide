import numpy as np,sys
a=np.load(sys.argv[1]); d=np.abs(np.diff(a,axis=0)).mean(1)
idx=np.where(d>0.3)[0]; grp=[]
for i in idx:
  if grp and i-grp[-1][-1]<=4: grp[-1].append(i)
  else: grp.append([i])
st=[g[0]+2 for g in grp if len(g)>=3 and g[0]>5]
b=[0]+st+[len(a)]; print(sys.argv[1],len(a),[int(b[i+1]-b[i]) for i in range(len(b)-1)])
