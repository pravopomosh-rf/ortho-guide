import subprocess,sys,numpy as np
v,rtl=sys.argv[1],sys.argv[2]=='1'
out=subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=width,height','-of','csv=p=0',v]).decode().split()[0].strip(',')
w,h=[int(x) for x in out.split(',')[:2]]
s=w/1080
x0=int((64 if rtl else 900)*s); cw=int(116*s)//2*2; y0=int(140*s); ch=int(50*s)//2*2
p=subprocess.Popen(['ffmpeg','-v','error','-i',v,'-vf',f'crop={cw}:{ch}:{x0}:{y0},format=gray','-f','rawvideo','-'],stdout=subprocess.PIPE)
raw=p.stdout.read(); a=np.frombuffer(raw,np.uint8).reshape(-1,ch*cw).astype(float)
np.save(sys.argv[3],a)
d=np.abs(np.diff(a,axis=0)).mean(1)
for r in sys.argv[4:]:
  lo,hi=map(int,r.split('-')); print(r,[round(x,2) for x in d[lo:hi]])
