import {T, setLang, isRTL, cueOf, dictOf, Lang} from './i18n';
import ANCH_HE from './preop_anchors_he.json';
import ANCH_AR from './preop_anchors_ar.json';
import ANCH_EN from './preop_anchors_en.json';
import React from 'react';
import {AbsoluteFill, Audio, Easing, interpolate, Sequence, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Ico, Item, Page, Scene, SCENES, Tone} from './preop_data';
import ANCH from './preop_anchors.json';
import {VISUALS} from './motion/registry';

export const FPS = 30;
const W = 1920;
const H = 1080;
const LEAD = 0.35; // сек тишины в начале озвучки (оценка)
export const PAD = 0.7; // пауза после сцены

export const K = {
  bg: '#FAFAF8',
  ink: '#14213D',
  sub: '#55627A',
  mute: '#B3BBC9',
  coral: '#D97757',
  pink: '#E8456B',
  green: '#1FA05A',
  red: '#E04848',
  amber: '#E89A1C',
  blue: '#2F7DE1',
  card: '#FFFFFF',
};
const toneColor: Record<Tone, string> = {ok: K.green, bad: K.red, info: K.blue, warn: K.amber};
const toneBg: Record<Tone, string> = {ok: '#E7F6EE', bad: '#FDECEC', info: '#E9F1FD', warn: '#FDF3E2'};
export const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
export const ease = Easing.bezier(0.16, 1, 0.3, 1);
export const FONT = 'Rubik, sans-serif';

const clean = (s: string) => s.replace(/[́´]/g, '');

/* ---------- тайминг: время произнесения символа по весам слов ---------- */
export type Tok = {w: string; t0: number; t1: number; c0: number};
// якоря: [начало паузы, конец паузы] после каждого предложения (сек от начала сцены) — из реальной озвучки
export const tokenize = (text: string, dur: number, anchors?: (number[] | null)[]): Tok[] => {
  const words = clean(text).split(/\s+/).filter(Boolean);
  const weight = (w: string) => {
    let x = w.replace(/[—–]/g, '').length + 1.5;
    if (/[.!?؟]$/.test(w)) x += 9;
    else if (/[:;؛]$/.test(w)) x += 6;
    else if (/[,،]$/.test(w)) x += 3.5;
    if (w === '—' || w === '–') x += 3;
    return x;
  };
  // предложения
  const sents: string[][] = [];
  let cur: string[] = [];
  words.forEach((w) => { cur.push(w); if (/[.!?؟]$/.test(w)) { sents.push(cur); cur = []; } });
  if (cur.length) sents.push(cur);
  const totalW = words.reduce((a, w) => a + weight(w), 0);
  // границы предложений по умолчанию — пропорционально
  const span = Math.max(1, dur - LEAD - 0.4);
  let accW = 0;
  const bounds: [number, number][] = sents.map((sw) => {
    const a = LEAD + (accW / totalW) * span;
    accW += sw.reduce((x, w) => x + weight(w), 0);
    return [a, LEAD + (accW / totalW) * span];
  });
  if (anchors) {
    anchors.forEach((an, i) => {
      if (!an || i + 1 >= bounds.length) return;
      bounds[i][1] = an[0];
      bounds[i + 1][0] = an[1];
    });
    // границы без найденной паузы: распределить по весам между соседними известными точками
    const sw = sents.map((s) => s.reduce((x, w) => x + weight(w), 0));
    let i = 0;
    while (i < sents.length) {
      let j = i;
      while (j + 1 < sents.length && !(anchors[j])) j++;
      // предложения i..j образуют блок от bounds[i][0] до конца блока
      const end = j + 1 < sents.length ? (anchors[j] as number[])[0] : dur - 0.4;
      const start = bounds[i][0];
      const tot = sw.slice(i, j + 1).reduce((a, b) => a + b, 0);
      let acc = 0;
      for (let k = i; k <= j; k++) {
        bounds[k][0] = k === i ? start : start + (acc / tot) * (end - start);
        acc += sw[k];
        bounds[k][1] = start + (acc / tot) * (end - start);
      }
      i = j + 1;
    }
  }
  const lower = clean(text);
  let c = 0;
  const out: Tok[] = [];
  sents.forEach((sw, si) => {
    const [a, b] = bounds[si];
    const tw = sw.reduce((x, w) => x + weight(w), 0) - 7; // без хвостовой паузы точки
    let acc = 0;
    sw.forEach((w) => {
      const t0 = a + (acc / tw) * (b - a);
      acc += weight(w);
      const t1 = Math.min(b, a + (acc / tw) * (b - a));
      const c0 = lower.indexOf(w, c);
      c = c0 + w.length;
      out.push({w, t0, t1, c0});
    });
  });
  return out;
};
export const cueTime = (toks: Tok[], text: string, cue: string) => {
  const src = clean(text);
  const i = src.indexOf(clean(cue));
  if (i < 0) return toks[0].t0;
  const tok = toks.find((t) => t.c0 + t.w.length > i) ?? toks[toks.length - 1];
  return tok.t0;
};

/* ---------- длительности ---------- */
export const sceneFrames = (s: Scene) => Math.round((s.dur + PAD) * FPS);
export const scenesFor = (lang: Lang): Scene[] => lang === 'ru' ? SCENES : SCENES.map((s) => {
  const d = dictOf(lang);
  return {...s, ...d.scenes[s.id], dur: d.durs[s.id] ?? s.dur};
});
export const anchorsFor = (lang: Lang) => (lang === 'he' ? ANCH_HE : lang === 'ar' ? ANCH_AR : lang === 'en' ? ANCH_EN : ANCH) as Record<string, (number[] | null)[]>;
export const OUT_F = 6 * FPS;
export const preopTotal = (lang: Lang = 'ru') => scenesFor(lang).reduce((a, s) => a + sceneFrames(s), 0) + 4 * FPS + OUT_F;

/* ---------- фон ---------- */
export const Bg: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{background: K.bg}}>
      <AbsoluteFill style={{backgroundImage: 'radial-gradient(#14213D14 2.2px, transparent 2.4px)', backgroundSize: '30px 30px'}} />
      <div style={{position: 'absolute', right: -260, top: -300, width: 760, height: 760, borderRadius: '50%',
        background: 'radial-gradient(circle, #FFD9B455 0%, transparent 62%)', scale: String(1 + Math.sin(f / 50) * 0.03)}} />
      <div style={{position: 'absolute', left: -300, bottom: -380, width: 820, height: 820, borderRadius: '50%',
        background: 'radial-gradient(circle, #CDEBDD55 0%, transparent 62%)'}} />
    </AbsoluteFill>
  );
};

/* ---------- иконки (простые линейные) ---------- */
export const Icon: React.FC<{name: Ico; c: string; size?: number}> = ({name, c, size = 84}) => {
  const st = {stroke: c, strokeWidth: 5, fill: 'none', strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const};
  const fl = {fill: c};
  const body = (() => {
    switch (name) {
      case 'shower': return <><path d="M20 16 V30 M14 30 H46 M30 30 a16 16 0 0 1 16 -16 h4" {...st} /><path d="M18 42 l-3 8 M30 42 v9 M42 42 l3 8 M24 56 l-2 7 M36 56 l2 7" {...st} /></>;
      case 'pill': return <><rect x="10" y="24" width="44" height="18" rx="9" transform="rotate(-35 32 33)" {...st} /><path d="M32 18 V48" transform="rotate(-35 32 33)" {...st} /></>;
      case 'clock': return <><circle cx="32" cy="34" r="22" {...st} /><path d="M32 20 V34 L42 40" {...st} /></>;
      case 'sun': return <><circle cx="32" cy="32" r="11" {...st} /><path d="M32 8v7 M32 49v7 M8 32h7 M49 32h7 M15 15l5 5 M44 44l5 5 M49 15l-5 5 M20 44l-5 5" {...st} /></>;
      case 'moon': return <path d="M42 10 A22 22 0 1 0 54 42 A17 17 0 0 1 42 10 Z" {...st} />;
      case 'calendar': return <><rect x="10" y="14" width="44" height="40" rx="6" {...st} /><path d="M10 26 H54 M22 8 V18 M42 8 V18" {...st} /><path d="M20 36h6 M30 36h6 M40 36h4 M20 45h6 M30 45h6" {...st} /></>;
      case 'microbe': return <><circle cx="32" cy="32" r="13" {...st} /><path d="M32 12v6 M32 46v6 M12 32h6 M46 32h6 M18 18l4 4 M42 42l4 4 M46 18l-4 4 M18 46l4-4" {...st} /><circle cx="28" cy="29" r="2.5" {...fl} /><circle cx="36" cy="36" r="2.5" {...fl} /></>;
      case 'joint': return <><circle cx="26" cy="24" r="12" {...st} /><path d="M34 32 L50 52 M28 36 L44 56" {...st} /><path d="M10 12 L18 18" {...st} /></>;
      case 'bone': return <path d="M18 14 a6 6 0 1 0 -4 10 L40 50 a6 6 0 1 0 10 4 a6 6 0 1 0 -4 -10 L20 18 a6 6 0 1 0 -2 -4 Z" {...st} />;
      case 'bottle': return <><path d="M26 8 H38 V16 L44 24 V56 H20 V24 L26 16 Z" stroke={c} strokeWidth={5} fill={c + '33'} strokeLinejoin="round" /><path d="M24 34 H40 M24 42 H36" {...st} /></>;
      case 'sponge': return <><rect x="10" y="20" width="44" height="28" rx="9" {...st} /><circle cx="22" cy="31" r="2.5" {...fl} /><circle cx="33" cy="37" r="2.5" {...fl} /><circle cx="43" cy="29" r="2.5" {...fl} /></>;
      case 'eye': return <><path d="M6 32 C16 16 48 16 58 32 C48 48 16 48 6 32 Z" {...st} /><circle cx="32" cy="32" r="7" {...st} /></>;
      case 'towel': return <><path d="M14 12 H50 V52 H14 Z" {...st} /><path d="M14 22 H50 M14 42 H50" {...st} /></>;
      case 'shirt': return <path d="M22 10 L12 18 L6 30 L16 34 L18 28 V54 H46 V28 L48 34 L58 30 L52 18 L42 10 C40 16 24 16 22 10 Z" {...st} />;
      case 'nocream': return <><rect x="20" y="20" width="24" height="34" rx="5" {...st} /><path d="M26 12 H38 V20" {...st} /><path d="M10 10 L54 54" stroke={K.red} strokeWidth={6} strokeLinecap="round" /></>;
      case 'allergy': return <><path d="M32 8 L58 54 H6 Z" {...st} /><path d="M32 24 V38" {...st} /><circle cx="32" cy="46" r="3" {...fl} /></>;
      case 'nurse': return <><circle cx="32" cy="20" r="10" {...st} /><path d="M12 56 C12 40 52 40 52 56" {...st} /><path d="M32 44 V54 M27 49 H37" {...st} /></>;
      case 'doctor': return <><circle cx="32" cy="18" r="10" {...st} /><path d="M12 56 C12 38 52 38 52 56" {...st} /><path d="M24 40 C24 50 30 52 34 52 M40 40 V46" {...st} /><circle cx="40" cy="49" r="3" {...st} /></>;
      case 'razor': return <><rect x="14" y="10" width="36" height="12" rx="3" {...st} /><path d="M32 22 V56" {...st} /><path d="M8 8 L56 56" stroke={K.red} strokeWidth={6} strokeLinecap="round" /></>;
      case 'clipper': return <><rect x="20" y="16" width="24" height="40" rx="10" {...st} /><path d="M18 10 H46 M22 6 V10 M28 6 V10 M34 6 V10 M40 6 V10" {...st} /></>;
      case 'stomach': return <path d="M26 8 V18 C26 24 14 24 14 38 C14 52 28 56 38 52 C50 48 52 34 44 28 C38 24 36 30 34 22 V8" {...st} />;
      case 'water': return <><path d="M18 14 H46 L42 56 H22 Z" {...st} /><path d="M20 30 H44" {...st} /></>;
      case 'gum': return <><rect x="10" y="22" width="44" height="20" rx="10" {...st} /><path d="M22 22 V42 M32 22 V42 M42 22 V42" {...st} /></>;
      case 'heart': return <path d="M32 54 C12 40 8 28 13 19 C18 10 30 10 32 21 C34 10 46 10 51 19 C56 28 52 40 32 54 Z" {...st} />;
      case 'brain': return <><path d="M32 12 C22 8 12 16 14 26 C8 30 10 42 18 44 C20 54 30 54 32 48 C34 54 44 54 46 44 C54 42 56 30 50 26 C52 16 42 8 32 12 Z" {...st} /><path d="M32 12 V48" {...st} /></>;
      case 'thyroid': return <><path d="M32 30 C26 20 14 18 14 32 C14 46 26 46 32 38 C38 46 50 46 50 32 C50 18 38 20 32 30 Z" {...st} /><path d="M32 8 V18" {...st} /></>;
      case 'lungs': return <><path d="M32 10 V30 M32 26 L24 32 M32 26 L40 32" {...st} /><path d="M24 20 C12 22 8 40 10 52 C16 54 26 52 26 44 V28" {...st} /><path d="M40 20 C52 22 56 40 54 52 C48 54 38 52 38 44 V28" {...st} /></>;
      case 'steroid': return <><circle cx="22" cy="22" r="10" {...st} /><circle cx="42" cy="42" r="10" {...st} /><path d="M29 29 L35 35" {...st} /></>;
      case 'list': return <><rect x="12" y="8" width="40" height="48" rx="6" {...st} /><path d="M20 22 h4 M30 22 h14 M20 32 h4 M30 32 h14 M20 42 h4 M30 42 h10" {...st} /></>;
      case 'drop': return <path d="M32 8 C24 22 14 32 14 42 C14 52 22 58 32 58 C42 58 50 52 50 42 C50 32 40 22 32 8 Z" {...st} />;
      case 'spine': return <><rect x="24" y="6" width="16" height="9" rx="3" {...st} /><rect x="24" y="19" width="16" height="9" rx="3" {...st} /><rect x="24" y="32" width="16" height="9" rx="3" {...st} /><rect x="24" y="45" width="16" height="9" rx="3" {...st} /><path d="M48 36 L60 30" {...st} /></>;
      case 'syringe': return <><rect x="16" y="24" width="30" height="14" rx="4" transform="rotate(-40 32 32)" {...st} /><path d="M10 54 L18 46 M46 18 L54 10 M42 12 L52 22" {...st} /></>;
      case 'stent': return <><path d="M8 24 H56 M8 40 H56" {...st} /><path d="M14 24 L22 40 L30 24 L38 40 L46 24 L54 40" {...st} /></>;
      case 'sugar': return <><path d="M32 8 C24 22 16 30 16 40 C16 50 24 56 32 56 C40 56 48 50 48 40 C48 30 40 22 32 8 Z" {...st} /><path d="M26 42 H38 M32 36 V48" {...st} /></>;
      case 'insulin': return <><rect x="22" y="14" width="20" height="36" rx="5" {...st} /><path d="M32 50 V58 M26 8 H38 M22 26 H32 M22 34 H30" {...st} /></>;
      case 'smoke': return <><rect x="8" y="34" width="40" height="10" rx="3" {...st} /><path d="M52 34 V44 M44 26 C44 20 52 20 52 14" {...st} /><path d="M8 8 L56 56" stroke={K.red} strokeWidth={6} strokeLinecap="round" /></>;
      case 'ring': return <><circle cx="32" cy="38" r="16" {...st} /><path d="M24 14 L32 6 L40 14 L32 22 Z" {...st} /></>;
      case 'band': return <><path d="M10 22 H54 V42 H10 Z" {...st} /><path d="M18 30 H34 M18 36 H28" {...st} /><rect x="40" y="28" width="8" height="8" {...st} /></>;
      case 'marker': return <><path d="M42 8 L56 22 L26 52 L12 52 L12 38 Z" {...st} /><path d="M36 14 L50 28" {...st} /></>;
      case 'id': return <><rect x="8" y="14" width="48" height="36" rx="6" {...st} /><circle cx="22" cy="30" r="6" {...st} /><path d="M14 44 C16 36 28 36 30 44 M36 26 H48 M36 34 H48" {...st} /></>;
      case 'sign': return <><path d="M14 8 H40 L50 18 V56 H14 Z" {...st} /><path d="M20 44 C24 38 28 50 32 42 C34 38 38 46 44 42" {...st} /></>;
      case 'walk': return <><circle cx="34" cy="10" r="5" {...st} /><path d="M32 18 L28 34 L36 42 L38 56 M28 34 L20 56 M30 22 L22 28 M32 22 L42 28" {...st} /></>;
      case 'check': return <path d="M12 34 L26 48 L52 18" stroke={c} strokeWidth={7} fill="none" strokeLinecap="round" strokeLinejoin="round" />;
      default: return <circle cx="32" cy="32" r="20" {...st} />;
    }
  })();
  return <svg width={size} height={size} viewBox="0 0 64 64">{body}</svg>;
};

/* ---------- заголовок сцены с рисованным подчёркиванием ---------- */
const Headline: React.FC<{s: Scene}> = ({s}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame: f - 2, fps, config: {damping: 15}});
  const ul = interpolate(f, [16, 32], [0, 1], {...clamp, easing: ease});
  const title = s.title;
  const i = title.indexOf(s.accent);
  const pre = i >= 0 ? title.slice(0, i) : title;
  const acc = i >= 0 ? s.accent : '';
  const post = i >= 0 ? title.slice(i + s.accent.length) : '';
  return (
    <div style={{position: 'absolute', left: 110, top: 70, right: 110, opacity: p, translate: `0 ${(1 - p) * 24}px`}}>
      <div style={{display: 'inline-flex', alignItems: 'center', gap: 14, padding: '8px 20px', borderRadius: 40, background: '#14213D0D',
        fontFamily: FONT, fontWeight: 600, fontSize: 26, color: K.sub, letterSpacing: 1}}>
        <span style={{color: K.coral, fontWeight: 800}}>{String(s.n).padStart(2, '0')}</span> {T('ПОДГОТОВКА К ОПЕРАЦИИ')}
      </div>
      <div style={{fontFamily: FONT, fontWeight: 800, fontSize: 72, color: K.ink, marginTop: 18, lineHeight: 1.08}}>
        {pre}
        <span style={{position: 'relative', color: K.coral, whiteSpace: 'nowrap'}}>
          {acc}
          {acc ? (
            <svg viewBox="0 0 300 20" preserveAspectRatio="none" style={{position: 'absolute', left: -4, right: -4, bottom: -16, width: 'calc(100% + 8px)', height: 20}}>
              <path d="M4 12 C 60 4, 120 18, 180 9 S 270 6, 296 11" stroke={K.coral} strokeWidth={6} fill="none" strokeLinecap="round"
                pathLength={1} strokeDasharray={1} strokeDashoffset={1 - ul} />
            </svg>
          ) : null}
        </span>
        {post}
      </div>
    </div>
  );
};

/* ---------- карточки ---------- */
const fitSize = (t: string, w: number) => {
  const longest = Math.max(...t.split(/\s+/).map((x) => x.length));
  return Math.max(28, Math.min(44, Math.floor((w - 80) / (longest * 0.62))));
};
const useIn = (atSec: number, damping = 13) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: f - Math.round(atSec * fps), fps, config: {damping}});
};

const Card: React.FC<{it: Item; at: number; w: number; h: number; hero?: boolean}> = ({it, at, w, h, hero}) => {
  const p = useIn(at);
  const f = useCurrentFrame();
  const tone = it.tone ?? 'info';
  const col = toneColor[tone];
  const badge = spring({frame: f - Math.round(at * FPS) - 8, fps: FPS, config: {damping: 10}});
  const mark = tone === 'ok' ? '✓' : tone === 'bad' ? '✕' : tone === 'warn' ? '!' : '';
  return (
    <div style={{width: w, height: h, opacity: Math.min(1, p * 1.4), scale: String(0.86 + 0.14 * p), translate: `0 ${(1 - p) * 30}px`,
      background: K.card, borderRadius: 28, boxShadow: '0 22px 44px rgba(20,33,61,.10), 0 2px 6px rgba(20,33,61,.06)',
      display: 'flex', flexDirection: hero || h < 300 ? 'row' : 'column', alignItems: hero || h < 300 ? 'center' : 'flex-start', gap: hero ? 44 : h < 300 ? 26 : 14,
      padding: hero ? '44px 60px' : '32px 36px', boxSizing: 'border-box', position: 'relative', borderTop: `8px solid ${col}`}}>
      <div style={{width: hero ? 170 : 116, height: hero ? 170 : 116, borderRadius: hero ? 40 : 26, background: toneBg[tone], flexShrink: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
        <Icon name={it.ico} c={col} size={hero ? 118 : 78} />
      </div>
      <div style={{minWidth: 0}}>
        <div style={{fontFamily: FONT, fontWeight: 700, fontSize: hero ? 60 : fitSize(it.title, h < 300 ? w - 150 : w), color: K.ink, lineHeight: 1.12}}>{it.title}</div>
        {it.sub ? <div style={{fontFamily: FONT, fontWeight: 400, fontSize: hero ? 38 : 31, color: K.sub, marginTop: 10, lineHeight: 1.25}}>{it.sub}</div> : null}
      </div>
      {mark ? (
        <div style={{position: 'absolute', right: 18, top: 16, width: 46, height: 46, borderRadius: 23, background: col, color: '#fff',
          fontFamily: FONT, fontWeight: 800, fontSize: 28, display: 'flex', alignItems: 'center', justifyContent: 'center', scale: String(badge)}}>{mark}</div>
      ) : null}
    </div>
  );
};

/* большие цифры (часы/дни) с катящимся счётчиком */
const BarRow: React.FC<{it: Item; at: number; maxBig: number; unit: string}> = ({it, at, maxBig, unit}) => {
  const f = useCurrentFrame();
  const p = useIn(at, 14);
  const tone = it.tone ?? 'info';
  const col = toneColor[tone];
  const big = it.big ?? '';
  const num = parseFloat(big) || 0;
  const grow = interpolate(f, [at * FPS + 4, at * FPS + 28], [0, 1], {...clamp, easing: ease});
  const shown = big.includes('–') ? (grow > 0.6 ? big : '') : num ? String(Math.round(num * grow)) : '';
  const barW = num ? 120 + (num / maxBig) * 560 * grow : 0;
  return (
    <div style={{display: 'flex', alignItems: 'center', gap: 34, opacity: Math.min(1, p * 1.4), translate: `${(1 - p) * -40}px 0`}}>
      <div style={{width: 92, height: 92, borderRadius: 26, background: toneBg[tone], display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
        <Icon name={it.ico} c={col} size={62} />
      </div>
      <div style={{width: 560}}>
        <div style={{fontFamily: FONT, fontWeight: 700, fontSize: 44, color: K.ink}}>{it.title}</div>
        {it.sub ? <div style={{fontFamily: FONT, fontSize: 30, color: K.sub, marginTop: 4}}>{it.sub}</div> : null}
      </div>
      {num ? (
        <div style={{height: 96, width: barW, borderRadius: 42, background: col, display: 'flex', alignItems: 'center', justifyContent: 'flex-end', paddingRight: 28, boxSizing: 'border-box',
          boxShadow: `0 14px 30px ${col}44`}}>
          <span style={{fontFamily: FONT, fontWeight: 800, fontSize: 50, color: '#fff', whiteSpace: 'nowrap'}}>{shown} <span style={{fontSize: 30, fontWeight: 600}}>{shown ? unit : ''}</span></span>
        </div>
      ) : null}
    </div>
  );
};

const unitFor = (s: Scene) => (s.id === 'S8' ? T('дн.') : s.id === 'S10' ? T('нед.') : T('ч'));

const PageView: React.FC<{s: Scene; pg: Page; toks: Tok[]}> = ({s, pg, toks}) => {
  const frame = useCurrentFrame();
  // первая карточка страницы — сразу вместе со страницей
  const at = (it: Item) => (it === pg.items[0] ? Math.min(cueTime(toks, s.text, it.cue), 0.3) : cueTime(toks, s.text, it.cue));
  const top = 270;
  const areaH = 600;
  const n = pg.items.length;
  if (pg.layout === 'hero') {
    const it = pg.items[0];
    return <div style={{position: 'absolute', left: 260, right: 260, top: top + 60}}><Card it={it} at={at(it)} w={1400} h={380} hero /></div>;
  }
  if (pg.layout === 'bars') {
    const maxBig = Math.max(...pg.items.map((i) => parseFloat(i.big ?? '0') || 0), 1);
    return (
      <div style={{position: 'absolute', left: 150, top: top + 10, display: 'flex', flexDirection: 'column', gap: 44}}>
        {pg.items.map((it, k) => <BarRow key={k} it={it} at={at(it)} maxBig={maxBig} unit={unitFor(s)} />)}
      </div>
    );
  }
  if (pg.layout === 'steps') {
    const w = Math.min(420, (W - 200 - (n - 1) * 30) / n);
    return (
      <div style={{position: 'absolute', left: 0, right: 0, top: top + 70, display: 'flex', justifyContent: 'center', gap: 30}}>
        {pg.items.map((it, k) => (
          <div key={k} style={{position: 'relative'}}>
            <Card it={it} at={at(it)} w={w} h={420} />
            <div style={{position: 'absolute', left: 30, bottom: -58, fontFamily: FONT, fontWeight: 800, fontSize: 30, color: K.mute, opacity: interpolate(frame, [at(it) * FPS, at(it) * FPS + 8], [0, 1], clamp)}}>{k + 1}</div>
          </div>
        ))}
      </div>
    );
  }
  if (pg.layout === 'two') {
    const split = pg.split ?? 1;
    const L = pg.items.slice(0, split);
    const R = pg.items.slice(split);
    const colW = 820;
    const col = (items: Item[], head: string) => {
      const h = Math.min(250, (areaH - 110 - (items.length - 1) * 20) / items.length);
      return (
        <div style={{width: colW, display: 'flex', flexDirection: 'column', gap: 20}}>
          <div style={{fontFamily: FONT, fontWeight: 700, fontSize: 32, color: K.sub, height: 50}}>{head}</div>
          {items.map((it, k) => <Card key={k} it={it} at={at(it)} w={colW} h={h} />)}
        </div>
      );
    };
    return (
      <div style={{position: 'absolute', left: 0, right: 0, top, display: 'flex', justifyContent: 'center', gap: 80}}>
        {col(L, pg.heads?.[0] ?? '')}
        {col(R, pg.heads?.[1] ?? '')}
      </div>
    );
  }
  // grid
  const cols = pg.cols ?? 3;
  const rows = Math.ceil(n / cols);
  const gap = 30;
  const cw = Math.min(560, (W - 200 - (cols - 1) * gap) / cols);
  const ch = Math.min(rows === 1 ? 380 : 255, (areaH - (rows - 1) * gap) / rows);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, top: top + (rows === 1 ? 70 : 0), display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap,
      width: cols * cw + (cols - 1) * gap, marginLeft: (W - (cols * cw + (cols - 1) * gap)) / 2}}>
      {pg.items.map((it, k) => <Card key={k} it={it} at={at(it)} w={cw} h={ch} />)}
    </div>
  );
};

/* ---------- живые субтитры по словам ---------- */
const Subs: React.FC<{toks: Tok[]}> = ({toks}) => {
  const f = useCurrentFrame();
  const t = f / FPS;
  // делим на фразы ≤ 11 слов, режем по знакам препинания
  const chunks: Tok[][] = [];
  let cur: Tok[] = [];
  toks.forEach((tk) => {
    cur.push(tk);
    const end = /[.!?:;؟؛]$/.test(tk.w) || (/[,،—]$/.test(tk.w) && cur.length >= 6) || tk.w === '—' && cur.length >= 6 || cur.length >= 11;
    if (end) { chunks.push(cur); cur = []; }
  });
  if (cur.length) chunks.push(cur);
  let ci = chunks.findIndex((c) => t < c[c.length - 1].t1 + 0.15);
  if (ci < 0) ci = chunks.length - 1;
  const ch = chunks[ci];
  const start = ch[0].t0;
  const endT = ch[ch.length - 1].t1 + 0.15;
  const out = interpolate(t, [endT - 0.12, endT], [1, 0], clamp);
  const isLast = ci === chunks.length - 1;
  return (
    <div style={{position: 'absolute', left: 160, right: 160, bottom: 70, height: 150, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
      <div style={{background: '#FFFFFFE8', borderRadius: 26, padding: '18px 38px', boxShadow: '0 10px 30px rgba(20,33,61,.08)',
        fontFamily: FONT, fontSize: 44, lineHeight: 1.32, textAlign: 'center', opacity: isLast ? 1 : out,
        filter: `blur(${(1 - (isLast ? 1 : out)) * 6}px)`}}>
        {ch.map((tk, k) => {
          const pIn = interpolate(t, [tk.t0 - 0.05, tk.t0 + 0.2], [0, 1], clamp);
          const spoken = t >= tk.t0;
          return (
            <span key={k} style={{display: 'inline-block', marginInlineEnd: 12, color: spoken ? K.ink : K.mute, fontWeight: spoken ? 500 : 400,
              translate: `0 ${(1 - pIn) * 8}px`}}>{tk.w}</span>
          );
        })}
      </div>
      {start < 0 ? null : null}
    </div>
  );
};

/* ---------- сцена ---------- */
export const SceneView: React.FC<{s: Scene; audio: boolean; lang?: Lang}> = ({s, audio, lang = 'ru'}) => {
  const f = useCurrentFrame();
  const t = f / FPS;
  const toks = React.useMemo(() => tokenize(s.text, s.dur, anchorsFor(lang)[s.id]), [s]);
  const starts = s.pages.map((pg, i) => (i === 0 ? 0 : cueTime(toks, s.text, pg.cue) - 0.25));
  let pi = 0;
  starts.forEach((st, i) => { if (t >= st) pi = i; });
  const nextStart = pi + 1 < starts.length ? starts[pi + 1] : 1e9;
  const pageOut = interpolate(t, [nextStart - 0.25, nextStart], [1, 0], clamp);
  const pageIn = interpolate(t, [starts[pi], starts[pi] + 0.3], [0, 1], clamp);
  const sceneIn = interpolate(f, [0, 10], [0, 1], clamp);
  const sceneOut = interpolate(f, [sceneFrames(s) - 10, sceneFrames(s)], [1, 0], clamp);
  const zoom = 1 + 0.025 * (t / (s.dur + PAD));
  return (
    <AbsoluteFill style={{direction: isRTL() ? 'rtl' : 'ltr', opacity: Math.min(sceneIn, sceneOut), filter: `blur(${(1 - Math.min(sceneIn, sceneOut)) * 8}px)`}}>
      {audio ? <Audio src={staticFile(`preop_${lang}/${s.id}.wav`)} /> : null}
      <Headline s={s} />
      <AbsoluteFill style={{opacity: Math.min(pageIn, pageOut), filter: `blur(${(1 - Math.min(pageIn, pageOut)) * 8}px)`, scale: String(zoom)}}>
        {VISUALS[s.id] ? null : (
          <Sequence from={Math.round(starts[pi] * FPS)} layout="none">
            <AbsoluteFill style={{translate: '0 0'}}>
              <PageAbs s={s} pg={s.pages[pi]} toks={toks} offset={starts[pi]} />
            </AbsoluteFill>
          </Sequence>
        )}
      </AbsoluteFill>
      {VISUALS[s.id] ? React.createElement(VISUALS[s.id], {at: (cue: string) => cueTime(toks, s.text, cueOf(s.id, cue)), dur: s.dur}) : null}
      <Subs toks={toks} />
    </AbsoluteFill>
  );
};
// PageView считает время от начала сцены; внутри Sequence кадр сдвинут — возвращаем абсолютный кадр
const PageAbs: React.FC<{s: Scene; pg: Page; toks: Tok[]; offset: number}> = ({s, pg, toks, offset}) => {
  const shifted = toks.map((tk) => ({...tk, t0: tk.t0 - Math.round(offset * FPS) / FPS, t1: tk.t1 - Math.round(offset * FPS) / FPS}));
  return <PageView s={s} pg={pg} toks={shifted} />;
};

/* ---------- титул и финал ---------- */
const Title: React.FC = () => {
  const f = useCurrentFrame();
  const p = spring({frame: f - 4, fps: FPS, config: {damping: 14}});
  const ul = interpolate(f, [20, 40], [0, 1], {...clamp, easing: ease});
  return (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', opacity: interpolate(f, [70, 90], [1, 0], clamp)}}>
      <div style={{textAlign: 'center', opacity: p, translate: `0 ${(1 - p) * 30}px`}}>
        <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 34, color: K.sub, letterSpacing: 2}}>{T('ПАМЯТКА ДЛЯ ПАЦИЕНТА')}</div>
        <div style={{fontFamily: FONT, fontWeight: 800, fontSize: 104, color: K.ink, marginTop: 20, lineHeight: 1.05}}>
          Подготовка<br />к <span style={{color: K.coral, position: 'relative'}}>плановой
            <svg viewBox="0 0 300 20" preserveAspectRatio="none" style={{position: 'absolute', left: 0, bottom: -18, width: '100%', height: 22}}>
              <path d="M4 12 C 60 4, 120 18, 180 9 S 270 6, 296 11" stroke={K.coral} strokeWidth={6} fill="none" strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - ul} />
            </svg>
          </span> {T('операции')}
        </div>
      </div>
    </AbsoluteFill>
  );
};

const TitleL: React.FC<{s: Scene}> = ({s}) => {
  const f = useCurrentFrame();
  const p = spring({frame: f - 4, fps: FPS, config: {damping: 14}});
  const ul = interpolate(f, [20, 40], [0, 1], {...clamp, easing: ease});
  const i = s.title.indexOf(s.accent);
  const pre = i >= 0 ? s.title.slice(0, i) : s.title, acc = i >= 0 ? s.accent : '', post = i >= 0 ? s.title.slice(i + s.accent.length) : '';
  return (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', direction: 'rtl', opacity: interpolate(f, [70, 90], [1, 0], clamp)}}>
      <div style={{textAlign: 'center', opacity: p, translate: `0 ${(1 - p) * 30}px`, maxWidth: 1500}}>
        <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 34, color: K.sub, letterSpacing: 2}}>{T('ПАМЯТКА ДЛЯ ПАЦИЕНТА')}</div>
        <div style={{fontFamily: FONT, fontWeight: 800, fontSize: 104, color: K.ink, marginTop: 20, lineHeight: 1.2}}>
          {pre}<span style={{color: K.coral, position: 'relative', whiteSpace: 'nowrap'}}>{acc}
            <svg viewBox="0 0 300 20" preserveAspectRatio="none" style={{position: 'absolute', left: 0, bottom: -18, width: '100%', height: 22}}>
              <path d="M4 12 C 60 4, 120 18, 180 9 S 270 6, 296 11" stroke={K.coral} strokeWidth={6} fill="none" strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - ul} />
            </svg>
          </span>{post}
        </div>
      </div>
    </AbsoluteFill>
  );
};

// финальная плашка: общие рекомендации, свой случай — с лечащим врачом
const Outro: React.FC<{audio: boolean; lang: Lang}> = ({audio, lang}) => {
  const f = useCurrentFrame();
  const p = spring({frame: f - 4, fps: FPS, config: {damping: 14}});
  const o = interpolate(f, [OUT_F - 12, OUT_F + 10], [1, 0], clamp);
  return (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', direction: isRTL() ? 'rtl' : 'ltr', opacity: o}}>
      {audio ? <Audio src={staticFile(`preop_${lang}/OUT.wav`)} /> : null}
      <div style={{textAlign: 'center', maxWidth: 1400, opacity: p, translate: `0 ${(1 - p) * 30}px`}}>
        <div style={{width: 120, height: 120, margin: '0 auto 40px', borderRadius: '50%', background: '#fff', boxShadow: '0 20px 50px rgba(20,33,61,.14)', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
          <svg width={70} height={70} viewBox="0 0 100 100"><circle cx={50} cy={34} r={16} fill="none" stroke={K.coral} strokeWidth={7} /><path d="M20 88c4-20 16-30 30-30s26 10 30 30" fill="none" stroke={K.coral} strokeWidth={7} strokeLinecap="round" /></svg>
        </div>
        <div style={{fontFamily: FONT, fontWeight: 800, fontSize: 68, color: K.ink, lineHeight: 1.2}}>{T('Это общие рекомендации')}</div>
        <div style={{fontFamily: FONT, fontWeight: 500, fontSize: 48, color: K.sub, marginTop: 28, lineHeight: 1.3}}>{T('Ваш конкретный случай обсудите с лечащим врачом')}</div>
      </div>
    </AbsoluteFill>
  );
};

export const PreopFilm: React.FC<{audio: boolean; draft: boolean; lang?: Lang}> = ({audio, draft, lang = 'ru'}) => {
  setLang(lang);
  const SC = scenesFor(lang);
  let acc = 3 * FPS;
  return (
    <AbsoluteFill style={{width: W, height: H}}>
      <Bg />
      <Sequence durationInFrames={3 * FPS}>{lang === 'ru' ? <Title /> : <TitleL s={SC[0]} />}</Sequence>
      {SC.map((s) => {
        const from = acc;
        acc += sceneFrames(s);
        return <Sequence key={s.id} from={from} durationInFrames={sceneFrames(s)} name={s.id}><SceneView s={s} audio={audio} lang={lang} /></Sequence>;
      })}
      <Sequence from={acc} durationInFrames={OUT_F + FPS} name="OUT"><Outro audio={audio} lang={lang} /></Sequence>
      <div style={{position: 'absolute', right: 40, bottom: 24, fontFamily: FONT, fontSize: 22, color: K.sub, opacity: 0.55, direction: isRTL() ? 'rtl' : 'ltr'}}>
        {T('Георгий Кокорин · медбрат')}{draft ? T(' · черновик') : ''}
      </div>
    </AbsoluteFill>
  );
};

export const PreopPiece: React.FC<{id: string; audio: boolean}> = ({id, audio}) => {
  const s = SCENES.find((x) => x.id === id)!;
  return (
    <AbsoluteFill style={{width: W, height: H}}>
      <Bg />
      <SceneView s={s} audio={audio} />
      <div style={{position: 'absolute', right: 40, bottom: 24, fontFamily: FONT, fontSize: 22, color: K.sub, opacity: 0.55}}>{T('Георгий Кокорин · медбрат · черновик')}</div>
    </AbsoluteFill>
  );
};
