// Локализация ролика: ru (исходник), he, ar. Строки на экране оборачиваются T('рус. строка').
import HE from '../../i18n/he.json';
import AR from '../../i18n/ar.json';
import EN from '../../i18n/en.json';

export type Lang = 'ru' | 'he' | 'ar' | 'en';
type Dict = {scenes: Record<string, {title: string; accent: string; text: string}>; durs: Record<string, number>; strings: Record<string, string>; cues: Record<string, Record<string, string>>};
const D: Record<string, Dict> = {he: HE as Dict, ar: AR as Dict, en: EN as unknown as Dict};
let LANG: Lang = 'ru';
export const setLang = (l: Lang) => { LANG = l; };
export const getLang = () => LANG;
export const isRTL = () => LANG === 'he' || LANG === 'ar';
export const dictOf = (l: Lang) => D[l];
export const T = (s: string): string => {
  if (LANG === 'ru') return s;
  const v = D[LANG].strings[s];
  if (v === undefined) { console.warn('[i18n missing]', LANG, s); return s; }
  return v;
};
export const cueOf = (id: string, c: string): string => { if (LANG === 'ru') return c; const v = D[LANG].cues[id]?.[c]; if (v === undefined) console.warn('[cue missing]', LANG, id, c); return v ?? c; };
