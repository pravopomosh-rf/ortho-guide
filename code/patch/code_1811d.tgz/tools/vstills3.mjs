// node tools/vstills.mjs LANG out_dir S1:1.5,S1:8 S2:3 ...  → PNG кадры вертикали (секунды от начала сцены)
import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition} from '@remotion/renderer';
import path from 'path';
const [lang, out, ...specs] = process.argv.slice(2);
const exe = '/opt/pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell';
const serveUrl = await bundle({entryPoint: path.resolve('src/index3.ts')});
const jobs = specs.join(',').split(',').filter(Boolean).map((x) => x.split(':'));
for (const [id, sec] of jobs) {
  const inputProps = {id, lang};
  const comp = await selectComposition({serveUrl, id: `SV-${lang}-${id}`, inputProps, browserExecutable: exe, chromiumOptions: {gl: 'swangle'}});
  const frame = Math.min(comp.durationInFrames - 1, Math.round(parseFloat(sec) * 30));
  await renderStill({serveUrl, composition: comp, frame, output: `${out}/${lang}_${id}_${sec}.png`, inputProps, browserExecutable: exe, chromiumOptions: {gl: 'swangle'}, scale: 0.5});
  console.log('ok', id, sec);
}
