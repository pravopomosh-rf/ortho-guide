# pub_rehabv.py LANG... — rehabv: заглушка vdev на rehab.html → .vfirst сверху; карточки шага «Реабилитация» в *-path.html → видео
import sys,re,glob,shutil
R='/home/claude/ortho-guide/'
T={'ru':'Реабилитация (шикум) после операции','he':'שיקום אחרי ניתוח','ar':'إعادة التأهيل بعد العملية','en':'Rehabilitation after surgery'}
pre=open(R+'ops/preop.html',encoding='utf8').read()
for L in sys.argv[1:]:
    shutil.copy(f'/home/claude/out/rehabv_{L}.mp4',R+f'video/rehabv_{L}.mp4')
    h2=re.search(r'<section class="vfirst" id="vids_'+L+r'"><h2>([^<]*)</h2>',pre).group(1)
    item=(f'<div class="vitem"><div class="vlabel"><span class="vplay" aria-hidden="true"></span><span>{T[L]}</span></div>'
          f'<video class="vid v9" width="1080" height="1920" style="aspect-ratio:1080/1920" controls preload="none" playsinline '
          f'poster="../video/c/rehabv_{L}.jpg" src="../video/rehabv_{L}.mp4"></video></div>')
    p=R+'ops/rehab.html'; s=open(p,encoding='utf8').read()
    if f'rehabv_{L}.mp4' not in s:
        s,k=re.subn(r'<section id="video_'+L+r'" class="vtop vdev">.*?</section>','',s,flags=re.S); assert k==1
        key=f'<section class="key" id="key_{L}">'; assert key in s
        s=s.replace(key,f'<section class="vfirst" id="vids_{L}"><h2>{h2}</h2>{item}</section>'+key,1)
        open(p,'w',encoding='utf8').write(s); print('rehab',L)
    for p in glob.glob(R+'ops/*-path.html'):
        s=open(p,encoding='utf8').read()
        chip=re.search(r'href="admission.html#lang='+L+r'">.*?(<span class="chip v">[^<]*</span>)',s).group(1)
        m=re.search(r'<a class="pc" href="rehab.html#lang='+L+r'"><span class="th"><img class="ph"[^>]*></span>(<span class="pt">[^<]*</span>)<span class="chip">[^<]*</span></a>',s)
        if m:
            s=s[:m.start()]+f'<a class="pc vd" href="rehab.html#lang={L}"><span class="th"><img loading="lazy" decoding="async" src="../video/t/rehabv_{L}.jpg" width="800" height="600" alt=""></span>{m.group(1)}{chip}</a>'+s[m.end():]
            open(p,'w',encoding='utf8').write(s); print('path',L,p.split('/')[-1])
