import './fonts';
import React from 'react';
import {registerRoot, Composition} from 'remotion';
import {PreopSceneV} from './wide/PreopFilmV';
import {sceneFrames, scenesFor} from './wide/PreopFilm';
const R: React.FC = () => React.createElement(React.Fragment, null, ...(['he', 'ar'] as const).flatMap((lang) => scenesFor(lang as any).map((s) =>
  React.createElement(Composition, {key: lang + s.id, id: `SV-${lang}-${s.id}`, component: PreopSceneV as any, durationInFrames: sceneFrames(s), fps: 30, width: 1080, height: 1920, defaultProps: {id: s.id, lang}}))));
registerRoot(R);
