// «Клинический случай» — визуальный кит (формат эталона 06.11): светлый фон, шапка с главой, 2-строчный заголовок с акцентом,
// белые карточки со счётчиками, субтитр-таблетка слово-в-слово, слоты «?», плавные перетекания.
import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig, staticFile, Easing} from 'remotion';

const ff = (name: string, file: string, w: number, range: string) =>
  `@font-face{font-family:'${name}';font-weight:${w};src:url('${staticFile('fonts/' + file)}') format('woff2');unicode-range:${range};font-display:block}`;
const HEBR = 'U+0590-05FF,U+FB1D-FB4F', ARAB = 'U+0600-06FF,U+0750-077F,U+FB50-FDFF,U+FE70-FEFC';
const CYR = 'U+0400-04FF', LAT = 'U+0000-024F,U+2000-206F,U+2190-21FF,U+2212';
export const FontCSS: React.FC = () => (
  <style>{[
    ff('Head', 'unbounded-cyrillic-800-normal.woff2', 800, CYR), ff('Head', 'unbounded-latin-800-normal.woff2', 800, LAT),
    ff('Head', 'unbounded-cyrillic-700-normal.woff2', 700, CYR), ff('Head', 'unbounded-latin-700-normal.woff2', 700, LAT),
    ff('Body', 'inter-cyrillic-600-normal.woff2', 600, CYR), ff('Body', 'inter-latin-600-normal.woff2', 600, LAT),
    ff('Body', 'inter-cyrillic-700-normal.woff2', 700, CYR), ff('Body', 'inter-latin-700-normal.woff2', 700, LAT),
    ff('Mono', 'jetbrains-mono-cyrillic-700-normal.woff2', 700, CYR), ff('Mono', 'jetbrains-mono-latin-700-normal.woff2', 700, LAT),
    ...['Head','Body','Mono'].flatMap((n) => [600, 700, 800].flatMap((w) => [ff(n, `noto-sans-hebrew-hebrew-${w}-normal.woff2`, w, HEBR), ff(n, `noto-sans-arabic-arabic-${w}-normal.woff2`, w, ARAB)])),
  ].join('')}</style>
);

export const C = {
  bg1: '#F6F6F8', bg2: '#ECECF0', ink: '#16181D', mute: '#8A8F98', line: '#DADDE3',
  acc: '#D9481F', accL: '#FBE3DA', teal: '#17A398', tealL: '#DDF3F0', blood: '#B3121B', bloodL: '#F6D9DA',
  card: '#FFFFFF', navy: '#1B2333', green: '#2BB673',
};
export const HEAD = "'Head', sans-serif", BODY = "'Body', sans-serif", MONO = "'Mono', monospace";
export const W = 1080, H = 1920;

export const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
export const ease = (f: number, a: number, b: number) => interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.bezier(0.22, 1, 0.36, 1)});
export const fadeIO = (f: number, a: number, b: number, r = 8) => Math.min(ease(f, a, a + r), 1 - ease(f, b - r, b));

export const Bg: React.FC = () => (
  <AbsoluteFill style={{background: `radial-gradient(120% 80% at 50% 0%, ${C.bg1} 0%, ${C.bg2} 100%)`}} />
);

// top bar: channel name · chapter counter · section label
export const Header: React.FC<{brand: string; n: number; total: number; label: string}> = ({brand, n, total, label}) => {
  const f = useCurrentFrame();
  return (
    <div style={{position: 'absolute', left: 64, right: 64, top: 150}}>
      <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'baseline'}}>
        <div style={{fontFamily: HEAD, fontWeight: 700, fontSize: 24, letterSpacing: 2, color: C.ink}}>{brand}</div>
        <div style={{fontFamily: MONO, fontWeight: 700, fontSize: 22, color: C.mute}}>{String(n).padStart(2, '0')} / {total}</div>
      </div>
      <div style={{height: 2, background: C.line, margin: '14px 0 10px'}} />
      <div style={{fontFamily: MONO, fontWeight: 700, fontSize: 22, letterSpacing: 2, color: C.acc, opacity: ease(f, 0, 10)}}>{label}</div>
    </div>
  );
};

// 2-line headline; words in `acc` are coloured. Cross-fades with blur on change.
export const Headline: React.FC<{text: string; acc?: string[]; at?: number; out?: number; size?: number; top?: number}> = ({text, acc = [], at = 0, out = 1e9, size = 66, top = 268}) => {
  const f = useCurrentFrame();
  const p = ease(f, at, at + 12), q = 1 - ease(f, out - 10, out);
  const o = Math.min(p, q);
  return (
    <div style={{position: 'absolute', left: 64, right: 64, top, fontFamily: HEAD, fontWeight: 800, fontSize: size, lineHeight: 1.12, color: C.ink,
      opacity: o, filter: `blur(${(1 - o) * 10}px)`, transform: `translateY(${(1 - p) * 18}px)`}}>
      {text.split(' ').map((w, i) => {
        const isA = acc.some((a) => w.toLowerCase().startsWith(a.toLowerCase()));
        return <span key={i} style={{color: isA ? C.acc : C.ink}}>{w} </span>;
      })}
    </div>
  );
};

// white rounded card with small-caps label
export const Card: React.FC<{x: number; y: number; w: number; h?: number; label?: string; at?: number; children?: React.ReactNode; style?: React.CSSProperties}> = ({x, y, w, h, label, at = 0, children, style}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: f - at, fps, config: {damping: 14, stiffness: 140, mass: 0.7}});
  return (
    <div style={{position: 'absolute', left: x, top: y, width: w, height: h, background: C.card, borderRadius: 28, padding: '26px 30px',
      boxShadow: '0 18px 40px rgba(20,24,32,.08), 0 2px 6px rgba(20,24,32,.05)', opacity: clamp01(s * 1.4), transform: `translateY(${(1 - s) * 40}px) scale(${0.94 + 0.06 * s})`, boxSizing: 'border-box', ...style}}>
      {label && <div style={{fontFamily: MONO, fontWeight: 700, fontSize: 20, letterSpacing: 2, color: C.acc, marginBottom: 12}}>{label}</div>}
      {children}
    </div>
  );
};

// rolling number
export const Counter: React.FC<{from: number; to: number; a: number; b: number; dec?: number; suffix?: string; size?: number; color?: string}> = ({from, to, a, b, dec = 0, suffix = '', size = 86, color = C.ink}) => {
  const f = useCurrentFrame();
  const v = from + (to - from) * ease(f, a, b);
  return <span style={{fontFamily: HEAD, fontWeight: 800, fontSize: size, color, fontVariantNumeric: 'tabular-nums'}}>{v.toFixed(dec)}<span style={{fontSize: size * 0.45}}>{suffix}</span></span>;
};

export const Bar: React.FC<{p: number; color?: string; h?: number}> = ({p, color = C.acc, h = 14}) => (
  <div style={{height: h, borderRadius: h, background: C.bg2, overflow: 'hidden'}}><div style={{height: '100%', width: `${clamp01(p) * 100}%`, background: color, borderRadius: h}} /></div>
);

// bottom subtitle pill, words revealed by timing; accent words coloured
export type Word = {w: string; t: number}; // t = frame where word starts
export const Subtitle: React.FC<{words: Word[]; acc?: string[]; maxWords?: number}> = ({words, acc = [], maxWords = 7}) => {
  const f = useCurrentFrame();
  const cur = words.filter((x) => x.t <= f).length - 1;
  if (cur < 0) return null;
  // chunks: break at sentence ends or every maxWords words
  const chunks: number[][] = []; let c: number[] = [];
  // sentences first, then each sentence split into k balanced parts (no 1–2-word tails like «like a / cuff.»)
  const pushBalanced = (s: number[]) => { const k = Math.ceil(s.length / maxWords); const base = Math.floor(s.length / k), extra = s.length % k; let p = 0;
    for (let j = 0; j < k; j++) { const n = base + (j < extra ? 1 : 0); chunks.push(s.slice(p, p + n)); p += n; } };
  words.forEach((x, i) => { c.push(i); if (/[.!?…]$/.test(x.w)) { pushBalanced(c); c = []; } });
  if (c.length) pushBalanced(c);
  const ci = chunks.findIndex((ch) => ch.includes(cur));
  const start = chunks[ci][0];
  const chunk = chunks[ci].map((i) => words[i]);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 300, display: 'flex', justifyContent: 'center'}}>
      <div dir="auto" style={{background: 'rgba(255,255,255,.92)', borderRadius: 999, padding: '16px 34px', boxShadow: '0 10px 30px rgba(20,24,32,.08)', maxWidth: 900,
        fontFamily: BODY, fontWeight: 700, fontSize: 38, textAlign: 'center', lineHeight: 1.25}}>
        {chunk.map((x, i) => {
          const k = start + i, on = k <= cur, p = ease(f, x.t, x.t + 6);
          const isA = acc.some((a) => x.w.toLowerCase().replace(/[.,:;!?«»]/g, '').startsWith(a.toLowerCase()));
          return <span key={k} style={{color: !on ? 'rgba(22,24,29,.25)' : isA ? C.acc : C.ink, filter: on && x.w.replace(/[.,:;!?«»—-]/g, '').length > 3 ? `blur(${(1 - p) * 2}px)` : 'none'}}>{x.w} </span>;
        })}
      </div>
    </div>
  );
};

// "?" slot that fills with content at time `at`
export const Slot: React.FC<{x: number; y: number; w: number; h: number; at: number; children: React.ReactNode}> = ({x, y, w, h, at, children}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: f - at, fps, config: {damping: 13, stiffness: 150}});
  return (
    <div style={{position: 'absolute', left: x, top: y, width: w, height: h}}>
      <div style={{position: 'absolute', inset: 0, borderRadius: 26, border: `3px dashed ${C.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: HEAD, fontWeight: 800, fontSize: 56, color: C.line, opacity: 1 - clamp01(s * 2)}}>?</div>
      <div style={{position: 'absolute', inset: 0, background: C.card, borderRadius: 26, boxShadow: '0 14px 34px rgba(20,24,32,.08)', padding: '20px 24px', boxSizing: 'border-box',
        display: 'flex', alignItems: 'center', gap: 20, opacity: clamp01(s), transform: `scale(${0.9 + 0.1 * s})`}}>{children}</div>
    </div>
  );
};

export const Note: React.FC<{children: React.ReactNode; color?: string; bg?: string; size?: number}> = ({children, color = C.acc, bg = C.accL, size = 24}) => (
  <span style={{display: 'inline-block', fontFamily: BODY, fontWeight: 700, fontSize: size, color, background: bg, borderRadius: 999, padding: '6px 16px'}}>{children}</span>
);

// Instagram/phone safe zone helper: content between y=440 and y=1560
export const SAFE = {top: 440, bottom: 1560};
