// «Длинная фиксация позвоночника до таза» — ролик для пациентов (9:16). Тексты SL01–SL12 ОДОБРЕНО ChatGPT 18.11 (tts-data spinelong.json).
// Надписи — дословные фрагменты одобренного текста на каждом языке. Тайминги — timing_spinelong[_lang].json.
import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Subtitle, Note, C, BODY, HEAD, ease, Word} from './kit';
import {Icon} from './Figures';
import {BedReal} from './WardArt';
import {Clip3D} from './Clip3D';
import {VertTopScrews} from './SpineArt';
import tRu from './timing_spinelong.json';
import tHe from './timing_spinelong_he.json';
import tAr from './timing_spinelong_ar.json';
import tEn from './timing_spinelong_en.json';

type TT = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const FPS = 30, PAD = 0.5;
const fr = (d: number, p: number) => Math.round(d * p);
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};

type Dict = {brand: string; rtl?: boolean; n: Record<string, string[]>};
const N: Record<string, Dict> = {
  ru: {
    brand: 'ОРТОПЕДИЯ · ПАЦИЕНТАМ',
    n: {
      SL01: ['стабилизируют протяжённый участок позвоночника', 'закрепляют конструкцию в костях таза', 'деформации, нестабильности или сдавлении нервов', 'спинальный хирург — ортопед или нейрохирург'],
      SL02: ['специальные винты', 'прочными стержнями', 'до костей таза', 'костный материал', 'декомпрессию'],
      SL03: ['необходимые обследования', 'препаратов, влияющих на свёртывание крови, и средств от диабета', 'душ с хлоргексидином четыре процента вечером и утром', 'шестью салфетками с хлоргексидином два процента', 'при аллергии на хлоргексидин эти средства не применяют', 'со спиной помогает персонал'],
      SL04: ['общей анестезией', 'вы спите', 'укладывает вас на живот', 'защищая участки тела, на которые приходится давление'],
      SL05: ['Навигационная система', 'роботизированный помощник', 'операцией управляет сам хирург', 'Нейромониторинг', 'не исключают все осложнения'],
      SL06: ['собирать потерянную кровь', 'собственные эритроциты', 'уменьшить потребность в донорской крови', 'иногда переливание донорской крови всё равно необходимо'],
      SL07: ['несколько часов', 'точную продолжительность заранее предсказать невозможно', 'Персонал объяснит близким'],
      SL08: ['палату пробуждения', 'дыханием, давлением, движениями ног и уровнем боли', 'дренаж', 'мочевой катетер'],
      SL09: ['только после разрешения медицинской команды', 'с помощью физиотерапевта', 'плечи и таз нужно поворачивать вместе', 'попросить помощи персонала'],
      SL10: ['разрешённые движения', 'раннюю безопасную ходьбу', 'средства компрессии ног', 'дыхательные упражнения'],
      SL11: ['боль, скованность и усталость', 'обезболивание', 'Восстановление занимает месяцы', 'костное сращение происходит постепенно', 'наклоны, скручивания и нагрузку'],
      SL12: ['новой слабости или онемении ног', 'нарушении мочеиспускания или контроля стула', 'температуре, выделениях из раны', 'боли и отёке ноги', 'внезапной боли в груди, одышке', 'индивидуальные указания лечащего врача и персонала отделения имеют приоритет'],
    },
  },
  he: {
    brand: 'אורתופדיה · למטופלים', rtl: true,
    n: {
      SL01: ['מייצבים חלק נרחב מעמוד השדרה', 'מעגנים את הקיבוע בעצמות האגן', 'עיוות משמעותי, חוסר יציבות או לחץ על עצבים', 'מנתח עמוד השדרה, שהוא אורתופד או נוירוכירורג'],
      SL02: ['ברגים מיוחדים', 'מחבר ביניהם מוטות', 'עד עצמות האגן', 'חומר עצם', 'שחרור לחץ'],
      SL03: ['הבדיקות הדרושות', 'תרופות שמשפיעות על קרישת הדם ותרופות לסוכרת', 'מתקלחים עם כלורהקסידין בריכוז ארבעה אחוזים בערב ובבוקר', 'בשש מטליות עם כלורהקסידין בריכוז שני אחוזים', 'במקרה של אלרגיה לכלורהקסידין אין להשתמש בתכשירים', 'הצוות מסייע בניגוב הגב'],
      SL04: ['בהרדמה כללית', 'אתם ישנים', 'משכיב אתכם בזהירות על הבטן', 'מגן על האזורים בגוף שעליהם מופעל לחץ'],
      SL05: ['מערכת ניווט', 'מערכת רובוטית מסייעת', 'המנתח הוא שמנהל את הניתוח', 'ניטור עצבי', 'אינן מבטיחות שלא יהיו סיבוכים'],
      SL06: ['לאסוף דם שאבד', 'כדוריות הדם האדומות שלו', 'להפחית את הצורך בדם מתורם', 'לפעמים עדיין נדרש עירוי דם מתורם'],
      SL07: ['כמה שעות', 'אי אפשר לחזות מראש את משכו המדויק', 'הצוות יסביר לבני המשפחה'],
      SL08: ['לחדר התאוששות', 'הנשימה, לחץ הדם, תנועות הרגליים ורמת הכאב', 'נקז', 'צנתר שתן'],
      SL09: ['רק לאחר אישור הצוות הרפואי', 'בעזרת פיזיותרפיסט', 'להזיז את הכתפיים והאגן יחד', 'לבקש עזרה מהצוות'],
      SL10: ['תנועות מותרות', 'הליכה מוקדמת ובטוחה', 'אמצעי לחץ לרגליים', 'תרגילי נשימה'],
      SL11: ['כאב, נוקשות ועייפות', 'טיפול מתאים בכאב', 'ההחלמה נמשכת חודשים', 'איחוי העצמות מתרחש בהדרגה', 'כיפוף, סיבוב ועומס'],
      SL12: ['חולשה חדשה או ירידה בתחושה ברגליים', 'שינוי במתן שתן או בשליטה ביציאות', 'חום, הפרשה מהפצע', 'כאב ונפיחות ברגל', 'כאב פתאומי בחזה, קוצר נשימה', 'ההנחיות האישיות של הרופא המטפל ושל הצוות במחלקה קודמות'],
    },
  },
  ar: {
    brand: 'جراحة العظام · للمرضى', rtl: true,
    n: {
      SL01: ["تثبيت جزء طويل من العمود الفقري", "ربط التثبيت بعظام الحوض", "تشوه واضح أو عدم ثبات أو ضغط على الأعصاب", "جرّاح عظام أو جرّاح أعصاب"],
      SL02: ["براغي خاصة", "بقضبان قوية", "حتى عظام الحوض", "مادة عظمية", "إزالة الضغط"],
      SL03: ["الفحوص اللازمة", "الأدوية التي تؤثر في تخثر الدم وأدوية السكري", "استحموا بالكلورهيكسيدين بتركيز أربعة بالمئة مساءً وصباحًا", "ست مناديل تحتوي على الكلورهيكسيدين بتركيز اثنين بالمئة", "لا تستخدموا هذه المستحضرات إذا كانت لديكم حساسية", "يساعدكم الطاقم في مسح الظهر"],
      SL04: ["التخدير العام", "تكونون نائمين", "الاستلقاء على البطن", "يحمي مناطق الجسم المعرضة للضغط"],
      SL05: ["أنظمة الملاحة", "المساعدة الروبوتية", "الجرّاح هو الذي يتحكم في العملية", "الرصد العصبي", "لا تمنع جميع المضاعفات"],
      SL06: ["يجمع جهاز خاص الدم المفقود", "كريات دمه الحمراء", "يقلل ذلك الحاجة إلى نقل دم من متبرع", "نقل دم المتبرعين قد يبقى ضروريًا"],
      SL07: ["عدة ساعات", "لا يمكن التنبؤ بمدتها الدقيقة مسبقًا", "سيشرح الطاقم لأفراد عائلتكم"],
      SL08: ["غرفة الإفاقة", "التنفس وضغط الدم وحركة الساقين ومستوى الألم", "أنبوب لتصريف السوائل", "قسطار بولي"],
      SL09: ["إلا بعد موافقة الفريق الطبي", "بمساعدة أخصائي العلاج الطبيعي", "حرّكوا الكتفين والحوض معًا", "اطلبوا مساعدة الطاقم"],
      SL10: ["الحركات المسموح بها", "المشي المبكر الآمن", "وسائل الضغط على الساقين", "تمارين التنفس"],
      SL11: ["الألم والتيبس والتعب", "تسكين الألم المناسب", "يستمر التعافي عدة أشهر", "يحدث التحام العظام تدريجيًا", "الانحناء والالتواء والتحميل"],
      SL12: ["ضعف جديد أو فقدان إحساس في الساقين", "تغير في التبول أو التحكم في البراز", "حرارة أو إفرازات من الجرح", "ألم وتورم في الساق", "ألم مفاجئ في الصدر أو ضيق في التنفس", "تعليمات الطبيب المعالج وطاقم القسم الخاصة بحالتكم لها الأولوية"],
    },
  },
  en: {
    brand: 'ORTHOPAEDICS · FOR PATIENTS',
    n: {
      SL01: ["stabilizes a long section of the spine", "anchors the fixation to the pelvic bones", "significant deformity, instability or nerve compression", "an orthopedic surgeon or a neurosurgeon"],
      SL02: ["special screws", "strong rods", "to the pelvic bones", "Bone graft material", "decompression"],
      SL03: ["the necessary tests", "blood thinners and diabetes medicines", "four percent chlorhexidine shower in the evening and morning", "six two percent chlorhexidine cloths", "must not be used if you are allergic to chlorhexidine", "staff help with your back"],
      SL04: ["general anesthesia", "you are asleep", "positions you face down", "protects pressure points on your body"],
      SL05: ["Navigation", "robotic assistance", "the surgeon remains in control", "Intraoperative neuromonitoring", "cannot eliminate every complication"],
      SL06: ["collect lost blood", "your own red blood cells", "reduce the need for donated blood", "a donor blood transfusion may still be necessary"],
      SL07: ["several hours", "exact duration cannot be predicted in advance", "Staff will explain how your family can receive updates"],
      SL08: ["the recovery room", "breathing, blood pressure, leg movements and pain", "A wound drain", "urinary catheter"],
      SL09: ["only when the medical team allows it", "help from a physiotherapist", "turn your shoulders and hips together", "ask staff for help"],
      SL10: ["permitted movements", "early safe walking", "leg compression devices", "breathing exercises"],
      SL11: ["Pain, stiffness and tiredness", "appropriate pain relief", "Recovery takes months", "bone fusion develops gradually", "bending, twisting and activity"],
      SL12: ["new leg weakness or numbness", "problems passing urine or controlling your bowels", "fever, wound discharge", "pain and swelling in a leg", "sudden chest pain, breathlessness", "individual instructions from your treating doctor and ward staff take priority"],
    },
  },
};

const NV = '#E3E7EF';
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10), transform: `translateY(${(1 - ease(f, a, a + 10)) * 14}px)`}}><Note size={30} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const Row: React.FC<{y: number; at: number; icon: string; text: string; red?: boolean; fs?: number}> = ({y, at, icon, text, red, fs = 32}) => (
  <Card x={64} y={y} w={952} at={at} style={red ? {borderLeft: `10px solid ${C.blood}`} : undefined}>
    <div style={{display: 'flex', alignItems: 'center', gap: 24}}>
      <Icon k={icon} s={56} c={red ? C.blood : C.acc} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: fs, color: C.ink, lineHeight: 1.22}}>{text}</div>
    </div>
  </Card>
);
const Stage: React.FC<{top: number; h?: number; bg?: string; children: React.ReactNode}> = ({top, h = 600, bg = '#F4F8FC', children}) => (
  <div style={{position: 'absolute', left: 64, top, width: 952, height: h, borderRadius: 36, background: '#fff', boxShadow: '0 18px 50px rgba(20,30,50,.10)', overflow: 'hidden', direction: 'ltr'}}>
    <svg width={952} height={h} viewBox={`0 0 952 ${h}`}><rect x={0} y={0} width={952} height={h} fill={bg} />{children}</svg>
  </div>
);
const SKIN = '#F1D3BC', HAIR = '#5B4636', GREY = '#B9B4AE';
const BONE = '#EFE6D8', BONES = '#C9B79C', DISC = '#BFD9E6', TI = '#8E99A8', TIS = '#4F5B6B';
const Bust: React.FC<{x: number; y: number; s?: number; col: string; hair?: string; o?: number; cap?: boolean; flip?: boolean}> = ({x, y, s = 1, col, hair = HAIR, o = 1, cap, flip}) => (
  <g transform={`translate(${x} ${y}) scale(${flip ? -s : s} ${s})`} opacity={o}>
    <path d="M-78 190 Q-80 70 0 62 Q80 70 78 190 Z" fill={col} />
    <path d="M-20 64 L0 96 L20 64 Z" fill="#fff" opacity={0.8} />
    <rect x={-14} y={36} width={28} height={30} rx={10} fill={SKIN} />
    <ellipse cx={0} cy={0} rx={40} ry={46} fill={SKIN} />
    <path d="M-42 -4 Q-44 -52 0 -52 Q44 -52 42 -4 Q30 -30 0 -28 Q-30 -30 -42 -4 Z" fill={hair} />
    {cap && <path d="M-44 -18 Q-40 -64 0 -64 Q40 -64 44 -18 Q20 -30 0 -30 Q-20 -30 -44 -18 Z" fill={col} />}
    <circle cx={-14} cy={4} r={4.5} fill="#3A3F4A" /><circle cx={14} cy={4} r={4.5} fill="#3A3F4A" />
    <path d="M-12 22 Q0 30 12 22" stroke="#B9806A" strokeWidth={4} fill="none" strokeLinecap="round" />
  </g>
);

// Вид сзади: позвонки T10–L5, крестец и подвздошные кости. hl — подсветка зоны фиксации (T11–таз),
// scr — винты в ножках (снизу вверх), rod — стержни, pel — тазовые винты, fuse — костный материал/сращение, body — силуэт тела.
const NV8 = 8, VH = 46, VG = 14, CX = 476, Y0 = 40;
const vy = (i: number) => Y0 + i * (VH + VG);
const LongSpine: React.FC<{top: number; hl?: number; scr?: number; rod?: number; pel?: number; fuse?: number; body?: number; deco?: number}> = ({top, hl = 0, scr = 0, rod = 0, pel = 0, fuse = 0, body = 0, deco = 0}) => {
  const f = useCurrentFrame();
  const sy = vy(NV8) + 4; // верх крестца
  const fixed = Array.from({length: NV8 - 1}, (_, k) => k + 1); // T11–L5 (индексы 1..7)
  const sOn = (k: number) => Math.max(0, Math.min(1, scr * fixed.length - (fixed.length - 1 - (k - 1))));
  const topY = vy(1) + VH / 2, pelY = sy + 70;
  return <Stage top={top} h={640} bg="#F3F7FB">
    <g opacity={body * 0.9}><path d={`M ${CX - 230} 0 C ${CX - 250} 200 ${CX - 220} 380 ${CX - 300} 640 L ${CX + 300} 640 C ${CX + 220} 380 ${CX + 250} 200 ${CX + 230} 0 Z`} fill="#F6E3D4" stroke="#E9CDB8" strokeWidth={4} /></g>
    <rect x={CX - 175} y={vy(1) - 10} width={350} height={pelY - vy(1) + 90} rx={30} fill={C.teal} opacity={0.13 * hl} />
    <rect x={CX - 175} y={vy(1) - 10} width={350} height={pelY - vy(1) + 90} rx={30} fill="none" stroke={C.teal} strokeWidth={5} strokeDasharray="16 10" opacity={hl} />
    {/* подвздошные кости */}
    {[-1, 1].map((s) => <path key={s} d={`M ${CX + s * 70} ${sy + 10} C ${CX + s * 160} ${sy - 60} ${CX + s * 300} ${sy - 50} ${CX + s * 330} ${sy + 30} C ${CX + s * 320} ${sy + 120} ${CX + s * 220} ${sy + 160} ${CX + s * 120} ${sy + 200} L ${CX + s * 80} ${sy + 150} Z`} fill={BONE} stroke={BONES} strokeWidth={4} />)}
    {/* крестец */}
    <path d={`M ${CX - 92} ${sy} L ${CX + 92} ${sy} L ${CX + 40} ${sy + 190} L ${CX - 40} ${sy + 190} Z`} fill={BONE} stroke={BONES} strokeWidth={4} />
    {[0, 1, 2, 3].map((i) => <g key={i}><circle cx={CX - 44 + i * 6} cy={sy + 40 + i * 38} r={7} fill="#E2D5C2" /><circle cx={CX + 44 - i * 6} cy={sy + 40 + i * 38} r={7} fill="#E2D5C2" /></g>)}
    {/* позвонки */}
    {Array.from({length: NV8}, (_, i) => { const y = vy(i), w = 64 + i * 3; return <g key={i}>
      {i < NV8 && <rect x={CX - w} y={y + VH} width={w * 2} height={VG} fill={DISC} opacity={0.8} />}
      <rect x={CX - w - 50} y={y + 14} width={(w + 50) * 2} height={16} rx={8} fill={BONE} stroke={BONES} strokeWidth={3} />
      <rect x={CX - w} y={y} width={w * 2} height={VH} rx={14} fill={BONE} stroke={BONES} strokeWidth={4} />
      <rect x={CX - 12} y={y + 4} width={24} height={VH + 6} rx={10} fill="#E2D5C2" stroke={BONES} strokeWidth={3} />
    </g>; })}
    {/* декомпрессия: «окно» над нервами */}
    <g opacity={deco}><rect x={CX - 26} y={vy(6) - 2} width={52} height={VH * 2 + VG + 4} rx={18} fill="#F2D27A" stroke="#C9A23A" strokeWidth={3} /></g>
    {/* костный материал вдоль поперечных отростков */}
    <g opacity={fuse}>{fixed.map((k) => [-1, 1].map((s) => <ellipse key={`${k}${s}`} cx={CX + s * 100} cy={vy(k) + VH / 2 + 4} rx={30} ry={VH / 2 + 12} fill="#F6E7B8" stroke="#D8B85A" strokeWidth={3} opacity={0.6 + 0.4 * Math.sin(f / 12 + k) ** 2} />))}</g>
    {/* стержни */}
    {[-1, 1].map((s) => <path key={s} d={`M ${CX + s * 48} ${topY - 16} L ${CX + s * 48} ${sy - 20} Q ${CX + s * 50} ${pelY - 30} ${CX + s * 130} ${pelY}`} stroke={TI} strokeWidth={12} fill="none" strokeLinecap="round" strokeDasharray={1000} strokeDashoffset={1000 * (1 - rod)} />)}
    {/* винты в ножках */}
    {fixed.map((k) => [-1, 1].map((s) => { const p = sOn(k); return <g key={`${k}${s}`} opacity={p} transform={`translate(${CX + s * 48} ${vy(k) + VH / 2}) scale(${0.6 + 0.4 * p})`}>
      <circle r={13} fill="#6B7686" stroke={TIS} strokeWidth={3} /><rect x={-6} y={-6} width={12} height={12} rx={2} fill={C.teal} opacity={rod} /></g>; }))}
    {/* тазовые винты: от задней части таза в подвздошную кость */}
    {[-1, 1].map((s) => <g key={s} opacity={pel}>
      <line x1={CX + s * 130} y1={pelY} x2={CX + s * (130 + 150 * pel)} y2={pelY - 10 + 40 * pel} stroke={TI} strokeWidth={14} strokeLinecap="round" />
      {Array.from({length: 6}, (_, i) => <line key={i} x1={CX + s * (150 + i * 22) * pel} y1={pelY - 12 + 6 * i * pel} x2={CX + s * (160 + i * 22) * pel} y2={pelY + 12 + 6 * i * pel} stroke={TIS} strokeWidth={3} opacity={pel} />)}
      <circle cx={CX + s * 130} cy={pelY} r={15} fill="#6B7686" stroke={TIS} strokeWidth={3} />
    </g>)}
  </Stage>;
};

const Months: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame(); const p = ease(f, fr(d, 0.4), fr(d, 0.85));
  return <div style={{position: 'absolute', left: 64, top, width: 952, height: 70, direction: 'ltr'}}>
    <svg width={952} height={70}><rect x={20} y={28} width={912} height={14} rx={7} fill={C.line} /><rect x={20} y={28} width={912 * p} height={14} rx={7} fill={C.teal} />
      {Array.from({length: 7}, (_, i) => <circle key={i} cx={20 + i * 152} cy={35} r={12} fill={i / 6 <= p ? C.teal : '#fff'} stroke={C.teal} strokeWidth={4} />)}</svg>
  </div>;
};

const OrTable: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame(); const flip = ease(f, fr(d, 0.42), fr(d, 0.6));
  const sleep = ease(f, fr(d, 0.12), fr(d, 0.25));
  return <Stage top={top} bg="#F2F7FA">
    <rect x={0} y={500} width={952} height={100} fill="#DDE8EF" />
    <rect x={110} y={420} width={740} height={34} rx={12} fill="#8C96A3" /><rect x={450} y={454} width={60} height={60} fill="#6B7686" /><rect x={380} y={510} width={200} height={20} rx={8} fill="#6B7686" />
    {/* монитор наркоза */}
    <g transform="translate(40 70)"><rect width={170} height={120} rx={14} fill="#1E2A3A" /><path d={Array.from({length: 30}, (_, i) => `${i ? 'L' : 'M'}${12 + i * 5} ${60 + ((i * 5 + f * 3) % 60 < 6 ? -26 : 0)}`).join(' ')} stroke={C.green} strokeWidth={4} fill="none" /><rect x={30} y={120} width={14} height={180} fill="#8C96A3" /></g>
    {/* на спине */}
    <g opacity={1 - flip}>
      <ellipse cx={210} cy={372} rx={46} ry={42} fill={SKIN} /><path d="M170 360 Q170 320 210 322 Q250 320 252 360 Q232 340 210 342 Q188 340 170 360 Z" fill={HAIR} />
      <path d="M250 340 h380 q40 0 40 40 v0 q0 40 -40 40 h-380 Z" fill="#CFE3F2" />
      <path d="M640 350 h200 q14 0 14 14 v20 q0 14 -14 14 h-200 Z" fill="#CFE3F2" />
      <g opacity={sleep}><path d="M196 384 q14 8 28 0" stroke="#3A3F4A" strokeWidth={4} fill="none" /><path d="M196 364 q8 -4 16 0 M222 364 q8 -4 16 0" stroke="#3A3F4A" strokeWidth={4} fill="none" />
        <text x={260} y={300} fontFamily={HEAD} fontWeight={800} fontSize={44} fill={C.acc} opacity={0.5 + 0.5 * Math.sin(f / 8)}>z z</text></g>
    </g>
    {/* на животе, на опорах */}
    <g opacity={flip}>
      <rect x={300} y={372} width={130} height={48} rx={18} fill={C.teal} opacity={0.85} /><rect x={540} y={372} width={130} height={48} rx={18} fill={C.teal} opacity={0.85} />
      <rect x={700} y={392} width={60} height={28} rx={12} fill={C.tealL} stroke={C.teal} strokeWidth={3} />
      <rect x={140} y={396} width={110} height={24} rx={12} fill={C.tealL} stroke={C.teal} strokeWidth={3} />
      <ellipse cx={200} cy={360} rx={44} ry={40} fill={HAIR} /><path d="M240 330 h400 q40 0 40 34 q0 10 -40 10 h-400 Z" fill="#CFE3F2" />
      <path d="M640 340 h200 q14 0 14 14 v6 q0 12 -14 12 h-200 Z" fill="#CFE3F2" />
      <path d="M380 318 h180" stroke={C.teal} strokeWidth={6} strokeDasharray="12 8" />
    </g>
  </Stage>;
};

const CellSaver: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame(); const o = (p: number) => ease(f, fr(d, p), fr(d, p + 0.08));
  const flow = (len: number, k: number) => Array.from({length: k}, (_, i) => ((f * 4 + i * (len / k)) % len));
  const bag = ease(f, fr(d, 0.35), fr(d, 0.7));
  return <Stage top={top}>
    <rect x={0} y={480} width={952} height={120} fill="#E4EAF1" />
    {/* операционное поле */}
    <g opacity={o(0)}><rect x={40} y={260} width={220} height={150} rx={20} fill="#9CCFC0" /><rect x={110} y={315} width={80} height={40} rx={18} fill="#F4C9C0" /><path d="M150 335 C 150 200 260 160 330 160" stroke="#C9D6E3" strokeWidth={10} fill="none" /></g>
    {/* резервуар */}
    <g opacity={o(0.08)} transform="translate(330 90)"><rect width={110} height={170} rx={20} fill="#fff" stroke="#9FB4C8" strokeWidth={5} /><rect x={8} y={170 - 60} width={94} height={52} rx={12} fill="#C4363B" opacity={0.75} /></g>
    {/* центрифуга (промывание) */}
    <g opacity={o(0.2)} transform="translate(560 190)">
      <circle r={86} fill="#fff" stroke="#9FB4C8" strokeWidth={5} />
      <g transform={`rotate(${f * 9})`}>{[0, 60, 120, 180, 240, 300].map((a) => <rect key={a} x={-6} y={-74} width={12} height={40} rx={6} fill="#C4363B" opacity={0.7} transform={`rotate(${a})`} />)}</g>
      <circle r={22} fill="#7FB8E0" />
    </g>
    <path d="M440 200 H 474" stroke="#C9D6E3" strokeWidth={10} opacity={o(0.2)} />
    {/* мешок эритроцитов */}
    <g opacity={o(0.35)} transform="translate(720 60)"><rect width={150} height={210} rx={30} fill="#fff" stroke="#9FB4C8" strokeWidth={5} /><rect x={10} y={200 - 180 * bag} width={130} height={180 * bag} rx={22} fill="#B3262B" /><path d="M75 210 v40 C 75 330 40 360 -10 380" stroke="#C9D6E3" strokeWidth={10} fill="none" /></g>
    <path d="M646 190 H 720" stroke="#C9D6E3" strokeWidth={10} opacity={o(0.35)} />
    {/* рука с капельницей */}
    <g opacity={o(0.55)}><path d="M420 470 L 720 430 Q 760 426 762 450 Q 760 474 720 472 L 420 500 Z" fill={SKIN} stroke="#D9B193" strokeWidth={4} /><rect x={680} y={428} width={50} height={30} rx={8} fill="#fff" stroke={C.teal} strokeWidth={4} /><path d="M710 440 C 712 410 690 400 710 380" stroke="#B3262B" strokeWidth={8} fill="none" /></g>
    {flow(160, 5).map((x, i) => <circle key={i} cx={170 + x} cy={170} r={6} fill="#C4363B" opacity={o(0.08)} />)}
  </Stage>;
};

const Waiting: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame(); const t = ease(f, 0, d);
  const talk = ease(f, fr(d, 0.55), fr(d, 0.65));
  return <Stage top={top} bg="#F6F3FA">
    <rect x={0} y={480} width={952} height={120} fill="#ECE6F3" />
    <g transform="translate(170 180)"><circle r={120} fill="#fff" stroke={C.navy} strokeWidth={8} />
      {Array.from({length: 12}, (_, i) => <line key={i} x1={0} y1={-104} x2={0} y2={-90} stroke={C.navy} strokeWidth={5} transform={`rotate(${i * 30})`} />)}
      <line x1={0} y1={0} x2={0} y2={-60} stroke={C.navy} strokeWidth={10} strokeLinecap="round" transform={`rotate(${30 + t * 120})`} />
      <line x1={0} y1={0} x2={0} y2={-90} stroke={C.acc} strokeWidth={6} strokeLinecap="round" transform={`rotate(${t * 1440})`} />
      <circle r={9} fill={C.navy} /></g>
    <g opacity={ease(f, 0, 12)}><rect x={360} y={420} width={300} height={40} rx={14} fill="#B49AD6" /><Bust x={420} y={300} col="#8DA9C4" hair={GREY} s={0.85} /><Bust x={580} y={300} col="#E3B48F" s={0.85} /></g>
    <g opacity={talk}><Bust x={810} y={300} col={C.teal} cap s={0.95} flip />
      <g transform="translate(700 120)"><rect x={-80} y={-50} width={160} height={100} rx={28} fill="#fff" stroke={C.line} strokeWidth={4} /><path d="M-40 -6 h80 M-40 18 h50" stroke={C.mute} strokeWidth={8} strokeLinecap="round" /></g></g>
  </Stage>;
};

const scene = (id: string, d: number, L: Dict) => {
  const n = L.n[id];
  const t = (p: number) => fr(d, p);
  const f0 = (a: number, b: number) => (fr2: number) => Math.max(0, Math.min(1, (fr2 - t(a)) / Math.max(1, t(b) - t(a))));
  switch (id) {
    case 'SL01': return <><SL top={440} d={d} k="01" /><Notes y={1100} items={[[n[0], t(0.08), C.navy, NV], [n[1], t(0.3), C.teal, C.tealL], [n[2], t(0.55)], [n[3], t(0.78), C.navy, NV]]} /></>;
    case 'SL02': return <><SL top={440} d={d} k="02" /><Notes y={1100} items={[[n[0], t(0.05), C.navy, NV], [n[1], t(0.2), C.navy, NV], [n[2], t(0.33), C.teal, C.tealL], [n[3], t(0.55)], [n[4], t(0.78), C.teal, C.tealL]]} /></>;
    case 'SL03': return <>{n.slice(0, 5).map((x, i) => <Row key={i} y={450 + i * 160} at={t(0.03 + [0, 0.1, 0.33, 0.55, 0.85][i])} icon={['check', 'pills', 'shower', 'check', 'check'][i]} text={x} red={i === 4} fs={30} />)}
      <Notes y={1270} items={[[n[5], t(0.78), C.teal, C.tealL]]} /></>;
    case 'SL04': return <><OrTable top={440} d={d} /><Notes y={1080} items={[[n[0], t(0.05), C.navy, NV], [n[1], t(0.25)], [n[2], t(0.5), C.teal, C.tealL], [n[3], t(0.72)]]} /></>;
    case 'SL05': return <><VertTopScrews top={420} d={d} /><Notes y={1130} items={[[n[0], t(0.05), C.navy, NV], [n[1], t(0.15), C.navy, NV], [n[2], t(0.3), C.teal, C.tealL], [n[3], t(0.48)], [n[4], t(0.82), C.blood, C.bloodL]]} /></>;
    case 'SL06': return <><CellSaver top={440} d={d} /><Notes y={1080} items={[[n[0], t(0.05), C.navy, NV], [n[1], t(0.3), C.blood, C.bloodL], [n[2], t(0.55), C.teal, C.tealL], [n[3], t(0.75)]]} /></>;
    case 'SL07': return <><Waiting top={440} d={d} /><Notes y={1080} items={[[n[0], t(0.05), C.navy, NV], [n[1], t(0.25)], [n[2], t(0.6), C.teal, C.tealL]]} /></>;
    case 'SL08': return <><BedReal top={440} d={d} bell={false} patient /><Notes y={1000} items={[[n[0], t(0.05), C.navy, NV], [n[1], t(0.2), C.teal, C.tealL], [n[2], t(0.55)], [n[3], t(0.68)]]} /></>;
    case 'SL09': return <><Clip3D src="c3/logroll_getup.mp4" y={440} h={600} d={d} dur={12} at={t(0.03)} /><Notes y={1080} items={[[n[0], t(0.05), C.navy, NV], [n[1], t(0.25)], [n[2], t(0.5), C.teal, C.tealL], [n[3], t(0.8)]]} /></>;
    case 'SL10': return <><Clip3D src="c3/swell_pump.mp4" y={440} h={600} d={d} dur={9} at={t(0.03)} /><Notes y={1080} items={[[n[0], t(0.1), C.navy, NV], [n[1], t(0.2), C.teal, C.tealL], [n[2], t(0.33)], [n[3], t(0.7), C.teal, C.tealL]]} /></>;
    case 'SL11': return <><SL top={440} d={d} k="11" /><Months top={1090} d={d} /><Notes y={1170} items={[[n[0], t(0.04)], [n[1], t(0.2), C.teal, C.tealL], [n[2], t(0.4), C.navy, NV], [n[3], t(0.55), C.navy, NV], [n[4], t(0.78)]]} /></>;
    case 'SL12': return <>
      {n.slice(0, 4).map((x, i) => <Row key={i} y={450 + i * 140} at={t(0.03 + i * 0.07)} icon={['leg', 'bladder', 'therm', 'calf'][i]} text={x} red fs={30} />)}
      <Card x={64} y={1020} w={952} at={t(0.42)} style={{background: '#FDECEC', border: `4px solid ${C.blood}`}}>
        <div style={{display: 'flex', alignItems: 'center', gap: 24}}><Icon k="heart" s={56} c={C.blood} />
          <div style={{flex: 1, fontFamily: BODY, fontWeight: 800, fontSize: 32, color: C.ink}}>{n[4]}</div>
          <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 54, color: C.blood, direction: 'ltr'}}>101</div></div>
      </Card>
      <Card x={64} y={1190} w={952} at={t(0.8)} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
        <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{n[5]}</div>
      </Card>
    </>;
  }
  void f0;
  return null;
};
// Анимированный позвоночник по сценам
const SL: React.FC<{top: number; d: number; k: string}> = ({top, d, k}) => {
  const f = useCurrentFrame(); const e = (a: number, b: number) => ease(f, fr(d, a), fr(d, b));
  if (k === '01') return <LongSpine top={top} body={1 - e(0.5, 0.7) * 0.6} hl={e(0.08, 0.2)} scr={e(0.3, 0.45)} rod={e(0.38, 0.5)} pel={e(0.45, 0.55)} />;
  if (k === '02') return <LongSpine top={top} scr={e(0.03, 0.22)} rod={e(0.2, 0.3)} pel={e(0.3, 0.42)} fuse={e(0.5, 0.62)} deco={e(0.75, 0.85)} />;
  return <LongSpine top={top} scr={1} rod={1} pel={1} fuse={0.3 + 0.7 * e(0.4, 0.85)} />;
};

export const mkSpinelong = (lang: string, timing: unknown) => {
  const TT = timing as TT;
  const L = N[lang];
  const total = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
  const Comp: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
    let at = 0;
    return <AbsoluteFill style={{direction: L.rtl ? 'rtl' : 'ltr'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={L.brand} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            {scene(x.id, d, L)}
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>;
  };
  return {Comp, total};
};
const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
const ru = mkSpinelong('ru', tRu); export const Spinelong = ru.Comp; export const totalSpinelong = ru.total;
const he = mkSpinelong('he', tHe); export const SpinelongHe = he.Comp; export const totalSpinelongHe = he.total;
const ar = mkSpinelong('ar', tAr); export const SpinelongAr = ar.Comp; export const totalSpinelongAr = ar.total;
const en = mkSpinelong('en', tEn); export const SpinelongEn = en.Comp; export const totalSpinelongEn = en.total;
