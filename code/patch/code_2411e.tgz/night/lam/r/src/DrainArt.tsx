// Анимации для ролика «Дренаж после операции» (без текста — одинаково для RU/HE/AR/EN).
import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C, ease} from './kit';

const fr = (d: number, p: number) => Math.round(d * p);
const SKIN = '#E9C9AE', SKINS = '#C99B7A', TUBE = '#B9D7E6', TUBES = '#6E9BB3', BLOOD = '#B3121B';
export const Panel: React.FC<{x: number; w: number; h: number; o?: number}> = ({x, w, h, o = 1}) => <rect x={x} y={0} width={w} height={h} rx={28} fill="#fff" opacity={o} />;

// ёмкость-гармошка (закрытый вакуумный дренаж); fill 0..1 — уровень, tint 0..1 — от тёмно-красного к светло-розовому; squeeze 0..1 — сжата
export const Accordion: React.FC<{x: number; y: number; s?: number; fill?: number; tint?: number; squeeze?: number}> = ({x, y, s = 1, fill = 0.4, tint = 0, squeeze = 0.6}) => {
  const h = 150 - 50 * squeeze, ribs = 5;
  const col = `rgb(${Math.round(179 + 60 * tint)},${Math.round(18 + 150 * tint)},${Math.round(27 + 140 * tint)})`;
  return <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-58} y={-h} width={116} height={h} rx={16} fill="#F2F6F9" stroke="#8CA3B5" strokeWidth={4} />
    <clipPath id={`acc${x}${y}`}><rect x={-56} y={-h + 2} width={112} height={h - 4} rx={14} /></clipPath>
    <rect x={-56} y={-(h - 4) * fill - 2} width={112} height={(h - 4) * fill} fill={col} opacity={0.85} clipPath={`url(#acc${x}${y})`} />
    {Array.from({length: ribs}, (_, i) => <line key={i} x1={-58} y1={-h + (i + 1) * h / (ribs + 1)} x2={58} y2={-h + (i + 1) * h / (ribs + 1)} stroke="#8CA3B5" strokeWidth={3} opacity={0.6} />)}
    <rect x={-22} y={-h - 16} width={44} height={18} rx={5} fill="#8CA3B5" />
  </g>;
};
const Bulb: React.FC<{x: number; y: number}> = ({x, y}) => <g transform={`translate(${x} ${y})`}>
  <ellipse cx={0} cy={-60} rx={46} ry={62} fill="#F2F6F9" stroke="#8CA3B5" strokeWidth={4} />
  <path d="M -44 -50 Q 0 -30 44 -50 L 40 -20 Q 0 0 -40 -20 Z" fill={BLOOD} opacity={0.75} />
  <rect x={-12} y={-136} width={24} height={20} rx={5} fill="#8CA3B5" /></g>;
const Bag: React.FC<{x: number; y: number}> = ({x, y}) => <g transform={`translate(${x} ${y})`}>
  <path d="M -50 -140 L 50 -140 L 56 -10 Q 0 6 -56 -10 Z" fill="#F2F6F9" stroke="#8CA3B5" strokeWidth={4} />
  <path d="M -54 -50 L 54 -50 L 56 -10 Q 0 6 -56 -10 Z" fill={BLOOD} opacity={0.6} />
  {[-110, -80].map((yy) => <line key={yy} x1={-30} y1={yy} x2={30} y2={yy} stroke="#8CA3B5" strokeWidth={3} />)}</g>;
// аппарат вакуумной терапии + повязка (губка под плёнкой)
export const NpwtUnit: React.FC<{x: number; y: number; s?: number; pulse?: number; alarm?: number}> = ({x, y, s = 1, pulse = 0, alarm = 0}) => <g transform={`translate(${x} ${y}) scale(${s})`}>
  <rect x={-80} y={-150} width={160} height={150} rx={22} fill="#E9EEF3" stroke="#6B7686" strokeWidth={4} />
  <rect x={-60} y={-130} width={120} height={56} rx={10} fill="#1B2333" />
  <rect x={-50} y={-118} width={60 + 30 * pulse} height={10} rx={5} fill={C.teal} />
  <rect x={-50} y={-100} width={40} height={10} rx={5} fill={C.teal} opacity={0.6} />
  <circle cx={44} cy={-38} r={14} fill={alarm > 0 ? C.acc : C.green} opacity={alarm > 0 ? 0.5 + 0.5 * alarm : 1} />
  <rect x={-60} y={-60} width={70} height={36} rx={8} fill="#F6D9DA" stroke="#B3121B" strokeWidth={3} opacity={0.8} />
</g>;
export const Foam: React.FC<{x: number; y: number; w: number; suck: number}> = ({x, y, w, suck}) => <g transform={`translate(${x} ${y})`}>
  <path d={`M 0 0 Q ${w / 2} ${18 * suck} ${w} 0 L ${w} 40 L 0 40 Z`} fill="#3E4652" />
  {Array.from({length: Math.floor(w / 18)}, (_, i) => <circle key={i} cx={10 + i * 18} cy={20 + 6 * suck} r={3} fill="#626B78" />)}
  <path d={`M -16 -8 Q ${w / 2} ${12 * suck} ${w + 16} -8`} stroke="#9FC7E0" strokeWidth={5} fill="none" opacity={0.9} />
</g>;
const Cross: React.FC<{x: number; y: number; r?: number; o: number}> = ({x, y, r = 80, o}) => <g transform={`translate(${x} ${y})`} opacity={o}>
  <circle r={r} fill="none" stroke={C.blood} strokeWidth={9} /><line x1={-r * 0.7} y1={r * 0.7} x2={r * 0.7} y2={-r * 0.7} stroke={C.blood} strokeWidth={9} strokeLinecap="round" /></g>;
const Check: React.FC<{x: number; y: number; o: number}> = ({x, y, o}) => <g transform={`translate(${x} ${y}) scale(${0.6 + 0.4 * o})`} opacity={o}>
  <circle r={30} fill={C.teal} /><path d="M -13 0 L -3 11 L 15 -11" stroke="#fff" strokeWidth={6} fill="none" strokeLinecap="round" /></g>;
// бегущие капли по трубке (путь задан строкой d)
const Flow: React.FC<{d: string; len: number; o?: number; col?: string}> = ({d, len, o = 1, col = BLOOD}) => {
  const f = useCurrentFrame();
  return <path d={d} stroke={col} strokeWidth={7} fill="none" strokeLinecap="round" strokeDasharray="10 34" strokeDashoffset={-f * 3} opacity={0.8 * o} pathLength={len} />;
};

// DR01: нога (вид сбоку) с повязкой; из-под повязки трубка к гармошке
export const LegDrain: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame(); const t = ease(f, fr(d, 0.15), fr(d, 0.45));
  const tube = 'M 470 205 C 520 300 560 360 640 380 C 720 400 760 420 780 440';
  return <svg width={1080} height={560} style={{position: 'absolute', left: 0, top}}>
    <Panel x={40} w={1000} h={550} />
    <rect x={90} y={150} width={820} height={34} rx={14} fill="#DDE6EF" />
    <path d="M 110 120 L 540 110 C 600 110 640 120 700 130 L 860 140 C 900 142 910 175 870 180 L 700 182 C 640 186 600 190 540 190 L 110 190 Z" fill={SKIN} stroke={SKINS} strokeWidth={4} />
    <rect x={380} y={104} width={170} height={92} rx={18} fill="#fff" stroke="#AEB6C2" strokeWidth={4} />
    <g opacity={t}>
      <path d={tube} stroke={TUBES} strokeWidth={14} fill="none" strokeLinecap="round" strokeDasharray="900" strokeDashoffset={900 * (1 - t)} />
      <path d={tube} stroke={TUBE} strokeWidth={8} fill="none" strokeLinecap="round" strokeDasharray="900" strokeDashoffset={900 * (1 - t)} />
      <Flow d={tube} len={900} o={ease(f, fr(d, 0.45), fr(d, 0.55))} />
    </g>
    <g opacity={ease(f, fr(d, 0.35), fr(d, 0.45))}><Accordion x={790} y={520} fill={0.3 + 0.05 * Math.sin(f / 20)} /></g>
  </svg>;
};

// DR02: разрез — под кожей скопление жидкости уходит по трубке наружу
export const FluidOut: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame(); const k = ease(f, fr(d, 0.15), fr(d, 0.8));
  return <svg width={1080} height={520} style={{position: 'absolute', left: 0, top}}>
    <Panel x={40} w={1000} h={510} />
    <rect x={80} y={80} width={920} height={50} fill="#F0D2BA" />
    <rect x={80} y={130} width={920} height={130} fill="#F7E7B4" />
    <rect x={80} y={260} width={920} height={200} fill="#E7A9A0" />
    {[0, 1, 2, 3, 4, 5].map((i) => <line key={i} x1={100 + i * 160} y1={290} x2={190 + i * 160} y2={420} stroke="#D4867B" strokeWidth={6} opacity={0.6} />)}
    <ellipse cx={420} cy={230} rx={190 * (1 - 0.75 * k) + 10} ry={60 * (1 - 0.7 * k) + 8} fill={BLOOD} opacity={0.55} />
    <path d="M 420 235 L 620 235 C 700 235 720 120 760 40" stroke={TUBES} strokeWidth={16} fill="none" strokeLinecap="round" />
    <path d="M 420 235 L 620 235 C 700 235 720 120 760 40" stroke={TUBE} strokeWidth={9} fill="none" strokeLinecap="round" />
    {[300, 360, 400].map((x) => <circle key={x} cx={x + 12} cy={235} r={5} fill="#fff" stroke={TUBES} strokeWidth={2} />)}
    <Flow d="M 420 235 L 620 235 C 700 235 720 120 760 40" len={600} o={1 - k * 0.6} />
    <path d="M 760 40 L 800 20" stroke={C.mute} strokeWidth={6} strokeLinecap="round" />
    <path d="M 790 8 L 812 16 L 800 36" stroke={C.mute} strokeWidth={6} fill="none" strokeLinecap="round" />
  </svg>;
};

// DR03: виды: гармошка, баллон, мешок | разделитель | вакуумная повязка с аппаратом
export const DrainTypes: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const o = (p: number) => ease(f, fr(d, p), fr(d, p + 0.06));
  const v = ease(f, fr(d, 0.5), fr(d, 0.58));
  return <svg width={1080} height={420} style={{position: 'absolute', left: 0, top}}>
    <Panel x={40} w={560} h={410} />
    <g opacity={o(0.05)}><Accordion x={140} y={330} s={0.9} fill={0.35} squeeze={0.4 + 0.2 * Math.sin(f / 15)} /></g>
    <g opacity={o(0.12)}><Bulb x={320} y={330} /></g>
    <g opacity={o(0.19)}><Bag x={490} y={330} /></g>
    <line x1={620} y1={30} x2={620} y2={380} stroke={C.line} strokeWidth={6} strokeDasharray="14 12" opacity={v} />
    <g opacity={0.25 + 0.75 * v}>
      <Panel x={640} w={400} h={410} />
      <path d="M 690 300 C 700 250 760 230 820 236" stroke="#6B7686" strokeWidth={8} fill="none" />
      <Foam x={680} y={300} w={160} suck={v * (0.6 + 0.4 * Math.sin(f / 12))} />
      <NpwtUnit x={940} y={340} s={0.9} pulse={(Math.sin(f / 10) + 1) / 2} />
    </g>
  </svg>;
};

// DR04: ёмкость: уровень и цвет меняются со временем; планшет с записями
export const DrainLevels: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame(); const k = ease(f, fr(d, 0.15), fr(d, 0.75));
  return <svg width={1080} height={440} style={{position: 'absolute', left: 0, top}}>
    <Panel x={40} w={1000} h={430} />
    {[0, 1, 2].map((i) => { const ki = Math.min(1, Math.max(0, k * 3 - i)); return <g key={i} opacity={0.3 + 0.7 * ki}>
      <Accordion x={170 + i * 200} y={380} fill={0.6 - i * 0.22} tint={i * 0.45} squeeze={0.3} />
      {i < 2 && <path d={`M ${240 + i * 200} 300 L ${300 + i * 200} 300`} stroke={C.mute} strokeWidth={6} strokeLinecap="round" />}
    </g>; })}
    <g transform="translate(800 60)" opacity={ease(f, fr(d, 0.6), fr(d, 0.7))}>
      <rect x={0} y={0} width={190} height={250} rx={16} fill="#F4F6F9" stroke="#AEB6C2" strokeWidth={4} />
      <rect x={60} y={-14} width={70} height={28} rx={8} fill="#8E99A8" />
      {[0, 1, 2, 3].map((i) => <g key={i}><line x1={30} y1={60 + i * 46} x2={160 - (i % 2) * 30} y2={60 + i * 46} stroke="#8E99A8" strokeWidth={6} strokeLinecap="round" opacity={ease(f, fr(d, 0.65 + i * 0.05), fr(d, 0.7 + i * 0.05))} /></g>)}
    </g>
  </svg>;
};

// DR05: человек стоит; рана на бедре (оранжевая метка), ёмкость закреплена ниже раны; трубка без перегибов
export const MoveWithDrain: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame(); const sway = Math.sin(f / 12) * 3;
  const ok = ease(f, fr(d, 0.4), fr(d, 0.48));
  return <svg width={1080} height={560} style={{position: 'absolute', left: 0, top}}>
    <Panel x={40} w={1000} h={550} />
    <g transform={`translate(${sway} 0)`}>
      <circle cx={460} cy={80} r={44} fill={SKIN} stroke={SKINS} strokeWidth={4} />
      <path d="M 390 130 L 530 130 L 545 330 L 375 330 Z" fill="#9CC3E6" stroke="#5E8FB8" strokeWidth={4} />
      <path d="M 395 330 L 445 330 L 440 520 L 400 520 Z M 475 330 L 525 330 L 520 520 L 480 520 Z" fill="#9CC3E6" stroke="#5E8FB8" strokeWidth={4} />
      <rect x={510} y={270} width={50} height={40} rx={10} fill="#fff" stroke="#AEB6C2" strokeWidth={3} />
      <path d="M 545 300 C 600 330 600 380 600 410" stroke={TUBES} strokeWidth={10} fill="none" strokeLinecap="round" />
      <path d="M 545 300 C 600 330 600 380 600 410" stroke={TUBE} strokeWidth={5} fill="none" strokeLinecap="round" />
      <Accordion x={600} y={540} s={0.75} fill={0.3} />
      <rect x={585} y={405} width={30} height={12} rx={4} fill="#5E8FB8" />
    </g>
    <line x1={360} y1={290} x2={760} y2={290} stroke={C.mute} strokeWidth={4} strokeDasharray="12 10" opacity={ok} />
    <g opacity={ok}><path d="M 700 300 L 700 400" stroke={C.teal} strokeWidth={7} /><path d="M 684 384 L 700 404 L 716 384" stroke={C.teal} strokeWidth={7} fill="none" strokeLinecap="round" /></g>
    <Check x={820} y={440} o={ease(f, fr(d, 0.55), fr(d, 0.62))} />
    {/* медсестра рядом */}
    <g opacity={ease(f, fr(d, 0.15), fr(d, 0.25))} transform="translate(200 0)">
      <circle cx={0} cy={110} r={38} fill="#E2BFA2" stroke={SKINS} strokeWidth={4} />
      <path d="M -60 160 L 60 160 L 70 520 L -70 520 Z" fill="#E4F2F0" stroke={C.teal} strokeWidth={4} />
      <rect x={-14} y={190} width={28} height={10} rx={3} fill={C.teal} /><rect x={-5} y={181} width={10} height={28} rx={3} fill={C.teal} />
    </g>
  </svg>;
};

// DR06: нельзя: открыть ёмкость, отсоединить трубку, сжать гармошку
export const DrainDont: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const o = [0.05, 0.2, 0.35].map((p) => ease(f, fr(d, p), fr(d, p + 0.07)));
  const lift = 20 * Math.max(0, Math.sin(f / 8));
  return <svg width={1080} height={400} style={{position: 'absolute', left: 0, top}}>
    {[40, 380, 720].map((x, i) => <Panel key={i} x={x} w={320} h={390} o={0.4 + 0.6 * o[i]} />)}
    <g opacity={0.3 + 0.7 * o[0]}><Accordion x={200} y={340} fill={0.4} squeeze={0.3} />
      <rect x={176} y={210 - lift} width={48} height={20} rx={5} fill="#5E8FB8" transform={`rotate(${-20 * Math.sin(f / 8)} 200 220)`} /></g>
    <Cross x={200} y={230} o={o[0]} />
    <g opacity={0.3 + 0.7 * o[1]}>
      <path d="M 430 200 L 520 200" stroke={TUBES} strokeWidth={14} strokeLinecap="round" /><path d="M 560 200 L 650 200" stroke={TUBES} strokeWidth={14} strokeLinecap="round" />
      <rect x={512} y={186} width={26} height={28} rx={5} fill="#5E8FB8" transform={`translate(${-8 * Math.abs(Math.sin(f / 9))} 0)`} />
      <rect x={542} y={186} width={26} height={28} rx={5} fill="#5E8FB8" transform={`translate(${8 * Math.abs(Math.sin(f / 9))} 0)`} />
    </g>
    <Cross x={540} y={200} o={o[1]} />
    <g opacity={0.3 + 0.7 * o[2]}><Accordion x={880} y={330} fill={0.3} squeeze={0.3 + 0.5 * Math.abs(Math.sin(f / 10))} />
      <rect x={790} y={240} width={34} height={70} rx={14} fill={SKIN} stroke={SKINS} strokeWidth={3} /><rect x={936} y={240} width={34} height={70} rx={14} fill={SKIN} stroke={SKINS} strokeWidth={3} /></g>
    <Cross x={880} y={230} o={o[2]} />
  </svg>;
};

// DR08: удаление: трубка выходит из кожи, на место — наклейка-повязка
export const DrainRemove: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame(); const out = ease(f, fr(d, 0.45), fr(d, 0.6)); const pl = ease(f, fr(d, 0.62), fr(d, 0.7));
  return <svg width={1080} height={380} style={{position: 'absolute', left: 0, top}}>
    <Panel x={40} w={1000} h={370} />
    <rect x={80} y={180} width={920} height={60} fill="#F0D2BA" />
    <rect x={80} y={240} width={920} height={100} fill="#F7E7B4" />
    <g transform={`translate(${-420 * out} ${-120 * out})`}>
      <path d="M 380 300 L 560 300 C 620 300 640 200 700 150" stroke={TUBES} strokeWidth={16} fill="none" strokeLinecap="round" />
      <path d="M 380 300 L 560 300 C 620 300 640 200 700 150" stroke={TUBE} strokeWidth={9} fill="none" strokeLinecap="round" />
    </g>
    {/* рука медработника в перчатке держит конец трубки и извлекает её */}
    <g transform={`translate(${-420 * out} ${-120 * out})`} opacity={1 - pl}>
      <path d="M 690 130 C 700 100 760 90 800 110 L 860 120 C 880 124 880 150 860 152 L 800 156 C 760 170 715 168 700 150 Z" fill="#7FB3E8" stroke="#3F7FBF" strokeWidth={4} />
      <rect x={850} y={112} width={150} height={46} rx={20} fill="#E4F2F0" stroke={C.teal} strokeWidth={4} />
    </g>
    <g opacity={pl}><rect x={560} y={160} width={140} height={84} rx={14} fill="#FFF" stroke="#C9CED6" strokeWidth={4} /><rect x={600} y={180} width={60} height={44} rx={8} fill="#F4E7DC" /></g>
    <Check x={900} y={110} o={pl} />
  </svg>;
};

// DR10: вакуумная повязка + аппарат; сигнал тревоги → кнопка вызова / телефон дома
export const NpwtScene: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame(); const al = ease(f, fr(d, 0.55), fr(d, 0.6)) * (0.5 + 0.5 * Math.sin(f / 3));
  const ring = ease(f, fr(d, 0.55), fr(d, 0.6));
  return <svg width={1080} height={440} style={{position: 'absolute', left: 0, top}}>
    <Panel x={40} w={1000} h={430} />
    <path d="M 110 300 C 140 250 300 240 520 250 L 860 250 C 900 252 905 300 860 305 L 520 312 C 300 318 140 330 110 300 Z" fill={SKIN} stroke={SKINS} strokeWidth={4} />
    <Foam x={340} y={240} w={200} suck={0.7 + 0.3 * Math.sin(f / 12)} />
    <path d="M 440 238 C 460 160 560 120 660 140" stroke="#6B7686" strokeWidth={8} fill="none" />
    <NpwtUnit x={760} y={230} s={1} pulse={(Math.sin(f / 10) + 1) / 2} alarm={al} />
    {[0, 1, 2].map((i) => <circle key={i} cx={804} cy={192} r={20 + i * 18 + (f % 20)} fill="none" stroke={C.acc} strokeWidth={4} opacity={ring * (0.6 - i * 0.18)} />)}
  </svg>;
};
