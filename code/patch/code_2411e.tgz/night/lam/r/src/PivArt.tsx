// «Гнойная инфекция» — рисунки сцен (светлые, объёмные градиенты). Описания картинок vis_PI* ОДОБРЕНО ChatGPT 16.11 (tts-data piv.json).
import React from 'react';
import {useCurrentFrame, random} from 'remotion';
import {C, BODY, ease} from './kit';
import {Foam, NpwtUnit, Panel} from './DrainArt';

const fr = (d: number, p: number) => Math.round(d * p);
const Frame: React.FC<{top: number; h: number; o: number; children: React.ReactNode}> = ({top, h, o, children}) => (
  <div style={{position: 'absolute', left: 64, top, width: 952, height: h, borderRadius: 34, overflow: 'hidden', background: 'linear-gradient(180deg,#FFFFFF 0%,#EEF2F5 100%)',
    boxShadow: '0 18px 50px rgba(20,40,60,.14)', opacity: o, transform: `translateY(${(1 - o) * 30}px)`}}>{children}</div>
);
const Defs: React.FC = () => <defs>
  <linearGradient id="pvEpi" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#F6D2B8" /><stop offset="1" stopColor="#E9B394" /></linearGradient>
  <linearGradient id="pvDer" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#F4B9B0" /><stop offset="1" stopColor="#EBA197" /></linearGradient>
  <radialGradient id="pvFat" cx="0.4" cy="0.35" r="0.7"><stop offset="0" stopColor="#FFF3C4" /><stop offset="1" stopColor="#F2D27A" /></radialGradient>
  <linearGradient id="pvMus" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#C9524A" /><stop offset="1" stopColor="#9E3530" /></linearGradient>
  <radialGradient id="pvGlow" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stopColor="#FF3B2F" stopOpacity="0.5" /><stop offset="1" stopColor="#FF3B2F" stopOpacity="0" /></radialGradient>
  <radialGradient id="pvAbs" cx="0.45" cy="0.4" r="0.6"><stop offset="0" stopColor="#FFF6D8" /><stop offset="0.7" stopColor="#F1D987" /><stop offset="1" stopColor="#D9A43C" /></radialGradient>
  <linearGradient id="pvBone" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#E8DFCB" /><stop offset="0.5" stopColor="#FBF7EE" /><stop offset="1" stopColor="#DCCFB2" /></linearGradient>
  <linearGradient id="pvTi" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#9AA7B6" /><stop offset="0.5" stopColor="#E4EAF0" /><stop offset="1" stopColor="#8796A7" /></linearGradient>
  <filter id="pvSh"><feDropShadow dx="0" dy="6" stdDeviation="6" floodOpacity="0.18" /></filter>
</defs>;

// Кусок тканей в разрезе (кожа → дерма → клетчатка → мышца) шириной w.
const Tissue: React.FC<{w: number; h: number; yE: number; yD: number; yF: number; seed: string}> = ({w, h, yE, yD, yF, seed}) => {
  const lob = Array.from({length: Math.ceil(w / 70) * 2}, (_, i) => ({x: 10 + (i % Math.ceil(w / 70)) * 70 + (Math.floor(i / Math.ceil(w / 70)) % 2) * 35, y: yD + 50 + Math.floor(i / Math.ceil(w / 70)) * 100, r: 40 + random(seed + i) * 9}));
  return <g>
    <rect x={0} y={yF} width={w} height={h - yF} fill="url(#pvMus)" />
    {Array.from({length: 6}, (_, i) => <line key={i} x1={0} x2={w} y1={yF + 18 + i * 20} y2={yF + 22 + i * 20} stroke="#E07A70" strokeWidth={3} opacity={0.45} />)}
    <rect x={0} y={yD} width={w} height={yF - yD} fill="#F7E3A6" />
    {lob.map((l, i) => <circle key={i} cx={l.x} cy={l.y} r={l.r} fill="url(#pvFat)" stroke="#E8C56A" strokeWidth={2} />)}
    <rect x={0} y={yE} width={w} height={yD - yE} fill="url(#pvDer)" />
    <rect x={0} y={yE - 34} width={w} height={34} fill="url(#pvEpi)" />
  </g>;
};

// PI01: слева абсцесс (ограниченный карман с гноем), справа флегмона (разлитое воспаление без полости).
export const AbsPhleg: React.FC<{top: number; d: number; lbl: [string, string]}> = ({top, d, lbl}) => {
  const f = useCurrentFrame();
  const o = ease(f, 2, 14), a = ease(f, fr(d, 0.08), fr(d, 0.3)), b = ease(f, fr(d, 0.4), fr(d, 0.62));
  const H = 600, PW = 440, yE = 120, yD = 230, yF = 450;
  const pulse = 1 + 0.03 * Math.sin(f / 8);
  return <Frame top={top} h={H} o={o}>
    <svg width={952} height={H} style={{direction: 'ltr'}}>
      <Defs />
      <g transform="translate(24 40)">
        <clipPath id="pvC1"><rect width={PW} height={H - 80} rx={24} /></clipPath>
        <g clipPath="url(#pvC1)"><Tissue w={PW} h={H - 80} yE={yE} yD={yD} yF={yF} seed="a" />
          <ellipse cx={PW / 2} cy={yD + 105} rx={170} ry={120} fill="url(#pvGlow)" opacity={a * 0.8} />
          <g opacity={a} transform={`translate(${PW / 2} ${yD + 105}) scale(${a * pulse})`}>
            <ellipse rx={118} ry={78} fill="#E7A9A0" opacity={0.9} />
            <ellipse rx={104} ry={66} fill="url(#pvAbs)" stroke="#C88A2C" strokeWidth={5} />
            <ellipse cx={-34} cy={-24} rx={30} ry={12} fill="#fff" opacity={0.5} />
          </g>
        </g>
        <rect width={PW} height={H - 80} rx={24} fill="none" stroke={C.line} strokeWidth={3} />
      </g>
      <g transform={`translate(${24 + PW + 24} 40)`} opacity={0.3 + 0.7 * b}>
        <clipPath id="pvC2"><rect width={PW} height={H - 80} rx={24} /></clipPath>
        <g clipPath="url(#pvC2)"><Tissue w={PW} h={H - 80} yE={yE} yD={yD} yF={yF} seed="b" />
          <rect x={0} y={yE - 34} width={PW} height={yF - yE + 34} fill="#FF3B2F" opacity={0.16 * b + 0.05 * b * Math.sin(f / 9)} />
          <ellipse cx={PW / 2} cy={(yE + yF) / 2} rx={PW * 0.75 * b + 1} ry={170} fill="url(#pvGlow)" opacity={b} />
        </g>
        <rect width={PW} height={H - 80} rx={24} fill="none" stroke={C.line} strokeWidth={3} />
      </g>
      {[lbl[0], lbl[1]].map((t, i) => <text key={i} x={24 + PW / 2 + i * (PW + 24)} y={H - 6} textAnchor="middle" fontFamily={BODY} fontWeight={800} fontSize={34}
        fill={i ? C.acc : '#B07A1E'} opacity={i ? b : a}>{t}</text>)}
    </svg>
  </Frame>;
};

// PI04: абсцесс → хирургическое вскрытие и удаление гноя (без инструментов в ране) → полость свободна → «этап 2» (повторная обработка).
export const Drainage: React.FC<{top: number; d: number; stage2: string}> = ({top, d, stage2}) => {
  const f = useCurrentFrame();
  const o = ease(f, 2, 14);
  const H = 620, W = 952, yE = 130, yD = 250, yF = 500;
  const open = ease(f, fr(d, 0.15), fr(d, 0.25));
  const out = ease(f, fr(d, 0.25), fr(d, 0.6));
  const s2 = ease(f, fr(d, 0.62), fr(d, 0.72));
  const cx = W / 2, cy = yD + 120;
  const drops = Array.from({length: 10}, (_, i) => ({ph: i / 10, dx: (random('dx' + i) - 0.5) * 60}));
  return <Frame top={top} h={H} o={o}>
    <svg width={W} height={H} style={{direction: 'ltr'}}>
      <Defs />
      <Tissue w={W} h={H} yE={yE} yD={yD} yF={yF} seed="dr" />
      <ellipse cx={cx} cy={cy} rx={260} ry={150} fill="url(#pvGlow)" opacity={0.8 - 0.5 * out} />
      {/* стенка полости остаётся, содержимое уходит */}
      <ellipse cx={cx} cy={cy} rx={150} ry={95} fill="#E7A9A0" opacity={0.85} />
      <ellipse cx={cx} cy={cy} rx={136} ry={82} fill="#F7D7CF" stroke="#D99485" strokeWidth={4} />
      <ellipse cx={cx} cy={cy + 82 * out * 0.9} rx={136 * (1 - out * 0.3)} ry={82 * (1 - out)} fill="url(#pvAbs)" stroke="#C88A2C" strokeWidth={5 * (1 - out)} />
      {/* разрез кожи и канал */}
      <g opacity={open}>
        <path d={`M${cx - 70 * open} ${yE - 34} Q ${cx} ${yE - 10} ${cx + 70 * open} ${yE - 34}`} stroke="#8E3B32" strokeWidth={6} fill="#C46A5E" />
        <rect x={cx - 16} y={yE - 30} width={32} height={cy - 70 - yE + 30} fill="#F7D7CF" opacity={0.9} />
      </g>
      {out > 0 && out < 1 && drops.map((p, i) => {
        const t = ((f / 24) + p.ph) % 1;
        const y = cy - 60 - t * (cy - 60 - yE + 90);
        return <circle key={i} cx={cx + p.dx * (1 - t)} cy={y} r={10 * (1 - t * 0.5)} fill="#F1D987" stroke="#C88A2C" strokeWidth={2} opacity={(1 - t) * (1 - out * 0.5)} />;
      })}
      <g opacity={ease(f, fr(d, 0.58), fr(d, 0.64))}><circle cx={cx + 190} cy={cy - 20} r={40} fill="#fff" /><path d={`M${cx + 170} ${cy - 20} l14 14 l26 -30`} stroke={C.green} strokeWidth={9} fill="none" strokeLinecap="round" strokeLinejoin="round" /></g>
      <g opacity={s2} transform={`translate(${W - 400} 30)`}>
        <rect width={370} height={70} rx={35} fill={C.tealL} stroke={C.teal} strokeWidth={4} />
        <text x={185} y={46} textAnchor="middle" fontFamily={BODY} fontWeight={800} fontSize={28} fill={C.teal}>{stage2}</text>
      </g>
    </svg>
  </Frame>;
};

// PI05: образец → стерильный контейнер → посев в чашке; лечение (таблетки, капельница) начато, не дожидаясь результата.
export const Culture: React.FC<{top: number; d: number; lbl: [string, string, string]}> = ({top, d, lbl}) => {
  const f = useCurrentFrame();
  const o = ease(f, 2, 14);
  const a = (p: number) => ease(f, fr(d, p), fr(d, p + 0.08));
  const H = 600, W = 952;
  const grow = ease(f, fr(d, 0.35), fr(d, 0.95));
  const col = Array.from({length: 16}, (_, i) => ({x: (random('cx' + i) - 0.5) * 150, y: (random('cy' + i) - 0.5) * 70, r: 5 + random('cr' + i) * 9}));
  return <Frame top={top} h={H} o={o}>
    <svg width={W} height={H} style={{direction: 'ltr'}}>
      <Defs />
      {/* контейнер */}
      <g opacity={a(0.05)} transform="translate(150 230)" filter="url(#pvSh)">
        <rect x={-62} y={-20} width={124} height={170} rx={18} fill="#EAF4FA" stroke="#8FB3C8" strokeWidth={4} />
        <rect x={-72} y={-62} width={144} height={46} rx={12} fill={C.teal} />
        <rect x={-50} y={40} width={100} height={60} rx={8} fill="#fff" stroke={C.line} strokeWidth={3} />
        <path d="M-34 58 h68 M-34 76 h44" stroke={C.mute} strokeWidth={5} strokeLinecap="round" />
        <ellipse cx={0} cy={128} rx={46} ry={14} fill="#F1D987" opacity={0.9} />
      </g>
      <path d="M 240 240 C 300 200 340 200 380 230" stroke={C.mute} strokeWidth={6} fill="none" strokeDasharray="12 10" opacity={a(0.2)} />
      {/* чашка с посевом */}
      <g opacity={a(0.25)} transform="translate(500 250)" filter="url(#pvSh)">
        <ellipse rx={120} ry={52} cy={20} fill="#D7E3EA" />
        <ellipse rx={118} ry={50} fill="#F4E3C8" stroke="#9FB4C2" strokeWidth={4} />
        {col.map((c, i) => <circle key={i} cx={c.x * 0.7} cy={c.y * 0.6} r={c.r * grow} fill="#E7C27A" stroke="#C99A44" strokeWidth={1.5} opacity={grow} />)}
        <ellipse rx={118} ry={50} fill="none" stroke="#fff" strokeWidth={3} opacity={0.6} />
      </g>
      <g transform="translate(500 360)" opacity={a(0.3)}>
        {[0, 1, 2].map((i) => <circle key={i} cx={-30 + i * 30} cy={0} r={9} fill={C.mute} opacity={0.3 + 0.7 * (((f / 10) | 0) % 3 === i ? 1 : 0)} />)}
      </g>
      {/* лечение начато сразу */}
      <g opacity={a(0.55)} transform="translate(800 120)">
        <path d="M-50 0 h100 v150 q0 30 -50 50 q-50 -20 -50 -50 Z" fill="#E6F5F3" stroke={C.teal} strokeWidth={4} />
        <rect x={-36} y={60} width={72} height={80} rx={10} fill={C.tealL} />
        <line x1={0} y1={200} x2={0} y2={300} stroke="#8FB3C8" strokeWidth={6} />
        <circle cx={0} cy={220 + ((f * 3) % 70)} r={7} fill={C.teal} />
      </g>
      <g opacity={a(0.62)} transform="translate(800 400)">
        <rect x={-70} y={-24} width={60} height={34} rx={17} fill="#fff" stroke={C.acc} strokeWidth={4} /><rect x={-40} y={-24} width={30} height={34} rx={0} fill={C.accL} />
        <circle cx={40} cy={-8} r={22} fill="#fff" stroke={C.acc} strokeWidth={4} /><line x1={24} y1={-8} x2={56} y2={-8} stroke={C.acc} strokeWidth={3} />
      </g>
      {lbl.map((t, i) => <text key={i} x={[150, 500, 800][i]} y={H - 40} textAnchor="middle" fontFamily={BODY} fontWeight={800} fontSize={30} fill={i === 2 ? C.teal : C.ink} opacity={a([0.08, 0.28, 0.6][i])}>{t}</text>)}
    </svg>
  </Frame>;
};

// PI06: пластина с винтами в кости и эндопротез — воспаление в окружающих тканях (не в металле).
export const ImplantInf: React.FC<{top: number; d: number; lbl: [string, string]}> = ({top, d, lbl}) => {
  const f = useCurrentFrame();
  const o = ease(f, 2, 14);
  const g1 = ease(f, fr(d, 0.12), fr(d, 0.3)), p2 = ease(f, fr(d, 0.3), fr(d, 0.4));
  const H = 520, W = 952;
  const glow = (cx: number, cy: number, rx: number, ry: number, k: number) => <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill="url(#pvGlow)" opacity={k * (0.75 + 0.25 * Math.sin(f / 9))} />;
  return <Frame top={top} h={H} o={o}>
    <svg width={W} height={H} style={{direction: 'ltr'}}>
      <Defs />
      {/* кость с пластиной */}
      <g transform="translate(240 40)">
        <ellipse cx={0} cy={210} rx={180} ry={190} fill="#F3D9C8" opacity={0.55} />
        {glow(10, 210, 170, 170, g1)}
        <path d="M-40 0 Q -60 -10 -50 30 L -38 400 Q -60 430 -30 440 L 30 440 Q 60 430 38 400 L 50 30 Q 60 -10 40 0 Z" fill="url(#pvBone)" stroke="#BFAE8A" strokeWidth={4} filter="url(#pvSh)" />
        <path d="M-44 214 L 44 200" stroke="#BFAE8A" strokeWidth={3} strokeDasharray="8 6" />
        <rect x={34} y={90} width={34} height={250} rx={14} fill="url(#pvTi)" stroke="#6B7686" strokeWidth={3} filter="url(#pvSh)" />
        {[120, 170, 250, 300].map((y) => <g key={y}><circle cx={51} cy={y} r={11} fill="#C9D2DC" stroke="#6B7686" strokeWidth={3} /><line x1={30} y1={y} x2={-36} y2={y} stroke="#8796A7" strokeWidth={8} opacity={0.7} /></g>)}
      </g>
      {/* эндопротез тазобедренного сустава */}
      <g transform="translate(680 40)" opacity={0.3 + 0.7 * p2}>
        <ellipse cx={0} cy={210} rx={180} ry={190} fill="#F3D9C8" opacity={0.55} />
        {glow(0, 220, 170, 180, p2)}
        <path d="M-60 120 Q -50 60 -10 40 L 60 40 Q 70 120 50 200 L 40 440 L -40 440 L -50 200 Z" fill="url(#pvBone)" stroke="#BFAE8A" strokeWidth={4} filter="url(#pvSh)" />
        <path d="M 10 70 L -60 0" stroke="url(#pvTi)" strokeWidth={30} strokeLinecap="round" />
        <circle cx={-72} cy={-8} r={44} fill="url(#pvTi)" stroke="#6B7686" strokeWidth={3} />
        <path d="M-6 60 L 24 60 L 14 380 Q 4 400 -6 380 Z" fill="url(#pvTi)" stroke="#6B7686" strokeWidth={3} />
      </g>
      {lbl.map((t, i) => <text key={i} x={[240, 680][i]} y={H - 14} textAnchor="middle" fontFamily={BODY} fontWeight={800} fontSize={30} fill={C.ink} opacity={i ? p2 : g1}>{t}</text>)}
    </svg>
  </Frame>;
};

// PI07: рана закрыта повязкой; вакуумная повязка с трубкой и аппаратом (спокойно, без тревоги) + знак «не отключать».
export const VacCalm: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const no = ease(f, fr(d, 0.72), fr(d, 0.8));
  return <svg width={1080} height={440} style={{position: 'absolute', left: 0, top}}>
    <Panel x={40} w={1000} h={430} />
    <path d="M 110 300 C 140 250 300 240 520 250 L 860 250 C 900 252 905 300 860 305 L 520 312 C 300 318 140 330 110 300 Z" fill="#E9C9AE" stroke="#C99B7A" strokeWidth={4} />
    <Foam x={340} y={240} w={200} suck={0.7 + 0.3 * Math.sin(f / 12)} />
    <path d="M 440 238 C 460 160 560 120 660 140" stroke="#6B7686" strokeWidth={8} fill="none" />
    {[0, 1, 2, 3].map((i) => { const t = ((f / 40) + i / 4) % 1; return <circle key={i} cx={440 + 220 * t} cy={238 - 100 * Math.sin(t * Math.PI * 0.8)} r={6} fill="#E7A9A0" opacity={0.8} />; })}
    <NpwtUnit x={760} y={230} s={1} pulse={(Math.sin(f / 10) + 1) / 2} alarm={0} />
    <g opacity={no} transform="translate(930 90)">
      <circle r={56} fill="#fff" stroke={C.blood} strokeWidth={9} />
      <path d="M-22 -14 v28 M22 -14 v28 M-30 -14 h60" stroke={C.ink} strokeWidth={8} strokeLinecap="round" />
      <line x1={-38} y1={38} x2={38} y2={-38} stroke={C.blood} strokeWidth={9} strokeLinecap="round" />
    </g>
  </svg>;
};
