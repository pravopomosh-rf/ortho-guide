// «Гнойная инфекция» — ролик для пациентов (9:16), сверху ops/purulent-infection.html. Тексты PI01–PI11, cap_* и vis_* ОДОБРЕНО ChatGPT 16.11 (tts-data piv.json).
import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Subtitle, Note, C, BODY, HEAD, ease, Word} from './kit';
import {Icon} from './Figures';
import {NpwtScene} from './DrainArt';
import {CallBell} from './WardArt';
import {Phone101} from './UrgentArt';
import {LegRed} from './CellvArt';
import {AbsPhleg, Drainage, Culture, ImplantInf, VacCalm} from './PivArt';
import tRu from './timing_piv.json';
import tHe from './timing_piv_he.json';
import tAr from './timing_piv_ar.json';
import tEn from './timing_piv_en.json';

type TT = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const FPS = 30, PAD = 0.5;
const fr = (d: number, p: number) => Math.round(d * p);
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};

type Dict = {brand: string; rtl?: boolean; n: Record<string, string[]>; end: [string, string]};
const N: Record<string, Dict> = {
  ru: {
    brand: 'ОРТОПЕДИЯ · ПАЦИЕНТАМ',
    n: {
      L01: ['абсцесс', 'флегмона'],
      PI01: ['абсцесс: ограниченное скопление гноя — «карман»', 'флегмона: распространённое воспаление, отдельной полости может не быть', 'не каждой флегмоне нужна операция'],
      PI02: ['ранка', 'укус', 'прокол кожи, в том числе укол', 'диабетическая стопа', 'операционный разрез', 'пластина или винт', 'эндопротез'],
      PI03: ['усиливающаяся боль', 'покраснение · отёк', 'кожа горячая на ощупь', 'иногда: размягчение · гной · температура · слабость', 'нет температуры или гноя — инфекция всё равно возможна'],
      PI04: ['вскрытие и удаление гноя', 'омертвевшие ткани — удаляют при необходимости', 'несколько операций — не обязательно неудача', 'глубокая или быстрая инфекция → срочно', 'повторная обработка'],
      PI05: ['гной или ткань', 'посев', 'лечение', 'по виду и тяжести инфекции', 'небольшой поверхностный абсцесс после дренирования — не всегда', 'тяжёлая инфекция: не ждать результатов посева'],
      PI06: ['пластина и винты', 'эндопротез', 'сохранить после хирургической обработки', 'заменить или удалить', 'зависит от инфекции, тканей и устойчивости конструкции', 'хирург и специалисты обсуждают варианты с вами'],
      PI07: ['рану могут оставить открытой или частично открытой', 'может быть дренаж', 'вакуумная повязка не заменяет операцию и антибиотики', 'не отключайте аппарат и не трогайте трубку'],
      PI08: ['не работает · сигнал · нет герметичности · свежая кровь → сразу персоналу', 'сильное кровотечение → помощь немедленно', 'в отделении перевязки делает персонал', 'больно → попросите обезболивание заранее'],
      PI09: ['контроль сахара при диабете', 'калории и белок', 'отказ от курения', 'мойте руки · не трогайте рану и повязку', 'движения и нагрузку — с врачом и физиотерапевтом'],
      PI10: ['температура · озноб · слабость · спутанность · частое дыхание', 'резкая боль, несоразмерная виду раны · быстро растёт покраснение или отёк', 'повязка промокла · запах · кожа темнеет · пузыри · онемение', 'отёк лица, губ, языка · трудно дышать · потеря сознания → экстренно', 'сыпь или зуд после антибиотика → сразу персоналу'],
      PI11: [],
    },
    end: ['Указания врача важнее', 'Лечащий врач · персонал отделения'],
  },
  en: {
    brand: 'ORTHOPAEDICS · FOR PATIENTS',
    n: {
      L01: ['abscess', 'phlegmon'],
      PI01: ['abscess: a contained pocket of pus', 'phlegmon: spreading inflammation, may have no separate pocket', 'not every phlegmon needs surgery'],
      PI02: ['wound', 'bite', 'skin puncture, including an injection', 'diabetic foot', 'surgical site', 'plate or screw', 'joint replacement'],
      PI03: ['increasing pain', 'redness · swelling', 'skin feels hot', 'sometimes: soft area · pus · fever · weakness', 'no fever or pus — infection still possible'],
      PI04: ['surgical opening and drainage of pus', 'dead or infected tissue removed if needed', 'several operations ≠ treatment failing', 'deep or rapid infection → urgent surgery', 'repeat cleaning'],
      PI05: ['pus or tissue', 'culture', 'treatment', 'by type and severity of infection', 'small superficial abscess after drainage: not always needed', 'severe infection: do not wait for cultures'],
      PI06: ['plate and screws', 'joint replacement', 'retained after surgical debridement', 'replaced or removed', 'depends on infection, tissues and implant stability', 'the surgeon and specialists discuss options with you'],
      PI07: ['wound may be left open or partly open', 'a drain may be used', 'a vacuum dressing does not replace surgery or antibiotics', 'do not disconnect the machine or handle the tubing'],
      PI08: ['stopped · alarm · seal lost · fresh blood → tell staff now', 'heavy bleeding → immediate help', 'on the ward, staff change the dressings', 'painful → ask for pain relief beforehand'],
      PI09: ['good glucose control in diabetes', 'enough calories and protein', 'stop smoking', 'wash hands · do not touch the wound or dressing', 'movement and weight-bearing: as your doctor and physio advise'],
      PI10: ['fever · chills · severe weakness · confusion · rapid breathing', 'pain out of proportion to the wound · rapidly spreading redness or swelling', 'soaked dressing · bad smell · darkening skin · blisters · numbness', 'swelling of face, lips, tongue · difficulty breathing · loss of consciousness → emergency', 'rash or itching after antibiotics → tell staff now'],
      PI11: [],
    },
    end: ["Your care team's instructions take priority", 'Treating doctor · ward staff'],
  },
  he: {
    brand: 'אורתופדיה · למטופלים', rtl: true,
    n: {
      L01: ['מורסה', 'פלגמונה'],
      PI01: ['מורסה: הצטברות מוגבלת של מוגלה, כמו כיס', 'פלגמונה: דלקת מפושטת, לא תמיד יש חלל נפרד', 'לא כל פלגמונה מצריכה ניתוח'],
      PI02: ['פצע', 'נשיכה', 'דקירה בעור, כולל זריקה', 'כף רגל סוכרתית', 'חתך ניתוחי', 'פלטה או בורג', 'מפרק מלאכותי'],
      PI03: ['כאב שמתגבר', 'אדמומיות · נפיחות', 'עור חם למגע', 'לפעמים: אזור רך · מוגלה · חום · חולשה', 'אין חום או מוגלה? זיהום עדיין אפשרי'],
      PI04: ['פתיחה כירורגית וניקוז המוגלה', 'רקמות מתות מוסרות לפי הצורך', 'כמה ניתוחים אינם בהכרח כישלון', 'זיהום עמוק או מהיר ← ניתוח דחוף', 'ניקוי חוזר'],
      PI05: ['מוגלה או רקמה', 'תרבית', 'טיפול', 'לפי סוג הזיהום וחומרתו', 'מורסה קטנה ושטחית אחרי ניקוז: לא תמיד', 'זיהום קשה: לא מחכים לתרבית'],
      PI06: ['פלטה וברגים', 'מפרק מלאכותי', 'להשאיר אחרי ניקוי כירורגי', 'להחליף או להוציא', 'תלוי בזיהום, ברקמות וביציבות השתל', 'המנתח והמומחים דנים איתכם באפשרויות'],
      PI07: ['לפעמים משאירים את הפצע פתוח', 'ייתכן נקז', 'חבישת ואקום אינה מחליפה ניתוח או אנטיביוטיקה', 'אל תנתקו את המכשיר ואל תגעו בצינורית'],
      PI08: ['הפסיק לעבוד · התראה · אין אטימות · דם טרי ← מיד לצוות', 'דימום חזק ← עזרה מיידית', 'במחלקה הצוות מחליף את החבישות', 'כואב? בקשו משכך כאבים מראש'],
      PI09: ['איזון סוכר בסוכרת', 'מספיק קלוריות וחלבון', 'הפסקת עישון', 'רחצו ידיים · אל תגעו בפצע ובחבישה', 'תנועה ועומס: לפי הרופא והפיזיותרפיסט'],
      PI10: ['חום גבוה · צמרמורות · חולשה קשה · בלבול · נשימה מהירה', 'כאב שאינו תואם את מראה הפצע · אדמומיות או נפיחות שמתפשטות מהר', 'חבישה ספוגה · ריח רע · עור מתכהה · שלפוחיות · חוסר תחושה', 'נפיחות בפנים, בשפתיים, בלשון · קושי בנשימה · אובדן הכרה ← עזרה דחופה', 'פריחה או גרד אחרי אנטיביוטיקה ← מיד לצוות'],
      PI11: [],
    },
    end: ['הנחיות הרופא המטפל קודמות', 'הרופא המטפל · הצוות במחלקה'],
  },
  ar: {
    brand: 'جراحة العظام · للمرضى', rtl: true,
    n: {
      L01: ['الخراج', 'الفلغمون'],
      PI01: ['الخراج: تجمع محدود للقيح يشبه الجيب', 'الفلغمون: التهاب منتشر، قد لا يوجد فيه تجويف منفصل', 'ليس كل فلغمون يحتاج إلى عملية'],
      PI02: ['جرح', 'عضة', 'وخز في الجلد، بما في ذلك الحقن', 'القدم السكرية', 'الجرح الجراحي', 'صفيحة أو برغي', 'مفصل اصطناعي'],
      PI03: ['ألم يزداد', 'احمرار · تورم', 'سخونة الجلد عند لمسه', 'أحيانًا: ليونة · قيح · حرارة · ضعف', 'لا حرارة ولا قيح؟ العدوى ما زالت ممكنة'],
      PI04: ['فتح جراحي وتصريف القيح', 'إزالة الأنسجة الميتة عند الحاجة', 'عدة عمليات لا تعني بالضرورة فشل العلاج', 'عدوى عميقة أو سريعة ← جراحة عاجلة', 'تنظيف متكرر'],
      PI05: ['قيح أو نسيج', 'زراعة', 'علاج', 'بحسب نوع العدوى وشدتها', 'خراج صغير وسطحي بعد التصريف: ليس دائمًا', 'عدوى شديدة: لا ننتظر نتائج الزراعة'],
      PI06: ['صفيحة وبراغٍ', 'مفصل اصطناعي', 'الحفاظ عليها بعد التنظيف الجراحي', 'الاستبدال أو الإزالة', 'حسب العدوى والأنسجة وثبات الزرعة', 'يناقش الجراح والمختصون الخيارات معكم'],
      PI07: ['قد يُترك الجرح مفتوحًا أو مفتوحًا جزئيًا', 'قد يوضع أنبوب تصريف', 'ضمادة الشفط لا تحل محل الجراحة أو المضادات', 'لا تفصلوا الجهاز ولا تلمسوا الأنبوب'],
      PI08: ['توقف · إنذار · فقدان الإحكام · دم جديد ← أبلغوا الطاقم فورًا', 'نزيف شديد ← مساعدة فورية', 'في القسم يغيّر الطاقم الضمادات', 'مؤلم؟ اطلبوا تسكين الألم مسبقًا'],
      PI09: ['ضبط السكر عند الإصابة بالسكري', 'سعرات حرارية وبروتين كافيان', 'الإقلاع عن التدخين', 'اغسلوا أيديكم · لا تلمسوا الجرح والضماد', 'الحركة والتحميل: حسب الطبيب وأخصائي العلاج الطبيعي'],
      PI10: ['حرارة مرتفعة · قشعريرة · ضعف شديد · تشوش · تنفس سريع', 'ألم لا يتناسب مع مظهر الجرح · احمرار أو تورم ينتشر بسرعة', 'ضماد مشبع · رائحة كريهة · اسوداد الجلد · فقاعات · فقدان الإحساس', 'تورم الوجه أو الشفتين أو اللسان · صعوبة التنفس · فقدان الوعي ← مساعدة طارئة', 'طفح أو حكة بعد المضاد الحيوي ← أبلغوا الطاقم فورًا'],
      PI11: [],
    },
    end: ['تعليمات الطبيب المعالج لها الأولوية', 'الطبيب المعالج · طاقم القسم'],
  },
};
const NV = '#E3E7EF';
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]; size?: number}> = ({y, items, size = 30}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10), transform: `translateY(${(1 - ease(f, a, a + 10)) * 14}px)`}}><Note size={size} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const CheckRow: React.FC<{y: number; at: number; icon: string; text: string; warn?: boolean}> = ({y, at, icon, text, warn}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at} style={warn ? {borderInlineStart: `10px solid ${C.blood}`} : undefined}>
    <div style={{display: 'flex', alignItems: 'center', gap: 24}}>
      <Icon k={icon} s={58} c={warn ? C.blood : C.acc} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 31, color: C.ink, lineHeight: 1.25}}>{text}</div>
      {!warn && <div style={{opacity: ease(f, at + 14, at + 22)}}><Icon k="check" s={52} /></div>}
    </div>
  </Card>;
};
const SRC_IC = ['wound', 'wound', 'drop', 'leg', 'wound', 'tube', 'leg'];
const SrcGrid: React.FC<{d: number; items: string[]}> = ({d, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: 450, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18}}>
    {items.map((t, i) => {
      const a = fr(d, 0.04 + i * 0.08), p = ease(f, a, a + 10);
      const impl = i >= 5;
      return <div key={i} style={{gridColumn: i === 2 ? '1 / 3' : undefined, opacity: p, transform: `translateY(${(1 - p) * 20}px) scale(${0.96 + p * 0.04})`, background: impl ? C.accL : '#fff', borderRadius: 26,
        boxShadow: '0 12px 30px rgba(20,40,60,.10)', padding: '22px 22px', display: 'flex', alignItems: 'center', gap: 16, minHeight: 112}}>
        <div style={{width: 64, height: 64, borderRadius: 18, background: impl ? '#fff' : C.tealL, display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none'}}><Icon k={SRC_IC[i]} s={48} c={impl ? C.acc : C.teal} /></div>
        <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 31, color: C.ink, lineHeight: 1.2}}>{t}</div>
      </div>;
    })}
  </div>;
};
const WarnList: React.FC<{d: number; items: string[]}> = ({d, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: 440, borderRadius: 30, border: `6px solid ${C.blood}`, background: '#fff', padding: '24px 28px 8px', opacity: ease(f, 2, 12)}}>
    {items.map((t, i) => {
      const a = fr(d, 0.03 + i * 0.12), p = ease(f, a, a + 10);
      return <div key={i} style={{display: 'flex', gap: 16, alignItems: 'flex-start', marginBottom: 16, opacity: p, transform: `translateX(${(1 - p) * 20}px)`}}>
        <div style={{flex: 'none', width: 22, height: 22, borderRadius: 11, background: i === 3 ? C.blood : C.acc, marginTop: 10}} />
        <div style={{fontFamily: BODY, fontWeight: i === 3 ? 800 : 700, fontSize: 30, color: i === 3 ? C.blood : C.ink, lineHeight: 1.25}}>{t}</div>
      </div>;
    })}
  </div>;
};
const TwoWays: React.FC<{y: number; at: number; a: string; b: string}> = ({y, at, a, b}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 20}}>
    {[a, b].map((t, i) => { const p = ease(f, at + i * 12, at + i * 12 + 12); return <div key={i} style={{flex: 1, opacity: p, transform: `translateY(${(1 - p) * 16}px)`, background: i ? NV : C.tealL, borderRadius: 24, padding: '22px 22px',
      fontFamily: BODY, fontWeight: 800, fontSize: 30, color: i ? C.navy : C.teal, lineHeight: 1.25, textAlign: 'center'}}>{t}</div>; })}
  </div>;
};

const scene = (id: string, d: number, L: Dict) => {
  const n = L.n[id];
  const t = (p: number) => fr(d, p);
  switch (id) {
    case 'PI01': return <>
      <AbsPhleg top={440} d={d} lbl={[L.n.L01[0], L.n.L01[1]]} />
      <Notes y={1070} items={[[n[0], t(0.15), '#9A6A12', '#FBF0D2'], [n[1], t(0.45)], [n[2], t(0.75), C.navy, NV]]} />
    </>;
    case 'PI02': return <SrcGrid d={d} items={n} />;
    case 'PI03': return <>
      <LegRed top={440} d={d} mode="red" />
      <Notes y={1030} items={[[n[0], t(0.04)], [n[1], t(0.14), C.navy, NV], [n[2], t(0.24), C.navy, NV], [n[3], t(0.4), C.teal, C.tealL], [n[4], t(0.75), C.blood, C.bloodL]]} />
    </>;
    case 'PI04': return <>
      <Drainage top={440} d={d} stage2={n[4]} />
      <Notes y={1090} items={[[n[0], t(0.12)], [n[1], t(0.32), C.navy, NV], [n[2], t(0.55), C.teal, C.tealL], [n[3], t(0.78), C.blood, C.bloodL]]} />
    </>;
    case 'PI05': return <>
      <Culture top={440} d={d} lbl={[n[0], n[1], n[2]]} />
      <Notes y={1070} items={[[n[3], t(0.04), C.navy, NV], [n[4], t(0.22)], [n[5], t(0.78), C.blood, C.bloodL]]} />
    </>;
    case 'PI06': return <>
      <ImplantInf top={440} d={d} lbl={[n[0], n[1]]} />
      <TwoWays y={990} at={t(0.4)} a={n[2]} b={n[3]} />
      <Notes y={1180} items={[[n[4], t(0.62), C.navy, NV], [n[5], t(0.8), C.teal, C.tealL]]} />
    </>;
    case 'PI07': return <>
      <VacCalm top={440} d={d} />
      <Notes y={920} items={[[n[0], t(0.06), C.navy, NV], [n[1], t(0.3), C.navy, NV], [n[2], t(0.5), C.teal, C.tealL], [n[3], t(0.78), C.blood, C.bloodL]]} />
    </>;
    case 'PI08': return <>
      <NpwtScene top={440} d={Math.round(d * 0.4)} />
      <CallBell x={60} y={560} s={0.5} at={t(0.12)} press={t(0.2)} cord={false} />
      <Notes y={920} items={[[n[0], t(0.05), C.blood, C.bloodL], [n[1], t(0.3), C.blood, C.bloodL], [n[2], t(0.55), C.navy, NV], [n[3], t(0.8), C.teal, C.tealL]]} />
    </>;
    case 'PI09': return <>
      {n.map((x, i) => <CheckRow key={i} y={450 + i * 186} at={t(0.04 + i * 0.15)} icon={['drop', 'pills', 'lungs', 'wound', 'leg'][i]} text={x} />)}
    </>;
    case 'PI10': return <>
      <WarnList d={Math.round(d * 0.75)} items={n.slice(0, 4)} />
      <Card x={64} y={1110} w={952} at={t(0.66)}><div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, color: C.navy, lineHeight: 1.3}}>{n[4]}</div></Card>
      <Phone101 y={1260} at={t(0.86)} s={0.6} />
    </>;
    case 'PI11': return <>
      <Card x={64} y={640} w={952} at={t(0.1)} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center', padding: '60px 40px'}}>
        <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 50, color: C.ink, marginBottom: 20, lineHeight: 1.2}}>{L.end[0]}</div>
        <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 34, color: C.mute}}>{L.end[1]}</div>
      </Card>
    </>;
  }
  return null;
};

export const mkPiv = (lang: string, timing: unknown) => {
  const TT = timing as TT;
  const L = N[lang];
  const total = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
  const Comp: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
    let at = 0;
    return <AbsoluteFill style={{direction: L.rtl ? 'rtl' : 'ltr'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={L.brand} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            {scene(x.id, d, L)}
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>;
  };
  return {Comp, total};
};
const ru = mkPiv('ru', tRu); export const Piv = ru.Comp; export const totalPiv = ru.total;
const he = mkPiv('he', tHe); export const PivHe = he.Comp; export const totalPivHe = he.total;
const ar = mkPiv('ar', tAr); export const PivAr = ar.Comp; export const totalPivAr = ar.total;
const en = mkPiv('en', tEn); export const PivEn = en.Comp; export const totalPivEn = en.total;

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
