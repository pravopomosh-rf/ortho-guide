import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition} from '@remotion/renderer';
import fs from 'fs';
const [comp, frames, out] = process.argv.slice(2);
const b = await bundle({entryPoint: '/home/claude/night/lam/r/src/index.ts'});
const c = await selectComposition({serveUrl: b, id: comp, browserExecutable: '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome'});
fs.mkdirSync(out, {recursive: true});
for (const f of frames.split(',').map(Number)) {
  await renderStill({serveUrl: b, composition: c, frame: f, output: `${out}/f${String(f).padStart(5,'0')}.png`, scale: 0.5, browserExecutable: '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome'});
}
console.log('ok');
