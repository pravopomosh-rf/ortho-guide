// «Первые дни после замены сустава» (колено/бедро) — ролик для пациентов (9:16). Тексты PJ01–PJ11 ОДОБРЕНО ChatGPT (tts-data pjv.json).
// Один файл на все языки: подписи в словаре N[lang], тайминги — timing_pjv[_lang].json.
import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Subtitle, Note, C, BODY, HEAD, ease, Word} from './kit';
import {Icon} from './Figures';
import {BedReal} from './WardArt';
import {FaceScale} from './PainArt';
import {Clip3D} from './Clip3D';
import {NerveBlock, TrayWait, IceKnee, KneeXray} from './PjvArt';
import tRu from './timing_pjv.json';

type TT = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const FPS = 30, PAD = 0.5;
const fr = (d: number, p: number) => Math.round(d * p);
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};

type Dict = {brand: string; rtl?: boolean; h: string; min: string; n: Record<string, string[]>; end: [string, string]};
const N: Record<string, Dict> = {
  ru: {
    brand: 'ОРТОПЕДИЯ · ПАЦИЕНТАМ', h: '1–2 ч', min: 'мин',
    n: {
      PJ01: ['боль · отёк · синяки', 'слабость · онемение кожи у шва', 'температура или нарастающая боль → медсестре', 'внезапная одышка или боль в груди → срочно зовите персонал'],
      PJ02: ['регулярно или по необходимости', 'не ждите сильной боли — особенно перед физиотерапией', 'схему самостоятельно не меняйте'],
      PJ03: ['местный анестетик рядом с нервом', 'часто под контролем ультразвука', 'нужна не каждому пациенту'],
      PJ04: ['онемение или слабость — иногда до 48 часов', 'не вставайте без персонала', 'усиливается или длится дольше ожидаемого → сразу сообщите'],
      PJ05: ['тошнота → скажите медсестре', 'первые 1–2 часа после возвращения обычно не едят', 'пить и есть — после разрешения медсестры'],
      PJ06: ['раздражение от трубки или маски', 'боль в горле · осиплость · ком — обычно проходят', 'трудно дышать или глотать → немедленно персоналу'],
      PJ07: ['только по инструкции персонала', 'обязательно через ткань · с перерывами', 'повязку не мочить'],
      PJ08: ['колено: прямое, опора под голенью и пяткой', 'не держать долго подушку под согнутым коленом', 'бедро: положение и ограничения — как показали'],
      PJ09: ['положение компонентов искусственного сустава', 'обычно — на следующий день', 'снимок оценивает травматолог-ортопед'],
      PJ10: ['3–4 физиотерапевта в отделении', 'на следующий день: сесть → встать → первые шаги', 'первый раз — только с персоналом', 'нагрузку определяет травматолог-ортопед'],
      PJ11: ['упражнения — в разрешённых пределах', 'сильная боль → остановитесь', 'вопросы — медсестре, физиотерапевту, врачу'],
    },
    end: ['Указания вашей команды важнее сайта', 'Медсестра · физиотерапевт · врач'],
  },
};

const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10), transform: `translateY(${(1 - ease(f, a, a + 10)) * 14}px)`}}><Note size={30} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const NV = ['#E3E7EF'] as const;
const CheckRow: React.FC<{y: number; at: number; icon: string; text: string}> = ({y, at, icon, text}) => {
  const f = useCurrentFrame();
  return <Card x={64} y={y} w={952} at={at}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={70} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
      <div style={{opacity: ease(f, at + 14, at + 22)}}><Icon k="check" s={60} /></div>
    </div>
  </Card>;
};
const Tiles: React.FC<{d: number; rtl?: boolean}> = ({d, rtl}) => {
  const f = useCurrentFrame();
  const col = (i: number) => `hsl(${120 - i * 12}, 62%, ${i < 5 ? 42 : 48}%)`;
  return <div style={{position: 'absolute', left: 64, top: 560, display: 'flex', gap: 8, flexDirection: rtl ? 'row-reverse' : 'row'}}>
    {Array.from({length: 11}, (_, i) => <div key={i} style={{width: 80, height: 110, borderRadius: 16, background: col(i), opacity: ease(f, fr(d, 0.02 + i * 0.02), fr(d, 0.06 + i * 0.02)), display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: HEAD, fontWeight: 800, fontSize: 38, color: '#fff'}}>{i}</div>)}
  </div>;
};

const scene = (id: string, d: number, L: Dict) => {
  const n = L.n[id];
  const t = (p: number) => fr(d, p);
  switch (id) {
    case 'PJ01': return <>
      <BedReal top={440} d={d} bell={false} patient />
      <Notes y={930} items={[[n[0], t(0.08), C.navy, NV[0]], [n[1], t(0.28), C.navy, NV[0]], [n[2], t(0.5)], [n[3], t(0.72), C.blood, C.bloodL]]} />
    </>;
    case 'PJ02': return <>
      <Tiles d={d} rtl={L.rtl} />
      <FaceScale d={d} ptrY={500} faceY={760} rtl={L.rtl} />
      <Notes y={1110} items={[[n[0], t(0.15), C.navy, NV[0]], [n[1], t(0.38)], [n[2], t(0.75), C.navy, NV[0]]]} />
    </>;
    case 'PJ03': return <>
      <NerveBlock top={440} d={d} />
      <Notes y={1230} items={[[n[0], t(0.3), C.navy, NV[0]], [n[1], t(0.5), C.teal, C.tealL], [n[2], t(0.75)]]} />
    </>;
    case 'PJ04': return <>
      <Clip3D src="c3/falls_sitfeet.mp4" y={440} h={660} d={d} dur={7} />
      <Notes y={1140} items={[[n[0], t(0.1), C.navy, NV[0]], [n[1], t(0.45)], [n[2], t(0.65), C.blood, C.bloodL]]} />
    </>;
    case 'PJ05': return <>
      <TrayWait top={450} d={d} txt={L.h} />
      <Notes y={1010} items={[[n[0], t(0.08), C.navy, NV[0]], [n[1], t(0.35), C.teal, C.tealL], [n[2], t(0.7)]]} />
    </>;
    case 'PJ06': return <>
      <Clip3D src="c3/anest_air.mp4" y={440} d={d} dur={12} from={28} label={(s) => s < 29 ? null : n[0]} />
      <Notes y={1220} items={[[n[1], t(0.45), C.navy, NV[0]], [n[2], t(0.75), C.blood, C.bloodL]]} />
    </>;
    case 'PJ07': return <>
      <IceKnee top={450} d={d} unit={L.min} />
      <Notes y={1090} items={[[n[0], t(0.3), C.navy, NV[0]], [n[1], t(0.5), C.teal, C.tealL], [n[2], t(0.75)]]} />
    </>;
    case 'PJ08': return <>
      <Clip3D src="c3/swell_elevate.mp4" y={440} h={640} d={d} dur={8} />
      <Notes y={1120} items={[[n[0], t(0.25), C.teal, C.tealL], [n[1], t(0.45)], [n[2], t(0.7), C.navy, NV[0]]]} />
    </>;
    case 'PJ09': return <>
      <KneeXray top={440} d={d} />
      <Notes y={1230} items={[[n[0], t(0.2), C.navy, NV[0]], [n[1], t(0.5), C.teal, C.tealL], [n[2], t(0.7)]]} />
    </>;
    case 'PJ10': return <>
      <Clip3D src="c3/walker_walk.mp4" y={440} h={640} d={d} dur={13.8} />
      <Notes y={1120} items={[[n[0], t(0.05), C.navy, NV[0]], [n[1], t(0.25), C.teal, C.tealL], [n[2], t(0.55)], [n[3], t(0.75), C.navy, NV[0]]]} />
    </>;
    case 'PJ11': return <>
      <CheckRow y={470} at={t(0.08)} icon="leg" text={n[0]} />
      <CheckRow y={660} at={t(0.3)} icon="head" text={n[1]} />
      <CheckRow y={850} at={t(0.5)} icon="check" text={n[2]} />
      <Card x={64} y={1080} w={952} at={t(0.72)} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
        <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 42, color: C.ink, marginBottom: 14}}>{L.end[0]}</div>
        <div style={{fontFamily: BODY, fontWeight: 600, fontSize: 32, color: C.mute}}>{L.end[1]}</div>
      </Card>
    </>;
  }
  return null;
};

export const mkPjv = (lang: string, timing: unknown) => {
  const TT = timing as TT;
  const L = N[lang];
  const total = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
  const Comp: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
    let at = 0;
    return <AbsoluteFill style={{direction: L.rtl ? 'rtl' : 'ltr'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={L.brand} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            {scene(x.id, d, L)}
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>;
  };
  return {Comp, total};
};
const ru = mkPjv('ru', tRu);
export const Pjv = ru.Comp;
export const totalPjv = ru.total;

const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
