import {T} from '../i18n';
import React, {useMemo} from 'react';
import {AbsoluteFill, interpolate} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import * as THREE from 'three';
import {Env} from '../../film/three3d';
import {Label3D} from './S5Premed3D';
import {C, Chip, Layer, pr, useT, VisualProps, win, easeIO} from './kit';
import {VERT} from './kit';
import {Card, Icon, Pop} from './kit2d';

const F = 'Rubik, sans-serif';
const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const rnd = (i: number) => {
  const x = Math.sin(i * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};
const Cam: React.FC<{p: [number, number, number]; l: [number, number, number]}> = ({p, l}) => {
  const {camera} = useThree();
  camera.position.set(...p);
  camera.lookAt(...l);
  return null;
};
const Lights: React.FC = () => (
  <>
    <Env intensity={0.55} />
    <ambientLight intensity={0.5} />
    <directionalLight position={[4, 6, 6]} intensity={1.5} />
    <directionalLight position={[-5, 2, -4]} intensity={0.5} color="#CFE3FF" />
  </>
);

/* ===================== S8: поясничный отдел, сагиттальная схема =====================
 * спереди (тела позвонков) — слева (−x), сзади (остистые отростки, кожа) — справа (+x).
 * Спинной мозг заканчивается на уровне L1–L2 (мозговой конус), ниже — конский хвост в дуральном мешке.
 * Игла: между остистыми отростками L3–L4 → жёлтая связка → эпидуральное пространство → твёрдая и паутинная оболочки → субарахноидальное (ликвор). Не касается корешков.
 * Гематома — снаружи твёрдой оболочки (эпидурально), сдавливает дуральный мешок.
 */
const LV = ['T12', 'L1', 'L2', 'L3', 'L4', 'L5'];
const yOf = (i: number) => 4.5 - i * 1.32; // центр тела позвонка
const DURA_X = 1.0, DURA_R = 0.3;
const Spine: React.FC<{t: number; needle: number; hem: number; lo: number}> = ({t, needle, hem, lo}) => {
  const roots = useMemo(() => Array.from({length: 9}, (_, i) => ({dx: (i - 4) * 0.055 + (rnd(i) - 0.5) * 0.02, dz: (rnd(i + 5) - 0.5) * 0.3})), []);
  const coneY = (yOf(1) + yOf(2)) / 2; // L1–L2
  const sacBot = -3.6;
  const ny = (yOf(3) + yOf(4)) / 2 + 0.05; // промежуток L3–L4
  const tipX = interpolate(needle, [0, 1], [3.6, DURA_X + 0.08]);
  const squeeze = hem * 0.12;
  return (
    <group>
      {/* тела позвонков и диски */}
      {LV.map((n, i) => (
        <group key={n}>
          <mesh position={[0, yOf(i), 0]}>
            <boxGeometry args={[1.15, 1.0, 1.1]} />
            <meshStandardMaterial color="#EDE6D8" roughness={0.75} />
          </mesh>
          {i < LV.length - 1 ? (
            <mesh position={[0, yOf(i) - 0.66, 0]}>
              <boxGeometry args={[1.1, 0.3, 1.05]} />
              <meshStandardMaterial color="#9CC3E6" roughness={0.6} />
            </mesh>
          ) : null}
          {/* дужка и остистый отросток */}
          <mesh position={[1.75, yOf(i) - 0.1, 0]} rotation={[0, 0, -0.32]}>
            <boxGeometry args={[0.95, 0.38, 0.4]} />
            <meshStandardMaterial color="#E6DECC" roughness={0.75} />
          </mesh>
          <mesh position={[1.42, yOf(i) + 0.05, 0]}>
            <boxGeometry args={[0.18, 0.62, 0.9]} />
            <meshStandardMaterial color="#E6DECC" roughness={0.75} />
          </mesh>
          {/* жёлтая связка между дужками */}
          {i < LV.length - 1 ? (
            <mesh position={[1.43, yOf(i) - 0.66, 0]}>
              <boxGeometry args={[0.1, 0.66, 0.8]} />
              <meshStandardMaterial color="#E9C64A" roughness={0.6} />
            </mesh>
          ) : null}
        </group>
      ))}
      {/* крестец */}
      <mesh position={[0.25, -4.05, 0]} rotation={[0, 0, 0.45]}>
        <boxGeometry args={[1.2, 1.4, 1.0]} />
        <meshStandardMaterial color="#E6DECC" roughness={0.75} />
      </mesh>
      {/* дуральный мешок с ликвором */}
      <mesh position={[DURA_X - squeeze / 2, (6.2 + sacBot) / 2, 0]} scale={[1 - squeeze, 1, 1]}>
        <cylinderGeometry args={[DURA_R, DURA_R, 6.2 - sacBot, 32, 1, true]} />
        <meshPhysicalMaterial color="#9FD0F0" roughness={0.3} transparent opacity={0.35} side={THREE.DoubleSide} depthWrite={false} />
      </mesh>
      <mesh position={[DURA_X, sacBot, 0]}>
        <sphereGeometry args={[DURA_R, 24, 12, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2]} />
        <meshPhysicalMaterial color="#9FD0F0" transparent opacity={0.35} depthWrite={false} />
      </mesh>
      {/* спинной мозг → мозговой конус на уровне L1–L2 */}
      <mesh position={[DURA_X, (6.2 + coneY + 0.5) / 2, 0]}>
        <cylinderGeometry args={[0.16, 0.16, 6.2 - coneY - 0.5, 24]} />
        <meshStandardMaterial color="#F2E3C6" roughness={0.5} />
      </mesh>
      <mesh position={[DURA_X, coneY + 0.25, 0]} rotation={[Math.PI, 0, 0]}>
        <coneGeometry args={[0.16, 0.5, 24]} />
        <meshStandardMaterial color="#F2E3C6" roughness={0.5} />
      </mesh>
      {/* конский хвост */}
      {roots.map((r, i) => {
        const len = coneY - (sacBot + 0.2);
        return (
          <mesh key={i} position={[DURA_X + r.dx * (i % 2 ? 1 : 1.4), coneY - len / 2, r.dz * 0.5]}>
            <cylinderGeometry args={[0.018, 0.018, len, 6]} />
            <meshStandardMaterial color="#EBD7B2" roughness={0.5} />
          </mesh>
        );
      })}
      {/* кожа */}
      <mesh position={[3.25, 0.3, 0]}>
        <boxGeometry args={[0.18, 10.5, 1.4]} />
        <meshStandardMaterial color="#F3C9AE" roughness={0.7} transparent opacity={0.55} />
      </mesh>
      {/* игла */}
      {needle > 0 ? (
        <group position={[(tipX + 5.2) / 2, ny, 0]} rotation={[0, 0, Math.PI / 2 + 0.05]}>
          <mesh>
            <cylinderGeometry args={[0.025, 0.025, 5.2 - tipX, 10]} />
            <meshStandardMaterial color="#C9D2DE" metalness={0.85} roughness={0.2} />
          </mesh>
          <mesh position={[0, -(5.2 - tipX) / 2 - 0.15, 0]}>
            <cylinderGeometry args={[0.09, 0.07, 0.3, 16]} />
            <meshStandardMaterial color="#F2B33D" roughness={0.4} />
          </mesh>
        </group>
      ) : null}
      {/* эпидуральная гематома (снаружи твёрдой оболочки) */}
      {hem > 0 ? (
        <mesh position={[DURA_X + DURA_R + 0.02, ny + 0.1, 0]} scale={[0.1 * hem + 0.01, 0.75 * hem + 0.01, 0.36 * hem + 0.01]}>
          <sphereGeometry args={[1, 28, 18]} />
          <meshStandardMaterial color="#B3202E" roughness={0.35} emissive="#B3202E" emissiveIntensity={0.25} />
        </mesh>
      ) : null}
      {/* подписи */}
      {LV.map((n, i) => <Label3D key={n} p={[-0.95, yOf(i), 0.7]} text={n} o={lo} />)}
      <Label3D p={[-1.1, coneY - 0.05, 1.2]} text={T("конец спинного мозга")} o={lo} color="#B5524A" />
      <Label3D p={[-0.9, -2.9, 1.2]} text={T("конский хвост")} o={lo} />
      <Label3D p={[4.3, ny + 0.75, 0.6]} text={T("игла")} o={lo * pr(needle, 0.1, 0.4)} />
    </group>
  );
};

const Fibrin: React.FC<{t: number; weak: number}> = ({t, weak}) => {
  const n = 22;
  return (
    <svg width={520} height={340} viewBox="0 0 520 340">
      <rect x={4} y={4} width={512} height={332} rx={24} fill="#fff" stroke="#E3E7EE" strokeWidth={3} />
      {Array.from({length: n}, (_, i) => {
        const keep = rnd(i * 3) > weak * 0.75;
        const x1 = 40 + rnd(i) * 440, y1 = 40 + rnd(i + 7) * 260, x2 = 40 + rnd(i + 3) * 440, y2 = 40 + rnd(i + 11) * 260;
        return keep ? <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#D9C27A" strokeWidth={4} opacity={0.9} /> : null;
      })}
      {Array.from({length: 14}, (_, i) => (
        <ellipse key={i} cx={60 + rnd(i * 5) * 400} cy={60 + rnd(i * 9) * 220 + Math.sin(t + i) * 3} rx={26} ry={18} fill="#D8404A" stroke="#A82634" strokeWidth={3} />
      ))}
    </svg>
  );
};

export const S8Anticoag: React.FC<VisualProps> = ({at, dur}) => {
  const t = useT();
  const tStop = at('Перед некоторыми операциями');
  const tSp = at('Это особенно важно');
  const tHem = at('кровоизлияние рядом');
  const tNone = at('Единого безопасного');
  const tPlan = at('План зависит');
  const tWho = at('Когда прекратить');
  const tWrit = at('Получите этот план');
  const tNoPlan = at('Если плана нет');
  const tEnox = at('Немногим пациентам');
  const tBridge = at('Это называется');
  const tDoac = at('При перерыве');
  const tStent = at('Если вам ставили');
  const tAnti = at('Такие препараты');
  const tCard = at('Не прекращайте их');
  const tSelf = at('Никогда не меняйте');
  const tIMA = tNone, tFin = tSelf, tEl = tPlan, tPr = tWho, tKu = tWrit, tNew = tNoPlan, tShort = tBridge, tDose = tDoac; // широкая версия ещё старая (TODO)
  const needle = pr(t, tSp + 2.2, tSp + 5.5, easeIO);
  const hem = pr(t, tHem + 0.6, tHem + 3.0, easeIO);
  if (VERT) {
    const VC = (p: {at: number; y: number; icon: string; title: string; sub?: string; tone?: string}) => <Card t={t} at={p.at} x={70} y={p.y} w={940 / 1.25} size={1.25} icon={p.icon} title={p.title} sub={p.sub} tone={p.tone} />;
    return (
      <AbsoluteFill>
        <Layer show={win(t, 0, tSp)}>
          {[T('Эликвис'), T('Ксарелто'), T('Прадакса'), T('Кумадин')].map((n, i) => (
            <Card key={n} t={t} at={0.2 + i * 0.5} x={70 + (i % 2) * 480} y={470 + Math.floor(i / 2) * 130} w={460 / 0.85} icon="pill" title={n} tone={C.red} size={0.85} />
          ))}
          <div style={{position: 'absolute', left: 70, top: 750, scale: '0.86', transformOrigin: 'top left'}}>
            <div style={{fontFamily: F, fontSize: 34, fontWeight: 700, color: C.ink, marginBottom: 10, opacity: pr(t, 1, 1.5)}}>{T('Обычно: прочная сеть фибрина')}</div>
            <div style={{opacity: pr(t, 1, 1.5)}}><Fibrin t={t} weak={0} /></div>
          </div>
          <div style={{position: 'absolute', left: 560, top: 750, scale: '0.86', transformOrigin: 'top left'}}>
            <div style={{fontFamily: F, fontSize: 34, fontWeight: 700, color: C.red, marginBottom: 10, opacity: pr(t, 2.4, 2.9), width: 520}}>{T('На фоне препарата: сеть слабее')}</div>
            <div style={{opacity: pr(t, 2.4, 2.9)}}><Fibrin t={t} weak={pr(t, 2.6, 4.5)} /></div>
          </div>
          <Chip t={t} at={tStop + 0.2} x={70} y={1250} text={T("Перед некоторыми операциями — могут временно прекратить")} color={C.ink} size={40} />
        </Layer>
        <Layer show={win(t, tSp, tNone)}>
          <div style={{position: 'absolute', left: 0, top: 760}}>
            <ThreeCanvas width={1080} height={800} camera={{position: [0, 0, 16], fov: 36}} gl={{preserveDrawingBuffer: true, antialias: true}}>
              <Cam p={[2.2 - pr(t, tSp, tHem) * 0.8, 0.4, 19 - pr(t, tHem, tHem + 2) * 6]} l={[0.9, 0.4 - pr(t, tHem, tHem + 2) * 1.0, 0]} />
              <Lights />
              <group rotation={[0, -0.28, 0]}>
                <Spine t={t} needle={needle} hem={hem} lo={pr(t, tSp + 0.5, tSp + 1.2)} />
              </group>
            </ThreeCanvas>
          </div>
          <Chip t={t} at={tSp + 0.2} x={70} y={470} text={T("Спинальная или эпидуральная анестезия")} color={C.blue} size={46} />
          <Layer show={pr(t, tHem, tHem + 0.4)}>
            <Chip t={t} at={tHem + 0.4} x={70} y={640} text={T("Кровоизлияние рядом с нервами")} color={C.red} size={44} />
            <div style={{position: 'absolute', left: 74, top: 745, fontFamily: F, fontSize: 36, color: C.red, opacity: pr(t, tHem + 2.4, tHem + 3.0)}}>{T('может вызвать серьёзное повреждение')}</div>
          </Layer>
        </Layer>
        <Layer show={win(t, tNone, tWrit)}>
          <VC at={tNone + 0.2} y={480} icon="calendar" title={T("Единого срока отмены для всех нет")} tone={C.red} />
          <VC at={tPlan + 0.2} y={720} icon="list" title={T("План зависит от:")} sub={T("препарат и доза · функция почек · вид операции · планируемая анестезия")} tone={C.blue} />
          <VC at={tWho + 0.2} y={1010} icon="doctor" title={T("Решают анестезиолог и врач, назначивший препарат")} tone={C.blue} />
        </Layer>
        <Layer show={win(t, tWrit, tEnox)}>
          <VC at={tWrit + 0.2} y={520} icon="pen" title={T("Письменный план: препарат, последняя доза, когда возобновить")} tone={C.green} />
          <VC at={tNoPlan + 0.2} y={820} icon="warn" title={T("Нет плана — свяжитесь с отделением до операции")} tone={C.amber} />
        </Layer>
        <Layer show={win(t, tEnox, tStent)}>
          <VC at={tEnox + 0.3} y={480} icon="syringe" title={T("Эноксапарин — у немногих, на время отмены Кумадина")} tone={C.amber} />
          <VC at={tBridge + 0.2} y={740} icon="check" title={T("Большинству переходная терапия не нужна")} tone={C.green} />
          <VC at={tDoac + 0.2} y={980} icon="pill" title={T("Эликвис, Ксарелто, Прадакса — обычно не рекомендуется")} tone={C.sub} />
        </Layer>
        <Layer show={win(t, tStent, tSelf)}>
          <VC at={tStent + 0.3} y={480} icon="stent" title={T("Стент в сосудах сердца — сообщите врачу")} tone={C.red} />
          <VC at={tAnti + 0.3} y={720} icon="pill" title={T("Аспирин, клопидогрел: отмена может быть опасна")} tone={C.amber} />
          <VC at={tCard + 0.2} y={980} icon="heart" title={T("Только по плану, согласованному с врачами")} sub={T("может участвовать кардиолог")} tone={C.blue} />
        </Layer>
        <Layer show={win(t, tSelf, dur + 1)}>
          <VC at={tSelf + 0.1} y={700} icon="stop" title={T("Самостоятельно ничего не меняйте")} tone={C.red} />
        </Layer>
        <div style={{position: 'absolute', left: 40, bottom: 30, fontFamily: F, fontSize: 26, color: C.sub, opacity: 0.6}}>{T('схема, не в масштабе')}</div>
      </AbsoluteFill>
    );
  }
  return (
    <AbsoluteFill>
      {/* A: препараты и фибрин */}
      <Layer show={win(t, 0, tSp)}>
        {[T('Эликвис'), T('Ксарелто'), T('Прадакса'), T('Кумадин')].map((n, i) => (
          <Card key={n} t={t} at={0.2 + i * 0.5} x={120} y={250 + i * 120} w={520} icon="pill" title={n} tone={C.red} size={0.78} />
        ))}
        <div style={{position: 'absolute', left: 760, top: 250}}>
          <div style={{fontFamily: F, fontSize: 28, fontWeight: 700, color: C.ink, marginBottom: 10, opacity: pr(t, 1, 1.5)}}>{T('Обычно: прочная сеть фибрина')}</div>
          <div style={{opacity: pr(t, 1, 1.5)}}><Fibrin t={t} weak={0} /></div>
        </div>
        <div style={{position: 'absolute', left: 1320, top: 250}}>
          <div style={{fontFamily: F, fontSize: 28, fontWeight: 700, color: C.red, marginBottom: 10, opacity: pr(t, 2.4, 2.9)}}>{T('На фоне препарата: сеть слабее')}</div>
          <div style={{opacity: pr(t, 2.4, 2.9)}}><Fibrin t={t} weak={pr(t, 2.6, 4.5)} /></div>
        </div>
        <Chip t={t} at={tStop + 0.2} x={760} y={680} text={T("Перед многими операциями — временно прекращают")} color={C.ink} size={34} />
      </Layer>
      {/* B: позвоночник 3D */}
      <Layer show={win(t, tSp, tIMA)}>
        <div style={{position: 'absolute', left: 760, top: 235}}>
          <ThreeCanvas width={1160} height={640} camera={{position: [0, 0, 16], fov: 36}} gl={{preserveDrawingBuffer: true, antialias: true}}>
            <Cam p={[3.0 - pr(t, tSp, tHem) * 0.8, 0.4, 17 - pr(t, tHem, tHem + 2) * 5]} l={[1.4, 0.4 - pr(t, tHem, tHem + 2) * 1.0, 0]} />
            <Lights />
            <group rotation={[0, -0.28, 0]}>
              <Spine t={t} needle={needle} hem={hem} lo={pr(t, tSp + 0.5, tSp + 1.2)} />
            </group>
          </ThreeCanvas>
        </div>
        <Chip t={t} at={tSp + 0.2} x={120} y={250} text={T("Спинальная анестезия")} color={C.blue} size={44} />
        <div style={{position: 'absolute', left: 124, top: 345, width: 600, fontFamily: F, fontSize: 28, color: C.sub, lineHeight: 1.35, opacity: pr(t, tSp + 1.4, tSp + 2)}}>
          {T('Иглу вводят ниже окончания спинного мозга — в мешок с ликвором, между корешками')}
        </div>
        <Layer show={pr(t, tHem, tHem + 0.4)}>
          <Chip t={t} at={tHem + 0.6} x={120} y={500} text={T("Гематома сдавливает нервы")} color={C.red} size={38} />
          <div style={{position: 'absolute', left: 124, top: 590, fontFamily: F, fontSize: 28, color: C.red, opacity: pr(t, tHem + 1.6, tHem + 2.2)}}>{T('редкое, но опасное осложнение')}</div>
        </Layer>
      </Layer>
      {/* C: сроки */}
      <Layer show={win(t, tIMA, tEnox)}>
        <div style={{position: 'absolute', left: 120, top: 240, fontFamily: F, fontSize: 28, color: C.sub, opacity: pr(t, tIMA, tIMA + 0.5)}}>{T('Пример: рекомендации Израильской ассоциации анестезиологов, 2019')}</div>
        <Card t={t} at={tEl + 0.1} x={120} y={300} w={1300} icon="calendar" title={T("Эликвис, Ксарелто — 3–4 дня")} sub={T("в зависимости от функции почек")} tone={C.red} size={0.9} />
        <Card t={t} at={tPr + 0.1} x={120} y={450} w={1300} icon="calendar" title={T("Прадакса — 3–5 дней")} tone={C.red} size={0.9} />
        <Card t={t} at={tKu + 0.1} x={120} y={600} w={1300} icon="calendar" title={T("Кумадин — 4–5 дней")} sub={T("+ анализ свёртываемости крови")} tone={C.red} size={0.9} />
        <Pop t={t} at={tEl + 0.8} x={1630} y={420} icon="kidney" size={170} />
        <Layer show={pr(t, tNew, tNew + 0.4)} style={{background: 'rgba(250,250,248,0.0)'}}>
          <Chip t={t} at={tNew + 0.3} x={120} y={760} text={T("Срок определяет анестезиолог: доза, почки, вид анестезии")} color={C.blue} size={32} icon="✓" />
        </Layer>
      </Layer>
      {/* D: эноксапарин */}
      <Layer show={win(t, tEnox, tStent)}>
        <Card t={t} at={tEnox + 0.4} x={120} y={260} w={1200} icon="syringe" title={T("Клексан / Крусия (эноксапарин) — иногда")} sub={T("при отмене Кумадина, если риск тромбоза особенно высок")} tone={C.amber} />
        <Card t={t} at={tShort + 0.3} x={120} y={430} w={1200} icon="clock" title={T("Действие короче и предсказуемее")} sub={T("легче спланировать время последней инъекции")} tone={C.blue} />
        <Card t={t} at={tDose + 0.2} x={120} y={600} w={1200} icon="kidney" title={T("Зависит от дозы и работы почек")} tone={C.sub} />
        <Layer show={pr(t, tDoac, tDoac + 0.4)}>
          <Chip t={t} at={tDoac + 0.3} x={120} y={780} text={T("Эликвис, Ксарелто, Прадакса — замена обычно не нужна")} color={C.green} size={32} />
        </Layer>
      </Layer>
      {/* E: стент и антиагреганты */}
      <Layer show={win(t, tStent, tFin)}>
        <Card t={t} at={tStent + 0.3} x={120} y={270} w={1200} icon="stent" title={T("Стент в сосудах сердца — сообщите врачу")} tone={C.red} />
        <Card t={t} at={tAnti + 0.3} x={120} y={440} w={1200} icon="pill" title={T("Антиагреганты: аспирин, клопидогрел")} sub={T("действуют на тромбоциты — другая группа")} tone={C.amber} />
        <Card t={t} at={tCard + 0.2} x={120} y={610} w={1200} icon="heart" title={T("Отмена — только вместе с кардиологом")} tone={C.blue} />
      </Layer>
      {/* F: итог */}
      <Layer show={win(t, tFin, dur + 1)}>
        <Card t={t} at={tFin + 0.2} x={120} y={300} w={1250} icon="doctor" title={T("Схему отмены и возобновления определяет врач")} tone={C.blue} />
        <Card t={t} at={tSelf + 0.1} x={120} y={480} w={1250} icon="stop" title={T("Самостоятельно ничего не меняйте")} tone={C.red} />
      </Layer>
      <div style={{position: 'absolute', left: 40, bottom: 24, fontFamily: F, fontSize: 20, color: C.sub, opacity: 0.6}}>{T('схема, не в масштабе')}</div>
    </AbsoluteFill>
  );
};

/* ===================== S10: сосуд и курение ===================== */
const Vessel: React.FC<{t: number; narrow: number}> = ({t, narrow}) => {
  const R = 1 - narrow * 0.45;
  const cells = useMemo(() => Array.from({length: 26}, (_, i) => ({o: rnd(i) * 12, r: rnd(i + 3) * 0.6, a: rnd(i + 9) * 6.28})), []);
  const speed = 2.4 - narrow * 1.5;
  return (
    <group rotation={[0, -0.5, 0]}>
      <mesh rotation={[0, 0, Math.PI / 2]} scale={[R, 1, R]}>
        <cylinderGeometry args={[1, 1, 12, 48, 1, true]} />
        <meshPhysicalMaterial color="#E58A87" roughness={0.45} transparent opacity={0.4} side={THREE.DoubleSide} depthWrite={false} />
      </mesh>
      {cells.map((c, i) => {
        const x = ((c.o + t * speed) % 12) - 6;
        return (
          <mesh key={i} position={[x, Math.cos(c.a) * c.r * R, Math.sin(c.a) * c.r * R]} rotation={[c.a, 0, 0.6]} scale={[0.32 * Math.max(R, 0.7), 0.32 * Math.max(R, 0.7), 0.12]}>
            <torusGeometry args={[0.6, 0.45, 12, 24]} />
            <meshStandardMaterial color="#C8303E" roughness={0.4} />
          </mesh>
        );
      })}
      {/* ткань у раны в конце сосуда */}
      <mesh position={[6.6, 0, 0]} scale={[0.6, 1.6, 1.6]}>
        <sphereGeometry args={[1, 32, 20]} />
        <meshStandardMaterial color={new THREE.Color('#F08F8A').lerp(new THREE.Color('#C9B5B2'), narrow)} roughness={0.7} />
      </mesh>
    </group>
  );
};
export const S10Smoking: React.FC<VisualProps> = ({at, dur}) => {
  const t = useT();
  const tQ = at('Лучше всего бросить');
  const tAny = at('Но отказ');
  const narrow = pr(t, 0.8, 3.2, easeIO) * (1 - pr(t, tQ + 0.8, tQ + 3.2, easeIO) * 0.85);
  if (VERT) return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 0, top: 990}}>
        <ThreeCanvas width={1080} height={600} camera={{position: [0, 2, 12], fov: 36}} gl={{preserveDrawingBuffer: true, antialias: true}}>
          <Cam p={[0, 2.6, 15]} l={[0.6, 0, 0]} />
          <Lights />
          <Vessel t={t} narrow={narrow} />
        </ThreeCanvas>
      </div>
      <Layer show={win(t, 0, tQ)}>
        <Card t={t} at={0.2} x={70} y={470} w={940 / 1.08} icon="cig" title={T("Курение")} tone={C.red} size={1.08} />
        <Chip t={t} at={1.4} x={70} y={650} text={T("Сосуды сужаются — меньше крови к тканям")} color={C.red} size={38} />
        <Chip t={t} at={2.6} x={70} y={780} text={T("Заживление медленнее")} color={C.ink} size={38} />
        <Chip t={t} at={3.6} x={70} y={890} text={T("Риск инфекции ↑")} color={C.red} size={38} />
      </Layer>
      <Layer show={win(t, tQ, dur + 1)}>
        <Card t={t} at={tQ + 0.2} x={70} y={470} w={940 / 1.08} icon="calendar" title={T("Бросить ≥ 4 недели до операции")} tone={C.green} size={1.08} />
        <Chip t={t} at={tAny + 0.2} x={70} y={690} text={T("Отказ полезен в любой момент")} color={C.green} size={44} icon="✓" />
      </Layer>
      <div style={{position: 'absolute', left: 40, bottom: 30, fontFamily: F, fontSize: 26, color: C.sub, opacity: 0.6}}>{T('схема, не в масштабе')}</div>
    </AbsoluteFill>
  );
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 880, top: 170}}>
        <ThreeCanvas width={1040} height={700} camera={{position: [0, 2, 12], fov: 36}} gl={{preserveDrawingBuffer: true, antialias: true}}>
          <Cam p={[0, 2.4, 12]} l={[0.6, 0, 0]} />
          <Lights />
          <Vessel t={t} narrow={narrow} />
        </ThreeCanvas>
      </div>
      <Layer show={win(t, 0, tQ)}>
        <Card t={t} at={0.2} x={120} y={250} w={620} icon="cig" title={T("Курение")} tone={C.red} size={0.9} />
        <Chip t={t} at={1.4} x={120} y={410} text={T("Сосуды сужаются — меньше крови к тканям")} color={C.red} size={30} />
        <Chip t={t} at={2.6} x={120} y={490} text={T("Заживление медленнее")} color={C.ink} size={30} />
        <Chip t={t} at={3.6} x={120} y={570} text={T("Риск инфекции ↑")} color={C.red} size={30} />
      </Layer>
      <Layer show={win(t, tQ, dur + 1)}>
        <Card t={t} at={tQ + 0.2} x={120} y={260} w={640} icon="calendar" title={T("Бросить ≥ 4 недели до операции")} tone={C.green} size={0.9} />
        <Chip t={t} at={tAny + 0.2} x={120} y={440} text={T("Отказ полезен в любой момент")} color={C.green} size={36} icon="✓" />
      </Layer>
      <div style={{position: 'absolute', left: 40, bottom: 24, fontFamily: F, fontSize: 20, color: C.sub, opacity: 0.6}}>{T('схема, не в масштабе')}</div>
    </AbsoluteFill>
  );
};
