import {T as tr} from '../i18n';
import React, {useMemo} from 'react';
import {AbsoluteFill, interpolate} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import * as THREE from 'three';
import {Env} from '../../film/three3d';
import {Body3D, BodyCoat, Bottle3D, Cosmetic3D, RingMark, Sponge3D, ZoneGlow, ZONES3, Zone} from './Body3D';
import {C, Chip, Layer, pr, sp, useT, VisualProps, win, easeIO} from './kit';
import {VERT} from './kit';

const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const rnd = (i: number) => {
  const x = Math.sin(i * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};
const lerp3 = (a: readonly number[], b: readonly number[], k: number): [number, number, number] => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];

type T = Record<string, number>;

const Cam: React.FC<{pos: [number, number, number]; look: [number, number, number]}> = ({pos, look}) => {
  const {camera} = useThree();
  camera.position.set(...pos);
  camera.lookAt(...look);
  return null;
};

/** струи воды: капли падают из лейки */
const Water: React.FC<{t: number; k: number; top?: number}> = ({t, k, top = 2.6}) => {
  if (k < 0.01) return null;
  return (
    <group>
      {Array.from({length: 90}, (_, i) => {
        const ph = (t * 1.6 + rnd(i)) % 1;
        const x = (rnd(i + 5) - 0.5) * 1.3;
        const z = (rnd(i + 9) - 0.5) * 0.7 + 0.15;
        return (
          <mesh key={i} position={[x, top - ph * 4.6, z]} scale={[0.012, 0.06, 0.012]}>
            <sphereGeometry args={[1, 8, 6]} />
            <meshStandardMaterial color="#9ED3F5" transparent opacity={0.75 * k} roughness={0.05} />
          </mesh>
        );
      })}
    </group>
  );
};

const ShowerHead: React.FC<{k: number}> = ({k}) =>
  k < 0.01 ? null : (
    <group position={[0, 2.75, 0.25]} scale={k}>
      <mesh rotation={[0.25, 0, 0]}>
        <cylinderGeometry args={[0.32, 0.22, 0.12, 40]} />
        <meshStandardMaterial color="#CFD6DF" metalness={0.8} roughness={0.2} />
      </mesh>
      <mesh position={[0, 0.35, -0.25]} rotation={[0.6, 0, 0]}>
        <cylinderGeometry args={[0.04, 0.04, 0.8, 16]} />
        <meshStandardMaterial color="#CFD6DF" metalness={0.8} roughness={0.2} />
      </mesh>
    </group>
  );

/** пена: белые пузырьки у обработанных зон; при смывании стекают вниз */
const Foam: React.FC<{t: number; on: number; rinse: number; zt: Record<string, number>}> = ({t, on, rinse, zt}) => {
  const pts = useMemo(() => {
    const zs: Zone[] = ['hip', 'armL', 'armR', 'navel', 'groin', 'foldL', 'foldR'];
    const zone = Array.from({length: 84}, (_, i) => {
      const z = ZONES3[zs[i % zs.length]];
      return {z: zs[i % zs.length] as string, p: [z[0] + (rnd(i) - 0.5) * 0.16, z[1] + (rnd(i + 3) - 0.5) * 0.16, z[2] + 0.02 + rnd(i + 7) * 0.04], r: 0.014 + rnd(i + 11) * 0.02, h: 0};
    });
    // пена по всему телу: туловище, руки, ноги (появляется сверху вниз вслед за губкой)
    const body = Array.from({length: 70}, (_, i) => {
      const part = i % 5;
      let p: number[];
      if (part < 2) p = [(rnd(i) - 0.5) * 0.55, 0.85 - rnd(i + 1) * 1.2, 0.2]; // туловище
      else if (part === 2) p = [(rnd(i) < 0.5 ? -1 : 1) * (0.46 + rnd(i + 2) * 0.06), 0.7 - rnd(i + 3) * 1.1, 0.07]; // руки
      else p = [(rnd(i) < 0.5 ? -1 : 1) * 0.2, -0.75 - rnd(i + 4) * 0.9, 0.13 - rnd(i + 5) * 0.03]; // ноги
      return {z: 'body', p, r: 0.012 + rnd(i + 11) * 0.016, h: (0.9 - p[1]) / 2.6};
    });
    return [...zone, ...body];
  }, []);
  if (on < 0.01) return null;
  return (
    <group>
      {pts.map((f, i) => {
        const fall = pr(rinse, (i % 7) * 0.05, 0.5 + (i % 7) * 0.05);
        const t0 = f.z === 'body' ? zt.apply + f.h * (zt.site - zt.apply) : zt[f.z] + (i % 5) * 0.06;
        const o = on * (1 - fall) * pr(t, t0, t0 + 0.5);
        if (o < 0.01) return null;
        return (
          <mesh key={i} position={[f.p[0], f.p[1] - fall * 1.6, f.p[2]]} scale={f.r * (0.6 + 0.4 * on)}>
            <sphereGeometry args={[1, 12, 10]} />
            <meshStandardMaterial color="#FFFFFF" roughness={0.2} transparent opacity={0.92 * o} />
          </mesh>
        );
      })}
    </group>
  );
};

/** кровать с лежащим пациентом и рука в перчатке, обтирающая кожу */
const BedScene: React.FC<{t: number; t0: number}> = ({t, t0}) => {
  const f = t - t0;
  return (
    <group position={[0, -0.6, 0]}>
      <mesh position={[0, -0.25, 0]}>
        <boxGeometry args={[4.2, 0.25, 1.6]} />
        <meshStandardMaterial color="#E9EEF5" roughness={0.6} />
      </mesh>
      <mesh position={[0, -0.75, 0]}>
        <boxGeometry args={[4.0, 0.12, 1.4]} />
        <meshStandardMaterial color="#9AA7B8" metalness={0.5} roughness={0.4} />
      </mesh>
      <mesh position={[-1.75, 0.0, 0]}>
        <boxGeometry args={[0.6, 0.18, 1.0]} />
        <meshStandardMaterial color="#FFFFFF" roughness={0.7} />
      </mesh>
      <group rotation={[0, 0, Math.PI / 2]} position={[0.05, 0.12, 0]} scale={1.05}>
        <group rotation={[0, Math.PI / 2, 0]}><Body3D /></group>
      </group>
      {/* рука медсестры в перчатке с салфеткой */}
      <group position={[-0.75 + Math.sin(f * 2.2) * 0.3, 0.45, 0.25]} rotation={[0, 0, -0.15]}>
        <mesh scale={[0.14, 0.06, 0.12]}>
          <sphereGeometry args={[1, 20, 14]} />
          <meshStandardMaterial color="#7FB2E5" roughness={0.5} />
        </mesh>
        {[0, 1, 2, 3].map((k) => (
          <mesh key={k} position={[-0.12 + k * 0.07, -0.01, 0.1]} rotation={[0.4, 0, 0]}>
            <capsuleGeometry args={[0.022, 0.08, 6, 12]} />
            <meshStandardMaterial color="#7FB2E5" roughness={0.5} />
          </mesh>
        ))}
        <group position={[0, -0.07, 0]}><Sponge3D /></group>
      </group>
    </group>
  );
};

const Scene: React.FC<{t: number; T: T}> = ({t, T}) => {
  // фазы
  const bottleK = win(t, 0, T.face - 0.2, 0.3, 0.5);
  const bodyK = pr(t, T.face - 0.1, T.face + 0.7);
  const bedK = pr(t, T.staff - 0.3, T.staff + 0.6);
  const water = Math.max(win(t, T.wet, T.apply + 1.2, 0.4, 0.8), win(t, T.rinse, T.towel, 0.4, 0.6));
  // губка: маршрут по зонам
  const route: {z: Zone; at: number}[] = [
    {z: 'hip', at: T.site}, {z: 'armL', at: T.pits}, {z: 'armR', at: T.pits + 0.6}, {z: 'navel', at: T.navel},
    {z: 'groin', at: T.groin}, {z: 'buttocks', at: T.butt}, {z: 'foldL', at: T.folds}, {z: 'foldR', at: T.folds + 0.6},
  ];
  let sp3: [number, number, number] = [1.6, 0.4, 0.8];
  for (let i = 0; i < route.length; i++) {
    const a = route[i];
    const b = route[i + 1];
    if (t >= a.at) {
      const za = ZONES3[a.z];
      const front = a.z === 'buttocks' ? -0.1 : 0.1;
      const base: [number, number, number] = [za[0], za[1], za[2] + front];
      if (b) {
        const zb = ZONES3[b.z];
        const kk = pr(t, b.at - 0.5, b.at, easeIO);
        sp3 = lerp3(base, [zb[0], zb[1], zb[2] + (b.z === 'buttocks' ? -0.1 : 0.1)], kk);
      } else sp3 = base;
      sp3 = [sp3[0] + Math.sin(t * 9) * 0.03, sp3[1] + Math.cos(t * 9) * 0.02, sp3[2]];
    }
  }
  // сначала губка проходит по всему телу (сверху вниз), затем — по зонам особого внимания
  if (t >= T.apply && t < T.site) {
    const k = pr(t, T.apply, T.site - 0.3, easeIO);
    sp3 = [Math.sin(k * Math.PI * 6) * 0.32, 0.9 - k * 2.3, 0.26 - Math.abs(Math.sin(k * Math.PI * 6)) * 0.08];
  }
  const spongeOn = win(t, T.apply, T.separate, 0.3, 0.3);
  // поворот к спине для ягодиц
  const turn = pr(t, T.butt - 0.6, T.butt, easeIO) * (1 - pr(t, T.folds - 0.7, T.folds - 0.1, easeIO));
  // камера: общий план → голова (лицо/глаза/уши) → общий
  const headK = pr(t, T.face - 0.3, T.face + 0.8, easeIO) * (1 - pr(t, T.wet - 0.5, T.wet + 0.4, easeIO));
  const camPos = lerp3([0.35, 0.3, 6.6], [1.05, 1.5, 1.45], headK);
  const camLook = lerp3([0, 0.05, 0], [0.75, 1.43, 0], headK);
  const zoneK = (z: Zone, at: number, until = T.rinse) => pr(t, at, at + 0.4) * (1 - pr(t, until, until + 0.6));
  return (
    <>
      <Cam pos={bedK > 0.5 ? [0.4, 1.6, 5.2] : camPos} look={bedK > 0.5 ? [0, -0.4, 0] : camLook} />
      <Env intensity={0.55} />
      <ambientLight intensity={0.4} />
      <directionalLight position={[3, 5, 5]} intensity={1.6} />
      <directionalLight position={[-4, 2, -3]} intensity={0.7} color="#CFE3FF" />
      {/* флакон */}
      {bottleK > 0.01 ? (
        <group position={[0.8, -1.25, 0]} rotation={[0.12, -0.6 + t * 0.35, 0]} scale={0.95 * (0.85 + 0.15 * bottleK)}>
          <Bottle3D slosh={Math.sin(t * 3)} />
        </group>
      ) : null}
      {bodyK > 0.01 && bedK < 0.5 ? (
        <group position={[0.75, 0, 0]} rotation={[0, turn * Math.PI, 0]} scale={0.95 + 0.05 * bodyK}>
          <Body3D wet={water} shirt={pr(t, T.clothes + 0.3, T.clothes + 0.8)} />
          <BodyCoat k={pr(t, T.apply + 0.2, T.apply + 1.6) * (1 - pr(t, T.rinse, T.rinse + 1.6))} />
          <ZoneGlow p={ZONES3.hip} k={zoneK('hip', T.site)} r={0.2} color="#E89A1C" />
          <ZoneGlow p={ZONES3.armL} k={zoneK('armL', T.pits)} />
          <ZoneGlow p={ZONES3.armR} k={zoneK('armR', T.pits + 0.6)} />
          <ZoneGlow p={ZONES3.navel} k={zoneK('navel', T.navel)} />
          <ZoneGlow p={ZONES3.groin} k={zoneK('groin', T.groin)} />
          <ZoneGlow p={ZONES3.buttocks} k={zoneK('buttocks', T.butt)} r={0.24} />
          <ZoneGlow p={ZONES3.foldL} k={zoneK('foldL', T.folds)} r={0.12} />
          <ZoneGlow p={ZONES3.foldR} k={zoneK('foldR', T.folds + 0.6)} r={0.12} />
          {/* голова/шея/волосы — обычный шампунь (синим) */}
          <ZoneGlow p={[0, 1.36, 0]} k={0.6 * win(t, T.face, T.wet)} r={0.27} color="#2F7DE1" />
          {/* глаза, уши: Септал скраб не должен попадать */}
          {(['eyeL', 'eyeR', 'earL', 'earR'] as Zone[]).map((z, i) => (
            <RingMark key={z} p={ZONES3[z]} k={win(t, T.eyes + i * 0.15, T.separate)} r={i < 2 ? 0.042 : 0.06} rotY={i === 2 ? -Math.PI / 2 : i === 3 ? Math.PI / 2 : 0} />
          ))}
          <Foam t={t} on={t < T.rinse + 3 ? 1 : 0} rinse={pr(t, T.rinse, T.rinse + 2.2)} zt={{apply: T.apply, site: T.site, hip: T.site, armL: T.pits, armR: T.pits + 0.6, navel: T.navel, groin: T.groin, foldL: T.folds, foldR: T.folds + 0.6}} />
          {/* отдельные губки для разных зон */}
          {t > T.separate - 0.3 && t < T.foam
            ? (['armL', 'navel', 'groin'] as Zone[]).map((z, i) => {
                const k = pr(t, T.separate + i * 0.35, T.separate + 0.9 + i * 0.35, easeIO);
                const zz = ZONES3[z];
                return (
                  <group key={z} position={lerp3([-1.6 + i * 0.4, -1.2, 1], [zz[0], zz[1], zz[2] + 0.1], k)} rotation={[0.3, 0, 0]}>
                    <Sponge3D color={['#F2C14E', '#7FC8A9', '#F49AC1'][i]} />
                  </group>
                );
              })
            : null}
          {spongeOn > 0.01 ? (
            <group position={sp3} scale={spongeOn} rotation={[0.3, 0, Math.sin(t * 9) * 0.2]}>
              <Sponge3D />
            </group>
          ) : null}
        </group>
      ) : null}
      {/* кремы, дезодорант — не наносить */}
      {(() => {
        const k = win(t, T.cream, T.eyeAcc, 0.4, 0.4);
        if (k < 0.01) return null;
        return (
          <group position={[-1.55, -0.45, 0.6]} scale={k * 0.85}>
            <group position={[-0.35, 0, 0]} rotation={[0.3, t * 0.4, 0]}><Cosmetic3D kind="jar" /></group>
            <group position={[0.35, 0.15, 0]} rotation={[0.2, -t * 0.4, 0.1]}><Cosmetic3D kind="stick" /></group>
            <group position={[0, 0.1, 0.45]}>
              <mesh><torusGeometry args={[0.62, 0.05, 12, 48]} /><meshStandardMaterial color="#E04848" emissive="#E04848" emissiveIntensity={0.5} /></mesh>
              <mesh rotation={[0, 0, Math.PI / 4]}><boxGeometry args={[1.2, 0.09, 0.05]} /><meshStandardMaterial color="#E04848" emissive="#E04848" emissiveIntensity={0.5} /></mesh>
            </group>
          </group>
        );
      })()}
      {bedK < 0.5 ? (
        <group position={[0.75, 0, 0]}>
          <ShowerHead k={Math.min(1, bodyK) * (1 - headK)} />
          <Water t={t} k={water * (1 - headK)} />
        </group>
      ) : null}
      {bedK > 0.01 ? (
        <group scale={bedK} position={[0.6, 0, 0]}>
          <BedScene t={t} t0={T.staff} />
        </group>
      ) : null}
    </>
  );
};

/* ---------- 2D-слой: список зон, день/ночь, песочные часы, предупреждения ---------- */
const ZoneList: React.FC<{t: number; T: T}> = ({t, T}) => {
  const items: [string, number][] = [
    [tr('Место операции'), T.site], [tr('Подмышки'), T.pits], [tr('Пупок'), T.navel], [tr('Паховые складки'), T.groin], [tr('Ягодицы'), T.butt], [tr('Кожные складки'), T.folds],
  ];
  return (
    <div style={VERT ? {position: 'absolute', left: 50, right: 50, top: 1215, display: 'flex', flexWrap: 'wrap', columnGap: 20, rowGap: 12, background: '#ffffffee', borderRadius: 32, padding: '22px 28px', boxShadow: '0 16px 40px rgba(20,33,61,.10)', boxSizing: 'border-box'} : {position: 'absolute', left: 120, top: 260, display: 'flex', flexDirection: 'column', gap: 16}}>
      <div style={{fontFamily: 'Rubik, sans-serif', fontSize: VERT ? 40 : 34, fontWeight: 800, color: C.green, marginBottom: 6, width: VERT ? '100%' : undefined}}>{tr('От шеи до ступней — и особенно:')}</div>
      {items.map(([n, at], i) => {
        const p = sp(t, at, 14);
        return (
          <div key={n} style={{display: 'flex', alignItems: 'center', gap: 18, opacity: t < at ? 0.28 : 1, translate: `${t < at ? 0 : (1 - p) * -20}px 0`,
            fontFamily: 'Rubik, sans-serif', fontSize: VERT ? 40 : 38, fontWeight: 700, color: C.ink, width: VERT ? 'calc(50% - 10px)' : undefined}}>
            <span style={{width: 46, height: 46, borderRadius: 23, background: t < at ? '#D9DEE6' : i === 0 ? C.amber : C.green, color: '#fff',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, scale: String(t < at ? 1 : 0.6 + 0.4 * p)}}>{t < at ? '' : '✓'}</span>
            {n}
            {i === 0 && !VERT ? <span style={{fontSize: 24, fontWeight: 500, color: C.sub}}>{tr('(пример: тазобедренный сустав)')}</span> : null}
          </div>
        );
      })}
    </div>
  );
};

const DayNight: React.FC<{t: number; at: number; morning: number}> = ({t, at, morning}) => {
  const k = pr(t, morning - 0.5, morning + 0.5, easeIO);
  const a = Math.PI * (1 - k);
  return (
    <div style={{position: 'absolute', left: VERT ? 180 : 140, top: VERT ? 400 : 280, width: 720, height: 460, scale: VERT ? '0.8' : undefined, transformOrigin: 'top center'}}>
      <svg width={720} height={460} viewBox="0 0 720 460" style={{direction: "ltr"}}>
        <path d="M 60 400 A 300 300 0 0 1 660 400" stroke="#D9DEE6" strokeWidth={6} fill="none" strokeDasharray="10 14" />
        <g transform={`translate(${360 + Math.cos(a) * 300} ${400 - Math.sin(a) * 300})`}>
          <circle r={58} fill={k < 0.5 ? '#3D4E7A' : '#FFC24A'} />
          {k < 0.5 ? <circle r={58} cx={24} cy={-18} fill="#F7F5F1" /> : null}
        </g>
        <text x={60} y={450} fontFamily="Rubik" fontWeight={800} fontSize={40} fill={C.ink} opacity={pr(t, at + 0.6, at + 1.1)}>{tr('Вечером')}</text>
        <text x={660} y={450} textAnchor="end" fontFamily="Rubik" fontWeight={800} fontSize={40} fill={C.ink} opacity={pr(t, morning, morning + 0.5)}>{tr('Утром')}</text>
      </svg>
      <div style={{position: 'absolute', left: 290, top: 150, fontFamily: 'Rubik, sans-serif', fontWeight: 800, fontSize: 120, color: C.coral, opacity: pr(t, morning + 0.8, morning + 1.3),
        scale: String(0.6 + 0.4 * sp(t, morning + 0.8, 10))}}>×2</div>
    </div>
  );
};

const vx = (x: number) => (VERT ? 70 : x);
const vy = (y: number) => (VERT ? Math.round(1240 + (y - 300) * 1.75) : y);
const vs = (z: number) => (VERT ? Math.round(z * 1.1) : z);
export const S3Shower3D: React.FC<VisualProps> = ({at}) => {
  const t = useT();
  const T: T = {
    twice: at('мойтесь им дважды'), morning: at('утром в день'), wet: at('Намочите'), apply: at('Губкой нанесите'),
    site: at('место операции'), pits: at('подмышки'), navel: at('пупок'), groin: at('паховые'), butt: at('ягодицы'), folds: at('кожные складки'),
    separate: at('Для разных'), foam: at('Сколько держать'), face: at('Сначала вымойте'), eyes: at('Не наносите средство'),
    rinse: at('Тщательно смойте'), towel: at('вытритесь'), clothes: at('Наденьте'), cream: at('После этого не'), allergy: at('аллергическая реакция'), staff: at('Если вы не можете'),
    eyeAcc: at('попал в глаза'), body: at('Мойте тело'), itch: at('зуд, сыпь'), swell: at('отекают губы'), home: at('Дома вызывайте'), noscrub: at('не выдали'),
  };
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: VERT ? -220 : 0, top: VERT ? 470 : 0}}>
        <ThreeCanvas width={VERT ? 1300 : 1920} height={VERT ? 1100 : 1080} camera={{position: [0.6, 0.35, 6.4], fov: 34}} gl={{preserveDrawingBuffer: true, antialias: true}}>
          <Scene t={t} T={T} />
        </ThreeCanvas>
      </div>
      {/* флакон: подписи */}
      <Layer show={win(t, 0.8, T.twice)}>
        <Chip t={t} at={0.8} x={vx(130)} y={vy(330)} text={tr("Септал скраб")} color={C.scrubD} size={vs(52)} />
        <Chip t={t} at={1.8} x={vx(130)} y={vy(430)} text={tr("антисептическое средство, хлоргексидин 4%")} color={C.sub} size={vs(32)} />
      </Layer>
      <Layer show={win(t, T.twice, T.face)}>
        <DayNight t={t} at={T.twice} morning={T.morning} />
      </Layer>
      <Layer show={win(t, T.face, T.wet)}>
        <Chip t={t} at={T.face + 0.3} x={vx(120)} y={vy(320)} text={tr("Сначала: волосы — шампунем")} color={C.blue} size={vs(42)} />
        <Chip t={t} at={T.face + 1.6} x={vx(120)} y={vy(400)} text={tr("лицо и наружные половые органы — обычным мылом")} color={C.sub} size={vs(32)} />
      </Layer>
      <Layer show={win(t, T.wet, T.apply)}>
        <Chip t={t} at={T.wet + 0.2} x={vx(120)} y={vy(320)} text={tr("Намочите тело водой")} color={C.blue} size={vs(44)} />
      </Layer>
      <Layer show={win(t, T.apply, T.body)}>
        <Chip t={t} at={T.apply + 0.3} x={vx(120)} y={vy(320)} text={tr("Губкой — около 25 мл, не разбавляя")} color={C.scrubD} size={vs(42)} />
        <Chip t={t} at={T.apply + 2.0} x={vx(120)} y={vy(400)} text={tr("на влажную неповреждённую кожу")} color={C.sub} size={vs(32)} />
      </Layer>
      <Layer show={win(t, T.body, T.eyes)}>
        <ZoneList t={t} T={T} />
      </Layer>
      <Layer show={win(t, T.eyes, T.separate)}>
        <Chip t={t} at={T.eyes + 0.3} x={vx(120)} y={vy(320)} text={tr("Не на половые органы, глаза, уши, слизистые")} color={C.red} size={vs(40)} icon="!" />
        <Chip t={t} at={T.eyes + 2.2} x={vx(120)} y={vy(420)} text={tr("не на открытые раны и раздражённую кожу")} color={C.red} size={vs(32)} />
      </Layer>
      <Layer show={win(t, T.separate, T.foam)}>
        <Chip t={t} at={T.separate + 0.3} x={vx(120)} y={vy(320)} text={tr("Отдельные губки")} color={C.ink} size={vs(46)} />
        <Chip t={t} at={T.separate + 1.0} x={vx(120)} y={vy(410)} text={tr("для разных частей тела")} color={C.sub} size={vs(30)} />
      </Layer>
      <Layer show={win(t, T.foam, T.rinse)}>
        <Chip t={t} at={T.foam + 0.2} x={vx(120)} y={vy(320)} text={tr("Сколько держать пену?")} color={C.ink} size={vs(46)} />
        <Chip t={t} at={T.foam + 1.4} x={vx(120)} y={vy(410)} text={tr("по инструкции вашего отделения")} color={C.blue} size={vs(34)} icon="i" />
      </Layer>
      <Layer show={win(t, T.rinse, T.clothes)}>
        <Chip t={t} at={T.rinse + 0.3} x={vx(120)} y={vy(320)} text={tr("Смыть проточной водой")} color={C.blue} size={vs(44)} />
        <Chip t={t} at={T.towel} x={vx(120)} y={vy(410)} text={tr("Вытереться чистым полотенцем")} color={C.ink} size={vs(36)} icon="✓" />
      </Layer>
      <Layer show={win(t, T.clothes, T.cream)}>
        <Chip t={t} at={T.clothes + 0.2} x={vx(120)} y={vy(320)} text={tr("Чистая одежда")} color={C.green} size={vs(44)} icon="✓" />
        <Chip t={t} at={T.clothes + 1.4} x={vx(120)} y={vy(410)} text={tr("и чистое постельное бельё")} color={C.green} size={vs(36)} icon="✓" />
      </Layer>
      <Layer show={win(t, T.cream, T.eyeAcc)}>
        <Chip t={t} at={T.cream + 0.3} x={vx(120)} y={vy(320)} text={tr("Без кремов, лосьонов, дезодоранта")} color={C.red} size={vs(42)} icon="✕" />
      </Layer>
      <Layer show={win(t, T.eyeAcc, T.allergy)}>
        <Chip t={t} at={T.eyeAcc + 0.2} x={vx(120)} y={vy(320)} text={tr("Попал в глаза — сразу промыть водой")} color={C.red} size={vs(42)} icon="!" />
        <Chip t={t} at={T.eyeAcc + 4.0} x={vx(120)} y={vy(410)} text={tr("срочно за медицинской помощью")} color={C.ink} size={vs(34)} />
        <Chip t={t} at={T.eyeAcc + 5.5} x={vx(120)} y={vy(490)} text={tr("особенно при боли, покраснении, изменении зрения")} color={C.sub} size={vs(28)} />
      </Layer>
      <Layer show={win(t, T.allergy, T.itch)}>
        <Chip t={t} at={T.allergy + 0.2} x={vx(120)} y={vy(320)} text={tr("Была аллергия на хлоргексидин?")} color={C.amber} size={vs(44)} icon="!" />
        <Chip t={t} at={T.allergy + 3.5} x={vx(120)} y={vy(410)} text={tr("не используйте и сообщите персоналу")} color={C.ink} size={vs(34)} />
      </Layer>
      <Layer show={win(t, T.itch, T.swell)}>
        <Chip t={t} at={T.itch + 0.2} x={vx(120)} y={vy(320)} text={tr("Зуд, сыпь, покраснение")} color={C.amber} size={vs(44)} icon="!" />
        <Chip t={t} at={T.itch + 2.5} x={vx(120)} y={vy(410)} text={tr("прекратить, смыть, сразу сообщить персоналу")} color={C.ink} size={vs(32)} />
      </Layer>
      <Layer show={win(t, T.swell, T.noscrub)}>
        <Chip t={t} at={T.swell + 0.2} x={vx(120)} y={vy(320)} text={tr("Отёк губ или горла, трудно дышать")} color={C.red} size={vs(42)} icon="!" />
        <Chip t={t} at={T.swell + 2.4} x={vx(120)} y={vy(410)} text={tr("немедленно позовите персонал")} color={C.red} size={vs(34)} />
        <Chip t={t} at={T.home + 0.2} x={vx(120)} y={vy(490)} text={tr("Дома — скорая помощь 101")} color={C.ink} size={vs(36)} />
      </Layer>
      <Layer show={win(t, T.noscrub, T.staff)}>
        <Chip t={t} at={T.noscrub + 0.2} x={vx(120)} y={vy(320)} text={tr("Не выдали — обычный душ с мылом")} color={C.blue} size={vs(42)} />
      </Layer>
      <Layer show={pr(t, T.staff + 0.3, T.staff + 0.8)}>
        <Chip t={t} at={T.staff + 0.5} x={vx(120)} y={vy(300)} text={tr("Не можете сами — попросите помощи")} color={C.blue} size={vs(42)} />
        <Chip t={t} at={T.staff + 1.4} x={vx(120)} y={vy(380)} text={tr("у медицинского персонала")} color={C.sub} size={vs(32)} />
      </Layer>
      {/* «Наденьте…» и «полотенце» — интерполяция для лёгкого затемнения нерабочих фаз не нужна */}
      {interpolate(0, [0, 1], [0, 1], cl) ? null : null}
    </AbsoluteFill>
  );
};
