import './fonts';
import React from 'react';
import {registerRoot, Composition} from 'remotion';
import {SCENES} from './wide/preop_data';
import {PreopSceneV} from './wide/PreopFilmV';
import {sceneFrames} from './wide/PreopFilm';
const R: React.FC = () => React.createElement(React.Fragment, null, ...SCENES.map((s) =>
  React.createElement(Composition, {key: s.id, id: `SV-${s.id}`, component: PreopSceneV as any, durationInFrames: sceneFrames(s), fps: 30, width: 1080, height: 1920, defaultProps: {id: s.id, lang: 'ru'}})));
registerRoot(R);
