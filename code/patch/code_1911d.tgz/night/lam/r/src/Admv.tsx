// «Поступление в отделение» — ролик для пациентов (9:16). Тексты AD01–AD11 ОДОБРЕНО ChatGPT 16.11 (tts-data admv.json).
// Надписи — дословные фрагменты одобренного текста на каждом языке. Тайминги — timing_admv[_lang].json.
import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Bg, FontCSS, Header, Headline, Card, Subtitle, Note, C, BODY, HEAD, ease, Word} from './kit';
import {Icon} from './Figures';
import {BedReal} from './WardArt';
import {Tube} from './Cpe';
import tRu from './timing_admv.json';
import tHe from './timing_admv_he.json';
import tAr from './timing_admv_ar.json';
import tEn from './timing_admv_en.json';

type TT = {id: string; dur: number; audio?: string; text: string; head: string; acc: string[]; label: string; sacc?: string[]}[];
const FPS = 30, PAD = 0.5;
const fr = (d: number, p: number) => Math.round(d * p);
const wordsOf = (text: string, d: number): Word[] => {
  const ws = text.split(' ');
  const tot = ws.reduce((s, w) => s + w.length + 1, 0);
  let acc = 0;
  return ws.map((w) => { const t = Math.round(6 + (acc / tot) * (d - 10)); acc += w.length + 1; return {w, t}; });
};

type Dict = {brand: string; rtl?: boolean; n: Record<string, string[]>};
const N: Record<string, Dict> = {
  ru: {
    brand: 'ОРТОПЕДИЯ · ПАЦИЕНТАМ',
    n: {
      AD01: ['медсестра и врач', 'осмотрит анестезиолог', 'могут проходить позже'],
      AD02: ['документы, медицинские выписки', 'актуальный список всех лекарств', 'покажите персоналу упаковки лекарств'],
      AD03: ['хронических заболеваниях', 'лекарствах, аллергиях', 'прежних операциях и анестезии', 'как вы передвигаетесь дома', 'электронную медицинскую карту'],
      AD04: ['рост и вес', 'От веса зависит доза некоторых лекарств', 'указать его точно'],
      AD05: ['особых потребностях', 'плохо слышите или видите', 'в особом питании', 'нужен переводчик'],
      AD06: ['идентификационный браслет', 'Не снимайте его самостоятельно', 'сообщите персоналу'],
      AD07: ['давление, пульс, температуру', 'насыщение крови кислородом', 'иногда и ночью'],
      AD08: ['мазки на CPE и VRE', 'мазок из прямой кишки', 'носительство без активной инфекции'],
      AD09: ['кнопка вызова медсестры', 'перед первым подъёмом с кровати', 'попросите показать'],
      AD10: ['туалет, душ и место с питьевой водой', 'больничную рубашку и полотенце', 'специальным средством для кожи', 'указания по еде и питью'],
      AD11: ['цель, ожидаемую пользу, основные риски и альтернативы', 'Анестезиолог обсудит анестезию', 'Подписывайте согласие только после понятных объяснений', 'о температуре, кашле, поносе, сыпи', 'Указания вашего лечащего врача важнее общих советов'],
    },
  },
  en: {
    brand: 'ORTHOPAEDICS · FOR PATIENTS',
    n: {
      AD01: ['A nurse will assess you', 'an anaesthetist will also assess you', 'Some assessments may take place later'],
      AD02: ['documents, medical reports', 'an up-to-date list of all medicines', 'show the medicine packages to staff'],
      AD03: ['medical conditions', 'medicines, allergies', 'previous operations and anaesthesia', 'how you move around at home', 'electronic medical record'],
      AD04: ['height and weight', 'The doses of some medicines depend on your weight', 'an accurate weight'],
      AD05: ['special needs', 'hearing or sight difficulties', 'special dietary needs', 'if you need an interpreter'],
      AD06: ['identification wristband', 'Do not remove it yourself', 'Tell staff'],
      AD07: ['blood pressure, pulse, temperature', 'a small sensor on your finger', 'sometimes overnight'],
      AD08: ['swabs to screen for CPE and VRE', 'a rectal swab', 'carriage without active infection'],
      AD09: ['a nurse call button', 'before getting out of bed for the first time', 'Ask staff to show you how'],
      AD10: ['toilet, shower and drinking water dispenser', 'a hospital gown and towel', 'a special skin cleanser', 'eating and drinking instructions'],
      AD11: ['purpose, expected benefits, main risks and alternatives', 'The anaesthetist will discuss anaesthesia', 'Sign consent only after clear explanations', 'fever, cough, diarrhoea, rash', "Your treating doctor's instructions take priority over general advice"],
    },
  },
  he: {
    brand: 'אורתופדיה · למטופלים', rtl: true,
    n: {
      AD01: ['אחות ורופא יבדקו את מצבכם', 'גם רופא מרדים', 'עשויים להתקיים בהמשך'],
      AD02: ['מסמכים, סיכומים רפואיים', 'רשימה מעודכנת של כל התרופות', 'הראו לצוות את אריזות התרופות'],
      AD03: ['מחלות רקע', 'תרופות, אלרגיות', 'ניתוחים והרדמות קודמים', 'הניידות שלכם בבית', 'בתיק הרפואי הממוחשב'],
      AD04: ['הגובה ואת המשקל', 'המינון של חלק מהתרופות תלוי במשקל', 'משקל מדויק'],
      AD05: ['צרכים מיוחדים', 'מתקשים בשמיעה או בראייה', 'לתזונה מיוחדת', 'בקשו מתורגמן'],
      AD06: ['צמיד זיהוי', 'אל תסירו אותו בעצמכם', 'דווחו לצוות'],
      AD07: ['לחץ הדם, הדופק, חום הגוף', 'חיישן קטן שמניחים על האצבע', 'לפעמים גם בלילה'],
      AD08: ['משטחים לבדיקת חיידקים עמידים', 'משטח מהחלחולת', 'נשאות ללא זיהום פעיל'],
      AD09: ['לחצן לקריאה לאחות', 'לפני הקימה הראשונה מהמיטה', 'בקשו מהצוות להראות לכם'],
      AD10: ['השירותים, המקלחת ומתקן מי השתייה', 'חלוק אשפוז ומגבת', 'בתכשיר מיוחד לניקוי העור', 'ההנחיות האישיות שקיבלתם לגבי אכילה ושתייה'],
      AD11: ['מטרתו, התועלת הצפויה, הסיכונים העיקריים והחלופות', 'הרופא המרדים ידון אתכם בהרדמה', 'חתמו על טופס ההסכמה רק לאחר שקיבלתם הסברים ברורים', 'חום, שיעול, שלשול, פריחה', 'הנחיות הרופא המטפל שלכם קודמות לעצות כלליות'],
    },
  },
  ar: {
    brand: 'جراحة العظام · للمرضى', rtl: true,
    n: {
      AD01: ['تستقبلكم الممرضة والطبيب', 'طبيب التخدير أيضًا', 'قد تُجرى بعض المقابلات والفحوصات لاحقًا'],
      AD02: ['الوثائق والتقارير الطبية', 'قائمة محدّثة بجميع الأدوية', 'فأروا الطاقم عبوات الأدوية'],
      AD03: ['الأمراض المزمنة', 'الأدوية والحساسية', 'العمليات والتخدير السابق', 'كيف تتحرّكون في المنزل', 'ملفكم الطبي الإلكتروني'],
      AD04: ['سيُقاس طولكم ووزنكم', 'تعتمد جرعات بعض الأدوية على الوزن', 'وزن دقيق'],
      AD05: ['احتياجاتكم الخاصة', 'صعوبات في السمع أو البصر', 'غذاء خاص', 'اطلبوا مترجمًا'],
      AD06: ['سوار تعريف', 'لا تنزعوه بأنفسكم', 'فأبلغوا الطاقم'],
      AD07: ['ضغط الدم والنبض ودرجة الحرارة', 'بمستشعر صغير يوضع على الإصبع', 'وأحيانًا خلال الليل'],
      AD08: ['المقاومة لمضادات حيوية معيّنة', 'المسحة من المستقيم', 'حمل البكتيريا دون عدوى نشطة'],
      AD09: ['زر لاستدعاء الممرضة', 'قبل النهوض من السرير للمرة الأولى', 'اطلبوا من الطاقم أن يشرح لكم'],
      AD10: ['المرحاض والدش ومكان مياه الشرب', 'ثوب المستشفى ومنشفة', 'بمستحضر خاص لتنظيف الجلد', 'بشأن الأكل والشرب'],
      AD11: ['هدفها وفوائدها المتوقعة ومخاطرها الرئيسية والبدائل الممكنة', 'سيناقش طبيب التخدير معكم التخدير', 'لا توقّعوا الموافقة إلا بعد الحصول على شرح واضح', 'الحمى أو السعال أو الإسهال أو الطفح الجلدي', 'تعليمات طبيبكم المعالج أهم من النصائح العامة'],
    },
  },
};

const NV = '#E3E7EF';
const Notes: React.FC<{y: number; items: [string, number, string?, string?][]}> = ({y, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top: y, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
    {items.map(([t, a, col, bg], i) => <div key={i} style={{opacity: ease(f, a, a + 10), transform: `translateY(${(1 - ease(f, a, a + 10)) * 14}px)`}}><Note size={30} color={col || C.acc} bg={bg || C.accL}>{t}</Note></div>)}
  </div>;
};
const Row: React.FC<{y: number; at: number; icon: string; text: string; red?: boolean}> = ({y, at, icon, text, red}) => (
  <Card x={64} y={y} w={952} at={at} style={red ? {borderLeft: `10px solid ${C.blood}`} : undefined}>
    <div style={{display: 'flex', alignItems: 'center', gap: 26}}>
      <Icon k={icon} s={64} c={red ? C.blood : C.acc} />
      <div style={{flex: 1, fontFamily: BODY, fontWeight: 700, fontSize: 34, color: C.ink, lineHeight: 1.25}}>{text}</div>
    </div>
  </Card>
);

// ——— светлые 2D-сцены ———
const Stage: React.FC<{top: number; h?: number; bg?: string; children: React.ReactNode}> = ({top, h = 600, bg = '#F4F8FC', children}) => (
  <div style={{position: 'absolute', left: 64, top, width: 952, height: h, borderRadius: 36, background: '#fff', boxShadow: '0 18px 50px rgba(20,30,50,.10)', overflow: 'hidden'}}>
    <svg width={952} height={h} viewBox={`0 0 952 ${h}`}><rect x={0} y={0} width={952} height={h} fill={bg} />{children}</svg>
  </div>
);
const SKIN = '#F1D3BC', HAIR = '#5B4636', GREY = '#B9B4AE';
// Человек по пояс: туловище, шея, голова, волосы; scrub — медицинская форма, steth — стетоскоп.
const Bust: React.FC<{x: number; y: number; s?: number; col: string; hair?: string; o?: number; steth?: boolean; cap?: boolean; flip?: boolean}> = ({x, y, s = 1, col, hair = HAIR, o = 1, steth, cap, flip}) => (
  <g transform={`translate(${x} ${y}) scale(${flip ? -s : s} ${s})`} opacity={o}>
    <path d="M-78 190 Q-80 70 0 62 Q80 70 78 190 Z" fill={col} />
    <path d="M-20 64 L0 96 L20 64 Z" fill="#fff" opacity={0.8} />
    <rect x={-14} y={36} width={28} height={30} rx={10} fill={SKIN} />
    <ellipse cx={0} cy={0} rx={40} ry={46} fill={SKIN} />
    <path d="M-42 -4 Q-44 -52 0 -52 Q44 -52 42 -4 Q30 -30 0 -28 Q-30 -30 -42 -4 Z" fill={hair} />
    {cap && <path d="M-44 -18 Q-40 -64 0 -64 Q40 -64 44 -18 Q20 -30 0 -30 Q-20 -30 -44 -18 Z" fill={col} />}
    <circle cx={-14} cy={4} r={4.5} fill="#3A3F4A" /><circle cx={14} cy={4} r={4.5} fill="#3A3F4A" />
    <path d="M-12 22 Q0 30 12 22" stroke="#B9806A" strokeWidth={4} fill="none" strokeLinecap="round" />
    {steth && <path d="M-34 70 Q-36 130 0 140 Q36 130 34 70 M0 140 v20" stroke="#3A3F4A" strokeWidth={6} fill="none" strokeLinecap="round" />}
    {steth && <circle cx={0} cy={168} r={11} fill="#8C96A3" />}
  </g>
);
const Bubble: React.FC<{x: number; y: number; o: number; w?: number; children: React.ReactNode}> = ({x, y, o, w = 150, children}) => (
  <g opacity={o} transform={`translate(${x} ${y + (1 - o) * 16})`}>
    <rect x={-w / 2} y={-55} width={w} height={110} rx={30} fill="#fff" stroke={C.line} strokeWidth={4} />
    <path d="M-14 54 L0 80 L14 54 Z" fill="#fff" stroke={C.line} strokeWidth={4} /><rect x={-18} y={48} width={36} height={10} fill="#fff" />
    {children}
  </g>
);
const Pill: React.FC<{x: number; y: number; c?: string; r?: number}> = ({x, y, c = '#F2A65A', r = 0}) => (
  <g transform={`translate(${x} ${y}) rotate(${r})`}><rect x={-28} y={-12} width={56} height={24} rx={12} fill="#fff" stroke="#C9CED6" strokeWidth={3} /><path d="M0 -12 h16 a12 12 0 0 1 0 24 h-16 Z" fill={c} /></g>
);
const Box: React.FC<{x: number; y: number; c: string; o?: number}> = ({x, y, c, o = 1}) => (
  <g opacity={o} transform={`translate(${x} ${y})`}><rect x={0} y={0} width={110} height={150} rx={10} fill="#fff" stroke="#C9CED6" strokeWidth={4} /><rect x={0} y={0} width={110} height={40} rx={10} fill={c} /><rect x={0} y={28} width={110} height={12} fill={c} /><rect x={18} y={66} width={74} height={10} rx={5} fill={C.line} /><rect x={18} y={88} width={50} height={10} rx={5} fill={C.line} /></g>
);

const Corridor: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const walk = ease(f, 0, fr(d, 0.35));
  return <Stage top={top} bg="#F3F6FA">
    <path d="M0 470 L952 470 L952 600 L0 600 Z" fill="#E4EAF1" />
    {[0, 1, 2, 3].map((i) => <rect key={i} x={40 + i * 240} y={70} width={150} height={240} rx={8} fill="#EAF1F8" stroke="#D3DEE9" strokeWidth={3} />)}
    {[0, 1, 2].map((i) => <rect key={i} x={120 + i * 300} y={20} width={140} height={14} rx={7} fill="#fff" />)}
    <g opacity={ease(f, 0, 12)}>
      <Bust x={640} y={300} col={C.teal} cap />
      <rect x={520} y={380} width={380} height={130} rx={18} fill="#fff" stroke="#C9D6E3" strokeWidth={5} />
      <rect x={520} y={380} width={380} height={26} rx={12} fill={C.tealL} />
      <rect x={760} y={330} width={110} height={70} rx={8} fill={C.navy} /><rect x={770} y={340} width={90} height={50} rx={4} fill="#BFE3F5" />
    </g>
    <g transform={`translate(${-160 + walk * 300} 0)`}>
      <Bust x={170} y={330} col="#8DA9C4" hair={GREY} s={0.95} />
      <Bust x={290} y={340} col="#E3B48F" s={0.9} />
    </g>
    <g opacity={ease(f, fr(d, 0.4), fr(d, 0.5))}><Bust x={810} y={250} s={0.8} col="#fff" steth /></g>
  </Stage>;
};
const Docs: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const a = ease(f, 0, 14), b = ease(f, fr(d, 0.35), fr(d, 0.45)), c = ease(f, fr(d, 0.7), fr(d, 0.8));
  return <Stage top={top} bg="#F7F4EE">
    <rect x={0} y={430} width={952} height={170} fill="#E8DCC8" />
    <g opacity={a} transform={`translate(90 ${110 + (1 - a) * 30})`}>
      <path d="M0 30 h110 l20 -30 h150 a14 14 0 0 1 14 14 v300 a14 14 0 0 1 -14 14 h-266 a14 14 0 0 1 -14 -14 Z" fill="#F2C46D" />
      <rect x={24} y={44} width={230} height={260} rx={8} fill="#fff" transform="rotate(-4 140 170)" />
      {[0, 1, 2, 3, 4].map((i) => <rect key={i} x={54} y={84 + i * 40} width={i % 2 ? 140 : 180} height={12} rx={6} fill={C.line} transform="rotate(-4 140 170)" />)}
    </g>
    <g opacity={b} transform={`translate(430 ${90 + (1 - b) * 30})`}>
      <rect x={0} y={0} width={210} height={290} rx={14} fill="#fff" stroke={C.line} strokeWidth={4} />
      <rect x={0} y={0} width={210} height={50} rx={14} fill={C.acc} /><rect x={0} y={30} width={210} height={20} fill={C.acc} />
      {[0, 1, 2, 3, 4].map((i) => <g key={i}><circle cx={30} cy={84 + i * 42} r={9} fill={C.teal} /><rect x={50} y={78 + i * 42} width={i % 2 ? 100 : 130} height={12} rx={6} fill={C.line} /></g>)}
    </g>
    <Box x={690} y={260} c={C.teal} o={c} /><Box x={790} y={300} c="#E59A9A" o={c} />
    <g opacity={c}><Pill x={720} y={480} r={-20} /><Pill x={800} y={500} c="#7FB8E0" r={15} /><Pill x={660} y={510} c="#9BD39B" /></g>
  </Stage>;
};
const Scale: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const kg = Math.round(78 * ease(f, fr(d, 0.15), fr(d, 0.4)));
  const dose = ease(f, fr(d, 0.5), fr(d, 0.62));
  return <Stage top={top}>
    <rect x={0} y={500} width={952} height={100} fill="#E4EAF1" />
    <g opacity={ease(f, 0, 12)}>
      <rect x={110} y={40} width={16} height={460} rx={8} fill="#9FB4C8" />
      {Array.from({length: 18}, (_, i) => <line key={i} x1={126} y1={60 + i * 24} x2={i % 5 ? 140 : 152} y2={60 + i * 24} stroke="#9FB4C8" strokeWidth={3} />)}
      <rect x={110} y={88} width={120} height={14} rx={7} fill={C.navy} />
      <path d="M180 300 Q180 150 250 140 Q320 150 320 300 Z" fill="#8DA9C4" /><ellipse cx={250} cy={96} rx={36} ry={42} fill={SKIN} />
      <path d="M214 92 Q212 50 250 50 Q288 50 286 92 Q270 70 250 72 Q230 70 214 92 Z" fill={GREY} />
      <rect x={196} y={300} width={44} height={180} rx={18} fill="#5D6F86" /><rect x={260} y={300} width={44} height={180} rx={18} fill="#5D6F86" />
      <rect x={150} y={480} width={200} height={34} rx={14} fill="#fff" stroke="#9FB4C8" strokeWidth={4} />
      <rect x={205} y={486} width={90} height={22} rx={6} fill="#1E2A3A" />
      <text x={250} y={504} textAnchor="middle" fontFamily={HEAD} fontWeight={800} fontSize={20} fill="#7FE0C8" direction="ltr">{kg} kg</text>
    </g>
    <g opacity={dose} transform="translate(470 120)">
      <rect x={0} y={0} width={380} height={300} rx={30} fill="#fff" stroke={C.line} strokeWidth={4} />
      <g transform="translate(110 150)"><path d="M-70 60 h140 l-20 -100 h-100 Z" fill={C.tealL} stroke={C.teal} strokeWidth={6} /><circle cx={0} cy={-58} r={18} fill={C.teal} /></g>
      <path d="M200 150 h40" stroke={C.mute} strokeWidth={6} strokeLinecap="round" /><path d="M232 138 l14 12 l-14 12" stroke={C.mute} strokeWidth={6} fill="none" strokeLinecap="round" />
      <g transform="translate(300 150)"><Pill x={0} y={-30} /><Pill x={0} y={10} c="#7FB8E0" /></g>
    </g>
  </Stage>;
};
const Needs: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const o = (p: number) => ease(f, fr(d, p), fr(d, p + 0.08));
  return <Stage top={top} bg="#F6F3FA">
    <rect x={0} y={480} width={952} height={120} fill="#ECE6F3" />
    <g opacity={ease(f, 0, 12)}>
      <Bust x={280} y={340} col="#B49AD6" hair={GREY} s={1.1} />
      <Bust x={680} y={340} col={C.teal} cap s={1.1} flip />
    </g>
    <Bubble x={180} y={120} o={o(0.25)}><path d="M-22 -10 a22 26 0 1 1 30 22 q-10 6 -8 18" stroke={C.navy} strokeWidth={8} fill="none" strokeLinecap="round" /><circle cx={0} cy={-6} r={6} fill={C.navy} /></Bubble>
    <Bubble x={380} y={90} o={o(0.35)}><circle cx={-26} cy={0} r={20} fill="none" stroke={C.navy} strokeWidth={7} /><circle cx={26} cy={0} r={20} fill="none" stroke={C.navy} strokeWidth={7} /><path d="M-6 0 h12" stroke={C.navy} strokeWidth={7} /></Bubble>
    <Bubble x={570} y={110} o={o(0.55)}><circle cx={-14} cy={4} r={26} fill="#fff" stroke={C.teal} strokeWidth={6} /><path d="M-30 4 h32" stroke={C.teal} strokeWidth={5} /><path d="M18 -20 v44 M30 -20 v14 q0 10 -12 10" stroke={C.teal} strokeWidth={6} fill="none" strokeLinecap="round" /></Bubble>
    <Bubble x={780} y={150} o={o(0.78)} w={170}><text x={-50} y={16} textAnchor="middle" fontFamily={HEAD} fontWeight={800} fontSize={44} fill={C.acc} direction="ltr">A</text><path d="M-24 -6 h46 m-10 -10 l10 10 l-10 10 M22 10 h-46 m10 -10 l-10 10 l10 10" stroke={C.mute} strokeWidth={4} fill="none" strokeLinecap="round" transform="translate(0 2)" /><text x={50} y={16} textAnchor="middle" fontFamily={BODY} fontWeight={800} fontSize={48} fill={C.teal} direction="rtl">א</text></Bubble>
  </Stage>;
};
const Band: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const close = ease(f, fr(d, 0.1), fr(d, 0.3));
  return <Stage top={top} bg="#F4F8FC">
    <g opacity={ease(f, 0, 12)}>
      <path d="M-20 360 C 200 330 420 330 560 340 L 700 300 Q 760 280 820 300 L 900 330 Q 930 360 900 390 L 820 420 Q 760 440 700 420 L 560 400 C 420 410 200 420 -20 430 Z" fill={SKIN} stroke="#D9B193" strokeWidth={4} />
      <rect x={430} y={300 - (1 - close) * 60} width={110} height={150} rx={22} fill="#fff" stroke="#C9D6E3" strokeWidth={5} />
      <rect x={445} y={322 - (1 - close) * 60} width={80} height={56} rx={6} fill="#F4F8FC" />
      {Array.from({length: 10}, (_, i) => <rect key={i} x={451 + i * 7} y={330 - (1 - close) * 60} width={i % 3 ? 3 : 5} height={40} fill={C.navy} />)}
      <rect x={445} y={392 - (1 - close) * 60} width={70} height={10} rx={5} fill={C.line} /><rect x={445} y={410 - (1 - close) * 60} width={50} height={10} rx={5} fill={C.line} />
    </g>
    <g opacity={ease(f, fr(d, 0.35), fr(d, 0.45))} transform="translate(200 150)">
      <path d="M-50 -40 Q-10 -80 30 -60 L40 -10" stroke="#D9B193" strokeWidth={22} fill="none" strokeLinecap="round" />
      <circle cx={0} cy={0} r={70} fill="none" stroke={C.blood} strokeWidth={10} /><line x1={-50} y1={-50} x2={50} y2={50} stroke={C.blood} strokeWidth={10} />
    </g>
    <g opacity={ease(f, fr(d, 0.7), fr(d, 0.8))} transform="translate(760 140)">
      <rect x={-90} y={-50} width={180} height={100} rx={26} fill={C.accL} stroke={C.acc} strokeWidth={4} />
      <text x={0} y={22} textAnchor="middle" fontFamily={HEAD} fontWeight={800} fontSize={64} fill={C.acc}>!</text>
    </g>
  </Stage>;
};
const Vitals: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const night = ease(f, fr(d, 0.72), fr(d, 0.82));
  const rows: [string, string, string][] = [['BP', '128/76', C.acc], ['HR', '72', C.green], ['T', '36.8°', '#F2A65A'], ['SpO₂', '97%', '#7FB8E0']];
  const beat = (x: number) => { const p = (x + f * 4) % 120; return p < 50 ? 0 : p < 56 ? -30 : p < 62 ? 26 : p < 66 ? -8 : 0; };
  return <Stage top={top} bg={night > 0.5 ? '#EAF0F8' : '#F4F8FC'}>
    <rect x={0} y={0} width={952} height={600} fill="#2B3A55" opacity={night * 0.25} />
    <g transform="translate(70 70)" opacity={ease(f, 0, 12)}>
      <rect x={0} y={0} width={520} height={400} rx={28} fill="#1E2A3A" />
      <path d={Array.from({length: 61}, (_, i) => `${i ? 'L' : 'M'}${30 + i * 7.5} ${90 + beat(i * 2)}`).join(' ')} stroke={C.green} strokeWidth={4} fill="none" />
      {rows.map(([k, v, c], i) => <g key={k} opacity={ease(f, fr(d, 0.05 + i * 0.08), fr(d, 0.1 + i * 0.08))}>
        <text x={40} y={190 + i * 60} fontFamily={HEAD} fontWeight={700} fontSize={30} fill="#9FB4C8" direction="ltr">{k}</text>
        <text x={480} y={190 + i * 60} textAnchor="end" fontFamily={HEAD} fontWeight={800} fontSize={44} fill={c} direction="ltr">{v}</text>
      </g>)}
    </g>
    <g transform="translate(620 300)" opacity={ease(f, fr(d, 0.38), fr(d, 0.48))}>
      <path d="M0 40 L180 40 Q230 40 230 70 Q230 100 180 100 L0 100 Z" fill={SKIN} stroke="#D9B193" strokeWidth={4} />
      <rect x={110} y={24} width={110} height={92} rx={30} fill="#7FB8E0" stroke="#4C88B8" strokeWidth={4} />
      <circle cx={140} cy={50} r={8} fill={C.blood} opacity={(Math.floor(f / 10) % 2) ? 1 : 0.3} />
    </g>
    <g opacity={night} transform="translate(800 120)"><path d="M30 -50 A60 60 0 1 0 30 70 A46 46 0 1 1 30 -50 Z" fill="#F2D27A" /></g>
  </Stage>;
};
const Swab: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const room = ease(f, fr(d, 0.6), fr(d, 0.7));
  return <Stage top={top}>
    <g opacity={ease(f, 0, 12) * (1 - room * 0.6)}><Tube x={240} y={170} s={1.3} /></g>
    <g opacity={ease(f, fr(d, 0.15), fr(d, 0.25)) * (1 - room * 0.6)} transform="translate(420 160)">
      <rect x={0} y={0} width={240} height={300} rx={20} fill="#fff" stroke={C.line} strokeWidth={4} />
      <rect x={20} y={20} width={200} height={50} rx={10} fill={C.tealL} />
      <text x={120} y={56} textAnchor="middle" fontFamily={HEAD} fontWeight={800} fontSize={34} fill={C.teal} direction="ltr">CPE · VRE</text>
      <line x1={120} y1={100} x2={120} y2={240} stroke="#C9A77A" strokeWidth={7} strokeLinecap="round" /><ellipse cx={120} cy={250} rx={13} ry={20} fill="#F4F1EA" stroke="#D8D0C0" strokeWidth={3} />
    </g>
    <g opacity={room} transform="translate(560 230)">
      <rect x={0} y={0} width={320} height={300} rx={14} fill="#EDE3D3" stroke="#C9B79A" strokeWidth={5} />
      <rect x={270} y={150} width={34} height={12} rx={6} fill="#8C96A3" />
      <g transform="translate(160 100)"><rect x={-70} y={-50} width={140} height={100} rx={14} fill="#fff" stroke={C.teal} strokeWidth={6} /><path d="M-30 0 L-8 22 L34 -22" stroke={C.green} strokeWidth={9} fill="none" strokeLinecap="round" /></g>
    </g>
  </Stage>;
};
const Bath: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const o = (p: number) => ease(f, fr(d, p), fr(d, p + 0.08));
  const drops = Array.from({length: 7}, (_, i) => ((f * 3 + i * 19) % 80));
  return <Stage top={top} bg="#F2F7FA">
    <rect x={0} y={470} width={952} height={130} fill="#DCE8EF" />
    {Array.from({length: 12}, (_, i) => <line key={i} x1={i * 80} y1={0} x2={i * 80} y2={470} stroke="#E4EEF3" strokeWidth={3} />)}
    <g opacity={o(0)}>
      <rect x={60} y={330} width={60} height={110} rx={10} fill="#fff" stroke="#9FB4C8" strokeWidth={4} />
      <path d="M50 330 h160 q0 70 -70 80 h-30 q-60 -10 -60 -80 Z" fill="#fff" stroke="#9FB4C8" strokeWidth={4} />
      <path d="M100 410 h60 v60 h-60 Z" fill="#fff" stroke="#9FB4C8" strokeWidth={4} />
      <path d="M230 260 h60 v120" stroke="#9FB4C8" strokeWidth={10} fill="none" strokeLinecap="round" />
    </g>
    <g opacity={o(0.1)}>
      <path d="M380 80 v60 q0 20 30 20 h50" stroke="#8C96A3" strokeWidth={12} fill="none" strokeLinecap="round" />
      <ellipse cx={470} cy={170} rx={40} ry={14} fill="#8C96A3" />
      {drops.map((y, i) => <circle key={i} cx={445 + (i % 4) * 16} cy={190 + y * 3} r={5} fill="#7FC4EE" opacity={0.85} />)}
      <rect x={520} y={330} width={110} height={18} rx={9} fill="#9FB4C8" /><rect x={530} y={348} width={12} height={80} fill="#9FB4C8" /><rect x={606} y={348} width={12} height={80} fill="#9FB4C8" />
    </g>
    <g opacity={o(0.22)} transform="translate(720 90)">
      <rect x={30} y={0} width={110} height={120} rx={30} fill="#CFE9F7" stroke="#7FB8E0" strokeWidth={4} />
      <rect x={0} y={120} width={170} height={250} rx={16} fill="#fff" stroke="#9FB4C8" strokeWidth={4} />
      <rect x={40} y={170} width={90} height={60} rx={10} fill="#EAF4FB" /><rect x={70} y={220} width={30} height={20} rx={4} fill="#4C88B8" />
    </g>
    <g opacity={o(0.4)} transform="translate(360 470)">
      <rect x={0} y={0} width={190} height={70} rx={12} fill="#BFD9EE" stroke="#86AFCF" strokeWidth={4} />
      <rect x={210} y={14} width={150} height={56} rx={12} fill="#fff" stroke="#C9D6E3" strokeWidth={4} /><rect x={210} y={36} width={150} height={8} fill={C.tealL} />
    </g>
    <g opacity={o(0.62)} transform="translate(840 500)"><rect x={-26} y={-60} width={52} height={90} rx={12} fill="#E9F7F5" stroke={C.teal} strokeWidth={5} /><rect x={-10} y={-80} width={20} height={22} fill={C.teal} /></g>
  </Stage>;
};

const scene = (id: string, d: number, L: Dict) => {
  const n = L.n[id];
  const t = (p: number) => fr(d, p);
  switch (id) {
    case 'AD01': return <><Corridor top={440} d={d} /><Notes y={1080} items={[[n[0], t(0.15), C.navy, NV], [n[1], t(0.45), C.teal, C.tealL], [n[2], t(0.75)]]} /></>;
    case 'AD02': return <><Docs top={440} d={d} /><Notes y={1080} items={[[n[0], t(0.08), C.navy, NV], [n[1], t(0.35), C.teal, C.tealL], [n[2], t(0.72)]]} /></>;
    case 'AD03': return <>{n.map((x, i) => <Row key={i} y={470 + i * 170} at={t(0.06 + i * 0.16)} icon={['heart', 'pills', 'wound', 'leg', 'check'][i]} text={x} />)}</>;
    case 'AD04': return <><Scale top={440} d={d} /><Notes y={1080} items={[[n[0], t(0.08), C.navy, NV], [n[1], t(0.45), C.teal, C.tealL], [n[2], t(0.8)]]} /></>;
    case 'AD05': return <><Needs top={440} d={d} /><Notes y={1080} items={[[n[0], t(0.06), C.navy, NV], [n[1], t(0.3)], [n[2], t(0.55), C.teal, C.tealL], [n[3], t(0.8)]]} /></>;
    case 'AD06': return <><Band top={440} d={d} /><Notes y={1080} items={[[n[0], t(0.08), C.navy, NV], [n[1], t(0.38), C.blood, C.bloodL], [n[2], t(0.72), C.teal, C.tealL]]} /></>;
    case 'AD07': return <><Vitals top={440} d={d} /><Notes y={1080} items={[[n[0], t(0.06), C.navy, NV], [n[1], t(0.42), C.teal, C.tealL], [n[2], t(0.75)]]} /></>;
    case 'AD08': return <><Swab top={440} d={d} /><Notes y={1080} items={[[n[0], t(0.08), C.navy, NV], [n[1], t(0.35)], [n[2], t(0.65), C.teal, C.tealL]]} /></>;
    case 'AD09': return <><BedReal top={440} d={d} bell patient /><Notes y={1000} items={[[n[0], t(0.06), C.navy, NV], [n[1], t(0.35), C.blood, C.bloodL], [n[2], t(0.7), C.teal, C.tealL]]} /></>;
    case 'AD10': return <><Bath top={440} d={d} /><Notes y={1080} items={[[n[0], t(0.06), C.navy, NV], [n[1], t(0.3)], [n[2], t(0.5), C.teal, C.tealL], [n[3], t(0.75), C.blood, C.bloodL]]} /></>;
    case 'AD11': return <>
      <Row y={460} at={t(0.04)} icon="check" text={n[0]} />
      <Row y={660} at={t(0.28)} icon="head" text={n[1]} />
      <Row y={840} at={t(0.4)} icon="check" text={n[2]} />
      <Row y={1040} at={t(0.58)} icon="therm" text={n[3]} red />
      <Card x={64} y={1220} w={952} at={t(0.85)} style={{borderTop: `8px solid ${C.teal}`, textAlign: 'center'}}>
        <div style={{fontFamily: HEAD, fontWeight: 800, fontSize: 38, color: C.ink}}>{n[4]}</div>
      </Card>
    </>;
  }
  return null;
};

export const mkAdmv = (lang: string, timing: unknown) => {
  const TT = timing as TT;
  const L = N[lang];
  const total = () => TT.reduce((s, x) => s + Math.round((x.dur + PAD) * FPS), 0);
  const Comp: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
    let at = 0;
    return <AbsoluteFill style={{direction: L.rtl ? 'rtl' : 'ltr'}}>
      <FontCSS /><Bg />
      {TT.map((x, i) => {
        const d = Math.round((x.dur + PAD) * FPS), from = at; at += d;
        return <Sequence key={x.id} from={from} durationInFrames={d + (i < TT.length - 1 ? 10 : 0)}>
          <Fade d={d} last={i === TT.length - 1}>
            <Header brand={L.brand} n={i + 1} total={TT.length} label={x.label} />
            <Headline text={x.head} acc={x.acc} at={0} />
            {scene(x.id, d, L)}
            <Subtitle words={wordsOf(x.text, Math.round(x.dur * FPS))} acc={x.sacc || x.acc} />
          </Fade>
          {withAudio && x.audio && <Sequence from={4}><Audio src={staticFile(`aud/${x.audio}`)} /></Sequence>}
        </Sequence>;
      })}
    </AbsoluteFill>;
  };
  return {Comp, total};
};
const Fade: React.FC<{d: number; last?: boolean; children: React.ReactNode}> = ({d, last, children}) => {
  const f = useCurrentFrame();
  const i = ease(f, 0, 10), o = last ? 1 : 1 - ease(f, d - 2, d + 10);
  const v = Math.min(i, o);
  return <AbsoluteFill style={{opacity: v, filter: `blur(${(1 - v) * 8}px)`}}>{children}</AbsoluteFill>;
};
const ru = mkAdmv('ru', tRu); export const Admv = ru.Comp; export const totalAdmv = ru.total;
const he = mkAdmv('he', tHe); export const AdmvHe = he.Comp; export const totalAdmvHe = he.total;
const ar = mkAdmv('ar', tAr); export const AdmvAr = ar.Comp; export const totalAdmvAr = ar.total;
const en = mkAdmv('en', tEn); export const AdmvEn = en.Comp; export const totalAdmvEn = en.total;
export {Stage, Bust, Bubble, Pill, Box, Fade, NV, SKIN, HAIR, GREY};
