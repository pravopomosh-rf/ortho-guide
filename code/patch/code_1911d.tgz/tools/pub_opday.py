# pub_opday.py LANG... — opday: в section#day_L всех операций (видео сверху), в preop.html .vfirst, карточка в *-path.html после admv
import sys,re,glob,shutil,subprocess
R='/home/claude/ortho-guide/'
T={'ru':'День операции: что будет происходить','he':'יום הניתוח: מה צפוי לקרות','ar':'يوم العملية: ماذا سيحدث','en':'Day of surgery: what to expect'}
for L in sys.argv[1:]:
    t=T[L]
    item=(f'<div class="vitem"><div class="vlabel"><span class="vplay" aria-hidden="true"></span><span>{t}</span></div>'
          f'<video class="vid v9" width="1080" height="1920" style="aspect-ratio:1080/1920" controls preload="none" playsinline '
          f'poster="../video/c/opday_{L}.jpg" src="../video/opday_{L}.mp4"></video></div>')
    n=0
    for p in sorted(glob.glob(R+'ops/*.html')):
        s=open(p,encoding='utf8').read(); o=s
        m=re.search(r'(<section id="day_'+L+r'"><h2>[^<]*</h2>)',s)
        if m and f'opday_{L}.mp4' not in s[m.end():m.end()+800]:
            s=s[:m.end()]+item+s[m.end():]
        if p.endswith('-path.html'):
            m=re.search(r'<a class="pc vd" href="admission.html#lang='+L+r'">.*?</a>',s)
            if m and f'opday_{L}.jpg' not in s:
                chip=re.search(r'<span class="chip v">[^<]*</span>',m.group(0)).group(0)
                card=(f'<a class="pc vd" href="preop.html#lang={L}"><span class="th"><img loading="lazy" decoding="async" src="../video/t/opday_{L}.jpg" width="800" height="600" alt=""></span>'
                      f'<span class="pt">{t}</span>{chip}</a>')
                s=s[:m.end()]+card+s[m.end():]
        if s!=o: open(p,'w',encoding='utf8').write(s); n+=1
    print(L,'pages',n)
    subprocess.run(['python3','/home/claude/tools/addvitem.py','ops/preop.html','opday',L,t])
