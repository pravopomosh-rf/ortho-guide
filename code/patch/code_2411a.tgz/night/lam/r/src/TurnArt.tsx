// Рисунки для ролика «Пролежни: чем помочь» (turn). Только иллюстрации, без медицинского текста.
import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C, ease, BODY} from './kit';

const fr = (d: number, p: number) => Math.round(d * p);

// Тело на кровати, точки давления загораются по очереди (как в Press, подписи — из Press_<lang>)
export const PressureBody: React.FC<{top: number; d: number; labels: string[]}> = ({top, d, labels}) => {
  const f = useCurrentFrame();
  const xs: [number, number][] = [[150, 150], [300, 165], [470, 175], [560, 165], [700, 150], [900, 170]];
  const squeeze = 0.5 + 0.5 * Math.sin(f / 9);
  return <svg width={1080} height={360} style={{position: 'absolute', left: 0, top, direction: 'ltr', overflow: 'visible'}}>
    <rect x={60} y={200} width={960} height={44} rx={16} fill="#C9CED6" />
    <rect x={60} y={244} width={960} height={70} rx={16} fill="#E3E7EF" />
    <path d="M 110 160 Q 110 120 160 120 Q 210 120 210 160 L 600 150 Q 640 140 680 150 L 940 160 Q 960 170 940 195 L 140 200 Q 110 195 110 160 Z" fill="#E9C3A4" stroke="#C99B7A" strokeWidth={4} />
    {xs.map(([x, y], i) => {
      const a = fr(d, 0.12 + i * 0.07), o = ease(f, a, a + 10);
      return <g key={i} opacity={o}>
        <circle cx={x} cy={y + 22} r={18 + squeeze * 8} fill={C.acc} opacity={0.35} />
        <circle cx={x} cy={y + 22} r={14} fill={C.acc} opacity={0.85} />
        <text x={x} y={y - 26 - (i % 2) * 46} textAnchor="middle" fontFamily="'Body'" fontWeight={700} fontSize={27} fill={C.ink}>{labels[i]}</text>
      </g>;
    })}
    {/* стрелки смены положения */}
    <g opacity={ease(f, fr(d, 0.72), fr(d, 0.82))} transform={`translate(540 ${330 + Math.sin(f / 8) * 4})`}>
      <path d="M -120 0 Q 0 40 120 0" stroke={C.teal} strokeWidth={8} fill="none" strokeLinecap="round" />
      <path d="M 120 0 l -26 -6 M 120 0 l -14 22" stroke={C.teal} strokeWidth={8} strokeLinecap="round" />
    </g>
  </svg>;
};

// Не тянуть по простыне: человек на простыне, стрелка «тянуть» перечёркнута; затем скользящая простыня
export const SheetDrag: React.FC<{top: number; d: number}> = ({top, d}) => {
  const f = useCurrentFrame();
  const x1 = ease(f, fr(d, 0.04), fr(d, 0.2)), no = ease(f, fr(d, 0.18), fr(d, 0.26));
  const ok = ease(f, fr(d, 0.3), fr(d, 0.42));
  const shift = (ok > 0 ? Math.sin(f / 18) * 18 * ok : 0);
  return <svg width={952} height={300} style={{position: 'absolute', left: 64, top, direction: 'ltr'}}>
    <rect width={952} height={300} rx={28} fill="#fff" />
    <rect x={40} y={190} width={872} height={36} rx={12} fill="#C9CED6" />
    {/* складки исчезают на ровной простыне */}
    <g opacity={1 - ok}>{[180, 420, 690].map((x) => <path key={x} d={`M ${x} 188 q 20 -14 40 0 q 20 14 40 0`} stroke="#9AA3AF" strokeWidth={4} fill="none" />)}</g>
    <rect x={60} y={176} width={832} height={14} rx={6} fill={ok > 0.5 ? C.tealL : '#F1F3F6'} stroke={ok > 0.5 ? C.teal : '#D5D9E0'} strokeWidth={3} />
    <g transform={`translate(${shift} 0)`}>
      <path d="M 120 140 Q 120 100 165 100 Q 210 100 210 140 L 560 132 Q 600 124 640 132 L 820 140 Q 840 150 820 172 L 140 176 Q 120 172 120 140 Z" fill="#E9C3A4" stroke="#C99B7A" strokeWidth={4} />
    </g>
    {/* «тянуть» — перечёркнуто */}
    <g opacity={x1 * (1 - ok)}>
      <path d="M 300 60 L 640 60" stroke={C.blood} strokeWidth={10} strokeLinecap="round" />
      <path d="M 640 60 l -30 -20 M 640 60 l -30 20" stroke={C.blood} strokeWidth={10} strokeLinecap="round" />
      <g opacity={no}><path d="M 430 20 L 510 100 M 510 20 L 430 100" stroke={C.blood} strokeWidth={14} strokeLinecap="round" /></g>
    </g>
    {/* руки персонала по обе стороны */}
    <g opacity={ok}>
      <circle cx={40} cy={150} r={26} fill="#7FA7C9" /><circle cx={912} cy={150} r={26} fill="#7FA7C9" />
      <path d="M 860 60 Q 900 40 930 80" stroke={C.green} strokeWidth={8} fill="none" strokeLinecap="round" />
    </g>
  </svg>;
};

// Белок: шесть карточек с рисунками продуктов
const FoodPic: React.FC<{k: number}> = ({k}) => {
  switch (k) {
    case 0: return <><ellipse cx={40} cy={44} rx={22} ry={28} fill="#FFF7E8" stroke="#E2C9A0" strokeWidth={4} /><ellipse cx={70} cy={50} rx={18} ry={22} fill="#FFF7E8" stroke="#E2C9A0" strokeWidth={4} /></>;
    case 1: return <><path d="M 34 22 L 66 22 L 74 36 L 74 82 L 26 82 L 26 36 Z" fill="#F3F7FC" stroke="#7FA7C9" strokeWidth={4} /><rect x={30} y={46} width={40} height={18} fill="#BFD6EA" /></>;
    case 2: return <><path d="M 14 50 Q 44 18 76 50 Q 44 82 14 50 Z" fill="#9CC7DE" stroke="#5E93B3" strokeWidth={4} /><path d="M 76 50 L 92 34 L 92 66 Z" fill="#9CC7DE" stroke="#5E93B3" strokeWidth={4} /><circle cx={30} cy={46} r={4} fill="#1B2333" /></>;
    case 3: return <><path d="M 18 40 Q 30 16 64 22 Q 92 30 82 60 Q 70 84 38 78 Q 10 70 18 40 Z" fill="#D98C7A" stroke="#A85A48" strokeWidth={4} /><path d="M 34 52 Q 50 44 66 52" stroke="#F4D7CF" strokeWidth={6} fill="none" strokeLinecap="round" /></>;
    case 4: return <><path d="M 30 26 Q 60 14 72 40 Q 80 62 58 68 L 46 80 Q 40 86 34 80 L 38 64 Q 18 52 30 26 Z" fill="#E7B36A" stroke="#B9813A" strokeWidth={4} /><rect x={30} y={78} width={12} height={10} rx={4} fill="#F7EFE2" /></>;
    default: return <>{[[30, 40], [52, 34], [70, 50], [40, 62], [62, 70]].map(([x, y], i) => <ellipse key={i} cx={x} cy={y} rx={11} ry={8} fill="#C0874F" stroke="#8C5A2B" strokeWidth={3} transform={`rotate(${i * 30} ${x} ${y})`} />)}</>;
  }
};
export const FoodGrid: React.FC<{top: number; d: number; items: string[]; rtl?: boolean}> = ({top, d, items}) => {
  const f = useCurrentFrame();
  return <div style={{position: 'absolute', left: 64, right: 64, top, display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 18}}>
    {items.map((t, i) => {
      const a = fr(d, 0.3 + i * 0.05), p = ease(f, a, a + 10);
      return <div key={i} style={{opacity: p, transform: `translateY(${(1 - p) * 20}px) scale(${0.94 + 0.06 * p})`, background: '#fff', borderRadius: 26, boxShadow: '0 12px 30px rgba(20,40,60,.10)', padding: '16px 10px 18px', textAlign: 'center'}}>
        <svg width={150} height={150} viewBox="0 0 100 100" style={{direction: 'ltr'}}><FoodPic k={i} /></svg>
        <div style={{fontFamily: BODY, fontWeight: 800, fontSize: 32, color: C.ink, lineHeight: 1.2}}>{t}</div>
      </div>;
    })}
  </div>;
};
